"""Save and verify a local source/evidence checkpoint without deploying code."""

import argparse
import hashlib
import json
import subprocess
import sys
import zipfile
from datetime import datetime
from pathlib import Path

OFFICIAL = Path(r"C:\Users\iannuzza\LOCAL_PROJ\Github_copilot_proj\Deterministic_Reqs_workflow")
TRIAL = Path(r"C:\Users\iannuzza\.copilot\session-state\80272f99-6494-4238-9a42-55101692cf95\files\descriptive_closure_20261026")
FILES = Path(__file__).resolve().parent
WORKSPACE = TRIAL / "workspace"
ID = "2026-10-27-main-controller-ipos-review-pass"
TAG = "main-controller-ipos-review-pass-2026-10-27"
CHECKPOINT = OFFICIAL / "local_memory" / "checkpoints" / ID
METADATA = ("chat_handoff.md", "checkpoint.md", "project_activity_log.md", "environment.md", "sync_manifest.json")
SOURCE_DIRS = (".github", "scripts", "templates", "tests")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def protected():
    baseline = json.loads((TRIAL / "baseline.json").read_text(encoding="utf-8"))
    changed = [name for name, value in baseline.items() if not (OFFICIAL / name).is_file()
               or digest(OFFICIAL / name) != value]
    if changed:
        raise RuntimeError("Protected official files changed: " + "; ".join(changed))
    return len(baseline)


def write_json(path, payload):
    path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


def eligible(path):
    return (path.is_file() and not set(path.parts) & {"__pycache__", ".pytest_cache"}
            and path.suffix not in {".pyc", ".pyo", ".sqlite", ".db", ".pdf"}
            and not path.name.startswith("~$") and not path.name.endswith(("-wal", "-shm")))


def prepare():
    target = CHECKPOINT / "before_metadata.zip"
    state = CHECKPOINT / "save_state.json"
    if target.exists() or state.exists():
        raise RuntimeError("Checkpoint metadata baseline already exists; do not overwrite")
    count = protected()
    before = {}
    with zipfile.ZipFile(target, "x", zipfile.ZIP_DEFLATED) as archive:
        for name in METADATA:
            path = OFFICIAL / "local_memory" / name
            before[name] = digest(path)
            archive.write(path, name)
        if archive.testzip() is not None:
            raise RuntimeError("Metadata backup integrity failure")
    write_json(state, {"checkpoint": ID, "official_metadata_before": before,
                      "protected_official_files": count, "before_metadata_sha256": digest(target)})
    print("Prepared metadata rollback backup; protected official files:", count)


def finish():
    state = json.loads((CHECKPOINT / "save_state.json").read_text(encoding="utf-8"))
    target = CHECKPOINT / "main_controller_ipos_review_pass_backup.zip"
    manifest_path = CHECKPOINT / "checkpoint_manifest.json"
    if target.exists() or manifest_path.exists():
        raise RuntimeError("Checkpoint archive already exists; preserve the saved checkpoint")
    if digest(CHECKPOINT / "before_metadata.zip") != state["before_metadata_sha256"]:
        raise RuntimeError("Metadata rollback archive changed")
    count = protected()
    verification = json.loads((FILES / r"ipos-section12-summary\verification.json").read_text(encoding="utf-8"))
    if (verification["generation"] != "PASS" or verification["document_contract"] != "PASS"
            or verification["focused_regressions"] != {"passed": 78, "failed": 0}):
        raise RuntimeError("Final scoped verification does not match the saved PASS")
    baseline = json.loads((FILES / r"ipos-section12-summary\baseline.json").read_text(encoding="utf-8"))
    for relative, expected in baseline["protected"].items():
        if digest(WORKSPACE / relative) != expected:
            raise RuntimeError("Protected isolated file changed: " + relative)
    entries = []
    sources = {}
    for directory in SOURCE_DIRS:
        for prefix, root in (("trial", WORKSPACE), ("baseline", TRIAL / "before")):
            for path in sorted((root / directory).rglob("*")):
                if eligible(path):
                    sources[prefix + "/" + path.relative_to(root).as_posix()] = path
    for directory in ("controller-function-coverage", "ipos-explanatory-composition",
                      "ipos-functional-openings", "ipos-section12-summary", "main-controller-final"):
        for path in sorted((FILES / directory).rglob("*")):
            if eligible(path):
                sources["session_evidence/" + path.relative_to(FILES).as_posix()] = path
    for path in FILES.glob("main-controller-*.json"):
        sources["session_evidence/" + path.name] = path
    for path in FILES.glob("main-controller-*.diff"):
        sources["session_evidence/" + path.name] = path
    pilot = WORKSPACE / r"artifacts\stage6_digital_ipos\blocks\main-controller"
    for path in sorted(pilot.rglob("*")):
        if eligible(path):
            sources["pilot/" + path.relative_to(pilot).as_posix()] = path
    for name in METADATA:
        if name != "sync_manifest.json":
            sources["memory/" + name] = OFFICIAL / "local_memory" / name
    for name in ("README.md", "restart_handoff.md"):
        sources["checkpoint/" + name] = CHECKPOINT / name
    for name in ("baseline.json", "trial_control.py", "protection_verification.json"):
        sources["protection/" + name] = TRIAL / name
    sources["checkpoint/save_main_controller_checkpoint.py"] = Path(__file__)
    sources["checkpoint/session_restart_handoff.md"] = FILES / "main-controller-ipos-review-pass-handoff.md"
    for name in ("ipos_generation_results.json",):
        sources["generation/" + name] = WORKSPACE / "artifacts" / "orchestrator" / name
    changed_sources = []
    for member, path in sources.items():
        if member.startswith("trial/"):
            relative = member.removeprefix("trial/")
            previous = TRIAL / "before" / Path(*relative.split("/"))
            if not previous.is_file() or digest(previous) != digest(path):
                changed_sources.append({"path": relative, "current_sha256": digest(path),
                    "baseline_sha256": digest(previous) if previous.is_file() else None})
    with zipfile.ZipFile(target, "x", zipfile.ZIP_DEFLATED) as archive:
        for member, path in sorted(sources.items()):
            data = path.read_bytes()
            archive.writestr(member, data)
            entries.append({"member": member, "bytes": len(data),
                            "sha256": hashlib.sha256(data).hexdigest(), "source": str(path)})
    with zipfile.ZipFile(target) as archive:
        if archive.testzip() is not None:
            raise RuntimeError("Checkpoint archive CRC failure")
        for entry in entries:
            if hashlib.sha256(archive.read(entry["member"])).hexdigest() != entry["sha256"]:
                raise RuntimeError("Checkpoint member hash mismatch: " + entry["member"])
    head = subprocess.run(["git", "-C", str(OFFICIAL), "rev-parse", "HEAD"],
                          check=True, capture_output=True, text=True).stdout.strip()
    subprocess.run(["git", "-C", str(OFFICIAL), "check-ref-format", "refs/tags/" + TAG], check=True)
    payload = {
        "checkpoint": ID, "created_at": datetime.now().astimezone().isoformat(),
        "status": "PASS_LOCAL_CHECKPOINT_VERIFIED", "user_session_acceptance": "PASS",
        "scope": "Completed isolated Main Controller IPOS; local memory/checkpoint save only.",
        "git_head": head, "suggested_tag": TAG, "tag_created": False,
        "git_commit_created": False, "git_push_performed": False,
        "official_runtime_imported": False, "official_documents_overwritten": False,
        "approvals_or_snapshot_changed": False,
        "pilot_snapshot_id": "snap-8b3673edc9cf590589b8ab39",
        "official_root": str(OFFICIAL), "trial_root": str(WORKSPACE),
        "protected_official_files_unchanged": count, "protected_trial_files_unchanged": len(baseline["protected"]),
        "before_metadata_archive": "before_metadata.zip", "before_metadata_sha256": state["before_metadata_sha256"],
        "archive": target.name, "archive_sha256": digest(target), "archive_integrity": "PASS",
        "archive_members": len(entries), "changed_source_files": changed_sources, "entries": entries,
        "final_scoped_verification": verification,
        "whole_workflow_pass_claimed": False, "implementation_readiness_claimed": False,
        "restore_warning": "Extract into a new isolated directory; do not overwrite the dirty official worktree.",
    }
    write_json(manifest_path, payload)
    subprocess.run([sys.executable, "-B", str(OFFICIAL / r"scripts\sync_repo_memory_local.py"), "--quiet"], check=True)
    payload["local_memory_sync_sha256"] = digest(OFFICIAL / r"local_memory\sync_manifest.json")
    payload["local_memory_after"] = {name: digest(OFFICIAL / "local_memory" / name) for name in METADATA}
    payload["protected_official_files_unchanged"] = protected()
    for entry in entries:
        if digest(Path(entry["source"])) != entry["sha256"]:
            raise RuntimeError("Archived source changed during save: " + entry["source"])
    write_json(manifest_path, payload)
    print(json.dumps({key: value for key, value in payload.items() if key not in {
        "entries", "final_scoped_verification", "local_memory_after"}}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("prepare", "finish"))
    {"prepare": prepare, "finish": finish}[parser.parse_args().mode]()
