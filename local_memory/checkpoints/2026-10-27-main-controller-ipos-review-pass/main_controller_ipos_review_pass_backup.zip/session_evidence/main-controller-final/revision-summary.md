# Main Controller IPOS: final isolated pilot

Snapshot: `snap-8b3673edc9cf590589b8ab39`.

## Open for review

- [Full revised Main Controller IPOS - Word](../../../80272f99-6494-4238-9a42-55101692cf95/files/descriptive_closure_20261026/workspace/artifacts/stage6_digital_ipos/blocks/main-controller/digital_ipos_main-controller.docx)
- [Revised excerpts - Word](main-controller-revised-excerpts.docx)
- [Revised excerpts - Markdown](main-controller-revised-excerpts.md)
- [Exact final-pass source diff](final-pass.diff)
- [Focused verification receipt](verification.json)

The full revised IPOS remains in the isolated trial workspace. It is not an
official publication or an overwritten official document.

## Short diff summary

- **1.1:** retained the existing concise macro-purpose unchanged.
- **1.2:** removed the four repeated inventory statements. The section now
  explains Device_FSM working-state identification, integrates Elab_FSM signal
  handling and initiation/communication responsibilities, and retains the I/O
  boundary. Initiation and communication are not described as execution.
- **1.4:** organized complete retained behavior into five groups: startup/mode
  control; PPG-related sequencing/calibration; result processing; storage
  behavior; and GSR acquisition timing. Group numbering is navigation, not an
  inferred execution order.
- Retained guard-qualified passive storage paths, including their different
  frame-averaging conditions and interface references. Preserved priorities,
  immediate reset semantics, quantities, dependencies and technical identifiers.
- Used bounded grammatical projections, including direct responsibility verbs
  and clear division wording for the 20-bit result. Source spellings
  `Avarage Circuit`, `Main Control ler`, and
  `avareges_between_equal_frames` were not silently renamed or reconciled.
- Changes are in the shared deterministic IPOS planner, existing readback
  checks, related tests and isolated IPOS presentation documentation. There is
  no project-specific function catalogue, manual prose patch or new gate.

## Verification

- **81 focused tests PASS**, including independently worded digital/analog
  fixtures and Markdown/Word mutations of actor, quantity, reset semantics,
  group identity and storage guards.
- Actual isolated Main Controller generation and the existing scoped IPOS gate
  **PASS**. The gate's 302-requirement/eight-block inventory count is not a claim
  that every block's descriptions were revalidated in this Main-only pass.
- Full-document and excerpt Markdown/Word overview parity **PASS**.
- Section 1.1 is unchanged. Source I/O and all **181 local normative requirement
  blocks** are unchanged in Markdown and Word content.
- The complete approved input, including provenance and destination bindings,
  is identical to the pre-pass input: **198 records and 216 propositions** were
  considered. No source was substituted, approved or removed to improve prose.
- Explicit same-owner instantiation evidence includes `ppg_fsm` and
  `average_block`. It does not by itself establish function semantics.
  Result formation remains passive where the source does not identify its
  executor; coordination with ADSP does not establish local execution ownership.
- All 47 captured isolated SRS/DRS/authority files are unchanged. No official
  source integration, official artifact overwrite, approval, snapshot change,
  commit, tag or push was performed.
- Final SHA256 verification also confirms all **5,595 protected official files**
  remain unchanged, including official SRS/DRS evidence and authority stores.

## Limits

This closes the requested bounded pilot revision, not general natural-language
interpretation or whole-workflow writing coverage. The broader independent
writing report remains **UNRESOLVED** with 1,381 reported findings; no full
descriptive closure, publication approval or implementation readiness is claimed.
The broader mixed suite also retains pre-existing SRS destination/context
failures, outside this Main Controller-only change.
