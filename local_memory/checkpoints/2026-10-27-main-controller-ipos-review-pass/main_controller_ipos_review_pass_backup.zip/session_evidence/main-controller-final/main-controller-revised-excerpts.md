# Main Controller IPOS - isolated revised excerpts

Review-only extraction from the deterministic generated trial; no official publication or authority change.

Snapshot: `snap-8b3673edc9cf590589b8ab39`.

### **1.1 Functionality** {#11-functionality}

The Main Controller block provides generation and reception of Analog Domain control signals, DSP elaboration on ADC outputs and writing of elaborated results to the defined addresses.

### **1.2 Supported functions and scope** {#12-supported-functions-and-scope}

Device_FSM identifies the working state of the device.

Elab_FSM identifies which signal is in elaboration and checks and generates signals from and for the Analog Domain. Elab_FSM initiates writes to the AHB Crossbar and communicates with Hardware DSP blocks such as the Avarage Circuit and ADSP, or starts PPG operation by communicating with the PPG_FSM.

The Main Controller block accepts configuration register settings, sampled data and produces control state and data routing.

### **1.4 Supported block functions** {#14-supported-block-functions}

#### **1.4.1 Startup and mode control** {#141-startup-and-mode-control}

When the wave velocity mode is selected and the device FSM is in WAIT_SU, the Elaboration FSM goes into the TIMER BUFFER State and then into the PPG ALC STORAGE. When the user selects an operative mode that includes the BIA channel, a start-up is performed.

#### **1.4.2 PPG-related sequencing and calibration** {#142-ppg-related-sequencing-and-calibration}

When in Measurement state, the PPG_FSM stays in this state until the rising of the i_end_average signal from the ADC block. When the ppg ioff calibration and the adc calibration are selected, the adc calibration is performed first. When the rstn_i is asserted low, the PPG FSM returns in Reset state immediately. When the wave velocity mode and the ppg ioff calibration are selected, the wave velocity mode is performed first. When the ppg ioff calibration is selected and device fsm is in WAIT_SU State, the Elab FSM goes into the Timer Buffer state and then PPG IOFF CALIB state.

#### **1.4.3 Result processing** {#143-result-processing}

After the last repetition has been accumulated, the data output is obtained by dividing the accumulated data by the number of repeated frames to obtain 20-bit data.

#### **1.4.4 Storage behavior** {#144-storage-behavior}

Once the Average is computed, if no averages_between_equal_frames option is selected, the data are written inside the FIFO Memory using the Main Control ler AHB Master interface. If there is avareges_between_equal_frames option selected from regmap, after the computations of this average, the obtained data is written inside the FIFO Memory using the Main Controller AHB Master interface. In Data Storage Mode, with DS_SEL=1 in Device_Config_Channel and PPG_ELAB=0 in General_Parameters_PPG, communication between Main Controller and ADSP is disabled.

#### **1.4.5 GSR acquisition timing** {#145-gsr-acquisition-timing}

The interval between two GSR acquisitions is defined in time slots.

