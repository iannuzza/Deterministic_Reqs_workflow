import csv
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

from spec_document_contract import assess_descriptive_synthesis
from csv_artifacts import csv_artifact_reader
from test_spec_document_contract import _write_docx
from workflow_routing import (
    build_ipos_functional_input,
    compose_ipos_overview,
    compose_technical_block_purpose,
)


class IPOSMainFunctionPlanningTests(unittest.TestCase):
    def test_large_audit_fields_are_complete_and_reader_limit_is_restored(self):
        previous = csv.field_size_limit()
        text = "evidence" * (previous // 4)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "audit.csv"
            with path.open("w", encoding="utf-8", newline="") as handle:
                writer = csv.DictWriter(handle, fieldnames=["source"])
                writer.writeheader()
                writer.writerow({"source": text})
            with csv_artifact_reader(path) as reader:
                self.assertEqual(list(reader), [{"source": text}])
            self.assertEqual(csv.field_size_limit(), previous)
            with self.assertRaisesRegex(RuntimeError, "test failure"):
                with csv_artifact_reader(path):
                    raise RuntimeError("test failure")
            self.assertEqual(csv.field_size_limit(), previous)

    def functional(self, statement="", *, requirements=(), function=None):
        source = {
            "record_id": "local-description",
            "statement": statement,
            "admission_state": "admitted",
            "snapshot_id": "synthetic-approved",
            "mapped_block": "Timing Engine",
            "domain": "digital",
        }
        return build_ipos_functional_input(
            "Timing Engine",
            {"Function": function or "Generate and receive channel control signals, process samples, and write results.",
             "Inputs": "sample data", "Outputs": "processed results"},
            requirements, domain="digital",
            descriptive_source_records=[source] if statement else [],
        )

    def test_complete_multiple_activities_have_one_bounded_macro_sentence(self):
        functional = self.functional()
        sections, _ = compose_ipos_overview(functional)
        self.assertEqual(len(sections["functionality"]), 1)
        purpose = sections["functionality"][0]
        self.assertLessEqual(len(purpose.split()), 45)
        self.assertIn("generation and reception of channel control signals", purpose)
        self.assertIn("processing of samples", purpose)
        self.assertIn("writing of results", purpose)
        self.assertIn("The Timing Engine block processes samples.", sections["scope"])
        self.assertEqual(compose_technical_block_purpose(
            "Timing Engine", functional.function, synthesize=True), "")

    def test_named_responsibilities_preserve_the_actor_and_initiation(self):
        functional = self.functional(
            "The first FSM called Cycle_FSM, is in charge of identify the working state of the device. "
            "The second FSM called Work_FSM, is in charge of identify the selected signal and to check inputs. "
            "The Work_FSM is also in charge to start writing to the local bus or to start "
            "conversion talking with the Converter_FSM.")
        sections, audit = compose_ipos_overview(functional)
        scope = " ".join(sections["scope"])
        self.assertIn("Cycle_FSM is responsible for identifying the working state of the device.", scope)
        self.assertIn("Work_FSM is responsible for identifying the selected signal and checking inputs", scope)
        self.assertIn("initiating writes to the local bus or starting conversion communicating with the Converter_FSM", scope)
        self.assertNotIn("executes conversion", scope)
        self.assertNotIn("Cycle_FSM", " ".join(sections["functionality"]))
        selected = [row for row in audit if row.get("source_record_id") == "source-context:local-description"
                    and row["decision"] == "selected"]
        self.assertTrue(selected)
        self.assertTrue(all("local-description" in row["provenance_references"] for row in selected))

    def test_unknown_or_qualified_responsibility_is_not_guessed(self):
        for statement in (
            "This block is in charge of control the channel.",
            "The Cycle_FSM is in charge of invent unsupported operations.",
            "The Cycle_FSM is in charge of start conversion only when the channel is ready.",
        ):
            with self.subTest(statement=statement):
                sections, audit = compose_ipos_overview(self.functional(statement))
                self.assertNotIn("responsible for", " ".join(sections["scope"]))
                self.assertTrue(any(row["decision"] in {"projection_gap", "omitted"}
                                    and row.get("source_record_id") == "source-context:local-description"
                                    for row in audit))

    def test_responsibility_grammar_reuses_irregular_action_forms(self):
        sections, _ = compose_ipos_overview(self.functional(
            "The Cycle Controller is in charge of run conversions and to set ready flags."))
        self.assertIn("Cycle Controller is responsible for running conversions and setting ready flags",
                      " ".join(sections["scope"]))

    def test_same_planner_applies_to_analog_evidence_without_a_function_catalogue(self):
        functional = build_ipos_functional_input(
            "Amplitude Core", {"Function": "Acquire samples, process data, and write results."},
            domain="analog", descriptive_source_records=[{
                "record_id": "analog-role", "statement": "The Gain Unit is in charge of control amplification.",
                "mapped_block": "Amplitude Core", "domain": "analog",
                "admission_state": "admitted", "snapshot_id": "synthetic-approved",
            }])
        sections, _ = compose_ipos_overview(functional)
        self.assertEqual(len(sections["functionality"]), 1)
        self.assertIn("Gain Unit is responsible for controlling amplification.", " ".join(sections["scope"]))
        self.assertNotIn("FSM", str(sections))

    def test_state_name_is_not_promoted_to_a_main_function(self):
        functional = self.functional(requirements=[
            {"source_req_id": "reset", "statement":
             "When reset_n is asserted low, the Converter_FSM shall return in Reset state immediately."},
        ])
        sections, _ = compose_ipos_overview(functional)
        self.assertNotIn("Converter_FSM", " ".join(sections["scope"]))
        behavior = " ".join(sections["internal_functions"])
        self.assertIn("When reset_n is asserted low", behavior)
        self.assertIn("Converter_FSM returns in Reset state immediately.", behavior)

    def test_isolated_result_variables_and_unbound_pronouns_stay_in_normative_detail(self):
        functional = self.functional(requirements=[
            {"source_req_id": "result", "statement": "Nm2 shall be the result of average on 6 samples."},
            {"source_req_id": "mask", "statement": "If the sample is masked, its contribution shall be 0."},
        ])
        sections, audit = compose_ipos_overview(functional)
        self.assertNotIn("Nm2", " ".join(sections["internal_functions"]))
        self.assertNotIn("its contribution", " ".join(sections["internal_functions"]))
        self.assertEqual(len([row for row in audit if row["decision"] == "demoted"]), 2)

    def test_partial_inventory_still_does_not_establish_a_macro_purpose(self):
        sections, audit = compose_ipos_overview(self.functional(
            function="Process samples; coordinate unspecified behavior."))
        self.assertEqual(sections["functionality"], [])
        self.assertTrue(any(row["decision"] == "projection_gap" for row in audit))

    def test_independent_markdown_and_word_readback_reject_actor_mutations(self):
        functional = self.functional(
            "The first FSM called Cycle_FSM, is in charge of identify the working state. "
            "The Work_FSM is in charge to start conversion talking with the Converter_FSM.")
        sections, _ = compose_ipos_overview(functional)
        paragraphs = []
        for key, title in (("functionality", "1.1 Functionality"),
                           ("scope", "1.2 Supported functions and scope"),
                           ("internal_functions", "1.4 Supported block functions")):
            paragraphs.extend(["# " + title, *sections[key]])
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "review.md"
            for artifact, original, changed in (
                ("", "", ""),
                ("markdown", "Cycle_FSM is responsible", "Foreign_FSM is responsible"),
                ("docx", "Cycle_FSM is responsible", "Foreign_FSM is responsible"),
                ("markdown", "starting conversion", "executing conversion"),
                ("docx", "starting conversion", "executing conversion"),
            ):
                with self.subTest(artifact=artifact, changed=changed):
                    output = [value.replace(original, changed) if artifact else value for value in paragraphs]
                    path.write_text("\n\n".join(output if artifact == "markdown" else paragraphs), encoding="utf-8")
                    _write_docx(path.with_suffix(".docx"), output if artifact == "docx" else paragraphs)
                    report = assess_descriptive_synthesis(path, "IPOS", {"functional_input": functional})
                    self.assertEqual(report["status"], "UNRESOLVED" if artifact else "PASS", report["gaps"])


if __name__ == "__main__":
    unittest.main()
