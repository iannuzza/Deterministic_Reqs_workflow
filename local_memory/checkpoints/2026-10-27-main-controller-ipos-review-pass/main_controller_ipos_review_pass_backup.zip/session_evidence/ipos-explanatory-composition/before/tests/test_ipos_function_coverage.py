import csv
import sys
import tempfile
import unittest
from dataclasses import replace
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

from test_spec_document_contract import _write_docx
from workflow_routing import (
    build_ipos_claim_plan,
    build_ipos_functional_input,
    compose_ipos_overview,
    ipos_claim_preflight_findings,
    _ipos_evidence_semantic_findings,
)
from validate_downstream_coherence import classify_descriptive_findings


class IPOSFunctionCoverageTests(unittest.TestCase):
    def functional(self, statements, owner="Measurement Unit", domain="digital"):
        return build_ipos_functional_input(
            owner, {"Function": "Control acquisitions, process samples, and write results."},
            [{"source_req_id": "REQ-" + str(index), "statement": text}
             for index, text in enumerate(statements)],
            domain=domain,
        )

    def test_technical_names_do_not_discard_complete_sampling_relationships(self):
        functional = self.functional([
            "When the Convert_Phases fsm is ready and an acquisition is required, the o_begin_sample shall stay High for i_sample_clocks+1 cycles.",
            "After an acquisition is started, the Convert_Phases shall wait for the i_conversion_done sampling the new data on the falling edge of the clock.",
            "When the last acquisition is performed, after the last i_conversion_done arrived, the Convert_Phases shall set to high the o_average_request signal for 2 clock cycles.",
        ])
        sections, _ = compose_ipos_overview(functional)
        text = " ".join(sections["scope"] + sections["internal_functions"])
        for expected in ("i_sample_clocks+1 cycles", "falling edge of the clock",
                         "last i_conversion_done", "o_average_request", "2 clock cycles"):
            self.assertIn(expected, text)
        self.assertEqual(classify_descriptive_findings(
            ipos_claim_preflight_findings(functional))["hard_findings"], [])

    def test_channel_counts_and_sequence_survive_conditional_compound_clauses(self):
        functional = self.functional([
            "When the Select_FSM is in INPUT State and only IN0 is selected, the o_converter_en shall go high, 7 acquisitions are required (acquisitions described in section 4.2).",
            "When the Select_FSM is in INPUT State and IN1 and IN2 are selected, the o_converter_en shall go high and 14 acquisitions are required and then device shall go in SLEEP.",
        ])
        sections, _ = compose_ipos_overview(functional)
        text = " ".join(sections["scope"] + sections["internal_functions"])
        for expected in ("only IN0", "7 acquisitions", "IN1 and IN2", "14 acquisitions", "SLEEP"):
            self.assertIn(expected, text)
        self.assertNotIn("shall", text)
        self.assertEqual(classify_descriptive_findings(
            ipos_claim_preflight_findings(functional))["hard_findings"], [])

    def test_cds_alternatives_preserve_separate_averages_and_subtraction(self):
        functional = self.functional([
            "If en_cds is set high [bit 2 of CHANNEL_CTRL] the ON_DATA and OFF_DATA shall be sampled 12 times, then averaged to get one single value for each of them, and then the final result shall be the subtraction between ON_DATA and OFF_DATA.",
            "If en_cds is set low, no acquisition of OFF_DATA shall be done and the result shall be the average of 12 acquisitions of ON_DATA.",
            "The mean block shall perform the average on 12 sample acquisition for IMP.",
        ])
        sections, _ = compose_ipos_overview(functional)
        text = " ".join(sections["scope"] + sections["internal_functions"])
        for expected in ("en_cds is set high", "12 times", "each of them",
                         "subtraction between ON_DATA and OFF_DATA", "en_cds is set low",
                         "no acquisition of OFF_DATA", "12 acquisitions of ON_DATA"):
            self.assertIn(expected, text)
        self.assertNotIn("shall", text)

    def test_startup_delays_and_clock_generator_ownership_are_not_rewritten(self):
        functional = self.functional([
            "At least 8ms after the falling of power_down and reset_hold, if i_injection is equal to 1, clock_enable shall be high and ck_a and ck_b shall be generated from Clock generator block.",
            "If i_restart is set to 1, the start-up phase shall restart but no clock shall stop if enabled.",
        ])
        sections, _ = compose_ipos_overview(functional)
        text = " ".join(sections["scope"] + sections["internal_functions"])
        for expected in ("At least 8ms", "i_injection is equal to 1",
                         "Clock generator block", "no clock", "if enabled"):
            self.assertIn(expected, text)
        self.assertNotIn("Measurement Unit generates", text)

    def test_unknown_or_truncated_clauses_remain_explicit_gaps(self):
        functional = self.functional([
            "When enabled, the device shall perform a new",
            "When READY is 1, the engine shall invent an unknown operation.",
        ])
        sections, audit = compose_ipos_overview(functional)
        text = " ".join(sections["scope"] + sections["internal_functions"])
        self.assertNotIn("unknown operation", text)
        self.assertTrue(any(row["decision"] in {"omitted", "projection_gap"} for row in audit))

    def test_same_record_standalone_condition_is_carried_into_timed_startup(self):
        functional = self.functional([
            "If i_delay is set to 0. At least after 180ms that reset_hold is gone low, startup_done shall go low.",
        ])
        sections, _ = compose_ipos_overview(functional)
        text = " ".join(sections["internal_functions"])
        self.assertIn("If i_delay is set to 0", text)
        self.assertIn("180ms", text)
        self.assertEqual(classify_descriptive_findings(
            ipos_claim_preflight_findings(functional))["hard_findings"], [])

    def test_source_check_rejects_changes_to_compound_quantity_guard_or_external_actor(self):
        functional = self.functional([
            "When the mode is selected, clock_enable shall be high and ck_a and ck_b shall be generated from Timing Generator block.",
            "When CH0 is selected, o_enable shall go high and 7 acquisitions are required and then device shall go in SLEEP.",
        ])
        evidence = build_ipos_claim_plan(functional).evidence
        self.assertEqual(_ipos_evidence_semantic_findings(evidence), [])
        for before, after in (("7 acquisitions", "8 acquisitions"),
                              ("Timing Generator", "Measurement Unit"), ("CH0", "CH1")):
            with self.subTest(after=after):
                changed = tuple(replace(value, meaning=replace(value.meaning,
                    objects=tuple(obj.replace(before, after) for obj in value.meaning.objects),
                    contexts=tuple(replace(context, text=context.text.replace(before, after))
                                   for context in value.meaning.contexts))) for value in evidence.propositions)
                self.assertNotEqual(changed, evidence.propositions)
                self.assertTrue(_ipos_evidence_semantic_findings(replace(evidence, propositions=changed)))

    def test_explicit_calibration_actor_and_same_record_reset_title_are_bound(self):
        functional = self.functional([
            "When the offset calibration algorithm is enabled, it shall be performed every time a new measurement cycle starts.",
            "If en_cds is set High [bit 2 of CHANNEL_CTRL], the interval shall define also when an acquisition without current injection (current_on set to 0) shall be performed.",
        ])
        sections, _ = compose_ipos_overview(functional)
        text = " ".join(sections["internal_functions"])
        self.assertIn("offset calibration algorithm is performed every time", text)
        self.assertIn("acquisition without current injection", text)
        self.assertNotIn("shall", text)
        functional = build_ipos_functional_input("Measurement Unit", {"Function": "Control acquisitions."},
            domain="digital", descriptive_source_records=[{
                "record_id": "reset", "statement": "This procedure reset all the Measurement Unit FSMs, reperforming the BOOT Phase without reset the Register Bank.",
                "admission_state": "admitted", "snapshot_id": "synthetic-approved",
                "mapped_block": "Measurement Unit", "domain": "digital",
                "section_context_json": '[["8.1", "Measurement Unit Soft Reset"]]',
            }])
        sections, _ = compose_ipos_overview(functional)
        text = " ".join(sections["internal_functions"])
        self.assertIn("without resetting the Register Bank", text)
        self.assertEqual(classify_descriptive_findings(
            ipos_claim_preflight_findings(functional))["hard_findings"], [])

    def test_alternative_retains_common_state_and_enable_conditions(self):
        functional = self.functional([
            "When DEVICE is in STARTUP, if path_enable is equal to 1 and current_enable is equal to 1, power_down shall go low. On the other hand, if current_enable is equal to 0, power_down shall remain high.",
            "When in Sleep Mode, the device shall go back to Operative if operations are ended. Furthermore, if no channel is selected and more than 170us are left, clock_disable shall be set to 1.",
        ])
        sections, _ = compose_ipos_overview(functional)
        text = " ".join(sections["internal_functions"])
        self.assertIn("When DEVICE is in STARTUP, if path_enable is equal to 1, if current_enable is equal to 0", text)
        self.assertIn("When in Sleep Mode, if no channel is selected and more than 170us", text)
        self.assertEqual(classify_descriptive_findings(
            ipos_claim_preflight_findings(functional))["hard_findings"], [])

    def test_nested_register_annotations_and_implicit_temporal_actor_are_preserved(self):
        functional = self.functional([
            "When the Select_FSM is in INPUT State, the mux (concatenation of {sel_a, sel_b} on top) output shall be set equal to 001 and after 6 acquisitions (described in section 4.2) shall be set to 010.",
            "When reference is equal to maximum (LIMIT (RAMP_CONFIG register [4:0])), rising_done shall go high.",
            "When a RAW data (valid_raw set to 1) or NOISE data is sampled (end_conversion set to 1) the data shall be accumulated until sample_limit is reached.",
            "When COMP starts, gain_value (2:0) shall be set at initial_gain (GAIN_CONFIG register [4:2]) and compensation (8:0) shall be set at 100000000.",
            "If the MASK is enabled, the result shall be only RAW data and the subtraction of the NOISE data shall not be performed.",
        ])
        sections, _ = compose_ipos_overview(functional)
        text = " ".join(sections["internal_functions"])
        for expected in ("6 acquisitions", "010", "rising_done", "sample_limit",
                         "initial_gain", "100000000", "subtraction of the NOISE data is not performed"):
            self.assertIn(expected, text)
        self.assertEqual(classify_descriptive_findings(
            ipos_claim_preflight_findings(functional))["hard_findings"], [])

    def test_postposed_state_qualifies_the_previous_assertion_not_a_new_function(self):
        functional = self.functional([
            "If IN1 and IN2 are selected, the mux_output shall be set to 011 and 100. In the INPUT state.",
        ])
        sections, _ = compose_ipos_overview(functional)
        text = " ".join(sections["internal_functions"])
        self.assertIn("When in the INPUT state, If IN1 and IN2 are selected", text)
        self.assertEqual(classify_descriptive_findings(
            ipos_claim_preflight_findings(functional))["hard_findings"], [])


if __name__ == "__main__":
    unittest.main()
