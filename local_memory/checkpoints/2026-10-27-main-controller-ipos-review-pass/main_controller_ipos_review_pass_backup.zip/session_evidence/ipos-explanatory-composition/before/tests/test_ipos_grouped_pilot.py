import csv
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

from test_spec_document_contract import _write_docx
from workflow_routing import (
    build_ipos_functional_input,
    compose_ipos_overview,
    validate_ipos_descriptive_output,
)


class GroupedIPOSPilotTests(unittest.TestCase):
    def functional(self, *, contained=True):
        descriptions = [
            "The first FSM called Cycle_FSM, is in charge of identify the working state. "
            "The second FSM called Route_FSM, is in charge of identify the selected signal. "
            "The Route_FSM is also in charge to start writing to the local bus and to talk with "
            "the external DSP, or to start sampling talking with the Wave_FSM.",
        ]
        if contained:
            descriptions.append("Instantiations \u2022 u_wave: wave_fsm \u2022 u_mean: mean_block")
        records = [{
            "record_id": "description-" + str(index), "statement": text,
            "admission_state": "admitted", "snapshot_id": "synthetic-approved",
            "mapped_block": "Signal Engine", "domain": "digital",
        } for index, text in enumerate(descriptions)]
        statements = [
            "When the user selects an operative mode that includes the bias channel, a start-up shall be done.",
            "When in Measurement state, the Wave_FSM shall stay in this state until the rising of data_done.",
            "When the wave calibration and the converter calibration are selected, the converter calibration shall be performed first.",
            "When reset_n is asserted low, the Wave_FSM shall return in Reset state immediately.",
            "After the last repetition has been accumulated, the data output shall be obtained dividing by the number of repeated frames the accumulated data to obtain a 18 bit data.",
            "The acquisition_interval shall define how many time slots pass between two AUX acquisitions.",
            "Once the reduction is computed, if no fold_between_frames option is selected, the data shall be written inside the sample memory using the host interface.",
            "If the fold_between_frames option is selected, after the reduction is computed, the obtained data shall be written inside the sample memory using the host interface.",
        ]
        return build_ipos_functional_input(
            "Signal Engine",
            {"Function": "Generate and receive channel control signals, process samples, and write results.",
             "Inputs": "samples", "Outputs": "control state"},
            [{"source_req_id": "R" + str(index), "statement": text}
             for index, text in enumerate(statements)],
            domain="digital", descriptive_source_records=records,
        )

    def materialize(self, directory, functional):
        sections, audit = compose_ipos_overview(functional)
        paragraphs = []
        for key, title in (("functionality", "1.1 Functionality"),
                           ("scope", "1.2 Supported functions and scope"),
                           ("internal_functions", "1.4 Supported block functions")):
            paragraphs.extend(["### " + title, *sections[key]])
        path = Path(directory) / "pilot.md"
        path.write_text("\n\n".join(paragraphs), encoding="utf-8")
        _write_docx(path.with_suffix(".docx"), paragraphs)
        audit_path = path.with_suffix(".csv")
        with audit_path.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=sorted({key for row in audit for key in row}))
            writer.writeheader()
            writer.writerows(audit)
        return path, audit_path, paragraphs

    def findings(self, path, audit, functional):
        return validate_ipos_descriptive_output(
            path, audit, functional.block, functional.local_requirement_evidence,
            functional.local_requirement_ids, (), functional,
        )

    def test_scope_adds_named_responsibilities_instead_of_repeating_inventory(self):
        sections, _ = compose_ipos_overview(self.functional())
        self.assertEqual(len(sections["functionality"]), 1)
        scope = " ".join(sections["scope"])
        for repeated in ("block generates channel", "block receives channel",
                         "block processes samples", "block writes results"):
            self.assertNotIn(repeated, scope)
        self.assertIn("Cycle_FSM identifies the working state.", scope)
        self.assertIn("Route_FSM identifies the selected signal.", scope)
        self.assertIn("initiates writes to the local bus", scope)
        self.assertIn("communicates with the external DSP", scope)
        self.assertNotIn("executes sampling", scope)
        self.assertEqual(sum("Route_FSM" in paragraph for paragraph in sections["scope"]), 1)

    def test_behavior_groups_preserve_all_qualifications_and_storage_alternatives(self):
        sections, _ = compose_ipos_overview(self.functional())
        behavior = "\n\n".join(sections["internal_functions"])
        headings = [text for text in sections["internal_functions"] if text.startswith("#### ")]
        self.assertGreaterEqual(len(headings), 4)
        for term in ("Configuration, lifecycle and status", "Result processing", "AUX acquisition and control",
                     "Storage behavior"):
            self.assertTrue(any(term in heading for heading in headings), headings)
        for term in ("until the rising of data_done", "performed first", "reset_n is asserted low",
                     "Reset state immediately", "last repetition", "18-bit data",
                     "number of repeated frames", "time slots", "if no fold_between_frames",
                     "If the fold_between_frames", "sample memory", "host interface"):
            self.assertIn(term, behavior)
        self.assertNotIn("obtained dividing by", behavior)
        self.assertNotIn("a start-up is done", behavior)

    def test_group_labels_do_not_invent_containment(self):
        sections, _ = compose_ipos_overview(self.functional(contained=False))
        headings = [text for text in sections["internal_functions"] if text.startswith("#### ")]
        self.assertFalse(any("Wave" in text for text in headings), headings)
        sections, _ = compose_ipos_overview(self.functional())
        headings = [text for text in sections["internal_functions"] if text.startswith("#### ")]
        self.assertTrue(any("wave" in text.casefold() for text in headings), headings)
        self.assertFalse(any("external DSP" in text for text in headings))

    def test_actual_markdown_and_word_reject_group_or_quantity_mutations(self):
        functional = self.functional()
        with tempfile.TemporaryDirectory() as directory:
            path, audit, paragraphs = self.materialize(directory, functional)
            self.assertEqual(self.findings(path, audit, functional), [])
            for artifact, before, after in (
                ("markdown", "18-bit", "19-bit"),
                ("docx", "Reset state immediately", "Reset state eventually"),
                ("markdown", "Result processing", "Firmware execution"),
                ("docx", "if no fold_between_frames", "if fold_between_frames"),
            ):
                with self.subTest(artifact=artifact, after=after):
                    changed = [value.replace(before, after) for value in paragraphs]
                    self.assertNotEqual(changed, paragraphs)
                    path.write_text("\n\n".join(changed if artifact == "markdown" else paragraphs), encoding="utf-8")
                    _write_docx(path.with_suffix(".docx"), changed if artifact == "docx" else paragraphs)
                    self.assertTrue(self.findings(path, audit, functional))


if __name__ == "__main__":
    unittest.main()
