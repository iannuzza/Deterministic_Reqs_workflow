# IPOS explanatory-composition update

Snapshot: `snap-8b3673edc9cf590589b8ab39`. Current isolated Main Controller
pilot only; shared rules apply to both digital and analog IPOS.

## Open for review

- [Full generated Main Controller IPOS - Word](../../../80272f99-6494-4238-9a42-55101692cf95/files/descriptive_closure_20261026/workspace/artifacts/stage6_digital_ipos/blocks/main-controller/digital_ipos_main-controller.docx)
- [Revised descriptive sections - Word](revised-excerpts.docx)
- [Revised descriptive sections - Markdown](revised-excerpts.md)
- [Document diff](document-update.diff)
- [Exact source, test and contract diff](source-update.diff)
- [Focused verification results](verification.json)

## Short diff summary

- Section 1.1 remains unchanged. Section 1.2 now describes responsibilities
  through evidence-supported activities rather than only naming families.
- All eleven section 1.4 groups start with an audited two- or three-sentence
  lead paragraph: a role/activity explanation and qualified source relationships.
  Unchanged relationships move into the introduction without repetition.
  When an introductory projection omits pure reference detail, the complete
  relationship remains beneath it.
- Primary relationships now take precedence over incidental words: data
  transformations remain in processing, destinations in storage, and explicit
  ramp-control relationships in ramp control. Whole claims retain their
  conditions and dependencies.
- Channel associations consume complete declarations after removing review
  markup. Shared signal prefixes remain ambiguous; a generic enable suffix
  cannot establish a channel or physical owner.
- Editorial rules correct bounded grammatical constructions without renaming
  technical identifiers or resolving ambiguous source meaning.
- Existing responsibility and semantic-unit types audit the explanations.
  The production CSV writer now persists all explanation-linkage fields;
  its real round trip is covered by regression tests.

## Existing obligation -> implementation -> check

| Existing contract obligation | Shared implementation | Focused check |
|---|---|---|
| Concise purpose and distinct capabilities | Existing IPOS presentation plus source-derived activity descriptions | Unchanged 1.1; no repeated inventory statements; independent source assessment |
| Paragraph responsibility and supported behavior | Typed responsibility/activity lead plus complete qualified relationships | First paragraph contains two or three sentences in each MD/DOCX group |
| Information gain and nonduplication | Intro/detail partition; reference-only projection retains informative detail | Duplicate/filler intro mutations rejected; full raw-meaning readback remains mandatory |
| Section purpose and ownership | Primary-relation classification, exact actors and unambiguous source-declared associations | Misplacement regressions; no channel from shared enable suffix; external-source ownership mutation rejected |
| Semantic fidelity | Existing meanings, source spans, dependencies and detailed readback | Timing, quantities, alternatives, polarity and reset mutations rejected |
| Provenance and materialization | Existing `DescriptiveResponsibility` and `SemanticUnit` records; persisted CSV fields | Production audit round trip, existing document contract and scoped gate PASS |
| Independent verification | Orientation activities checked against admitted meanings, without detailed-coverage credit | Planner/composer-disabled assessment regressions PASS |
| Digital/analog consistency | Same document-specific planner and composition path | Independently worded analog charge-sampling/readout and digital-sequencing fixtures |

These implement the existing paragraph, information-gain, section-role,
semantic-fidelity and materialization obligations. There is no new synthesis
engine, authority source, approval lane or gate.

## Results

- **98 focused tests PASS**, including digital and analog synthetic fixtures,
  independent source/readback tests and production audit persistence.
- **22/22 actual lead checks PASS:** eleven groups in each of Markdown and Word.
- **16/16 principal-function coverage checks PASS** on actual generated prose.
- **16 actual-prose mutation checks PASS:** altered quantities, timing guards,
  ownership, CDS behavior, reset restrictions and polarity are rejected.
- Existing Main Controller document contract and scoped IPOS gate **PASS**.
- Full-document and excerpt Markdown/Word overview parity **PASS**.
- Complete selected input is unchanged: **198 admitted records**.
- All **181 normative requirements**, IDs, Covers and Source I/O are unchanged
  in Markdown and Word content.
- All **47 protected isolated SRS/DRS/authority files** and **5,595 protected
  official files** remain unchanged.

The gate's 302-requirement/eight-block inventory count is not a claim that other
blocks were regenerated or that their descriptions were revalidated.

## Remaining gaps

- The broader writing assessment remains **UNRESOLVED**, with **466 reported
  findings**. Focused pilot checks do not certify every source construction.
- Unsupported/truncated clauses and uncertain scope or antecedents remain
  explicit audit gaps rather than completed prose.
- Source inconsistencies and technical spellings, including `EC0`,
  `Avarage Circuit`, `Main Control ler`, and differing frame-averaging identifiers,
  are not silently reconciled. Conflicting state encodings remain source issues.
- Explanations use a bounded deterministic activity vocabulary. Some technical
  detail retains source phrasing where a safe editorial projection is not
  established; arbitrary natural-language readability is not certified.

No broad regeneration, official overwrite, approval, destination-permission,
allocation, ownership or snapshot change occurred. No commit, tag, push,
official publication or implementation-readiness certification was performed.
