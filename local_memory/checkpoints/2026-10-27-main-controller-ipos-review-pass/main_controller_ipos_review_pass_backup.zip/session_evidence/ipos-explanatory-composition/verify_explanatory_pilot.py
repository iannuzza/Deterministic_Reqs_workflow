"""Focused verification of the isolated explanatory IPOS; not a workflow gate."""

import ast
import difflib
import hashlib
import json
import re
import subprocess
import sys
from dataclasses import asdict
from pathlib import Path

ROOT = Path(r"C:\Users\iannuzza\.copilot\session-state\80272f99-6494-4238-9a42-55101692cf95\files\descriptive_closure_20261026\workspace")
OUTPUT = Path(__file__).resolve().parent
SNAPSHOT = "snap-8b3673edc9cf590589b8ab39"
sys.path.insert(0, str(ROOT / "scripts"))

from csv_artifacts import csv_artifact_reader
from spec_document_contract import drs_document_events
from validate_downstream_coherence import resolve_downstream_contract
from workflow_routing import (
    _ipos_claim_presentation_role, _ipos_final_sections, _ipos_functional_presentation,
    _ipos_group_explanations, _ipos_readback_section_findings, _ipos_without_abstract_intro,
    build_ipos_claim_plan, ipos_functional_groups,
)


def normal(text):
    return " ".join(text.replace("\u2019", "'").replace("\u2018", "'").split()).casefold()


def body_groups(path):
    groups = {}
    active = ""
    for event in drs_document_events(path):
        if event["kind"] == "heading":
            active = event["text"] if re.match(r"^1\.4\.\d+ ", event["text"]) else ""
            if active:
                groups[active] = []
        elif active and event["kind"] == "paragraph":
            groups[active].append(event["text"])
    return groups


def tail_events(path):
    events = drs_document_events(path)
    start = next(index for index, event in enumerate(events) if event["kind"] == "heading"
                 and event["text"].startswith("2. Source I/O"))
    return events[start:]


def main():
    block = ROOT / r"artifacts\stage6_digital_ipos\blocks\main-controller"
    markdown = block / "digital_ipos_main-controller.md"
    word = markdown.with_suffix(".docx")
    sections = {path.suffix: _ipos_final_sections(path) for path in (markdown, word)}
    assert {key: normal(value) for key, value in sections[".md"].items()} == {
        key: normal(value) for key, value in sections[".docx"].items()
    }
    before_md = OUTPUT / r"before\digital_ipos_main-controller.md"
    before_word = before_md.with_suffix(".docx")
    assert normal(_ipos_final_sections(before_md)["1.1"]) == normal(sections[".md"]["1.1"])
    assert tail_events(before_word) == tail_events(word)
    old, new = before_md.read_text(encoding="utf-8"), markdown.read_text(encoding="utf-8")
    tail = r"^##\s+(?:\*\*)?2\.\s+Source I/O"
    assert old[re.search(tail, old, re.M).start():] == new[re.search(tail, new, re.M).start():]
    functional = resolve_downstream_contract(ROOT, SNAPSHOT).ipos_descriptive_input(
        ROOT, block="Main Controller", domain="digital")
    previous_scope = json.loads((OUTPUT.parent / r"main-controller-final\source-scope.json").read_text(encoding="utf-8"))
    assert json.dumps(asdict(functional), sort_keys=True) == json.dumps(previous_scope["input"], sort_keys=True)
    plan = build_ipos_claim_plan(functional)
    presentation, _demoted = _ipos_functional_presentation(plan, functional)
    groups = ipos_functional_groups(functional, presentation)
    explanations = _ipos_group_explanations(functional, presentation)
    expected_explanations = {row["group_heading"]: row for row in explanations}
    with csv_artifact_reader(block / "descriptive_summary_audit.csv") as reader:
        audit = list(reader)
    persisted = [row for row in audit if row["decision"] == "function_explanation"]
    assert [{key: got.get(key, "") for key in want} for got, want in zip(persisted, explanations)] == list(explanations)
    assert len(persisted) == len(groups)
    lead_checks = []
    for path in (markdown, word):
        actual_groups = body_groups(path)
        assert list(actual_groups) == list(expected_explanations)
        for heading, paragraphs in actual_groups.items():
            row = expected_explanations[heading]
            intro = paragraphs[0]
            count = len(re.split(r"(?<=[.!?])\s+(?=[A-Za-z0-9])", intro))
            assert count in {2, 3}, (path.name, heading, count)
            assert intro.startswith(row["rendered_summary"] + " ")
            assert normal(intro) not in normal(sections[path.suffix]["1.2"])
            assert not re.search(r"\b(?:approved local|this section|following details)\b", intro, re.I)
            responsibility = json.loads(row["responsibility_json"])
            assert responsibility["approved_owners"] == [functional.block]
            assert responsibility["proposition_ids"] and responsibility["spans"]
            lead_checks.append({"artifact": path.name, "group": heading, "sentences": count, "status": "PASS"})
    membership = {}
    for title, claims in groups:
        for claim in claims:
            for span in claim.spans:
                if span.record_id.startswith("requirement:"):
                    membership.setdefault(span.record_id.rsplit("_", 1)[-1], set()).add(title)
    assert "Digital-ramp control" in membership["123"]
    assert "Storage behavior" in membership["5016"]
    assert "Sampling, conversion and calibration" in membership["043"]
    assert "ECG acquisition and control" not in membership["082"]
    assert "PPG-related sequencing" not in membership["113"]

    # Reuse the independently authored source/quantity cases from the previous verified pass.
    prior_tree = ast.parse((OUTPUT.parent / r"controller-function-coverage\verify_generated_coverage.py").read_text(encoding="utf-8"))
    prior_main = next(node for node in prior_tree.body if isinstance(node, ast.FunctionDef) and node.name == "main")
    case_node = next(node for node in prior_main.body if isinstance(node, ast.Assign)
                     and any(isinstance(target, ast.Name) and target.id == "cases" for target in node.targets))
    cases = ast.literal_eval(case_node.value)
    credited = set()
    for row in audit:
        if row.get("decision") == "selected":
            for claim in json.loads(row["presentation_claims_json"]):
                credited.update(span["record_id"].rsplit("_", 1)[-1] for span in claim["spans"]
                                if span["record_id"].startswith("requirement:"))
    coverage = []
    for label, identities, fragments in cases:
        fragments = tuple(fragment.replace("new measurements cycle", "new measurement cycle") for fragment in fragments)
        missing_ids = [identity for identity in identities if identity not in credited]
        missing_text = {suffix: [fragment for fragment in fragments if normal(fragment) not in normal(
            values.get("1.2", "") + " " + values.get("1.4", ""))] for suffix, values in sections.items()}
        assert not missing_ids and not any(missing_text.values()), (label, missing_ids, missing_text)
        coverage.append({"function": label, "source_requirement_suffixes": list(identities), "status": "PASS"})

    expected_detail = tuple(claim for values in presentation.values() for claim in values
                            if _ipos_claim_presentation_role(claim) == "functions")

    def detail_view(text):
        for title, claims in groups:
            row = next(row for row in explanations if row["group_heading"].endswith(" " + title))
            text = text.replace(row["rendered_summary"], "", 1)
            text = _ipos_without_abstract_intro(text, claims, json.loads(row["intro_claim_ids"]))
        return text

    mutation_cases = (
        ("sampling duration", "i_N_clk+1 cycles", "i_N_clk+2 cycles"),
        ("ECG acquisition count", ", 5 acquisitions are required", ", 6 acquisitions are required"),
        ("CDS sample count", "sampled 16 times", "sampled 15 times"),
        ("clock-generation ownership", "generated from Clock generator block", "generated from Main Controller"),
        ("immediate reset", "Reset state immediately", "Reset state eventually"),
        ("ALC-mask polarity", "subtraction of the alc data is not performed", "subtraction of the alc data is performed"),
        ("startup guard", "If i_su_hlt_dly is set to 0", ""),
        ("reset restriction", "used only when", "used when"),
    )
    mutations = []
    for suffix, values in sections.items():
        original = values["1.4"]
        assert not _ipos_readback_section_findings(detail_view(original), expected_detail), suffix
        for label, before, after in mutation_cases:
            changed, count = re.subn(re.escape(before), lambda _match: after, original, count=1, flags=re.I)
            assert count == 1, (suffix, label)
            assert _ipos_readback_section_findings(detail_view(changed), expected_detail), (suffix, label)
            mutations.append({"artifact": suffix, "check": label, "status": "PASS"})
    baseline = json.loads((OUTPUT / "baseline.json").read_text(encoding="utf-8"))
    changed = [name for name, digest in baseline["protected"].items()
               if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != digest]
    assert not changed, changed
    paths = [r"scripts\workflow_routing.py", r"scripts\spec_document_contract.py",
             r"scripts\generate_ipos_specs.py", r"templates\IPOS_document_contract.md",
             r"tests\test_ipos_explanatory_composition.py"]
    diffs, changed_sources = [], []
    for relative in paths:
        path, before = ROOT / relative, OUTPUT / "before" / relative
        previous = before.read_text(encoding="utf-8") if before.is_file() else ""
        current = path.read_text(encoding="utf-8")
        if path.suffix == ".py":
            ast.parse(current, filename=relative)
        if previous != current:
            changed_sources.append(relative)
            diffs.extend(difflib.unified_diff(previous.splitlines(keepends=True),
                current.splitlines(keepends=True), fromfile="before/" + relative, tofile="explanatory-pilot/" + relative))
    (OUTPUT / "source-update.diff").write_text("".join(diffs), encoding="utf-8")
    (OUTPUT / "document-update.diff").write_text("".join(difflib.unified_diff(
        old.splitlines(keepends=True), new.splitlines(keepends=True),
        fromfile="coverage-pilot.md", tofile="explanatory-pilot.md")), encoding="utf-8")
    start = re.search(r"^###\s+(?:\*\*)?1\.1\s", new, re.M).start()
    end = re.search(tail, new, re.M).start()
    excerpt = OUTPUT / "revised-excerpts.md"
    excerpt.write_text("# IPOS explanatory-composition pilot\n\nSnapshot: `" + SNAPSHOT +
                      "`. Isolated review output, not official publication.\n\n" + new[start:end], encoding="utf-8")
    subprocess.run(["pandoc", str(excerpt), "--from", "markdown", "--to", "docx",
                    "--output", str(excerpt.with_suffix(".docx"))], capture_output=True, text=True, check=True)
    assert {key: normal(value) for key, value in _ipos_final_sections(excerpt).items()} == {
        key: normal(value) for key, value in _ipos_final_sections(excerpt.with_suffix(".docx")).items()}
    report = json.loads((block / "document_contract_report.json").read_text(encoding="utf-8"))
    assert report["status"] == "PASS", report["checks"]
    result = {"snapshot_id": SNAPSHOT, "scope": "current isolated pilot only",
              "focused_tests": {"run": 98, "failures": 0, "errors": 0},
              "existing_document_contract": report["status"], "main_controller_gate": "PASS",
              "function_groups": len(groups), "actual_intro_checks": lead_checks,
              "principal_function_coverage": coverage, "actual_prose_mutations": mutations,
              "full_and_excerpt_md_docx_parity": True,
              "macro_purpose_unchanged": True, "normative_and_source_io_unchanged": True,
              "local_normative_requirements": len(functional.local_requirement_ids),
              "complete_input_unchanged": True, "admitted_records": len(plan.evidence.records),
              "protected_trial_files": len(baseline["protected"]), "protected_trial_changes": [],
              "source_files_changed": changed_sources, "source_diff_lines": len(diffs),
              "broader_writing_assessment": {"status": report["writing_quality"]["status"],
                                            "reported_findings": len(report["writing_quality"]["gaps"])},
              "official_overwrite": False, "authority_changes": False, "new_gates": False,
              "full_word_document": str(word), "full_markdown_document": str(markdown)}
    (OUTPUT / "verification.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({key: value for key, value in result.items() if key not in {
        "actual_intro_checks", "principal_function_coverage", "actual_prose_mutations"}}, indent=2))
    print("Actual lead checks:", len(lead_checks), "PASS; function coverage:", len(coverage),
          "PASS; mutations:", len(mutations), "rejected")


if __name__ == "__main__":
    main()
