# Main Controller IPOS: principal-function coverage update

Snapshot: `snap-8b3673edc9cf590589b8ab39`. Isolated review document only.

## Open the document

- [Full generated Main Controller IPOS - Word](../../../80272f99-6494-4238-9a42-55101692cf95/files/descriptive_closure_20261026/workspace/artifacts/stage6_digital_ipos/blocks/main-controller/digital_ipos_main-controller.docx)
- [Revised descriptive sections - Word](revised-excerpts.docx)
- [Revised descriptive sections - Markdown](revised-excerpts.md)
- [Document diff](document-update.diff)
- [Exact source/test/template diff](source-update.diff)
- [Source-to-function coverage and verification](coverage-verification.json)

## Short change summary

- **1.1 remains unchanged.**
- **1.2** now introduces the supported functional families from retained
  snapshot evidence, alongside the Device_FSM/Elab_FSM explanations and
  supported interactions. The introduction is source-linked, not copied from
  the preceding conversational analysis.
- **1.4** now includes the previously missing converter phases, ECG0/ECG1/ECG2,
  BIA and BIO-path coordination, GSR current/CDS behavior, PPG startup and
  sequencing, calibration/ALC, digital ramps, averaging, result transfer and
  power/reset restrictions. Sixteen analytical coverage categories are checked;
  the generated document groups them into eleven subsections.
- Complete technical relationships are no longer discarded merely for
  containing register/signal identifiers. Compound assertions keep their
  explicit actors, quantities, alternative branches and timing dependencies.
- Same-record interpretation preserves standalone startup conditions, common
  outer guards on alternatives, and the postposed ECG-state qualification.
  Clock generation remains assigned to the Clock Generator; initiating or
  waiting for another function is not rewritten as executing it.
- The runtime change is in the existing shared deterministic planner and
  existing readback path, with related template guidance and tests. No fixed
  Main Controller prose/function catalogue or new gate was introduced.

## Focused results

| Check | Result |
|---|---|
| Regression tests | 87 PASS |
| Principal-function source-to-actual-prose checks | 16/16 PASS |
| Actual Markdown/Word mutations: quantities, CDS, ownership, reset, guards, polarity | 16 rejected as expected |
| Existing scoped Main Controller IPOS gate | PASS |
| Full-document and excerpt Markdown/Word overview parity | PASS |
| All 181 normative requirements, IDs, Covers and Source I/O | Unchanged in Markdown and Word content |
| Complete selected input: 198 admitted records, provenance and permissions | Unchanged |
| Protected isolated SRS/DRS/authority files | 47 unchanged |
| Protected official files | 5,595 unchanged |

The gate's overall inventory count of 302 requirements/eight blocks is not a
claim that every block's descriptions were revalidated in this Main-only pass.

## Limits and authority

The sixteen function checks inspect actual generated descriptions, not just
headings or producer selection. They are focused verification of this pilot,
not proof that every source construction has complete semantic interpretation.
The broader writing assessment remains **UNRESOLVED**, with 583 reported
findings retained for review; unsupported/damaged source detail remains visible
in the existing audits and unchanged normative requirements.

No approval, destination permission, allocation, ownership, selected snapshot,
official source or official generated document was changed. No commit, tag,
push, official publication or implementation-readiness certification occurred.
