"""Focused, read-only source/output checks for the requested isolated pilot."""

import ast
import difflib
import hashlib
import json
import re
import sys
from dataclasses import asdict
from pathlib import Path

ROOT = Path(r"C:\Users\iannuzza\.copilot\session-state\80272f99-6494-4238-9a42-55101692cf95\files\descriptive_closure_20261026\workspace")
OUTPUT = Path(__file__).resolve().parent
SNAPSHOT = "snap-8b3673edc9cf590589b8ab39"
sys.path.insert(0, str(ROOT / "scripts"))

from csv_artifacts import csv_artifact_reader
from spec_document_contract import drs_document_events
from validate_downstream_coherence import resolve_downstream_contract
from workflow_routing import (
    _ipos_claim_presentation_role, _ipos_final_sections, _ipos_functional_presentation,
    _ipos_readback_section_findings, build_ipos_claim_plan,
)


def normal(text):
    return " ".join(text.replace("\u2019", "'").replace("\u2018", "'").split()).casefold()


def tail_events(path):
    events = drs_document_events(path)
    start = next(index for index, event in enumerate(events)
                 if event["kind"] == "heading" and event["text"].startswith("2. Source I/O"))
    return events[start:]


def main():
    block = ROOT / r"artifacts\stage6_digital_ipos\blocks\main-controller"
    markdown = block / "digital_ipos_main-controller.md"
    word = markdown.with_suffix(".docx")
    sections = {path.suffix: _ipos_final_sections(path) for path in (markdown, word)}
    assert {key: normal(value) for key, value in sections[".md"].items()} == {
        key: normal(value) for key, value in sections[".docx"].items()
    }, "Markdown/Word overview parity"
    before_md = OUTPUT / r"before\digital_ipos_main-controller.md"
    before_word = before_md.with_suffix(".docx")
    assert normal(sections[".md"]["1.1"]) == normal(_ipos_final_sections(before_md)["1.1"])
    assert tail_events(before_word) == tail_events(word), "Normative or Source I/O Word content changed"
    old, new = before_md.read_text(encoding="utf-8"), markdown.read_text(encoding="utf-8")
    tail = r"^##\s+(?:\*\*)?2\.\s+Source I/O"
    assert old[re.search(tail, old, re.M).start():] == new[re.search(tail, new, re.M).start():]
    functional = resolve_downstream_contract(ROOT, SNAPSHOT).ipos_descriptive_input(
        ROOT, block="Main Controller", domain="digital")
    previous_scope = OUTPUT.parent / r"main-controller-final\source-scope.json"
    previous = json.loads(previous_scope.read_text(encoding="utf-8"))
    assert json.dumps(asdict(functional), sort_keys=True) == json.dumps(previous["input"], sort_keys=True)
    plan = build_ipos_claim_plan(functional)
    with csv_artifact_reader(block / "descriptive_summary_audit.csv") as reader:
        audit = list(reader)
    credits = {}
    for row in audit:
        if row.get("decision") != "selected":
            continue
        for claim in json.loads(row["presentation_claims_json"]):
            actual_section = {"purpose": "1.1", "main_functions": "1.2",
                              "boundaries": "1.2", "organization": "1.3",
                              "functions": "1.4", "limits": "1.4"}[claim["role"]]
            for span in claim["spans"]:
                identity = span["record_id"]
                if identity.startswith("requirement:"):
                    identity = identity.rsplit("_", 1)[-1]
                credits.setdefault(identity, []).append((actual_section, row["rendered_summary"]))

    cases = (
        ("Configuration and mode control", ("002", "051", "5005"), ("mode_operation", "1024", "i_N_clk")),
        ("Device lifecycle and boot dependency", ("004", "034", "035"), ("ADSP", "BOOT", "IDLE", "o_MC_busy")),
        ("Elaboration and BIO-path coordination", ("037", "038"), ("BIO-Channel", "o_en_bufxbio", "o_ADC_mux_reg", "4 acquisitions", "When in the ecg state, If ECG1 and ECG2 are selected")),
        ("ADC phase generation", ("043", "053", "054", "055", "060"), ("16 MHz", "160 clock cycles", "i_N_clk+1 cycles", "falling edge", "o_do_avarage")),
        ("ADC calibration and diagnostics", ("058", "0152", "062", "063"), ("adc_error_cap", "POR", "bypassed", "set to 2")),
        ("All ECG channels and startup", ("3124", "3125", "3126", "075", "076", "077", "078"), ("only ECG0", "ECG1 and ECG2", "5 acquisitions", "10 acquisitions", "15 acquisitions", "32KHz", "205ms")),
        ("BIA startup and acquisition", ("080", "083", "084", "085", "086", "087", "3127", "128"), ("Clock generator block", "5ms", "15ms", "20ms", "30ms", "205", "755ms", "16 acquisitions", "21 acquisitions")),
        ("GSR scheduling, current and CDS", ("088", "089", "090", "092", "093"), ("time slots", "300us", "current injection", "16 times", "subtraction between GSR_SNS and GSR_CDS", "no acquisition of GSR_CDS")),
        ("PPG startup and frame sequencing", ("101", "103", "108", "113", "300"), ("T_rx_set", "TX_start_up", "i_end_average", "rx_channel", "Reset state immediately")),
        ("Local ALC and coordination", ("126", "127", "129", "133", "7135", "9139"), ("ALC", "T1", "T2", "GAIN", "subtraction of the alc data is not performed")),
        ("IOFF and conditional calibration priorities", ("1116", "3129", "3130", "3131", "6098"), ("new measurements cycle", "adc calibration is performed first", "wave velocity mode is performed first", "never repeated")),
        ("Digital-ramp control", ("118", "120", "122", "123", "124", "125"), ("i_N_start", "N_MAX", "2-clock cycle", "o_rising_ramp_end", "o_falling_ramp_end")),
        ("Channel averaging and result formation", ("137", "138", "139", "143", "2145"), ("4 Samples", "1 Sample ECG_x_DC", "GSR ON", "GSR OFF", "i_n_average_ppg", "20-bit data")),
        ("Routing, tagging and storage", ("008", "115", "5016"), ("dedicated tag", "FIFO", "AHB Master", "DS_SEL", "ECG0_AC", "averages_between_equal_frames", "avareges_between_equal_frames")),
        ("Power and sleep-clock dependencies", ("009", "036", "436"), ("150us", "34 clock cycles", "32kHz", "Sleep Mode")),
        ("Reset restrictions, status and soft reset", ("4079", "4091", "5080", "5092", "5015"), ("no clock stops if enabled", "used only", "not considered interruptible", "without resetting the Regmap")),
    )
    coverage = []
    for name, sources, fragments in cases:
        missing_sources = [identity for identity in sources if identity not in credits]
        missing_prose = {
            suffix: [fragment for fragment in fragments if normal(fragment) not in normal(
                contents.get("1.2", "") + " " + contents.get("1.4", ""))]
            for suffix, contents in sections.items()
        }
        coverage.append({"function": name, "source_requirement_suffixes": list(sources),
                         "missing_source_contributions": missing_sources,
                         "missing_actual_prose": missing_prose,
                         "status": "PASS" if not missing_sources and not any(missing_prose.values()) else "FAIL"})
    presentation, _demoted = _ipos_functional_presentation(plan, functional)
    expected_details = tuple(claim for values in presentation.values() for claim in values
                             if _ipos_claim_presentation_role(claim) == "functions")
    mutations = (
        ("sampling duration", "i_N_clk+1 cycles", "i_N_clk+2 cycles"),
        ("ECG acquisition count", ", 5 acquisitions are required", ", 6 acquisitions are required"),
        ("CDS sample count", "sampled 16 times", "sampled 15 times"),
        ("clock-generation ownership", "generated from Clock generator block", "generated from Main Controller"),
        ("immediate reset", "Reset state immediately", "Reset state eventually"),
        ("ALC-mask polarity", "subtraction of the alc data is not performed", "subtraction of the alc data is performed"),
        ("startup guard", "If i_su_hlt_dly is set to 0, At least after 205ms", "At least after 205ms"),
        ("reset restriction", "used only when", "used when"),
    )
    mutation_results = []
    for suffix, contents in sections.items():
        original_detail = contents["1.4"]
        assert not _ipos_readback_section_findings(original_detail, expected_details), suffix
        for name, old_phrase, new_phrase in mutations:
            changed, count = re.subn(re.escape(old_phrase), lambda _match: new_phrase,
                                     original_detail, count=1, flags=re.I)
            assert count == 1, (suffix, name)
            findings = _ipos_readback_section_findings(changed, expected_details)
            assert findings, (suffix, name)
            mutation_results.append({"artifact": suffix, "check": name, "status": "PASS"})
    baseline = json.loads((OUTPUT / "baseline.json").read_text(encoding="utf-8"))
    changed = [name for name, digest in baseline["protected"].items()
               if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != digest]
    assert not changed, changed
    before_sources = OUTPUT / "before"
    paths = [r"scripts\workflow_routing.py", r"scripts\spec_document_contract.py",
             r"scripts\generate_ipos_specs.py", r"templates\IPOS_document_contract.md",
             r"tests\test_ipos_function_coverage.py", r"tests\test_ipos_grouped_pilot.py"]
    diffs = []
    changed_sources = []
    for relative in paths:
        path, before = ROOT / relative, before_sources / relative
        old_source = before.read_text(encoding="utf-8") if before.is_file() else ""
        if not before.is_file() and relative.endswith("test_ipos_grouped_pilot.py"):
            continue
        new_source = path.read_text(encoding="utf-8")
        if path.suffix == ".py":
            ast.parse(new_source, filename=relative)
        if old_source != new_source:
            changed_sources.append(relative)
            diffs.extend(difflib.unified_diff(old_source.splitlines(keepends=True),
                new_source.splitlines(keepends=True), fromfile="before/" + relative,
                tofile="isolated-coverage/" + relative))
    (OUTPUT / "source-update.diff").write_text("".join(diffs), encoding="utf-8")
    (OUTPUT / "document-update.diff").write_text("".join(difflib.unified_diff(
        old.splitlines(keepends=True), new.splitlines(keepends=True),
        fromfile="previous-pilot.md", tofile="expanded-pilot.md")), encoding="utf-8")
    overview_start = re.search(r"^###\s+(?:\*\*)?1\.1\s", new, re.M).start()
    overview_end = re.search(tail, new, re.M).start()
    (OUTPUT / "revised-excerpts.md").write_text(
        "# Main Controller IPOS - isolated function coverage\n\n"
        "Snapshot: `" + SNAPSHOT + "`. Review-only; no official publication.\n\n"
        + new[overview_start:overview_end], encoding="utf-8")
    writing = json.loads((block / "descriptive_writing_quality.json").read_text(encoding="utf-8"))
    report = {"snapshot_id": SNAPSHOT, "scope": "isolated Main Controller only",
              "principal_function_checks": coverage,
              "principal_functions_passed": sum(value["status"] == "PASS" for value in coverage),
              "principal_functions_checked": len(coverage),
              "actual_prose_mutation_checks": mutation_results,
              "actual_prose_mutations_rejected": len(mutation_results),
              "normalized_input_unchanged": True, "source_records": len(plan.evidence.records),
              "local_normative_requirements": len(functional.local_requirement_ids),
              "normative_and_source_io_md_word_unchanged": True,
              "macro_purpose_unchanged": True, "md_docx_overview_parity": True,
              "trial_protected_files": len(baseline["protected"]), "trial_protected_changes": changed,
              "actual_overview_words": len(" ".join(sections[".md"].values()).split()),
              "source_files_changed": changed_sources, "source_diff_lines": len(diffs),
              "full_word_document": str(word), "full_markdown_document": str(markdown),
              "broader_writing_assessment": {"status": writing["status"],
                                            "reported_findings": len(writing["gaps"])},
              "new_gates": False, "authority_changes": False, "official_overwrite": False}
    (OUTPUT / "coverage-verification.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps({key: value for key, value in report.items()
                      if key not in {"principal_function_checks", "actual_prose_mutation_checks"}}, indent=2))
    failures = [value for value in coverage if value["status"] != "PASS"]
    if failures:
        print(json.dumps(failures, indent=2))
        raise SystemExit(1)


if __name__ == "__main__":
    main()
