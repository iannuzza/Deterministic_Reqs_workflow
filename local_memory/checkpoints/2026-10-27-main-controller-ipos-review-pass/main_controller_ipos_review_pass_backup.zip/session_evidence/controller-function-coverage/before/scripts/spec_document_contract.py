"""Project-agnostic contracts for generated specification documents."""

from __future__ import annotations

import hashlib
import csv
import json
import re
import zipfile
from collections import Counter
import xml.etree.ElementTree as ET
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable, Mapping, Sequence

import yaml


CONTRACT_VERSION = "1.0"
IPOS_DETAIL_POLICY = "functional_detail_v1"

DRS_TEMPLATE = "templates/DRS_gen_AI_template_prompt.md"
DRS_RULES = frozenset({
    "structure", "conventions", "navigation", "table_preservation",
    "technical_prose", "evidence_fidelity", "artifact_fidelity",
})
IPOS_TEMPLATE = "templates/IPOS_document_contract.md"
IPOS_CONTRACT_RULES = frozenset({"section_roles", "functional_claims", "information_gain", "semantic_fidelity",
                                 "publication_quality", "materialization"})

PUBLICATION_REVIEW_MARKERS = re.compile(
    r"\b(?:need clarification|requires? clarification|not specified|not described|"
    r"TBD(?:-\d+)?|TBC|clarification|placeholder|insufficient|unresolved|SRS_(?:CATALOG|POWER)_[A-Z_]+)\b", re.I,
)


def clean_descriptive_review_text(text: str) -> str:
    if not PUBLICATION_REVIEW_MARKERS.search(text):
        return text
    if re.search(r"signal spelling:\s*need clarification", text, re.I):
        return ""
    segments = re.split(r"(?<=[.;])\s+", text)
    retained = [segment for segment in segments if not PUBLICATION_REVIEW_MARKERS.search(segment)]
    if retained and re.fullmatch(r"[-*+]\s*", retained[0]):
        retained.pop(0)
    return " ".join(retained).strip()


def clean_publication_title(text: str) -> str:
    return re.sub(r"\s+(?:and|&)\s+TBD\b", "", text, flags=re.I)


def clean_publication_line(line: str) -> str:
    if line.lstrip().startswith("#"):
        projected = clean_publication_title(line)
    elif line.strip().startswith("|"):
        cells = re.split(r"(?<!\\)\|", line.strip().strip("|"))
        projected = "| " + " | ".join(clean_descriptive_review_text(clean_publication_title(cell.strip()))
                                        for cell in cells) + " |"
    else:
        projected = clean_descriptive_review_text(line)
    return re.sub(r"(?:-and)?-tbd\b", "", projected, flags=re.I)


def apply_clean_document_presentation(lines: list[str], output_path: Path, document_type: str, *,
                                      technical_policy_review: bool = False) -> list[str]:
    snapshot = next((match[1] for line in lines if (match := re.match(r"Snapshot ID:\s*(\S+)", line))), "")
    result, omissions = [], []
    section, numbered_section, normative = "Document", "", False
    technical_gaps = []
    for number, line in enumerate(lines, 1):
        if re.match(r"^\s*(?:\*\*)?\[[A-Z][A-Z0-9-]*-REQ-\d+\]", line):
            normative = True
        if line.lstrip().startswith("#"):
            section = clean_publication_title(line.lstrip("# "))
            section_number = re.match(r"(\d+(?:\.\d+)*)(?:\.?\s|$)", _drs_text(section))
            if section_number:
                numbered_section = section_number[1]
        if normative:
            if PUBLICATION_REVIEW_MARKERS.search(line):
                raise ValueError("Approved normative text contains a review marker; source review is required")
            result.append(line)
        else:
            from workflow_routing import ARBITRATION_POLICY_GAP
            retained_policy_gap = (technical_policy_review and document_type == "DRS"
                                   and numbered_section == "3.1"
                                   and line.strip() == ARBITRATION_POLICY_GAP)
            if retained_policy_gap:
                projected = line
                technical_gaps.append({"text": line.strip(), "section": "3.1",
                                       "reason": "arbitration_policy_requires_source_clarification"})
            else:
                projected = clean_publication_line(line) if PUBLICATION_REVIEW_MARKERS.search(line) or re.search(r"-tbd\b", line, re.I) else line
            if projected != line:
                omissions.append({"location": section, "input_line": number, "original": line,
                                  "retained": projected, "reason": "review_only_or_unsupported_presentation",
                                  "source_references": [output_path.name + f":renderer-input-line:{number}"],
                                  "user_review_only": True})
            result.append(projected)
        if "[End]" in line:
            normative = False
    payload = {"schema_version": 1, "document_type": document_type, "snapshot_id": snapshot,
               "authority": False, "user_review_only": True, "omissions": omissions}
    if technical_gaps:
        payload["technical_policy_gaps"] = technical_gaps
    output_path.with_name("descriptive_publication_audit.json").write_text(
        json.dumps(payload, indent=2, ensure_ascii=True) + "\n", encoding="utf-8")
    return result


def publication_text_is_accounted(original: str, markdown: str, docx_text: str, audit: dict) -> bool:
    projected = clean_descriptive_review_text(original)
    if projected and (projected not in markdown or projected not in docx_text):
        return False
    if projected != original:
        return any(original in item["original"] for item in audit.get("omissions", []))
    return True


def validate_clean_document_presentation(markdown_path: Path) -> list[str]:
    findings = []
    audit_path = markdown_path.with_name("descriptive_publication_audit.json")
    if not audit_path.exists():
        return ["publication_omission_audit_missing"]
    audit = json.loads(audit_path.read_text(encoding="utf-8"))
    if audit.get("authority") is not False or audit.get("user_review_only") is not True:
        findings.append("publication_omission_audit_authority_invalid")
    text = markdown_path.read_text(encoding="utf-8")
    snapshot = re.search(r"(?m)^Snapshot ID:\s*(\S+)", text)
    if snapshot and audit.get("snapshot_id") != snapshot[1]:
        findings.append("publication_omission_audit_snapshot_invalid")
    for item in audit.get("omissions", []):
        if item["retained"] != clean_publication_line(item["original"]) or not item.get("user_review_only"):
            findings.append("publication_omission_projection_invalid")
        if item["retained"].strip() and item["retained"] not in text:
            findings.append("publication_supported_projection_missing")
    for path in (markdown_path, markdown_path.with_suffix(".docx")):
        if not path.exists():
            findings.append("publication_artifact_missing:" + path.name)
            continue
        events = drs_document_events(path)
        values = [event["text"] for event in events if event["kind"] != "table"]
        values.extend(cell for event in events if event["kind"] == "table" for row in event["rows"] for cell in row)
        from workflow_routing import ARBITRATION_POLICY_GAP
        retained = {item["text"] for item in audit.get("technical_policy_gaps", ())
                    if audit.get("document_type") == "DRS" and item.get("section") == "3.1"
                    and item.get("reason") == "arbitration_policy_requires_source_clarification"
                    and item.get("text") == ARBITRATION_POLICY_GAP}
        if any(PUBLICATION_REVIEW_MARKERS.search(value) and value not in retained for value in values):
            findings.append("publication_inline_marker:" + path.name)
    return findings


SHARED_CATEGORY_CONVENTIONS = (
    (
        "Comment",
        "This category denotes that the content of the object text is a general comment. For example, this may be an explanation why the requirement demands certain items when there would also be other possibilities. A comment should not be necessary to understand the related requirements",
    ),
    (
        "Definition",
        "This category is used for the definition of terms, wordings, technical expressions etc. It is a documentation of design decisions and general instructions that belong to the document itself, e.g. owner of the document, structure of the document. It is needed to understand a related requirement. It is not linked to any test case.",
    ),
    (
        "Assumption",
        "This category is used for requirements this document provide upstream to another document, indicating what this IP/block/system needs to work properly.",
    ),
    (
        "Requirement",
        "This category denotes a requirement that has to be implemented and verified. Accordingly, it is necessary to establish traces from the different requirement levels to the test cases for this category.",
    ),
)


def shared_category_conventions_markdown() -> list[str]:
    """Render the shared category definitions used by SRS and DRS."""
    lines: list[str] = []
    for index, (name, definition) in enumerate(SHARED_CATEGORY_CONVENTIONS, start=1):
        lines.extend([f"#### 2.5.{index} {name}", "", definition, ""])
    return lines


def load_embedded_document_contract(template_path: Path, document_type: str) -> dict:
    text = template_path.read_text(encoding="utf-8")
    marker = re.escape(document_type.lower() + "-document-contract")
    blocks = re.findall(r"(?ms)^```yaml " + marker + r"\s*\n(.*?)^```\s*$", text)
    if len(blocks) != 1:
        raise ValueError(document_type + " requires exactly one embedded YAML document contract")

    class UniqueLoader(yaml.SafeLoader):
        pass

    def unique_mapping(loader, node):
        result = {}
        for key_node, value_node in node.value:
            key = loader.construct_object(key_node)
            if key in result:
                raise ValueError(f"Duplicate {document_type} contract key: {key}")
            result[key] = loader.construct_object(value_node)
        return result

    UniqueLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, unique_mapping)
    payload = yaml.load(blocks[0], Loader=UniqueLoader)
    if not isinstance(payload, dict) or payload.get("document_type") != document_type or type(payload.get("version")) is not int:
        raise ValueError("Invalid " + document_type + " contract envelope")
    if "sha256" in payload:
        raise ValueError("Reserved derived document contract field: sha256")
    payload["sha256"] = hashlib.sha256(text.encode("utf-8")).hexdigest()
    return payload


def validate_descriptive_synthesis_contract(payload: dict) -> dict:
    policy = payload.get("descriptive_synthesis")
    fields = {"version", "abstraction", "obligations", "sections", "detail_roles", "literal_policy", "gap_policy"}
    obligations = {"semantic_fidelity", "section_roles", "supported_function_coverage",
                   "essential_qualifications", "nonduplication", "bounded_synthesis"}
    roles = {"purpose", "main_functions", "organization", "boundaries", "interaction",
             "context", "behavior", "restriction"}
    if (not isinstance(policy, dict) or set(policy) != fields or type(policy["version"]) is not int
            or policy["version"] != 1 or policy["abstraction"] not in {"system", "digital_integration", "block_local"}
            or not isinstance(policy["obligations"], list)
            or any(not isinstance(value, str) for value in policy["obligations"])
            or set(policy["obligations"]) != obligations or len(policy["obligations"]) != len(obligations)
            or policy["detail_roles"] != ["configuration", "procedure", "implementation"]
            or policy["literal_policy"] != "preserve_authorized_use_without_synthesis_credit"
            or policy["gap_policy"] != "existing_descriptive_residuals"):
        raise ValueError("Unsupported descriptive synthesis contract")
    if not isinstance(policy["sections"], dict) or not policy["sections"]:
        raise ValueError("Missing descriptive synthesis sections")
    for number, section in policy["sections"].items():
        if (not isinstance(number, str) or not re.fullmatch(r"\d+(?:\.\d+)*", number)
                or not isinstance(section, dict) or set(section) != {"roles", "required"}
                or type(section["required"]) is not bool or not isinstance(section["roles"], list)
                or not section["roles"] or any(not isinstance(role, str) for role in section["roles"])
                or not set(section["roles"]).issubset(roles)
                or len(set(section["roles"])) != len(section["roles"])):
            raise ValueError("Unsupported descriptive synthesis section obligation")
    return policy


def load_descriptive_synthesis_contract(document: str, repo_root: Path | None = None) -> dict:
    templates = {"SRS": "SRS_gen_AI_template_prompt.md", "DRS": "DRS_gen_AI_template_prompt.md",
                 "IPOS": "IPOS_document_contract.md"}
    if document not in templates:
        raise ValueError("Unsupported descriptive document: " + document)
    root = repo_root if repo_root is not None else Path(__file__).resolve().parents[1]
    payload = load_embedded_document_contract(root / "templates" / templates[document], document)
    return {**validate_descriptive_synthesis_contract(payload), "contract_sha256": payload["sha256"]}


def document_synthesis_evidence(repo_root: Path, document: str, snapshot_id: str, *, functional_input=None,
                                 scope_review: Mapping | None = None) -> dict:
    """Read admitted inputs, not a composer's claim selection or output audit."""
    from validate_downstream_coherence import resolve_downstream_contract
    if document == "IPOS":
        if functional_input is None:
            raise ValueError("Independent IPOS assessment requires its admitted functional input")
        contract = resolve_downstream_contract(repo_root, snapshot_id)
        collected = contract.synthesis_evidence(repo_root, document=document, block=functional_input.block,
                                               domain=functional_input.domain)
        return {**collected, "functional_input": functional_input}
    contract = resolve_downstream_contract(repo_root, snapshot_id)
    collected = contract.synthesis_evidence(repo_root, document=document)
    if scope_review is not None:
        from descriptive_review_proposals import with_descriptive_scope_review
        collected = with_descriptive_scope_review(collected, functional_roles=scope_review["functional_roles"],
                                                  rationale=scope_review["rationale"])
        if collected["descriptive_scope_review"] != scope_review:
            raise ValueError("Independent scope review differs from its evidence binding")
    return {**collected, "functions": [row for row in collected["inventory"] if row["applicable"]
            and (document == "SRS" or row["scope"] == "allocated_owner")]}


def descriptive_section_paragraphs(path: Path, policy: dict) -> dict[str, list[str]]:
    sections = {number: [] for number in policy["sections"]}
    active, level = "", 0
    for event in drs_document_events(path):
        if event["kind"] == "heading":
            number = re.match(r"^(\d+(?:\.\d+)*)(?:\.?\s|$)", event["text"])
            targets = [target for target in sections if number
                       and (number[1] == target or number[1].startswith(target + "."))]
            if targets:
                active = max(targets, key=len)
                level = event["level"]
            elif event["level"] <= level:
                active = ""
        elif active and event["kind"] == "paragraph":
            sections[active].append(re.sub(r"^(?:[-*+]\s+|\d+[.)]\s+)", "", event["text"]))
    return sections


def _source_mode_responsibilities(model):
    """Derive the bounded common storage outcome from source actions, not a prose plan."""
    from workflow_routing import DescriptiveMeaning

    outcomes = {}
    for value in model.propositions:
        meaning = value.meaning
        if (meaning.subject != "The system" or meaning.predicate != "acquire"
                or meaning.negative or meaning.modality or not meaning.mode):
            continue
        destinations = re.findall(r"\bstores the (?:raw )?samples in ([^;]+)$", ";".join(meaning.results))
        if len(destinations) == 1:
            outcomes.setdefault((meaning.contexts, meaning.mode, destinations[0]), {})[meaning] = value
    return [(DescriptiveMeaning("responsibility", "The system", "support",
        ("measurement acquisition with sample storage in " + storage,), contexts=contexts, mode=mode),
        tuple(dict.fromkeys(span for value in members.values() for span in value.spans)))
        for (contexts, mode, storage), members in outcomes.items() if len(members) > 1]


def assess_srs_meaning_dispositions(evidence: dict, mappings: list, gaps: list,
                                    artifacts_checked: list) -> list[dict]:
    """Read complete approved source scope, independently of selected producer claims."""
    from dataclasses import asdict
    from governed_descriptive_scope import DOCUMENT_SECTIONS, SRS_DESTINATION_MEANINGS, descriptive_uses
    from workflow_routing import (
        abstract_srs_evidence_model, functional_meaning_role, srs_source_evidence_model,
    )

    shared = {row["record_id"]: json.loads(row["provenance_json"])
              for row in evidence.get("shared_records", ())}
    sources = evidence.get("source_records")
    if sources is None:
        sources = list({binding["record"]["record_id"]: binding["record"]
                        for binding in shared.values()}.values())
    destinations = {semantic: DOCUMENT_SECTIONS["SRS"][role]
                    for role, semantics in SRS_DESTINATION_MEANINGS.items() for semantic in semantics}
    result = []
    for source in sources:
        if source.get("review_decision") != "approved":
            continue
        identity = source["record_id"]
        uses = [use for use in descriptive_uses(source) if use["document"] == "SRS"]
        base = {"source_record_id": identity, "source_file": source.get("source_file", ""),
                "source_section": source.get("section", ""), "snapshot_id": evidence["snapshot_id"],
                "final_coverage_credit": False}
        if (source.get("evidence_scope", "block_local") == "block_local"
                or source.get("mapped_block")) and not uses:
            result.append({**base, "disposition": "retained_in_authorized_detail",
                "detail_owner": source.get("mapped_block", ""), "detail_readback": "NOT CHECKED",
                "reason": "Approved local source retained; not promoted to a system explanation."})
            continue
        if source.get("domain") != "system" and not uses:
            result.append({**base, "disposition": "justified_exclusion",
                "reason": "No approved system scope or SRS use; subsystem context is not system authority."})
            continue
        raw = srs_source_evidence_model(source)
        abstraction = []
        projected = abstract_srs_evidence_model(raw, structural_evidence=evidence, audit_rows=abstraction)
        meanings = {value.proposition_id: value.meaning for value in projected.propositions}
        exclusions = {row["proposition_id"]: row for row in abstraction}
        for proposition in raw.propositions:
            role = functional_meaning_role(proposition.meaning)
            target = destinations.get(role, "")
            meaning = meanings.get(proposition.proposition_id)
            entry = {**base, "proposition_id": proposition.proposition_id,
                "source_meaning": asdict(proposition.meaning),
                "system_meaning": asdict(meaning) if meaning is not None else None,
                "spans": [asdict(span) for span in proposition.spans], "semantic_role": role,
                "section": target, "responsibility": {
                    "actor": proposition.meaning.subject,
                    "supported_outcomes": list(proposition.meaning.results),
                    "contributing_activity": proposition.meaning.predicate,
                    "objects": list(proposition.meaning.objects),
                    "qualifications": list(proposition.meaning.qualifiers)},
                "disposition": "unresolved", "gap_class": "unsupported_interpretation"}
            if meaning is None:
                exclusion = exclusions[proposition.proposition_id]
                if exclusion["behavior_preservation"] == "detail_only_no_consequence_inferred":
                    entry.update(disposition="justified_exclusion", gap_class="",
                                 reason=exclusion["reason"], authorized_detail_readback="NOT CHECKED")
                else:
                    entry["reason"] = exclusion["reason"]
            elif not target:
                entry.update(disposition="justified_exclusion", gap_class="",
                             reason="Implementation/procedure meaning does not establish an SRS summary.")
            else:
                permissions = [use for use in uses
                    if DOCUMENT_SECTIONS["SRS"][use["role"]] == target
                    and all(use["start"] <= span.start and use["end"] >= span.end
                            for span in proposition.spans)]
                entry["authorized_use_ids"] = [use["use_id"] for use in permissions]
                observations = [row for row in mappings
                    if row["meaning"] == asdict(meaning) and row["source"] in shared
                    and shared[row["source"]]["record"]["record_id"] == identity]
                placed = [row for row in observations if row["section"] == target]
                entry["observed_artifacts"] = sorted({row["artifact"] for row in placed})
                defects = [gap for gap in gaps if gap["obligation"] in {
                    "semantic_fidelity", "essential_qualifications", "bounded_synthesis", "nonduplication"}
                    and any(row["source"] in gap.get("source", "").split(";")
                            and row["artifact"] == gap.get("artifact")
                            and (not gap.get("section") or row["section"] == gap["section"])
                            for row in placed)]
                if not permissions:
                    entry.update(gap_class="missing_authorization",
                                 reason="Supported meaning has no explicit use at its semantic destination.")
                elif observations and not placed:
                    entry.update(gap_class="incorrect_placement", reason="Meaning appears outside its section.")
                elif len(artifacts_checked) != 2:
                    entry.update(gap_class="NOT CHECKED", reason="Both final artifacts have not been read.")
                elif len(entry["observed_artifacts"]) != 2:
                    entry.update(gap_class="authorized_but_unrendered",
                                 reason="Authorized meaning not recovered in both actual final artifacts.")
                elif defects:
                    entry.update(gap_class="prose_defect", reason="Independent prose checks remain unresolved.",
                                 findings=defects)
                else:
                    entry.update(disposition="synthesized", gap_class="",
                                 final_coverage_credit=True,
                                 reason="Meaning recovered at its authorized destination in Markdown and Word.")
            result.append(entry)
        for unresolved in raw.unresolved_contexts:
            result.append({**base, "proposition_id": unresolved.context_id,
                "spans": [asdict(span) for span in unresolved.spans],
                "disposition": "unresolved", "gap_class": "unsupported_interpretation",
                "reason": unresolved.reason})
    return result


def assess_descriptive_synthesis(markdown_path: Path, document: str, evidence: dict,
                                 *, repo_root: Path | None = None) -> dict:
    """Check admitted source meanings against final prose without consulting a claim plan."""
    from workflow_routing import (
        DescriptiveFunctionalClaim, DescriptiveMeaning, DescriptiveSourceSpan, _ipos_meaning, _ipos_phrase_pattern,
        _ipos_readback_section_findings, bounded_functional_summary, build_ipos_evidence_model,
        extract_srs_descriptive_facts, functional_abstraction, functional_behavior_meaning,
        functional_meaning_role, ipos_functional_abstraction, ipos_meaning_role,
        ipos_has_local_responsibilities, ipos_presentation_meaning,
        functional_semantic_atoms, shared_descriptive_evidence_model, functional_conversion_scope,
        document_responsibility_model,
        descriptive_context_relationships, functional_inventory_meanings, _ipos_readback_finite_verb_pattern,
        concrete_owner_rows, structural_owner_rows, descriptive_functional_roles, descriptive_processing_meaning,
        descriptive_processing_contribution,
        shared_resource_relations, shared_arbitration_policies, ARBITRATION_POLICY_GAP,
        system_responsibility_meaning, system_domain_responsibilities, ipos_local_context_relationships,
        system_local_capability_meanings,
        digital_overview_meaning,
        system_mode_capability_projections,
        abstract_srs_evidence_model, srs_implementation_syntax, srs_source_evidence_model,
    )
    from governed_descriptive_scope import qualified_shared_context_synthesis_gap
    policy = load_descriptive_synthesis_contract(document, repo_root)
    obligations = {name: {"status": "PASS", "checked": 0, "findings": []} for name in policy["obligations"]}
    gaps, mappings, expected, sources, literals, functions = [], [], [], [], [], []
    raw_sources = {}
    context_applicability = []
    system_abstraction = []
    implementation_findings = []
    implementation_artifacts_checked = []
    collection_status = "NOT_ASSESSED"

    def finding(obligation, reason, *, source="", section="", artifact="", impact="requires_assessment"):
        row = {"obligation": obligation, "reason": reason, "source": source, "section": section,
               "artifact": artifact, "kind": "projection_gap", "authority": False,
               "readiness_impact": impact}
        obligations[obligation]["findings"].append(row)
        obligations[obligation]["status"] = "UNRESOLVED"
        gaps.append(row)

    def add_meaning(meaning, role, source, spans=(), proposition_id="", optional=False):
        expected.append({"meaning": meaning, "role": role, "source": source,
                         "spans": [asdict(span) for span in spans], "proposition_id": proposition_id,
                         "optional": optional})

    functional = evidence.get("functional_input")
    if "requirements" in evidence and repo_root is not None:
        from validate_downstream_coherence import resolve_downstream_contract
        contract = resolve_downstream_contract(repo_root, evidence["snapshot_id"])
        expected_scope = contract.synthesis_evidence(repo_root, document=document,
            block=functional.block if functional is not None else "",
            domain=functional.domain if functional is not None else "")
        collection_status = "PASS"
        for field in ("requirements", "inventory", "shared_records", "local_records", "function_decomposition",
                      "descriptive_scope", "interactions", "interfaces",
                      *(("source_records",) if document == "SRS" else ())):
            obligations["supported_function_coverage"]["checked"] += 1
            if evidence.get(field) != expected_scope.get(field):
                collection_status = "UNRESOLVED"
                finding("supported_function_coverage", "collection differs from applicable approved snapshot scope: " + field,
                        source=evidence["snapshot_id"], impact="collection_completeness")
    if document in {"SRS", "DRS", "ARS"}:
        from workflow_routing import _descriptive_join
        from validate_downstream_coherence import human_label_key
        owners = {human_label_key(row["owner"]) for row in evidence.get("inventory", ()) if row["applicable"]}
        if "requirements" in evidence:
            source_model = document_responsibility_model(evidence, document=document)
            for unresolved in source_model.unresolved_contexts:
                if unresolved.spans[0].record_id in {record["record_id"] for record in evidence.get("shared_records", ())}:
                    continue
                finding("supported_function_coverage", "supporting scope not fully interpreted: " + unresolved.reason,
                        source=unresolved.spans[0].record_id, impact="requires_assessment")
        for index, row in enumerate(evidence.get("function_decomposition", ()), start=1):
            members = tuple(value.strip() for value in row["blocks_involved"].split(";") if value.strip())
            if document != "SRS" and not any(human_label_key(value) in owners for value in members):
                continue
            source = "architecture-function:" + str(index)
            text = json.dumps(dict(row), sort_keys=True)
            span = DescriptiveSourceSpan(source, 0, len(text), text)
            subfunctions = tuple(value.strip() for value in row["subfunctions"].split(";") if value.strip())
            enriched = []
            for subfunction in subfunctions:
                converted = subfunction
                for inventory in evidence.get("inventory", ()):
                    if (inventory["applicable"] and human_label_key(inventory["owner"]) in
                            {human_label_key(value) for value in members}
                            and human_label_key(subfunction) == human_label_key(inventory["owner"] + " conversion")):
                        conversion = functional_conversion_scope(inventory["statement"])
                        if conversion:
                            converted += " of " + conversion
                enriched.append(converted)
            subfunctions = tuple(enriched)
            meaning = (system_responsibility_meaning(row["top_function"], subfunctions,
                           inventory=tuple(item for item in evidence.get("inventory", ()) if item["applicable"]
                               and human_label_key(item["owner"]) in {
                                   human_label_key(member) for member in members})) if document == "SRS" else
                       DescriptiveMeaning("responsibility", "The " + row["top_function"] + " responsibility",
                           "comprise", subfunctions, qualifiers=("across " + _descriptive_join(members),)))
            add_meaning(meaning, "main_functions", source, (span,), optional=document == "DRS")
        if document == "SRS":
            for _domain, meaning, contributors in system_domain_responsibilities(evidence):
                add_meaning(meaning, "organization", ";".join(contributors))
            for row, meaning in system_local_capability_meanings(evidence):
                span = DescriptiveSourceSpan(row["source"], 0, len(row["statement"]), row["statement"])
                add_meaning(meaning, "main_functions", row["source"], (span,))
            for proposition, meaning in system_mode_capability_projections(evidence):
                source = proposition.spans[-1].record_id
                authorized = any(row["record_id"] == source and row["role"] == "functions"
                                 for row in evidence.get("shared_records", ()))
                add_meaning(meaning, "main_functions", source, proposition.spans, optional=not authorized)
    if document == "IPOS":
        if functional is None:
            raise ValueError("Missing admitted IPOS evidence")
        model = build_ipos_evidence_model(functional)
        sources.extend(record.text for record in model.records if not record.record_id.startswith("inventory:"))
        raw_sources.update({record.record_id: record.text for record in model.records
                            if not record.record_id.startswith("inventory:")})
        functions.append({"owner": functional.block, "source": "inventory:function", "statement": functional.function})
        for proposition in model.propositions:
            identity = proposition.spans[0].record_id
            meaning = proposition.meaning
            if identity == "inventory:function":
                macro, activities, gap = ipos_functional_abstraction(functional.function)
                if gap:
                    finding("section_roles", gap, source=identity)
                if macro or activities:
                    for phrase in macro:
                        action, obj = phrase.split(" ", 1)
                        add_meaning(DescriptiveMeaning("behavior", meaning.subject, action.lower(), (obj,)),
                                    "purpose", identity, proposition.spans)
                    if activities != macro and not (macro and ipos_has_local_responsibilities(model, functional)):
                        for phrase in activities:
                            action, obj = phrase.split(" ", 1)
                            add_meaning(DescriptiveMeaning("behavior", meaning.subject, action.lower(), (obj,)),
                                        "main_functions", identity, proposition.spans)
                continue
            shared_roles = {"source-context:" + source_id: json.loads(provenance)["role"]
                            for source_id, _text, provenance in functional.shared_context_records}
            role = ("context" if shared_roles.get(identity) == "context" else
                    "boundaries" if identity in {"inventory:inputs", "inventory:outputs"}
                    else ipos_meaning_role(meaning))
            if identity in shared_roles and (meaning.contexts or meaning.mode):
                role = "behavior"
            if identity in shared_roles:
                links = ipos_local_context_relationships(meaning, functional.block)
                context_applicability.append({"proposition_id": proposition.proposition_id,
                    "source": identity, "applicable": bool(links), "relationships": list(links),
                    "meaning": asdict(meaning), "spans": [asdict(span) for span in proposition.spans]})
                if not links:
                    continue
            if role in policy["detail_roles"]:
                continue
            add_meaning(ipos_presentation_meaning(meaning), role, identity, proposition.spans,
                        proposition.proposition_id)
        for unresolved in model.unresolved_contexts:
            for span in unresolved.spans:
                finding("bounded_synthesis", unresolved.reason, source=span.record_id)
                finding("supported_function_coverage", unresolved.reason, source=span.record_id,
                        impact="requires_assessment")
                finding("essential_qualifications", "unsupported source construction; qualifications not certified",
                        source=span.record_id)
    else:
        functions.extend(evidence.get("functions", ()))
        specific_srs_meanings = set()
        if document == "SRS":
            from governed_descriptive_scope import SRS_DESTINATION_MEANINGS
            for record in evidence.get("shared_records", ()):
                if record["role"] == "context":
                    continue
                candidate = abstract_srs_evidence_model(
                    shared_descriptive_evidence_model((record,), document="SRS"), structural_evidence=evidence)
                specific_srs_meanings.update(value.meaning for value in candidate.propositions
                    if functional_meaning_role(value.meaning) in SRS_DESTINATION_MEANINGS[record["role"]])
        for record in evidence.get("shared_records", ()):
            sources.append(record["statement"])
            from governed_descriptive_scope import DOCUMENT_SECTIONS
            destination = DOCUMENT_SECTIONS[document][record["role"]]
            raw_sources[record["record_id"]] = record["statement"]
            model = shared_descriptive_evidence_model((record,), document=document)
            if document == "SRS":
                model = abstract_srs_evidence_model(model, audit_rows=system_abstraction,
                                                    structural_evidence=evidence)
            for proposition in model.propositions:
                if document == "SRS":
                    if record["role"] == "context" and proposition.meaning in specific_srs_meanings:
                        continue
                    if record["role"] != "context" and functional_meaning_role(
                            proposition.meaning) not in SRS_DESTINATION_MEANINGS[record["role"]]:
                        continue
                semantic_role = functional_meaning_role(proposition.meaning)
                if (document == "SRS" and semantic_role not in
                        SRS_DESTINATION_MEANINGS[record["role"]]):
                    finding("section_roles", "existing use does not authorize the semantic destination",
                            source=record["record_id"], section=destination,
                            impact="destination_authorization")
                    gaps[-1]["gap_class"] = "missing_authorization"
                add_meaning(proposition.meaning, semantic_role if document == "SRS"
                    else "context" if record["role"] == "context" else semantic_role, record["record_id"],
                    proposition.spans, proposition.proposition_id,
                    optional=(document == "SRS" and proposition.meaning.predicate == "describe")
                        or (document == "DRS" and not digital_overview_meaning(proposition.meaning)))
            if document == "SRS":
                for meaning, spans in _source_mode_responsibilities(model):
                    add_meaning(meaning, "behavior", record["record_id"], spans)
            for unresolved in model.unresolved_contexts:
                finding("bounded_synthesis", unresolved.reason, source=record["record_id"], section=destination)
                finding("supported_function_coverage", unresolved.reason, source=record["record_id"], section=destination)
                finding("essential_qualifications", "unsupported source construction; qualifications not certified",
                        source=record["record_id"], section=destination)
    for function in functions:
        projection = bounded_functional_summary(function["statement"])
        if projection.gap:
            finding("supported_function_coverage", projection.gap, source=function["source"])
        if document == "DRS":
            continue
        if document != "IPOS" and projection.responsibilities and not (
                document == "SRS" and evidence.get("function_decomposition")):
            macro, activities, macro_gap = functional_abstraction(function["statement"])
            if macro_gap:
                finding("section_roles", macro_gap, source=function["source"])
            for phrase in (*macro, *activities) if activities != macro else macro:
                action, obj = phrase.split(" ", 1)
                span = DescriptiveSourceSpan(function["source"], 0, len(function["statement"]), function["statement"])
                add_meaning(DescriptiveMeaning("behavior", "The " + function["owner"] + " block", action.lower(), (obj,)),
                            "main_functions", function["source"], (span,))
    if document == "DRS":
        resources = shared_resource_relations(evidence)
        policies = shared_arbitration_policies(evidence)
        missing_policy = {row["owner"] for row in resources} - {meaning.subject for meaning in policies}
        for resource in resources:
            source = "shared-resource:" + resource["owner"]
            statement = json.dumps(dict(resource), sort_keys=True)
            meaning = DescriptiveMeaning("responsibility", resource["owner"], "be",
                ("a shared " + _descriptive_join(resource["kinds"]) + " resource",),
                qualifiers=("with documented integration paths connecting " + _descriptive_join(resource["users"]),))
            add_meaning(meaning, "main_functions", source,
                        (DescriptiveSourceSpan(source, 0, len(statement), statement),))
        for meaning in policies:
            add_meaning(meaning, "main_functions", "shared-policy:" + meaning.subject)
        if missing_policy:
            finding("supported_function_coverage", "arbitration policy is not established for "
                    + ", ".join(sorted(missing_policy)), section="3.1", impact="source_policy_clarification")
        owned_blocks = concrete_owner_rows(evidence, domain="digital")
        if owned_blocks:
            source = "approved-snapshot:digital-block-allocation"
            statement = json.dumps(list(owned_blocks), sort_keys=True)
            add_meaning(DescriptiveMeaning("responsibility", "The approved digital block allocation", "cover",
                        tuple(row["owner"] for row in owned_blocks)), "context", source,
                        (DescriptiveSourceSpan(source, 0, len(statement), statement),), optional=True)
        for row in evidence.get("inventory", ()) if document == "DRS" else ():
            if (row["applicable"] and row.get("entity_kind") == "concrete_block"
                    and row["owner"] not in descriptive_functional_roles(evidence)
                    and row not in structural_owner_rows(evidence, domain="digital")
                    and row.get("domains") != ["analog"]
                    and (row.get("scope") != "allocated_owner" or row.get("domains") != ["digital"])):
                finding("section_roles", "concrete block digital ownership is not established; "
                        "purpose obligation requires ownership review",
                        source=row["source"], section="3.1", impact="functional_ownership")
            if (not row["applicable"] or row.get("scope") == "approved_function_boundary"
                    or row.get("domains") not in (None, ["digital"])):
                continue
            for meaning in functional_inventory_meanings(row["owner"], row["statement"]):
                span = DescriptiveSourceSpan(row["source"], 0, len(row["statement"]), row["statement"])
                add_meaning(meaning, "main_functions", row["source"], (span,))
    if document in {"SRS", "DRS"}:
        for row in evidence.get("inventory", ()):
            if row["owner"] in descriptive_functional_roles(evidence):
                for meaning in functional_inventory_meanings("The " + row["owner"] + " role", row["statement"]):
                    add_meaning(meaning, "main_functions", row["source"],
                        (DescriptiveSourceSpan(row["source"], 0, len(row["statement"]), row["statement"]),))
        for domain in ("digital",) if document == "DRS" else ():
            structural = structural_owner_rows(evidence, domain=domain)
            if structural:
                source = "snapshot-structure:" + domain
                statement = json.dumps(list(structural), sort_keys=True)
                add_meaning(DescriptiveMeaning("containment", "The " + domain + " domain", "include",
                    ("the following implementation blocks: " + _descriptive_join(
                        tuple(row["owner"] for row in structural)),)), "organization" if document == "SRS" else "context",
                    source, (DescriptiveSourceSpan(source, 0, len(statement), statement),), optional=True)

    def normal(text):
        return " ".join(_drs_text(text).casefold().split())

    def atoms(text):
        if document == "IPOS":
            forms = {"identifies": "identify", "initiates": "initiate", "communicates": "communicate"}
            text = re.sub(r"\b(?:identifies|initiates|communicates)\b",
                          lambda match: forms[match[0].casefold()], text, flags=re.I)
        return functional_semantic_atoms(text)

    for path in (markdown_path, markdown_path.with_suffix(".docx")):
        if not path.is_file():
            for obligation in obligations:
                finding(obligation, "artifact missing; obligation unchecked", artifact=path.name)
            continue
        sections = descriptive_section_paragraphs(path, policy)
        if document == "IPOS":
            parent = ""
            for event in drs_document_events(path):
                if event["kind"] != "heading":
                    continue
                number = re.match(r"^(\d+(?:\.\d+)*)(?:\.?\s|$)", event["text"])
                if event["level"] <= 3:
                    parent = number[1] if number else ""
                elif number and number[1].startswith("1.4.") and parent != "1.4":
                    finding("section_roles", "functional group is outside section 1.4",
                            section=number[1], artifact=path.name)
        if document == "SRS":
            for proposition, capability in system_mode_capability_projections(evidence):
                claims = (DescriptiveFunctionalClaim("independent-mode-capability", "main_functions",
                                                     (), (capability,), (), ()),)
                if any(not _ipos_readback_section_findings(text, claims) for text in sections.get("3.2", ())):
                    obligations["essential_qualifications"]["checked"] += 1
                    operation_model = abstract_srs_evidence_model(shared_descriptive_evidence_model(
                        evidence.get("shared_records", ()), document="SRS"), structural_evidence=evidence)
                    operation_meanings = tuple(value.meaning for value in operation_model.propositions
                        if functional_meaning_role(value.meaning) in {"behavior", "restriction"})
                    source_outcomes = tuple(meaning for meaning, _spans in
                                            _source_mode_responsibilities(operation_model))
                    variants = (operation_meanings, (*operation_meanings, *source_outcomes))
                    if all(_ipos_readback_section_findings(" ".join(sections.get("3.5", ())),
                            (DescriptiveFunctionalClaim("independent-operating-dependency", "functions",
                                                        (), values, (), proposition.spans),))
                           for values in variants):
                        finding("essential_qualifications", "cross-section operating dependency missing or changed",
                                source=proposition.spans[-1].record_id, section="3.5", artifact=path.name,
                                impact="semantic_fidelity")
        if document in {"SRS", "DRS"} and evidence.get("inventory"):
            target = "3.3" if document == "SRS" else "3"
            for domain in ("digital",) if document == "DRS" else ():
                structural = structural_owner_rows(evidence, domain=domain)
                if not structural:
                    continue
                catalogues = [text for text in sections.get(target, ()) if re.search(
                    r"\b" + re.escape(domain) + r"\s+domain\b.+\bimplementation blocks\s*:", text, re.I)]
                membership_descriptions = [text for values in sections.values() for text in values
                    if re.search(r"\bthe\s+" + re.escape(domain)
                                 + r"\s+domain\s+(?:includes?|comprises?|contains?)\b", text, re.I)]
                if catalogues and len(membership_descriptions) > 1:
                    finding("nonduplication", "domain membership is repeated instead of consolidated",
                            section=target, artifact=path.name, impact="architecture_repetition")
                for row in structural:
                    obligations["supported_function_coverage"]["checked"] += 1
                    if not any(re.search(r"(?<!\w)" + _ipos_phrase_pattern(row["owner"]) + r"(?!\w)", text, re.I)
                               for text in catalogues):
                        finding("supported_function_coverage", "supported structural block missing from domain inventory",
                                source=row["source"], section=target, artifact=path.name, impact="architecture_coverage")
        if document == "DRS":
            if missing_policy and not any(ARBITRATION_POLICY_GAP == text for text in sections.get("3.1", ())):
                finding("supported_function_coverage", "missing arbitration policy clarification is not visible",
                        section="3.1", artifact=path.name, impact="policy_coverage")
            processing_prose = []
            active_processing = False
            for event in drs_document_events(path):
                if event["kind"] == "heading":
                    if event["text"] == "Digital processing blocks":
                        active_processing = True
                    elif active_processing and event["level"] <= 4:
                        active_processing = False
                elif active_processing and event["kind"] == "paragraph" and not event.get("is_list"):
                    processing_prose.append(event["text"])
            processing_expected = []
            for row in structural_owner_rows(evidence, domain="digital"):
                if not bounded_functional_summary(row["statement"]).gap:
                    processing_expected.extend((contribution, row["source"]) for meaning in
                        functional_inventory_meanings(row["owner"], row["statement"])
                        if (contribution := descriptive_processing_contribution(meaning)) is not None)
            if "requirements" in evidence:
                digital_owners = {human_label_key(row["owner"]) for row in structural_owner_rows(evidence, domain="digital")}
                for proposition in document_responsibility_model(evidence, document="DRS").propositions:
                    if (proposition.domain == "digital" and human_label_key(proposition.owner) in digital_owners
                            and "local_activity" in descriptive_context_relationships(
                                proposition.meaning, proposition.owner)
                            and not any(span.record_id.startswith("inventory:") for span in proposition.spans)
                            and descriptive_processing_meaning(proposition.meaning)):
                        contribution = descriptive_processing_contribution(proposition.meaning)
                        if contribution is not None:
                            processing_expected.append((contribution, proposition.spans[0].record_id))
            for meaning, source in dict.fromkeys(processing_expected):
                obligations["supported_function_coverage"]["checked"] += 1
                actor = re.compile(r"(?<!\w)" + _ipos_phrase_pattern(meaning.subject) + r"\s+"
                                   + _ipos_readback_finite_verb_pattern(meaning) + r"\b", re.I)
                if not any(actor.search(text)
                           and all(atoms(value) <= atoms(text) for value in
                                   (*meaning.objects, *meaning.qualifiers, *meaning.results,
                                    *(context.text for context in meaning.contexts),
                                    *((meaning.mode,) if meaning.mode else ())))
                           for text in processing_prose):
                    finding("supported_function_coverage", "supported elaboration contribution missing from processing theme",
                            source=source, section="3.1", artifact=path.name, impact="processing_coverage")
            prose_events = []
            active_purpose_section = False
            for event in drs_document_events(path):
                if event["kind"] == "heading":
                    number = re.match(r"^(\d+(?:\.\d+)*)(?:\.?\s|$)", event["text"])
                    if number:
                        active_purpose_section = number[1] == "3.1" or number[1].startswith("3.1.")
                    elif event["level"] <= 3:
                        active_purpose_section = False
                elif (active_purpose_section and event["kind"] == "paragraph"
                      and not event.get("is_list")):
                    prose_events.append(event["text"])
            for row in structural_owner_rows(evidence, domain="digital"):
                obligations["section_roles"]["checked"] += 1
                meanings = functional_inventory_meanings(row["owner"], row["statement"])
                subjects = re.compile(r"^(?:The\s+)?" + _ipos_phrase_pattern(row["owner"])
                                      + r"(?:\s+block)?\s+", re.I)
                matches = [text for text in prose_events if subjects.search(text)
                           and meanings and not _ipos_readback_section_findings(text, (
                               DescriptiveFunctionalClaim("independent-block-purpose", "purpose",
                                                          (), meanings, (), ()),))]
                if len(matches) != 1:
                    finding("section_roles", "expected one supported concrete block purpose paragraph; found "
                            + str(len(matches)), source=row["source"], section="3.1", artifact=path.name,
                            impact="functional_ownership")
        paragraphs = []
        for section, texts in sections.items():
            for text in texts:
                matched_literal = next(((destination, source) for destination, literal, source in literals
                                        if normal(text) == normal(literal)), None)
                if matched_literal:
                    if section != matched_literal[0]:
                        finding("section_roles", "authorized literal outside its approved destination",
                                source=matched_literal[1], section=section, artifact=path.name)
                    continue
                paragraphs.append((section, text))
        for section, rule in policy["sections"].items():
            obligations["section_roles"]["checked"] += 1
            if rule["required"] and not any(number == section for number, _text in paragraphs):
                finding("section_roles", "required synthesis section has no independently checked prose",
                        section=section, artifact=path.name)
                matching = [item for item in expected if item["role"] in rule["roles"] or (
                    document == "SRS" and functional_meaning_role(item["meaning"]) in rule["roles"])]
                if document == "SRS" and matching:
                    from governed_descriptive_scope import DOCUMENT_SECTIONS
                    authorized = {record["record_id"]: DOCUMENT_SECTIONS["SRS"][record["role"]]
                                  for record in evidence.get("shared_records", ())}
                    gaps[-1]["gap_class"] = ("missing_authorization" if all(
                        item["source"] in authorized and authorized[item["source"]] != section
                        for item in matching) else "missing_supported_projection")
                else:
                    if document == "SRS":
                        gaps[-1]["gap_class"] = ("NOT_CHECKED" if collection_status != "PASS" else
                            "unsupported_interpretation" if any(
                                row.get("review_decision") == "approved" and row.get("domain") == "system"
                                and srs_source_evidence_model(row).unresolved_contexts
                                for row in evidence.get("source_records", ())) else "missing_evidence")
                    else:
                        gaps[-1]["gap_class"] = "missing_evidence_or_supported_interpretation"
        for function in functions:
            if document == "SRS" and evidence.get("function_decomposition"):
                continue
            projection = bounded_functional_summary(function["statement"])
            if not projection.responsibilities:
                continue
            allowed_text = " ".join(text for section, text in paragraphs if any(
                role in policy["sections"][section]["roles"] for role in ("purpose", "main_functions")))
            responsibilities = projection.responsibilities
            if document == "DRS":
                responsibilities = tuple(re.sub(r"^(?:provide|perform)\s+", "", value, flags=re.I)
                                         for value in responsibilities)
            missing = sorted(atoms(" ".join(responsibilities)) - atoms(allowed_text))
            obligations["supported_function_coverage"]["checked"] += 1
            if missing:
                finding("supported_function_coverage", "source functional terms missing: " + ", ".join(missing),
                        source=function["source"], artifact=path.name, impact="functional_coverage")
            if document == "IPOS":
                if ipos_has_local_responsibilities(model, functional):
                    continue
                _macro, activities, _gap = ipos_functional_abstraction(function["statement"])
                capability_text = [text for section, text in paragraphs
                                   if "main_functions" in policy["sections"][section]["roles"]]
                for activity in activities:
                    if not any(atoms(activity).issubset(atoms(text)) for text in capability_text):
                        finding("supported_function_coverage", "separate main-functions synthesis not established: " + activity,
                                source=function["source"], artifact=path.name, impact="functional_coverage")
        recognized = set()
        assignments = {}
        recovered = {}
        if document == "SRS":
            if paragraphs:
                implementation_artifacts_checked.append(path.name)
            for section, text in paragraphs:
                if srs_implementation_syntax(text):
                    implementation_findings.append({"section": section, "artifact": path.name, "text": text})
                    finding("bounded_synthesis", "implementation syntax remains in system-level prose",
                            section=section, artifact=path.name, impact="system_abstraction")
        for item in context_applicability:
            obligations["section_roles"]["checked"] += 1
            if item["applicable"]:
                continue
            source_meaning = item["meaning"]
            for section, text in paragraphs:
                if (re.search(_ipos_phrase_pattern(source_meaning["subject"]), text, re.I)
                        and atoms(" ".join(source_meaning["objects"])).issubset(atoms(text))):
                    finding("section_roles", "shared context has no directly supported local function, boundary or limitation",
                            source=item["source"], section=section, artifact=path.name, impact="functional_ownership")
        for item in expected:
            meaning = item["meaning"]
            verbs = tuple(dict.fromkeys(_ipos_readback_finite_verb_pattern(other["meaning"])
                                       for other in expected if other["meaning"].subject == meaning.subject))
            actor = re.compile(_ipos_phrase_pattern(meaning.subject) + r"\s+(?:"
                               + "|".join(verbs) + r")\b", re.I)
            candidates = []
            for index, (section, text) in enumerate(paragraphs):
                if meaning.mode and not re.search(_ipos_phrase_pattern(meaning.mode), text, re.I):
                    continue
                label = ""
                if meaning.relation == "responsibility":
                    family = re.fullmatch(r"The (.+) responsibility", meaning.subject)
                    if meaning.subject == "The system" and meaning.predicate == "support" and len(meaning.objects) == 1:
                        label = meaning.objects[0]
                    elif meaning.predicate == "comprise" and family:
                        label = family[1]
                headline = bool(label and re.match(_ipos_phrase_pattern(label) + r"\s*:", text, re.I))
                nominal = re.match(_ipos_phrase_pattern(meaning.subject) + r"\s*:", text, re.I)
                if (document == "DRS" and item["source"] in
                        {row["source"] for row in evidence.get("inventory", ())}
                        and not re.match(r"^(?:The\s+)?" + _ipos_phrase_pattern(meaning.subject)
                                         + r"(?:\s+block)?(?:\s|:)", text, re.I)):
                    continue
                supported_actor = any(
                    actor.search(sentence) and atoms(meaning.predicate).issubset(atoms(sentence))
                    and atoms(" ".join(meaning.objects)).issubset(atoms(sentence))
                    and (document != "IPOS" or re.search(
                        r"\b" + _ipos_readback_finite_verb_pattern(meaning) + r"\b", sentence, re.I))
                    for sentence in re.split(r";\s*|(?<=[.!?])\s+(?=[A-Za-z0-9])", text))
                if (headline or (nominal and atoms(" ".join(meaning.objects)).issubset(atoms(text)))
                        or supported_actor):
                    candidates.append((index, section, text))
            obligations["semantic_fidelity"]["checked"] += 1
            obligations["essential_qualifications"]["checked"] += 1
            if not candidates:
                attempted_optional = bool(item["optional"] and meaning.modality and any(
                    re.search(_ipos_phrase_pattern(meaning.subject), text, re.I)
                    and atoms(" ".join(meaning.objects)).issubset(atoms(text))
                    for _section, text in paragraphs))
                if item["optional"] and not attempted_optional:
                    continue
                finding("semantic_fidelity", "admitted functional meaning not independently recovered from prose",
                        source=item["source"], artifact=path.name, impact="functional_coverage")
                finding("essential_qualifications", "qualifications unchecked because the functional meaning is absent",
                        source=item["source"], artifact=path.name, impact="semantic_fidelity")
                if item["role"] in {"main_functions", "behavior", "restriction"}:
                    finding("supported_function_coverage", "supported functional responsibility not recovered",
                            source=item["source"], artifact=path.name, impact="functional_coverage")
                continue
            focused_processing_overlap = (document == "DRS" and len(candidates) == 2
                and candidates[0][2] != candidates[1][2]
                and sum(text in processing_prose for _index, _section, text in candidates) == 1
                and item["source"] in {row["source"] for row in evidence.get("inventory", ())})
            if len(candidates) > 1 and not focused_processing_overlap:
                finding("nonduplication", "same admitted functional meaning repeated in multiple paragraphs",
                        source=item["source"], artifact=path.name)
            for index, section, text in candidates:
                if item["proposition_id"]:
                    recovered.setdefault(item["proposition_id"], set()).add(index)
                recognized.add(index)
                assignments.setdefault(index, []).append(meaning)
                if item["role"] not in policy["sections"][section]["roles"]:
                    finding("section_roles", "source role " + item["role"] + " conflicts with section obligation",
                            source=item["source"], section=section, artifact=path.name)
                    gaps[-1]["gap_class"] = ("missing_authorization"
                        if functional_meaning_role(meaning) in policy["sections"][section]["roles"]
                        and any(record["record_id"] == item["source"] for record in evidence.get("shared_records", ()))
                        else "incorrect_placement")
                mappings.append({"source": item["source"], "spans": item["spans"], "role": item["role"],
                                 "proposition_id": item["proposition_id"],
                                 "meaning": asdict(meaning), "section": section, "artifact": path.name,
                                 "actual_text": text})
        if document == "IPOS":
            for edge in model.dependencies:
                if edge.relation == "referenced_context" and recovered.get(edge.source_id) and not (
                        recovered[edge.source_id] & recovered.get(edge.target_id, set())):
                    finding("essential_qualifications", "essential dependency separated from its retained action",
                            source=edge.dependency_id, artifact=path.name, impact="semantic_fidelity")
        for index, (section, text) in enumerate(paragraphs):
            if index not in recognized:
                finding("semantic_fidelity", "output prose has no independently matched admitted meaning",
                        section=section, artifact=path.name)
            else:
                meanings = tuple(dict.fromkeys(assignments[index]))
                claim = DescriptiveFunctionalClaim("independent-readback", "functions", (), meanings, (), ())
                for reason in _ipos_readback_section_findings(text, (claim,)):
                    source_ids = tuple(dict.fromkeys(item["source"] for item in expected
                                                     if item["meaning"] in meanings))
                    finding("essential_qualifications", reason, source=";".join(source_ids),
                            section=section, artifact=path.name,
                            impact="semantic_fidelity")
            obligations["bounded_synthesis"]["checked"] += 1
            for source in sources:
                if normal(source) and normal(source) in normal(text):
                    finding("bounded_synthesis", "literal source text does not establish a synthesis obligation",
                            section=section, artifact=path.name)
            if (policy["abstraction"] == "system" and section in {"3.1", "3.2"}
                    and re.search(r"\bblock\b", text, re.I)):
                finding("section_roles", "block-local prose does not establish system-level abstraction",
                        section=section, artifact=path.name)
            if policy["abstraction"] == "system" and section == "3.2":
                obligations["section_roles"]["checked"] += 1
                if re.search(r"\bresponsibility comprises\b.+\bacross\b|\b(?:regmap|regbank|registers?)\b"
                             r"|\b[A-Z][A-Z0-9_]*(?:/[A-Z][A-Z0-9_]*)+\s+signaling\b", text, re.I):
                    finding("section_roles", "integration or implementation prose is not a device capability",
                            section=section, artifact=path.name, impact="system_abstraction")
                if re.search(r"\b(?:refers to|describes changes in|emotional arousal)\b", text, re.I):
                    finding("section_roles", "physiological definition does not establish device behavior",
                            section=section, artifact=path.name, impact="system_abstraction")
            if policy["abstraction"] == "system" and section == "3.3":
                obligations["section_roles"]["checked"] += 1
                named = [row["owner"] for row in evidence.get("inventory", ()) if re.search(
                    r"(?<!\w)" + _ipos_phrase_pattern(row["owner"]) + r"(?!\w)", text, re.I)]
                if "implementation blocks:" in text or (len(named) > 1 and re.search(
                        r"\b(?:includes?|comprises?|contains?)\b", text, re.I)):
                    finding("section_roles", "block inventory does not establish domain responsibilities",
                            section=section, artifact=path.name, impact="system_abstraction")
            if document == "DRS" and section == "3" and re.search(
                    r"\b(?:optical transceiver|driven reference|sweat gland|emotional arousal)\b", text, re.I):
                finding("section_roles", "parallel channel description is not a Digital Top objective",
                        section=section, artifact=path.name, impact="digital_integration_abstraction")
            if (re.search(r"\bconfigurable\b|(?<!one-time-)\bprogrammable\b", text, re.I) or
                    not set(policy["sections"][section]["roles"]).intersection({"behavior", "restriction"})
                    and re.search(r"\b(?:regbank|0x[0-9a-f]+)\b", text, re.I)):
                finding("section_roles", "technical/configuration detail in functional prose",
                        section=section, artifact=path.name)
        seen = {}
        for section, text in paragraphs:
            obligations["nonduplication"]["checked"] += 1
            identity = normal(text)
            if identity in seen:
                finding("nonduplication", "duplicate descriptive prose (also " + seen[identity] + ")",
                        section=section, artifact=path.name)
            seen[identity] = section
        for section, literal, source in literals:
            if normal(literal) not in {normal(text) for text in sections.get(section, ())}:
                finding("semantic_fidelity", "authorized literal not preserved at approved destination",
                        source=source, section=section, artifact=path.name)
    for result in obligations.values():
        if not result["checked"] and result["status"] == "PASS":
            result.update(status="NOT_CHECKED", reason="No independently checkable construction")
    abstraction_assessment = {}
    if document == "SRS":
        abstraction_assessment = {
            "implementation_syntax_exclusion": {
                "status": "UNRESOLVED" if implementation_findings else
                    "PASS" if len(implementation_artifacts_checked) == 2 else "NOT_CHECKED",
                "findings": implementation_findings,
                "artifacts_checked": implementation_artifacts_checked,
                "source_decisions": system_abstraction,
            },
            "behavior_and_essential_qualifications": {
                "status": "UNRESOLVED" if any(
                    row["behavior_preservation"] == "unresolved" for row in system_abstraction) or any(
                    obligations[key]["status"] == "UNRESOLVED" for key in
                    ("semantic_fidelity", "essential_qualifications", "supported_function_coverage")) else
                    "PASS" if expected else "NOT_CHECKED",
                "reason": "Independent final-prose readback against applicable source meanings, not syntax absence.",
                "unresolved_source_projections": [
                    row for row in system_abstraction if row["behavior_preservation"] == "unresolved"],
            },
            "section_placement_and_authorization": {
                "status": obligations["section_roles"]["status"],
                "findings": obligations["section_roles"]["findings"],
            },
        }
    return {"document": document, "snapshot_id": evidence.get("snapshot_id", ""),
            "readability": {"status": "NOT_ASSESSED",
                            "reason": "Bounded semantic and structural checks do not certify general readability."},
            "collection_completeness": collection_status,
            "status": "UNRESOLVED" if gaps else "PASS" if all(
                value["status"] == "PASS" for value in obligations.values()) else "NOT_ASSESSED",
            "obligations": obligations, "gaps": gaps, "claim_to_source": mappings,
            "context_applicability": context_applicability,
            **({"meaning_dispositions": assess_srs_meaning_dispositions(
                evidence, mappings, gaps, implementation_artifacts_checked),
                "source_records_examined": "source_records" in evidence,
                "scope_examination": "COMPLETE_APPROVED_SCOPE" if (
                    "source_records" in evidence and collection_status == "PASS") else "NOT CHECKED"}
               if document == "SRS" else {}),
            "system_abstraction_assessment": abstraction_assessment,
            "literal_exceptions": [{"section": section, "source": source, "satisfies_synthesis": False}
                                   for section, _literal, source in literals],
            "abstraction": policy["abstraction"], "synthesis_contract_sha256": policy["contract_sha256"],
            "generation_blocking": False, "authority": False,
            "gate_mapping": "Existing descriptive residuals; no new generation/publication gate. "
                            "Functional/semantic impacts require existing target-specific readiness assessment."}


def load_ipos_contract(template_path: Path) -> dict:
    payload = load_embedded_document_contract(template_path, "IPOS")
    fields = {"version", "document_type", "profile", "mandatory_rules", "sections", "paragraph", "interpretation",
              "synthesis", "detail_policy", "gap_policy", "essential_sources", "rendering", "validation_hooks",
              "descriptive_synthesis", "sha256"}
    if set(payload) != fields or payload["version"] != 1 or payload["profile"] != "block_local_v1":
        raise ValueError("Unsupported IPOS contract schema or profile")
    for field, expected in (
        ("interpretation", "admitted_normative_clauses_v1"), ("synthesis", "explicit_functional_claims_v1"),
        ("detail_policy", "preserve_essential_block_detail_v1"),
        ("gap_policy", "required_sections_with_audited_omissions_v1"),
        ("rendering", "scoped_explanatory_prose_v1"),
    ):
        if payload[field] != expected:
            raise ValueError("IPOS rule without implementation: " + field)
    rules = payload["mandatory_rules"]
    if payload["essential_sources"] != {"purpose": ["inventory:function"],
            "capabilities": ["inventory:main_functions", "inventory:inputs", "inventory:outputs"]}:
        raise ValueError("Unsupported IPOS essential source obligations")
    if not isinstance(rules, list) or any(not isinstance(value, str) for value in rules) or set(rules) != IPOS_CONTRACT_RULES or len(rules) != len(IPOS_CONTRACT_RULES):
        raise ValueError("IPOS mandatory rule missing or unknown")
    hooks = payload["validation_hooks"]
    if hooks != ["semantic_fidelity", "publication_quality", "materialization"]:
        raise ValueError("Invalid IPOS independent validation hooks")
    paragraph = payload["paragraph"]
    if paragraph != {"required": ["responsibility", "supported_behavior"],
                     "when_supported": ["condition", "effect", "result", "dependency", "exception"],
                     "claim_scope": ["initiation", "behavior", "result", "exception", "local_interaction"]}:
        raise ValueError("Unsupported IPOS functional paragraph obligations")
    sections = payload["sections"]
    expected_roles = ["purpose", "capabilities", "organization", "functions", "architecture"]
    if not isinstance(sections, list) or len(sections) != len(expected_roles):
        raise ValueError("Invalid IPOS section obligations")
    for section, role, number in zip(sections, expected_roles, ("1.1", "1.2", "1.3", "1.4", "1.5")):
        if (not isinstance(section, dict) or set(section) != {"role", "title", "required", "information_gain"}
                or section["role"] != role or not isinstance(section["title"], str)
                or not section["title"].startswith(number + " ") or not section["title"][len(number):].strip()
                or section["required"] is not (role in {"purpose", "capabilities"})
                or section["information_gain"] is not True):
            raise ValueError("Unsupported IPOS section role or information-gain obligation")
    validate_descriptive_synthesis_contract(payload)
    return payload


def load_drs_contract(template_path: Path) -> dict:
    """Load the sole DRS presentation contract; reject unsupported instructions."""
    payload = load_embedded_document_contract(template_path, "DRS")
    fields = {"version", "document_type", "mandatory_rules", "sections", "conventions", "navigation", "writing",
              "descriptive_synthesis"}
    if set(payload) != fields | {"sha256"}:
        raise ValueError("Invalid DRS contract fields")
    if type(payload["version"]) is not int or payload["version"] != 1 or payload["document_type"] != "DRS":
        raise ValueError("Unsupported DRS contract version or document type")
    rules = payload["mandatory_rules"]
    if not isinstance(rules, list) or any(not isinstance(rule, str) for rule in rules):
        raise ValueError("Invalid DRS mandatory rules")
    if set(rules) != DRS_RULES or len(rules) != len(DRS_RULES):
        raise ValueError("DRS mandatory rule missing or without implementation")
    for field in ("sections", "navigation"):
        values = payload[field]
        if not isinstance(values, list) or not values or any(not isinstance(value, str) or not value.strip() for value in values) or len(set(values)) != len(values):
            raise ValueError(f"Invalid DRS {field}")
    if [value.split(".", 1)[0] for value in payload["sections"]] != [str(number) for number in range(1, 11)]:
        raise ValueError("Unsupported DRS section renderer or section mapping")
    conventions = payload["conventions"]
    if not isinstance(conventions, dict) or set(conventions) != {"heading", "after", "before", "categories"}:
        raise ValueError("Invalid DRS conventions")
    if (conventions["heading"], conventions["after"], conventions["before"]) != (
        "2.1 Conventions", "2. Definitions and terminology", "3. Top Level Overview"
    ):
        raise ValueError("Unsupported DRS conventions placement")
    categories = conventions["categories"]
    if not isinstance(categories, list) or len(categories) != 4:
        raise ValueError("DRS requires four conventions")
    for category, name in zip(categories, ("Comment", "Definition", "Assumption", "Requirement")):
        if not isinstance(category, dict) or set(category) != {"name", "definition"} or category["name"] != name or not isinstance(category["definition"], str) or not category["definition"].strip():
            raise ValueError("Invalid DRS convention order or definition")
    if payload["writing"] != "evidence_bounded_technical_prose_v1":
        raise ValueError("DRS writing rule without implementation")
    validate_descriptive_synthesis_contract(payload)
    return payload


def ipos_document_contract_report(repo_root: Path, markdown_path: Path, audit_path: Path, functional_input) -> dict:
    from workflow_routing import (
        build_ipos_normalized_records, validate_ipos_descriptive_output,
        _ipos_final_sections, ipos_publication_quality_findings, ipos_derivative_residuals,
    )
    contract = load_ipos_contract(repo_root / IPOS_TEMPLATE)
    semantic = validate_ipos_descriptive_output(markdown_path, audit_path, functional_input.block,
               functional_input.local_requirement_evidence, functional_input.local_requirement_ids, (),
               functional_input, include_publication=False)
    publication = []
    for path in (markdown_path, markdown_path.with_suffix(".docx")):
        if not path.is_file():
            publication.append("missing_final_artifact:" + path.name)
            continue
        publication.extend(path.name + ":" + finding for finding in
                           ipos_publication_quality_findings(_ipos_final_sections(path)))
    materialization = validate_materialization_chain(audit_path.with_name("materialization_audit.json"), "IPOS",
                      build_ipos_normalized_records(functional_input), markdown_path, markdown_path.with_suffix(".docx"))
    boundaries = {"semantic_fidelity": semantic, "publication_quality": publication, "materialization": materialization}
    from validate_downstream_coherence import classify_descriptive_findings
    classified = {hook: classify_descriptive_findings(values) for hook, values in boundaries.items()}
    snapshot = re.search(r"\bSnapshot(?: ID)?:\s*[`*]*([\w-]+)", markdown_path.read_text(encoding="utf-8"), re.I)
    writing = assess_descriptive_synthesis(markdown_path, "IPOS",
               {"functional_input": functional_input, "snapshot_id": snapshot[1] if snapshot else ""},
               repo_root=repo_root)
    return {"document_type": "IPOS", "contract_sha256": contract["sha256"],
            "status": "FAIL" if any(value["hard_findings"] for value in classified.values()) else "PASS",
            "residuals": ipos_derivative_residuals(functional_input) + writing["gaps"]
                         + [row for value in classified.values() for row in value["residuals"]],
            "generation_status": "GENERATED",
            "publication_status": "ELIGIBLE" if not any(value["hard_findings"] for value in classified.values()) else "BLOCKED",
            "readiness_status": "NOT_ASSESSED",
            "writing_quality": writing,
            "checks": {hook: {"status": "FAIL" if classified[hook]["hard_findings"] else "PASS", "findings": classified[hook]["hard_findings"]}
                       for hook in contract["validation_hooks"]}}


def validate_ipos_document_contract(repo_root: Path, markdown_path: Path, audit_path: Path, functional_input) -> list[str]:
    try:
        report = ipos_document_contract_report(repo_root, markdown_path, audit_path, functional_input)
    except (OSError, ValueError, TypeError, KeyError, zipfile.BadZipFile, ET.ParseError) as error:
        return ["ipos_document_contract_invalid:" + str(error)]
    return ["ipos_contract:" + hook + ":" + finding for hook, result in report["checks"].items()
            for finding in result["findings"]]


def drs_conventions_markdown(contract: dict) -> list[str]:
    lines = ["### " + contract["conventions"]["heading"], ""]
    for category in contract["conventions"]["categories"]:
        lines.extend(["#### " + category["name"], "", " ".join(category["definition"].split()), ""])
    return lines


def _drs_text(value: str) -> str:
    value = re.sub(r"\[([^\]]+)\]\([^)]+\)", r"\1", value)
    value = re.sub(r"\s*\{#[^}]+\}", "", value).replace("**", "")
    return " ".join(value.split())


def markdown_table_cells(line: str) -> list[str]:
    return [_drs_text(cell.replace(r"\|", "|"))
            for cell in re.split(r"(?<!\\)\|", line.strip().strip("|"))]


def drs_document_events(path: Path) -> list[dict]:
    """Read actual headings, paragraphs and editable tables, in document order."""
    events = []
    if path.suffix == ".md":
        return drs_markdown_events(path.read_text(encoding="utf-8"))
    else:
        word = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
        with zipfile.ZipFile(path) as archive:
            body = ET.fromstring(archive.read("word/document.xml")).find(word + "body")
        if body is None:
            raise ValueError("DOCX body missing")
        for element in body:
            if element.tag == word + "tbl":
                rows = [[_drs_text(" ".join("".join(node.text or "" for node in paragraph.iter(word + "t")) for paragraph in cell.iter(word + "p")))
                         for cell in row.findall(word + "tc")] for row in element.findall(word + "tr")]
                events.append({"kind": "table", "rows": rows})
            elif element.tag == word + "p":
                text = _drs_text("".join(node.text or "" for node in element.iter(word + "t")))
                if not text:
                    continue
                style = element.find(word + "pPr/" + word + "pStyle")
                heading = re.fullmatch(r"Heading([1-6])", style.get(word + "val", ""), re.I) if style is not None else None
                event = ({"kind": "heading", "level": int(heading[1]), "text": text} if heading
                         else {"kind": "paragraph", "text": text})
                if not heading and (element.find(word + "pPr/" + word + "numPr") is not None
                                    or style is not None and re.match(r"List", style.get(word + "val", ""), re.I)
                                    or re.match(r"^\s*(?:[-*+]\s+|\d+[.)]\s+)", text)):
                    event["is_list"] = True
                events.append(event)
    return events


def drs_markdown_events(text: str) -> list[dict]:
    events = []
    in_table = False
    for line in text.splitlines():
        if not line.strip() or line.startswith("<"):
            in_table = False
            continue
        heading = re.match(r"^(#{1,6})\s+(.+)$", line)
        if heading:
            events.append({"kind": "heading", "level": len(heading[1]), "text": _drs_text(heading[2])})
        elif line.startswith("|"):
            if re.fullmatch(r"[| :\-]+", line):
                continue
            cells = markdown_table_cells(line)
            if not in_table:
                events.append({"kind": "table", "rows": []})
            events[-1]["rows"].append(cells)
            in_table = True
        else:
            event = {"kind": "paragraph", "text": _drs_text(line)}
            if re.match(r"^\s*(?:[-*+]\s+|\d+[.)]\s+)", line):
                event["is_list"] = True
            events.append(event)
        if not line.startswith("|"):
            in_table = False
    return events


def preserve_drs_overview_tables(lines: list[str], baseline: list[dict]) -> list[str]:
    """Retain explicit pre-pilot tables as presentation, never as evidence for new prose."""
    actual = drs_table_inventory(drs_markdown_events("\n".join(lines)))
    for row in actual:
        if row not in baseline:
            raise ValueError("Generated DRS overview table differs from its explicit preservation baseline: "
                             + row["owner"])
    result = list(lines)
    remaining = list(actual)
    for index, table in enumerate(baseline):
        if table in remaining:
            remaining.remove(table)
            continue
        owner_pattern = re.compile(r"^#{1,6}\s+" + re.escape(table["owner"]) + r"$")
        owner = next((number for number, line in enumerate(result) if owner_pattern.fullmatch(line)), None)
        if owner is not None:
            level = len(result[owner]) - len(result[owner].lstrip("#"))
            insertion = next((number for number in range(owner + 1, len(result))
                              if re.match(r"^#{1," + str(level) + r"}\s", result[number])), len(result))
            heading = []
        else:
            following = {row["owner"] for row in baseline[index + 1:]}
            insertion = next((number for number, line in enumerate(result)
                              if re.sub(r"^#{1,6}\s+", "", line) in following), len(result))
            heading = ["#### " + table["owner"], ""]
        rows = ["| " + " | ".join(cell.replace("|", r"\|") for cell in row) + " |"
                for row in table["rows"]]
        if not rows:
            raise ValueError("Empty DRS preservation table")
        rows.insert(1, "|" + "---|" * len(table["rows"][0]))
        result[insertion:insertion] = [*heading, *rows, ""]
    if drs_table_inventory(drs_markdown_events("\n".join(result))) != baseline:
        raise ValueError("DRS overview table order or owner association differs from its preservation baseline")
    return result


def drs_table_inventory(events: list[dict]) -> list[dict]:
    owner = ""
    result = []
    for event in events:
        if event["kind"] == "heading":
            owner = event["text"]
        elif event["kind"] == "table":
            result.append({"owner": owner, "rows": event["rows"]})
    return result


def capture_drs_preservation_baseline(markdown: Path, docx: Path, destination: Path, snapshot_id: str) -> None:
    """Explicit one-time baseline capture; never silently refresh it during generation."""
    payload = {"snapshot_id": snapshot_id, "markdown_sha256": file_sha256(markdown), "docx_sha256": file_sha256(docx)}
    for name, path in (("markdown", markdown), ("docx", docx)):
        payload[name] = drs_table_inventory(drs_document_events(path))
    with destination.open("x", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)


def validate_drs_events(
    events: list[dict], contract: dict, baseline_tables: list[dict], *,
    verified_shared_paragraphs: Mapping[str, set[str]] | None = None,
) -> list[str]:
    findings = []
    headings = [event["text"] for event in events if event["kind"] == "heading"]
    top = [event["text"] for event in events if event["kind"] == "heading" and event["level"] == 2 and re.match(r"^[1-9]\d*\. ", event["text"])]
    if top != contract["sections"]:
        findings.append("structure: top-level section order/content differs from template")
    for title in contract["navigation"]:
        if headings.count(title) != 1:
            findings.append(f"navigation: missing or duplicate {title}")
    toc_start = next((index for index, event in enumerate(events) if event.get("text") == "0.1 Table of contents" and event["kind"] == "heading"), None)
    toc_end = next((index for index, event in enumerate(events) if event.get("text") == "0.2 Internal index for paragraphs and pages" and event["kind"] == "heading"), None)
    if toc_start is None or toc_end is None or toc_start >= toc_end:
        findings.append("navigation: invalid TOC placement")
    else:
        entries = {re.sub(r"^-\s+", "", event.get("text", "")) for event in events[toc_start + 1:toc_end]}
        expected_entries = {title for title in headings if re.match(r"^[1-9]\d*\.", title)}
        for title in sorted(expected_entries - entries):
            findings.append(f"navigation: TOC entry missing: {title}")
    conventions = contract["conventions"]
    positions = [index for index, event in enumerate(events) if event["kind"] == "heading" and event["text"] == conventions["heading"]]
    if len(positions) != 1:
        findings.append("conventions: missing or duplicate Conventions")
    else:
        position = positions[0]
        prior_headings = [event["text"] for event in events[:position] if event["kind"] == "heading"]
        if not prior_headings or prior_headings[-1] != conventions["after"]:
            findings.append("conventions: must be the first subsection under Definitions and terminology")
        expected = []
        for category in conventions["categories"]:
            expected.extend([{"kind": "heading", "level": 4, "text": category["name"]}, {"kind": "paragraph", "text": _drs_text(category["definition"])}])
        actual = events[position + 1:position + 1 + len(expected)]
        if actual != expected:
            findings.append("conventions: category content/order differs from template")
        following = events[position + 1 + len(expected):position + 2 + len(expected)]
        if not following or following[0].get("text") != conventions["before"] or following[0]["kind"] != "heading":
            findings.append("conventions: must end before the next top-level section")
        parent = next((event for event in reversed(events[:position]) if event["kind"] == "heading" and event["level"] == 2), None)
        if events[position]["level"] != 3 or not parent or parent["text"] != conventions["after"]:
            findings.append("conventions: 2.1 must be a subsection of Definitions and terminology")
    for category in conventions["categories"]:
        if sum(event.get("text") == _drs_text(category["definition"]) for event in events) != 1:
            findings.append(f"conventions: missing or duplicate definition {category['name']}")
    actual_tables = drs_table_inventory(events)
    remaining = Counter(stable_payload_hash(table) for table in actual_tables)
    for table in baseline_tables:
        if table["owner"] == "0.4 Table of tables":
            candidates = [item for item in actual_tables if item["owner"] == table["owner"]]
            expected_rows = table["rows"]
            known = {row[0] for row in expected_rows[1:]}
            known.update(match[1] for item in baseline_tables
                         if (match := re.match(r"^(Table \d+)\. ", item["owner"])))
            additions = []
            for title in headings:
                caption = re.fullmatch(r"(Table \d+)\. (.+)", title)
                if caption and caption[1] not in known:
                    additions.append([caption[1], caption[2], "Go to " + caption[1]])
            actual_rows = candidates[0]["rows"] if len(candidates) == 1 else []
            if (len(candidates) != 1 or actual_rows != expected_rows + additions
                    or len({row[0] for row in additions}) != len(additions)):
                findings.append("navigation: table index rows changed or additions lack unique actual captions")
            continue
        if table["owner"] == "Table 1. Version history":
            candidates = [item for item in actual_tables if item["owner"] == table["owner"]]
            if len(candidates) != 1 or candidates[0]["rows"][:len(table["rows"])] != table["rows"]:
                findings.append("table_preservation: previous version history rows removed, changed or reordered")
            continue
        if table["owner"] == "Table 3. Section navigation index":
            candidates = [item for item in actual_tables if item["owner"] == table["owner"]]
            def normalize_navigation_row(row):
                if row and row[0] == "3. System context for digital behavior":
                    return ["3. Top Level Overview", *row[1:]]
                return [clean_publication_title(value) for value in row]
            expected_rows = [normalize_navigation_row(row) for row in table["rows"]]
            actual_rows = [normalize_navigation_row(row) for row in candidates[0]["rows"]] if len(candidates) == 1 else []
            if len(candidates) != 1 or any(row not in actual_rows for row in expected_rows):
                findings.append("navigation: existing index rows removed or changed")
            continue
        projected_table = {"owner": clean_publication_title(table["owner"]),
                   "rows": [[clean_descriptive_review_text(value) for value in row] for row in table["rows"]]}
        key = stable_payload_hash(projected_table)
        if remaining[key] < 1:
            findings.append(f"table_preservation: table changed or missing under {table['owner']}")
        else:
            remaining[key] -= 1
    navigation_tables = [table for table in actual_tables if table["owner"] == "Table 3. Section navigation index"]
    if not navigation_tables or not any(row[0] == conventions["heading"] and row[1] == "2.1" for row in navigation_tables[0]["rows"] if len(row) > 1):
        findings.append("navigation: 2.1 Conventions missing from internal index")
    if navigation_tables:
        numbers = [tuple(int(part) for part in row[1].split(".")) for row in navigation_tables[0]["rows"]
                   if len(row) > 1 and re.fullmatch(r"\d+(?:\.\d+)*", row[1])]
        if numbers != sorted(numbers):
            findings.append("navigation: internal index is not in numerical order")
    from workflow_routing import drs_section_prose_findings
    active = ""
    phase = 0
    for event in events:
        if event["kind"] == "heading":
            match = re.match(r"^(\d+(?:\.\d+)*)\.?\s", event["text"])
            if match:
                active = match[1]
            phase = 0
            continue
        if active not in {"1.2", "3", "3.1", "4.2", "4.3", "4.4", "4.5", "4.6", "4.7", "7"}:
            continue
        if event["kind"] == "table":
            if phase == 2:
                findings.append(f"technical_prose: {active}: table after clarification")
            phase = max(phase, 1)
            continue
        text = event["text"]
        findings.extend(f"technical_prose: {active}: {item}" for item in drs_section_prose_findings(text))
        verified_context = literal_publication_text(text) in (verified_shared_paragraphs or {}).get(active, set())
        if (not verified_context
                and re.search(r"\[(?:TO:|Vpriority|[A-Z]+[_-]REQ)|:\s*[•]\s*|(?:->.*){2,}", text)):
            findings.append(f"technical_prose: {active}: raw snippet or path concatenation")
        if "need clarification" in text.casefold() or "requiring clarification" in text.casefold():
            phase = 2
        elif not text.endswith(":"):
            if phase:
                findings.append(f"technical_prose: {active}: known behavior must precede tables and clarification")
    return list(dict.fromkeys(findings))


def arrange_drs_contract_lines(lines: list[str], contract: dict) -> list[str]:
    """Arrange existing semantic content without altering technical evidence or tables."""
    context_start = next((index for index, line in enumerate(lines) if line.startswith("## 6.4 ")), None)
    if context_start is not None:
        context_end = next(index for index in range(context_start + 1, len(lines)) if lines[index].startswith("## 10. "))
        context = ["#" + line if line.startswith(("## ", "### ")) else line for line in lines[context_start:context_end]]
        del lines[context_start:context_end]
        insertion = next(index for index, line in enumerate(lines) if line.startswith("## 7. "))
        lines[insertion:insertion] = context
    starts = [index for index, line in enumerate(lines) if re.match(r"^## [1-9]\d*\. ", line)]
    chunks = {re.match(r"^## (\d+)\.", lines[start])[1]: lines[start:end] for start, end in zip(starts, starts[1:] + [len(lines)])}
    ordered = lines[:starts[0]]
    for title in contract["sections"]:
        number = title.split(".", 1)[0]
        if number not in chunks:
            raise ValueError(f"DRS section has no renderer: {title}")
        chunk = chunks.pop(number)
        chunk[0] = "## " + title
        ordered.extend(chunk)
    if chunks:
        raise ValueError("DRS contract omits implemented sections")
    result = []
    active = ""
    chunk = []

    def flush():
        if active not in {"1.2", "3", "3.1", "4.2", "4.3", "4.4", "4.5", "4.6", "4.7", "7"}:
            result.extend(chunk)
            return
        known, tables, clarifications = [], [], []
        for line in chunk:
            if not line.strip():
                tables.append("")
                continue
            if line.startswith("|") or line.endswith(":"):
                tables.append(line)
            elif "need clarification" in line.casefold() or "requiring clarification" in line.casefold():
                if clean_descriptive_review_text(line):
                    known.append(line)
                else:
                    clarifications.append(line)
            else:
                known.append(line)
        result.extend(known + [""] + tables + [""] + clarifications + [""])

    for line in ordered:
        if line.startswith("#"):
            flush()
            chunk = []
            result.append(line)
            match = re.match(r"^#+ (\d+(?:\.\d+)*)\.?\s", line)
            if match:
                active = match[1]
        else:
            chunk.append(line)
    flush()
    return result


def validate_drs_document_contract(
    repo_root: Path, *, check_metadata: bool = True, snapshot_id: str | None = None,
) -> list[str]:
    """Shared final-artifact gate, called by DRS crosscheck and central coherence."""
    root = repo_root / "artifacts/stage5_drs"
    try:
        contract = load_drs_contract(repo_root / DRS_TEMPLATE)
        baseline_path = root / "drs_preservation_baseline.json"
        baseline = json.loads(baseline_path.read_text(encoding="utf-8"))
        findings = validate_clean_document_presentation(root / "digital_requirements_specification.md")
        verified_context = {}
        if snapshot_id is not None:
            from workflow_routing import verified_shared_descriptive_paragraphs
            verified_context, shared_findings = verified_shared_descriptive_paragraphs(
                repo_root, root / "digital_requirements_specification.md",
                document="DRS", snapshot_id=snapshot_id)
            findings.extend(shared_findings)
        for kind, suffix in (("markdown", ".md"), ("docx", ".docx")):
            path = root / ("digital_requirements_specification" + suffix)
            events = drs_document_events(path)
            findings.extend(f"{kind}: {finding}" for finding in validate_drs_events(
                events, contract, baseline[kind], verified_shared_paragraphs=verified_context))
            snapshots = [event["text"].split("Snapshot ID:", 1)[1].strip() for event in events if event.get("text", "").startswith("Snapshot ID:")]
            if len(snapshots) != 1 or not snapshots[0]:
                findings.append(f"{kind}: missing or duplicate document snapshot")
            elif snapshot_id is not None and snapshots[0] != snapshot_id:
                findings.append(f"{kind}: document snapshot differs from selected snapshot")
        markdown_path = root / "digital_requirements_specification.md"
        markdown = markdown_path.read_text(encoding="utf-8")
        anchors = set(re.findall(r"\{#([^}]+)\}", markdown))
        targets = set(re.findall(r"\]\(#([^)]+)\)", markdown))
        if targets - anchors:
            findings.append("navigation: unresolved Markdown internal targets")
        docx_path = markdown_path.with_suffix(".docx")
        word = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
        with zipfile.ZipFile(docx_path) as archive:
            document = ET.fromstring(archive.read("word/document.xml"))
        bookmarks = {node.get(word + "name") for node in document.iter(word + "bookmarkStart")}
        docx_targets = {node.get(word + "anchor") for node in document.iter(word + "hyperlink") if node.get(word + "anchor")}
        if docx_targets - bookmarks:
            findings.append("navigation: unresolved DOCX internal targets")
        from workflow_routing import validate_ipos_docx_layout
        findings.extend(validate_ipos_docx_layout(docx_path))
        if check_metadata:
            metadata = json.loads((root / "drs_document_contract.json").read_text(encoding="utf-8"))
            expected = drs_contract_metadata(repo_root, contract)
            if not isinstance(metadata, dict) or _drs_integrity_metadata(metadata) != _drs_integrity_metadata(expected):
                findings.append("artifact_fidelity: contract metadata or final artifact hash mismatch")
        return findings
    except (OSError, ValueError, KeyError, TypeError, ET.ParseError, zipfile.BadZipFile, yaml.YAMLError) as exc:
        return [f"document_contract: {exc}"]


def _drs_integrity_metadata(metadata: dict) -> dict:
    # Writing residuals are not an artifact-integrity gate, including for older artifacts.
    integrity = {key: value for key, value in metadata.items() if key != "writing_quality"}
    rules = integrity.get("rules")
    if isinstance(rules, dict) and rules.get("technical_prose") == "UNRESOLVED":
        integrity["rules"] = {**rules, "technical_prose": "PASS"}
    return integrity


def drs_contract_metadata(repo_root: Path, contract: dict) -> dict:
    from run_drs_gen_spec_agent import drs_synthesis_rows
    from workflow_routing import document_descriptive_writing_quality

    root = repo_root / "artifacts/stage5_drs"
    writing = document_descriptive_writing_quality(
        root / "digital_requirements_specification.md", "DRS", drs_synthesis_rows(repo_root), repo_root=repo_root)
    return {
        "version": contract["version"], "template_sha256": contract["sha256"],
        "preservation_baseline_sha256": file_sha256(root / "drs_preservation_baseline.json"),
        "markdown_sha256": file_sha256(root / "digital_requirements_specification.md"),
        "docx_sha256": file_sha256(root / "digital_requirements_specification.docx"),
        "rules": {rule: "UNRESOLVED" if rule == "technical_prose" and writing["status"] != "PASS" else "PASS"
                  for rule in contract["mandatory_rules"]},
        "writing_quality": writing,
    }

def resolve_ipos_description_policy(repo_root: Path, snapshot_id: str, kind: str, block: str) -> str:
    """Resolve a presentation-only pilot without changing approved scope or ownership."""
    path = repo_root / "config/ipos_description_pilots.json"
    if not path.exists():
        return "legacy"
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict) or set(payload) != {"version", "pilots"} or payload["version"] != 1:
        raise ValueError("Invalid IPOS description pilot configuration")
    pilots = payload["pilots"]
    if not isinstance(pilots, list):
        raise ValueError("IPOS description pilots must be a list")
    identities = set()
    selected = "legacy"
    for pilot in pilots:
        if not isinstance(pilot, dict) or set(pilot) != {"snapshot_id", "kind", "block", "policy"}:
            raise ValueError("Invalid IPOS description pilot selector")
        if any(not isinstance(value, str) or not value.strip() for value in pilot.values()):
            raise ValueError("IPOS description pilot selectors must be nonempty strings")
        if pilot["kind"] not in {"digital", "analog"} or pilot["policy"] != IPOS_DETAIL_POLICY:
            raise ValueError("Unsupported IPOS description pilot policy or domain")
        identity = (pilot["snapshot_id"], pilot["kind"], pilot["block"])
        if identity in identities:
            raise ValueError("Duplicate IPOS description pilot selector")
        identities.add(identity)
        if identity == (snapshot_id, kind, block):
            selected = pilot["policy"]
    return selected


@dataclass(frozen=True)
class DocumentTypeContract:
    """Authority and projection boundary for one generated document type."""

    key: str
    authority_sources: tuple[str, ...]
    discovery_sources: tuple[str, ...]
    abstraction_level: str
    ownership_scope: str
    required_sections: tuple[str, ...]
    promotion_rule: str
    suppression_rule: str


DOCUMENT_TYPE_CONTRACTS: Mapping[str, DocumentTypeContract] = {
    "SRS": DocumentTypeContract(
        key="SRS",
        authority_sources=("approved system-scoped snapshot requirements",),
        discovery_sources=("approved vocabulary and structural context",),
        abstraction_level="system behavior and externally observable capability",
        ownership_scope="system",
        required_sections=("requirements", "traceability"),
        promotion_rule="retain only approved system-owned content",
        suppression_rule="suppress architecture implementation and block-local detail",
    ),
    "ARS": DocumentTypeContract(
        key="ARS",
        authority_sources=("approved analog or mixed-signal snapshot requirements",),
        discovery_sources=("approved interface and architecture context",),
        abstraction_level="analog and mixed-signal architecture",
        ownership_scope="top analog and analog integration",
        required_sections=("requirements", "traceability"),
        promotion_rule="retain only approved analog or mixed-signal architecture content",
        suppression_rule="suppress system-only and unrelated block-local detail",
    ),
    "DRS": DocumentTypeContract(
        key="DRS",
        authority_sources=("approved top-digital and digital-integration snapshot requirements",),
        discovery_sources=("approved interface and architecture context",),
        abstraction_level="top-digital architecture and integration",
        ownership_scope="top digital and digital integration",
        required_sections=("requirements", "traceability"),
        promotion_rule="retain only approved top-digital or integration content",
        suppression_rule="suppress system-only and block-local implementation detail",
    ),
    "IPOS": DocumentTypeContract(
        key="IPOS",
        authority_sources=(
            "approved block inventory function and I/O",
            "approved same-block snapshot requirements",
        ),
        discovery_sources=("complete snapshot-scoped candidate requirement set",),
        abstraction_level="block-local purpose, capability, interface, and requirement detail",
        ownership_scope="one approved concrete block",
        required_sections=("functionality", "supported_functions_and_scope", "source_io", "requirements"),
        promotion_rule="retain supported same-block content within the approved block function and I/O boundary",
        suppression_rule="suppress cross-scope, conflicting, unsupported, table-only, signal-only, and non-projectable normative candidates",
    ),
}


def _json_compatible(value: object) -> object:
    return json.loads(json.dumps(value, sort_keys=True, ensure_ascii=True))


@dataclass(frozen=True)
class NormalizedSourceRecord:
    """One classified input candidate, including retained or suppressed rationale."""

    record_id: str
    text: str
    authority_tier: str
    ownership_scope: str
    provenance: tuple[str, ...]
    decision: str
    rationale: str


@dataclass(frozen=True)
class SemanticUnit:
    """One ordered semantic unit emitted by a deterministic composer."""

    unit_id: str
    section: str
    text: str
    source_record_ids: tuple[str, ...]
    output_order: int


def stable_payload_hash(payload: object) -> str:
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def normalized_record_hash(records: Sequence[NormalizedSourceRecord]) -> str:
    return stable_payload_hash([asdict(record) for record in records])


def write_materialization_audit(
    path: Path,
    document_type: str,
    records: Sequence[NormalizedSourceRecord],
    units: Sequence[SemanticUnit],
    markdown_path: Path,
    docx_path: Path,
) -> None:
    """Record the approved-input-to-final-artifact chain after post-processing."""
    contract = DOCUMENT_TYPE_CONTRACTS[document_type]
    payload = {
        "contract_version": CONTRACT_VERSION,
        "document_type": document_type,
        "document_contract": asdict(contract),
        "normalized_input_sha256": normalized_record_hash(records),
        "normalized_records": [asdict(record) for record in records],
        "semantic_units": [asdict(unit) for unit in units],
        "markdown": {"path": markdown_path.name, "sha256": file_sha256(markdown_path)},
        "docx": {"path": docx_path.name, "sha256": file_sha256(docx_path)},
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def literal_publication_text(value: str) -> str:
    """Normalize publishing typography/spacing without folding identifier case."""
    value = value.replace("\u2018", "'").replace("\u2019", "'").replace("\u201c", '"').replace("\u201d", '"')
    return re.sub(r"\s+", " ", value).strip()


def _normalized_text(value: str) -> str:
    without_bold_markup = re.sub(r"\*\*([^*]+)\*\*", r"\1", value)
    return literal_publication_text(without_bold_markup).casefold()


def docx_body_text(docx_path: Path) -> str:
    """Extract final DOCX body text without depending on the composer or renderer."""
    namespace = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
    with zipfile.ZipFile(docx_path) as archive:
        root = ET.fromstring(archive.read("word/document.xml"))
    paragraphs = []
    for paragraph in root.iter(f"{namespace}p"):
        paragraphs.append("".join(node.text or "" for node in paragraph.iter(f"{namespace}t")))
    return "\n".join(paragraphs)


def validate_materialization_chain(
    audit_path: Path,
    document_type: str,
    expected_records: Sequence[NormalizedSourceRecord],
    markdown_path: Path,
    docx_path: Path,
) -> list[str]:
    """Independently validate normalized inputs, audit, Markdown, and final DOCX."""
    findings: list[str] = []
    if not audit_path.exists():
        return [f"{audit_path.name}: materialization audit is missing"]
    if not markdown_path.exists() or not docx_path.exists():
        return [f"{audit_path.name}: audited Markdown or DOCX artifact is missing"]
    try:
        payload = json.loads(audit_path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        return [f"{audit_path.name}: invalid materialization audit: {exc}"]
    if payload.get("contract_version") != CONTRACT_VERSION:
        findings.append(f"{audit_path.name}: contract version mismatch")
    if payload.get("document_type") != document_type:
        findings.append(f"{audit_path.name}: document type mismatch")
    if payload.get("document_contract") != _json_compatible(asdict(DOCUMENT_TYPE_CONTRACTS[document_type])):
        findings.append(f"{audit_path.name}: document contract mismatch")
    expected_hash = normalized_record_hash(expected_records)
    if payload.get("normalized_input_sha256") != expected_hash:
        findings.append(f"{audit_path.name}: normalized input fingerprint mismatch")
    if payload.get("normalized_records") != _json_compatible([asdict(record) for record in expected_records]):
        findings.append(f"{audit_path.name}: normalized input records differ from approved inputs")
    if payload.get("markdown", {}).get("sha256") != file_sha256(markdown_path):
        findings.append(f"{markdown_path.name}: content changed after audited materialization")
    if payload.get("docx", {}).get("sha256") != file_sha256(docx_path):
        findings.append(f"{docx_path.name}: content changed after audited post-processing")

    units = payload.get("semantic_units") or []
    expected_order = list(range(1, len(units) + 1))
    if [unit.get("output_order") for unit in units] != expected_order:
        findings.append(f"{audit_path.name}: semantic unit order is incomplete or unstable")
    record_by_id = {record.record_id: record for record in expected_records}
    represented_record_ids = {
        str(source_id)
        for unit in units
        for source_id in (unit.get("source_record_ids") or ())
    }
    missing_retained = [
        record.record_id
        for record in expected_records
        if record.decision == "retained" and record.record_id not in represented_record_ids
    ]
    if missing_retained:
        findings.append(
            f"{audit_path.name}: retained normalized inputs lack semantic units: "
            + ", ".join(missing_retained)
        )
    markdown = _normalized_text(markdown_path.read_text(encoding="utf-8", errors="replace"))
    docx = _normalized_text(docx_body_text(docx_path))
    markdown_units = markdown
    if document_type == "IPOS":
        markdown_units = _normalized_text(" ".join(
            cell for event in drs_document_events(markdown_path)
            for cell in ([cell for row in event["rows"] for cell in row]
                         if event["kind"] == "table" else [event["text"]])))
    markdown_position = -1
    docx_position = -1
    for unit in units:
        unit_id = str(unit.get("unit_id") or "").strip()
        text = str(unit.get("text") or "")
        if document_type == "IPOS" and text.startswith("|"):
            text = " ".join(cell for line in text.splitlines() for cell in markdown_table_cells(line))
        unit_text = _normalized_text(text)
        source_ids = tuple(unit.get("source_record_ids") or ())
        if not unit_id or not unit_text or not source_ids:
            findings.append(f"{audit_path.name}: semantic unit lacks identity, text, or provenance")
            continue
        if any(source_id not in record_by_id for source_id in source_ids):
            findings.append(f"{audit_path.name}: semantic unit references an unknown source record")
        if any(record_by_id[source_id].decision == "suppressed" for source_id in source_ids if source_id in record_by_id):
            findings.append(f"{audit_path.name}: semantic unit promotes a suppressed source record")
        next_markdown_position = markdown_units.find(unit_text, markdown_position + 1)
        next_docx_position = docx.find(unit_text, docx_position + 1)
        if next_markdown_position < 0:
            findings.append(f"{markdown_path.name}: selected semantic unit missing or reordered: {unit_id}")
        else:
            markdown_position = next_markdown_position
        if next_docx_position < 0:
            findings.append(f"{docx_path.name}: selected semantic unit missing or reordered: {unit_id}")
        else:
            docx_position = next_docx_position
    retained_texts = {
        _normalized_text(record.text)
        for record in expected_records
        if record.decision == "retained" and record.text
    }
    for record in expected_records:
        normalized_record_text = _normalized_text(record.text)
        suppressed_tokens = re.findall(r"[a-z0-9]+", normalized_record_text)
        if (
            record.decision == "suppressed"
            and normalized_record_text
            and len(suppressed_tokens) >= 2
            and len(normalized_record_text) >= 16
            and normalized_record_text not in retained_texts
            and normalized_record_text in markdown
        ):
            findings.append(f"{markdown_path.name}: suppressed source content was rendered: {record.record_id}")
    return findings