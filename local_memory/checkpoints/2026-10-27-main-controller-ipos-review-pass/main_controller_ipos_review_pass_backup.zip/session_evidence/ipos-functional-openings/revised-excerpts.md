# IPOS explanatory-composition pilot

Snapshot: `snap-8b3673edc9cf590589b8ab39`. Isolated review output, not official publication.

### **1.1 Functionality** {#11-functionality}

The Main Controller block provides generation and reception of Analog Domain control signals, DSP elaboration on ADC outputs and writing of elaborated results to the defined addresses.

### **1.2 Supported functions and scope** {#12-supported-functions-and-scope}

Configuration, lifecycle and status covers state progression, configuration updates, operating-parameter selection, completion-dependent sequencing, clocked operation, timed control-output updates and operating restrictions. Channel acquisition and BIO-path coordination covers state progression and timed control-output updates. Sampling, conversion and calibration covers operating-parameter selection, timing definition, clocked operation, calibration precedence, completion-dependent data capture, control-pulse timing and timed control-output updates. PPG acquisition and control covers state progression, timed control-output updates, calibration precedence, completion-dependent sequencing and peer-operation initiation. BIA acquisition and control covers operating-state restrictions, measurement startup, counted acquisition sequencing and timed control-output updates. ECG acquisition and control covers timed control-output updates, counted acquisition sequencing, state progression and operating-state restrictions. GSR acquisition and control covers sampling-preparation timing and acquisition scheduling. Digital-ramp control covers reference-step control, operating-parameter selection, timed control-output updates and peer-operation initiation. Result processing covers sample accumulation, sample averaging, averaging and difference formation, repeated-frame result formation and measurement sampling. Storage behavior covers result transfer. Power, clock and reset coordination covers timed control-output updates, reset and restart handling, source-controlled signal generation and state progression.

Device_FSM identifies the working state of the device.

Elab_FSM identifies which signal is in elaboration and checks and generates signals from and for the Analog Domain. Elab_FSM initiates writes to the AHB Crossbar and communicates with Hardware DSP blocks such as the Avarage Circuit and ADSP, or starts PPG operation by communicating with the PPG_FSM.

The Main Controller block accepts configuration register settings, sampled data and produces control state and data routing.

### **1.4 Supported block functions** {#14-supported-block-functions}

#### **1.4.1 Configuration, lifecycle and status** {#141-configuration-lifecycle-and-status}

Device_FSM coordinates progression through the device operating states. The boot flow waits for the ADSP to complete the BOOT Phase before advancing. 

When the wave velocity mode is selected and the device FSM is in WAIT_SU, the Elaboration FSM goes into the TIMER BUFFER State and then into the PPG ALC STORAGE.

When i_wave_velocity_mode is set to 1, the ALC Compensation is set only when the ELAB FSM is into the PPG_ALC_STORAGE and then never repeated.

When the i_ADC_en_mc and i_adc_en_mask is set to 0, all outputs are set to 0, except for the o_end_cal_phases and o_ADC_clk_en.

The o_end_cal_phases is set to 1 if i_do_calibration (bit 0 of ADC_CAL_CONFIG) is set to 0, otherwise is set to 0 until the end of the calibration phase.

All other signals change only with mode_operation set to 0 or when i_debug is set to 1.

If the user set a value greater than 1024 into ones of the m_channel (see req 5004), the value clamps at 1024 (check the input i_m_ecg, i_m_bia, i_m_gsr or i_m_ppg into the main controller fsm).

When i_imp_curinj signal is equal to 1, the o_imp_curinj_pd goes low.

if i_imp_curinj is equal to 0, the o_imp_curinj_pd stays high; the ck_m_p_q stays low.

At first, o_Txi_idac_VREF is increased its value of N_START for next step o_Txi_idac_VREF is increase its value by 1.

Nmax is a value between 1 and 15 configurable by user.

At the end of each Frame, the start_avarage signal rises to the Average block computation.

When i_rstn is asserted low, all outputs are set to 0, except for count_cap that is set to 9 and o_end_cal_phase that is set to high.

if IMP_CURRINJ_EN (CURR_INJ register [3]) is equal to 0, ck_m, ck_p and ck_q stay low.

When in Sleep Mode, the device goes back to the Operative State if no error (o_error_irq stuck at 0) occurs and all the operations are ended.

When in OPERATIVE (main_controller_status_register (DEVICE_STATUS_REG register [2:0]) is equal to 0x02), if the time slot counter reaches its limit, the Device_FSM goes into the error state (DEVICE_STATUS_REGISTER) and raises an interrupt (o_error_time_slot) to the Digital_Top.

When ALC_COMP starts, o_BTIA_gain (2:0) is set at i_gain_start (PPG_ALC_CONFIG_PARAM_2 register [4:2]) and o_w_BTIA_ALC (8:0) is set at 100000000.

When the Device_FSM is in BOOT State, that is DEVICE_STATUS_REG register [2:0] == 0x01 (main_controller_status_register), the Device_FSM waits for the ADSP to complete the BOOT Phase, checking when the i_quokka_boot_end is set high.

When the BOOT Phase is ended, the Device_FSM goes to IDLE State, check that DEVICE_STATUS_REG register [2:0] == 0x02, (main_controller_status_register), check that the w_en_ldo1v8 signal is set low and that the O_PD_CLKF signal is set to high.

The counter that defines the timing during the start-up phase works at 32KHz.

The first i_ADC_EOC is ignored.

If i_su_hlt_dly is set to 0,at least 205 ms after the falling of o_rsti_imp, o_sug_imp goes low.

if i_su_hlt_dly is set to 1, 755ms after the falling of o_rsti_imp, o_sug_imp goes low.

I_noise is set to 0 during the ADC calibration.

The State WAIT_SU is not considered interruptible.

If the ALC_COARSE (o_w_BTIA_ALC) result is equal to zero, the ALC_COARSE (o_w_BTIA_ALC) result is brought to 1.

The o_En_TIA, o_EN_Buff, o_EN_ADC and o_EN_IDAC are high when the PPG_FSM is RX_START UP state.

ALC cycle algorithm is done until the set of the last o_w_BTIA_ALC bit.

#### **1.4.2 Channel acquisition and BIO-path coordination** {#142-channel-acquisition-and-bio-path-coordination}

Input-path coordination prepares and selects the required measurement channel. Buffer enablement precedes the first selected channel measurement by at least the configured lead time. 

When only GSR is selected (NO ECG0 and PPG are selected), if i_m_gsr [SET_GSR_FREQ_h and SET_GSR_FREQ_l] is greater than 0, the Device FSM goes in SLEEP after the IDLE State and goes back in Operative State only when the measurement is run or, in case of cds disabled, when the o_gsr_curr changes its polarity.

When DEVICE_FSM is in IDLE STATE (main_controller_status_register (DEVICE_STATUS_REG register [2:0]) is equal to 0x02) if HC_EN (ECG_CTRL register [0]) is set to 1 and ECG0_SEL (DEVICE_CONFIG_CHANNEL [0]) is set to 1 and IMP_EN (IMP_CTRL register [0]) is set to 1 and BIA_SEL (DEVICE_CONFIG_CHANNEL [2]) is set to 1, after WAIT_SU, the device FSM goes in OPERATIVE (DEVICE_STATUS_REG register [2:0] is equal to 0x04).

When in IDLE State, if ECG0_SEL (DEVICE_CONFIG_CHANNEL register [0]) is high, or BIA_SEL (DEVICE_CONFIG_CHANNEL register [2]) is set high, or ECG1_ECG2_SEL (DEVICE_CONFIG_CHANNEL register [1]) is set high, or GSR_SEL (DEVICE_CONFIG_CHANNEL register [3]) is set high, or ADC_DO_CALIBRATION ( ADC_CAL_CONFIG register [0]) is set high, or WAVE_VELOCITY_MODE (GENERAL_PPG_PARAMETERS_1 register [4]) is set high together wit h PPG_SEL (DEVICE_CONFIG_CHANNEL register [4]), when MODE_OPERATION (DEVICE_CONFIG_OPERATION register [1:0] ) is set different from 0, the O_PD_CLKF goes to 0, the w_en_ldo1v8 is set to 1.

When ECG0 and BIA are selected, 21 acquisitions are required (acquisitions described in section 5.4 ADC PHASE) and then device goes in SLEEP (DEVICE_STATUS_REG register [2:0] is equal to 101).

When in Sleep Mode, if no Bio -Channel operations are selected and more than 150us are left before the start of a new time slot, the o_pd_clkf (Digital Top signal) is set to 1, otherwise is left to 0.

In a Time Slot, when a BIO-Channel operation is selected, o_en_bufxbio signal (in Digital Top) goes high at least a configurable time (Device Config Operation [6:5]) before selecting the first bio-channel to measure with the o_ADC_mux_reg.

When in Sleep Mode and no Bio-Channel are selected, if every elaboration is ended and there are at least 34 clock cycles at 32kHz before the start of a new time slot, the o_en_ldo_1v8 goes low.

#### **1.4.3 Sampling, conversion and calibration** {#143-sampling-conversion-and-calibration}

Acquisition control coordinates sampling and measurement-data capture. The sampling sequence uses its sampling window and completion feedback to control progression. 

The Sampling Phase is configurable by the user with i_N_clk values from 0 up to 63; i_N_clk defines the number of clock cycles for which o_ADC_start stays high.

When ECG, BIA or GSR Is sampled, i_ADC_en is equal to 1, the o_ADC_clk_en is set to 1.

The ADC_PHGEN works at 16 MHz clock frequency.

When the ppg ioff calibration and the adc calibration are selected, the adc calibration is performed first.

After an acquisition is started, the ADC_Phases waits for the i_ADC_EOC sampling the new data on the falling edge of the clock.

When i_debug_adc_error_cap8_0_bypass is set to 1 (set to 1 en_debug_adc_error_cap8_0_bypass of ADC_GENERAL_DEBUG_0 ), the calibration result is bypassed in favor of the value written inside the registers ADC_ERROR_CAP_x_DEBUG.

The o_adc_ready is set to 1 when the ADC is getting ready (o_adc_en is set to 1 but not 160 clock cycles are passed), or i_calibration_phase is set to 1 or i_adc_start is set to 1.

When the ADC_phases fsm is ready and an acquisition is required, the o_ADC_start stays High for i_N_clk+1 cycles.

When the last acquisition is performed, after the last i_ADC_EOC has arrived, the ADC_phases sets to high the o_do_avarage signal for 1 clock cycle.

The calibration phase sets the adc_error_cap8…0 to the correct value, following the calibration algorithm.

When the Ioff Calibration algorithm is enabled, the Ioff Calibration algorithm is performed every time a new measurement cycle starts.

When i_debug_calibration is set (second bitfield of ADC_CAL_CONFIG ), the number of samples used by the avarage block during the calibration is set to 2. (The purpose of this mode is to speed-up the AM-S simulation).

#### **1.4.4 PPG acquisition and control** {#144-ppg-acquisition-and-control}

PPG_FSM coordinates measurement-frame startup, acquisition and completion. PPG_FSM frame coordination initiates ALC Compensation through its owning function and waits for completion before the following startup phase. Continuation of PPG_FSM depends on remaining-frame and receive-channel conditions. 

When in Rx_Start_Up state, the o_tx_Preset is set 0, the en_tx_i is set to 1, the o_BIDAC maintains the value reached during the ALC Compensation summed up, if i_ppg_ioff_calibration is enabled, with the IOFF_OFFSET computed during the IOFF Calibration Procedure; the PPG_FSM stays in this state for the T_rx_set time (GENERAL_PPG_PARAMETERS_3 register [3:0]) and then go into the FIRST_ALC_SAMPLES state.

When in FIRST_ALC_SAMPLES state, the o_start_ADC signal is set high until i_end_average is low; the PPG_FSM stays in this state until 1 clock cycle after the rise of the i_end_average and the TX_start_up time has passed.

Once the PPG Raw Data and PPG Noise reach the i_n_average_ppg value, depending on the ALC Mask bit value, the two accumulated is subtracted.

When the i_m_ppg ( SET_PPG_FREQ_h and SET_PPG_FREQ_l) is different from 0 and PPG_SEL in DEVICE_CONFIG_CHANNEL register is set to 1, when the ELAB_FSM is in PPG STATE, PPG_IOFF_CALIB or PPG_ALC_STORAGE, the i_start_operation_for_ppg is set to 1.

When in Measurement state, the PPG_FSM stays in this state until the rising of the i_end_average signal from the ADC block.

If multiple frame is selected (i_frame_repetition in ppg_fsm greater than 0), when Tx Preset falls from 1 to 0, the en_tx passes from 1 to 0 only during the last repetition (check that when o_end_ppg_fsm is set, en_tx is 0).

When in Rising_Ramp State, the PPG_FSM stays in this state until the end of the Rising Time and then go into the Measurement state.

When in Falling_Ramp state, the PPG_FSM stays in this state until the end of the Falling Time (depends on the user's configuration of Digital Ramp parameters) and bring itself into the SECOND_ALC_SAMPLES state.

If the i_noise signal is set to 1 when the DEVICE_FSM is into PPG State, the i_n_avarage is divided by 2.

If during the PPG Frame computation, the i_alc_mask (ALC Disabled) is enabled, the final result is only the ppg acquisition and the subtraction of the alc data is not performed.

When i_ALC_comp_start is set to 1 and the o_BTIA_ALC (ALC Compensation) change is value, after a configurable time T1 (PPG_ALC_CONFIG_PARAM_1 register [3:0]), o_comp_rx_ck is high.

When DEVICE_FSM is in IDLE if PPG_SEL (DEVICE_CONFIG_CHANNEL [4]) is set to 1 and MODE_OPERATION (bit [1:0] on DEVICE_CONFIG_OPERATION register) is different to 0, O_PD_TIA and O_PD_IDAC go low.

When the wave velocity mode and the ppg ioff calibration are selected, the wave velocity mode is performed first.

When in ALC Compensation, the PPG waits for the rise of i_end_compensation signal from the ALC Compensation block to go into the RX_Start_UP state.

When in ALC Compensation, the PPG FSM raises the o_start_alc_comp signal to the ALC Compensation block to start the ALC Compensation algorithm.

When the PPG_FSM is in the RX_START_UP state, the o_PD_PGA goes to 0.

When in SECOND_ALC_SAMPLES state, the PPG_FSM stays in this state until the rise of the end_of_conversion signal from the ADC block; the o_en_Txi is set low after the end at least of the T_tx_ledoff time (TX_LEDOFF_FRAME_{n}) and the o_start_adc signal is set to 1.

After that, if there are no more frames to run, the PPG_FSM goes into the Reset State, otherwise, if there are other frames to run and channel rx is not changed, the PPG_FSM goes into the Rx_start_up phase.

if there are other frame to run and rx_channel is changed, the PPG_FSM goes into the RESET_PPG state and the into the ALC_Compensation state.

When i_wave_velocity mode is enabled together with the DISABLE_ALC, the PPG_ALC_STORAGE is performed but once the Device goes into OPERATIVE State, the values are not summed (visible) to the o_BIDAC.

When the ppg ioff calibration is selected and device fsm is in WAIT_SU State, the Elab FSM goes into the Timer Buffer state and then PPG IOFF CALIB state.

If no multiple frame is selected (i_frame_repetition in ppg_fsm set to 0), when Tx Preset falls from 1 to 0, also the en_tx passes from 1 to 0.

#### **1.4.5 BIA acquisition and control** {#145-bia-acquisition-and-control}

The BIA measurement path coordinates channel selection, startup and acquisition sequencing. Averaging of the BIA samples forms the channel measurement results. Selection of the BIA channels determines the applicable acquisition count. 

i_rst_async_bia is used also to reset the START-UP phase for ECG channel 1 and 2 and is used only when Device FSM is in OPERATIVE or SLEEP state.

When the user selects an operative mode that includes the BIA channel, a start-up is performed.

When i_imp_en signal is equal to 1, the o_pd_imp_from_bia goes low.

When ELAB_FSM is in BIA state, o_ADC_EN goes high and 16 acquisitions are required (acquisitions described in section 5.4 ADC PHASE ) and then device goes in SLEEP (DEVICE_STATUS_REG register [2:0] is equal to 0x05).

When DEVICE_FSM is in WAIT_SU state, if IMP_EN (IMP_CTRL register [0]) is equal to 1 and BIA_SEL (DEVICE_CONFIG_CHANNEL register [2]) is equal to 1; 30ms after the falling of O_RST_IMP, O_RSTI_IMP goes low.

When DEVICE is in WAIT_SU, if IMP_EN (IMP_CTRL register [0]) is equal to 1 and BIA_SEL (DEVICE_CONFIG_CHANNEL register [2]) is equal to 1 and the IMP_CURRINJ_EN (CURR_INJ register [3]) is equal to 1, the O_IMP_CURINJ_PD goes low.

When DEVICE is in WAIT_SU, if IMP_EN (IMP_CTRL register [0]) is equal to 1 and BIA_SEL (DEVICE_CONFIG_CHANNEL register [2]) is equal to 1, if IMP_CURRINJ_EN (CURR_INJ register [3]) is equal to 0, the O_IMP_CURINJ_PD remains high.

When DEVICE_FSM is in WAIT_SU state, if IMP_EN (IMP_CTRL register [0]) is equal to 1 and BIA_SEL (DEVICE_CONFIG_CHANNEL register [2]) is equal to 1, 15ms after the falling of O_PD_IMP, the O_RST_IMP goes low.

At least 15ms after the falling of o_pd_imp_from_bia, the o_rst_imp goes low.

When the ELAB_FSM is in BIA State (Check ELAB_STATUS_REG), the ADC_Mux (o_adc_mux_biochannel on digital top) output is set equal to 011, 100, 101 or 110.

When DEVICE is in WAIT_SU, if IMP_EN (IMP_CTRL register [0]) is equal to 1 and BIA_SEL (DEVICE_CONFIG_CHANNEL [2]) is equal to 1, O_PD_IMP goes low within 5 clock cycle at 32kHz.

When DEVICE_FSM is in WAIT_SU state, if IMP_EN signal (IMP_CTRL register [0]) is equal to 1 and BIA_SEL (DEVICE_CONFIG_CHANNEL register [2]) is equal to 1; If i_su_hlt_dly is set to 0, 205ms after the falling of O_RSTI_IMP, O_SUG_IMP goes low.

if SU_DLY (EN_CHOP_FREQ_MOD_DEMOD register [2]) is set to 1, 755ms after the falling of O_RSTI_IMP, O_SUG_IMP goes low.

#### **1.4.6 ECG acquisition and control** {#146-ecg-acquisition-and-control}

The ECG measurement path coordinates channel selection and acquisition sequencing. Averaging of the ECG samples forms the channel measurement results. Selection of the ECG channels determines the applicable acquisition count. 

When the HC_EN (ECG_CTRL register [0]) is set to 0 and IMP_EN (IMP_CTRL register [0]) is set to 1 and ECG1_ECG2_SEL (DEVICE_CONFIG_CHANNEL register [1]) is set to 1, ECG1 and ECG2 are active so, when MODE_OPERATION (DEVICE_CONFIG_OPERATION register [1:0] ) is set different from 0, the O_PD_HC2 remains high, O_PD_IMP goes low and the Device_FSM goes to the WAIT_SU State, so main_controller_status_register (DEVICE_STATUS_REG register [2:0]) is equal to 0x03.

If i_su_hlt_dly is set to 0, At least after 205ms that the o_rsti_hc2 is gone low, o_su_hc2 goes low.

When the ELAB_FSM is in ECG State and only ECG0 is selected, the o_ADC_EN goes high, 5 acquisitions are required (acquisitions described in section 5.4 ADC PHASE).

When the i_hc_en is set to 1 and i_imp_en is set to 1 and i_n_ecg_channel is equal to 3, ECG0- ECG1 and ECG2 are active so the o_pd_hc2 goes low, o_pd_imp goes low and counter works.

When the ELAB_FSM is in ECG State, the ADC_Mux (concatenation of {o_adc_mux_sel, o_adc_mux_bio_channel} on digital top) output is set equal to 001 and after 4 acquisitions (described in section 5.4 ADC PHASE) is set to 010.

When in the ECG state, If ECG1 and ECG2 are selected, the o_adc_mux_biochannel is set also to 011, 100, 101 and 110.

When ELAB_FSM is in ECG state and EC0, ECG1 and ECG2 are selected, o_ADC_EN goes high and 15 acquisitions are required (acquisitions described in 5.4 ADC PHASE) and then device goes in SLEEP (DEVICE_STATUS_REG register [2:0] is equal to 0x05).

When the user selects the ECG, BIA, the wave velocity mode or the ppg ioff calibration, the device goes to WAIT_SU state.

15ms after that the o_pd_hc2 is gone low, the o_rst_hc2 goes low.

When the i_hc_en is set to 0 and i_imp_en is set to 1 and i_n_ecg_channel is equal to 2, ECG1 and ECG2 are active so the o_pd_hc2 remains high, o_pd_imp_from_bia goes low and counter works.

i_rst_async_ecg is used only when the Device FSM is in SLEEP or Operative State.

When ELAB_FSM is in ECG state and ECG1 and ECG2 are selected, o_ADC_EN goes high and 10 acquisitions are required (acquisitions described in chapter in section 5.4 ADC PHASE).

#### **1.4.7 GSR acquisition and control** {#147-gsr-acquisition-and-control}

The GSR path schedules measurement acquisition for its paired and single-measurement modes. The GSR paired-measurement path forms a difference from separately averaged measurements when enabled. The GSR single-measurement path uses only its own average. 

If en_gsr_cds is set low [bit 3 of GSR_CTRL], the gsr_curr_on sets high in every time slot where the GSR_SNS signal is acquired and sets low at end of the same time slot.

The gsr_on sets high at least 300us before the start of the sampling.

If the en_gsr_cds [bit 3 of GSR_CTRL] is set High, the i_m_gsr defines also in which time slot after the GSR_Curr_on falls from 1 to 0, an acquisition without current injection (o_gsr_curr_on set to 0) is performed.

If en_gsr_cds is set low, no acquisition of GSR_CDS is done and the result is the average of 16 acquisitions of GSR_SNS.

The interval between two GSR acquisitions is defined in time slots.

#### **1.4.8 Digital-ramp control** {#148-digital-ramp-control}

Ramp control generates the rising and falling value sequence. The preset and step controls establish the initial level and the progression toward the peak and back to zero. Progress reporting identifies intermediate and completed ramp phases. 

When o_Tx_Vref is equal to 0 during the falling and the rising ramp is ended (o_rising_ramp_end ==0), o_falling_ramp_end goes high.

When the input signal o_Tx_preset is set to 1, the o_Tx_Vref increments the first step at value i_N_start (DIGITAL_RAMP_CONFIG_PARAM_3 register [2:0]) at a time i_T_preset (DIGITAL_RAMP_CONFIG_PARAM_1 register [5:4]).

Tx Preset is set to 0 before the rising phase(i_start_digtal_ramp) and after the falling phase (i_start_falling_ramp) of the digital ramp.

Tx Preset is set to 1 a configurable TX_Preset_Step time before the start of the Digital Ramp rising phase.

When in Rising_Ramp state, at the half of Rising_time, the o_idac_dc_ppg_frame is set to the IDAC_DC_PPG_FRAME_{n} (FRAME_n_PARAMETERS_5 register [5:0]) value related to the frame that is being executed.

When in MEASUREMENT State, the o_falling_digital_ramp signal is set to 1 to go into the FALLING_RAMP State and stays 1 until i_falling_ramp_end is different from 1.

When in FIRST_ALC_SAMPLES state, when i_end_average is set to 1, the o_start_digital_ramp signal is set high to start the rising of the digital ramp and go into the RISING_RAMP state.

When in Falling_Ramp State, at the half of the Falling_Time the o_idac_dc_ppg_frame is set to 0.

When the rising ramp reaches half its value, o_half_rising_ramp goes high.

When o_ TX_Vref is equal to i_Nmax_to_reg (N_MAX (DIGITAL_RAMP_CONFIG_PARAM_1 register [3:0])), o_rising_ramp_end goes high.

When the i_falling_digital_ramp is set to 1, the o_TX_Vref decrements from N_MAX value (DIGITAL_RAMP_CONFIG_PARAM_1 register [3:0]) to zero with a step equal to 1 every 2-clock cycle.

#### **1.4.9 Result processing** {#149-result-processing}

Measurement processing forms results from acquired data. Result formation uses sample accumulation, sample averaging and conditional difference processing. After the last repetition has been accumulated, repeated-frame processing averages the accumulated frame data to form the final result. 

When i_end_of_conversion is set to 1 and i_n_average_ecg_bia_gsr (average ecg,bia and gsr) or i_n_average_ppg (Frame_X_Parameter_1) is equal to their limit values, an average operation is done and o_write_enable is set to 1.

The PPG Noise Data is accumulated in two phases, the first when the PPG FSM state is in FIRST_ALC_SAMPLES States and the second when the PPG FSM state is in the SECOND_ALC_SAMPLES.

The average block performs the average on 16 sample acquisitions for GSR and an average on 4 Samples for each of ECG_x_AC, BIA AC P, BIA AC Q, BIA DC P and BIA DC Q , 1 Sample ECG_x_DC.

When the CDS mode is enabled, the average block performs an average on 16 sample acquisitions on GSR ON and 16 sample acquisitions on GSR OFF, then performs a subtraction operation between the two results.

After the last repetition has been accumulated, the data output is obtained by dividing the accumulated data by the number of repeated frames to obtain 20-bit data.

If en_gsr_cds is set high [bit 3 of GSR_CTRL], the GSR_SNS (acquisition with o_gsr_curr_on set to 1) and GSR_CDS (acquisition with o_gsr_curr_on set to 0) are sampled 16 times, then mediated to get one single value for each of them, and then the final result is the subtraction between GSR_SNS and GSR_CDS.

When a PPG Raw data ( i_data_valid_ppg_adc set to 1) or a PPG_Noise (i_data_valid_noise_ppg_adc set to 1) data is sampled (i_end_of_conversion set to 1), the data are accumulated until i_n_average_ppg is not reached.

#### **1.4.10 Storage behavior** {#1410-storage-behavior}

The transfer path delivers data records to regmap registers and FIFO storage. An averaging-dependent transfer waits for the applicable computation to finish before writing. 

When an ECG, BIA or GSR Operation is selected and DS_SEL is set to 0, the DATA Output for these two channels is written in the following regmap registers ECG0_AC ECG0_DC ECG1_BIA_P_AC ECG1_BIA_P_DC ECG2_BIA_Q_AC ECG2_BIA_Q_DC GSR_RESULT.

Once the Average is computed, if no averages_between_equal_frames option is selected, the data are written inside the FIFO Memory using the Main Control ler AHB Master interface.

If there is avareges_between_equal_frames option selected from regmap, after the computations of this average, the obtained data is written inside the FIFO Memory using the Main Controller AHB Master interface.

When in unique_fifo_mode (i_multiple_fifo set to 0), if during a time slot an operation is done, the Main_Controller_FSM writes the time_slot_data inside the FIFO with a dedicated tag.

In Data Storage Mode, with DS_SEL=1 in Device_Config_Channel and PPG_ELAB=0 in General_Parameters_PPG, communication between Main Controller and ADSP is disabled.

#### **1.4.11 Power, clock and reset coordination** {#1411-power-clock-and-reset-coordination}

Clock and restart coordination controls measurement-path enablement while leaving clock generation to the source block. A permitted channel-startup restart retains clocks that are already enabled. PPG FSM returns to its reset state immediately when reset is asserted. 

If i_rst_async_bia is set to 1, i_rst_async_bia goes to zero at least 5ms after that the o_sug_imp is set to 0 as in the next figure; the start-up phase restarts but no clock stops if enabled.

When i_reset_ramp is high, all outputs are down.

Every Time a new measurement cycle starts (DEVICE FSM goes in OPERATIVE from another state), the o_irq_start_measurement is set to 1 for at least 1 clock cycle.

When the calibration phase is ended, the o_end_cal_phase is set to 1 and stays high until the reset is not asserted or the i_reset_end_calibration is set to 1.

If the calibration has been done, the ADC_error_caps values computed resets only if the POR signal is asserted or is overwritten if another calibration is performed.

Once is set to 1, o_comp_rx_ck is set to 0 after a T2+1 clock cycle.

When DEVICE is in WAIT_SU, if IMP_EN (IMP_CTRL register [0]) signal is equal to 1 and BIA_SEL (DEVICE_CONFIG_CHANNEL register [2]) is equal to 1, 5ms after the falling of imp_curinj_pd and O_PD_IMP, if IMP_CURRINJ_EN (CURR_INJ register [3]) is equal to 1, O_CK_M, O_CK_P and O_CK_Q are generated from Clock generator block so they run at FREQ_BIA_CLK_m_p_q (EN_CHOP_FREQ_MOD_DEMOD register [4:3] ) and its values are chosen from 20kHz, 50kHz, 100kHz, 200kHz.

When the rstn_i is asserted low, the PPG FSM returns in Reset state immediately.

When the i_ADC_en_mc and i_adc_en_mask is set to 1, at least 160 clock cycles pass before the ADC is ready to work.

If i_rst_async_ecg is set to 1, the start-up phase restarts but no clock stops if enabled; i_rst_async_ecg goes to zero at least 5ms after that o_su_hc2 is set to 0.

When DEVICE_FSM is in WAIT_SU state, if IMP_EN (IMP_CTRL register [0]) is equal to 1 and BIA_SEL (DEVICE_CONFIG_CHANNEL register [2]) is equal to 1; 20ms after the falling of O_RST_IMP, if EN_CHOP_CLK_IMP (EN_CHOP_FREQ_MOD_DEMOD register [1]) is set to 1, O_CK_CHOP_IMP is generated from Clock generator block, so O_CK_CHOP_IMP is run at 10kHz frequency.

At least 5ms after the falling of o_imp_curinj_pd and o_pd_imp_from_bia, if i_imp_curinj is equal to 1, o_en_ck_m_p_q is high and ck_m, ck_p and ck_q are generated from Clock generator block.

When the i_reset_end_calibration , i_do_calibration and i_mode_operation are set to 1, the o_end_cal_phase is set to 0.

When DEVICE_FSM is in Operative State (DEVICE_STATUS_REG register [2:0]==0x04), the o_MC_busy goes to 1 and goes to 0 one clock cycle after entering the SLEEP state if no error occurred.

20ms after that the o_rst_hc2 is gone low, if i_clk_hlt_en is equal to 1, chopper_clock is generated and after another 10ms, o_rsti_hc2 goes low.

20ms after the falling of o_rst_imp, if i_clk_imp_en is set to 1, the o_en_ck_chop_imp is high and ck_chop_imp are generated from Clock generator block.

30ms after the falling of o_rst_imp, o_rsti_imp goes low.

The Main Controller Soft Reset procedure resets all the Main Controller FSMs and related IPs, repeating the BOOT Phase without resetting the Regmap.

When IMP_CURRINJ_EN (CURR_INJ register [3]) is high, O_CK_Q is run with a phase delay of 90 degrees (opposite) with respect O_CK_P.

if i_clk_imp_en is set to 0, the o_en_ck_chop_imp stays low.

