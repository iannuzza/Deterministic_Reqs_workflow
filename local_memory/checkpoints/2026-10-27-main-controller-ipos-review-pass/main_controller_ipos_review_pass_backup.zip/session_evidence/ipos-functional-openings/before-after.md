# Actual before/after functional openings

Extracted from the saved prior pilot and the current generated document. No output paragraphs were manually edited.

## Sampling, conversion and calibration

### Before

The sampling, conversion and calibration function combines completion-dependent data capture and control-pulse timing. After an acquisition is started, the ADC_Phases waits for the i_ADC_EOC sampling the new data on the falling edge of the clock. When the ADC_phases fsm is ready and an acquisition is required, the o_ADC_start stays High for i_N_clk+1 cycles.

### After

Acquisition control coordinates sampling and measurement-data capture. The sampling sequence uses its sampling window and completion feedback to control progression.

## GSR acquisition and control

### Before

The GSR acquisition and control function combines sampling-preparation timing and acquisition scheduling. If en_gsr_cds is set low [bit 3 of GSR_CTRL], the gsr_curr_on sets high in every time slot where the GSR_SNS signal is acquired and sets low at end of the same time slot. If the en_gsr_cds [bit 3 of GSR_CTRL] is set High, the i_m_gsr defines also in which time slot after the GSR_Curr_on falls from 1 to 0, an acquisition without current injection (o_gsr_curr_on set to 0) is performed.

### After

The GSR path schedules measurement acquisition for its paired and single-measurement modes. The GSR paired-measurement path forms a difference from separately averaged measurements when enabled. The GSR single-measurement path uses only its own average.

## Result processing

### Before

The result processing function combines sample averaging and averaging and difference formation. The average block performs the average on 16 sample acquisitions for GSR and an average on 4 Samples for each of ECG_x_AC, BIA AC P, BIA AC Q, BIA DC P and BIA DC Q , 1 Sample ECG_x_DC. When the CDS mode is enabled, the average block performs an average on 16 sample acquisitions on GSR ON and 16 sample acquisitions on GSR OFF, then performs a subtraction operation between the two results.

### After

Measurement processing forms results from acquired data. Result formation uses sample accumulation, sample averaging and conditional difference processing. After the last repetition has been accumulated, repeated-frame processing averages the accumulated frame data to form the final result.

## Storage behavior

### Before

The storage behavior function provides result transfer. When an ECG, BIA or GSR Operation is selected and DS_SEL is set to 0, the DATA Output for these two channels is written in regmap registers. Once the Average is computed, if no averages_between_equal_frames option is selected, the data are written inside the FIFO Memory using the Main Control ler AHB Master interface.

### After

The transfer path delivers data records to regmap registers and FIFO storage. An averaging-dependent transfer waits for the applicable computation to finish before writing.
