# Functional-opening pilot: completed

Snapshot: `snap-8b3673edc9cf590589b8ab39`. Isolated Main Controller IPOS only.

## Open for review

- [Full generated IPOS - Word](../../../80272f99-6494-4238-9a42-55101692cf95/files/descriptive_closure_20261026/workspace/artifacts/stage6_digital_ipos/blocks/main-controller/digital_ipos_main-controller.docx)
- [Actual before/after comparison - Word](before-after.docx)
- [Actual before/after comparison - Markdown](before-after.md)
- [Updated descriptive sections - Word](revised-excerpts.docx)
- [Verification results](verification.json)
- [Exact document diff](document-update.diff)
- [Exact source, test and contract diff](source-update.diff)

## What changed

The shared IPOS planner now constructs higher-level purpose, activity and result
meanings from complementary, source-bound relationships. It no longer opens
functional groups with activity-label wrappers or selected requirement sentences.

The reusable constructions cover state/completion coordination, input-path
selection, sampling/capture, selected measurement paths, frame/peer coordination,
numeric progression, paired-measurement processing, result formation, completed
data delivery and clock/restart coordination. They are enabled only by their
evidence patterns, not by project names or a fixed principal-function catalogue.
Existing semantic types, the document-specific planner, source witnesses,
materialization and gates remain in use; no separate synthesis engine was added.

All retained signal, register, timing, state and quantity details follow the
functional opening. The introduction does not replace the normative content or
earn detailed-coverage credit merely by existing. Execution and coordination
remain distinct, including compensation initiation and external clock generation.

Repeated cross-channel sentences were corrected by retaining the channel context
in the synthesized relationships. A multi-channel regression prevents recurrence.

## Actual result example

The generated acquisition opening is:

> Acquisition control coordinates sampling and measurement-data capture. The
> sampling sequence uses its sampling window and completion feedback to control
> progression.

The generated GSR opening explains scheduling and the paired/single-measurement
result paths without starting with enable bits or register settings. The
comparison document contains exact extracted before/after paragraphs for four
groups, rather than manually edited proposed output.

## Verification

| Check | Result |
|---|---|
| Focused digital/analog and regression tests | 102 PASS |
| Existing actual IPOS document contract and scoped gate | PASS |
| Actual functional openings | 11/11 supported |
| Opening checks in Markdown and Word | 22 PASS |
| Opening style | No signal/register lists or generic activity wrappers; each at most 90 words |
| Principal-function coverage | 16/16 PASS |
| Actual-prose semantic mutations | 16 rejected |
| Full-document and excerpt Markdown/Word consistency | PASS |
| All 181 normative requirements, IDs, Covers and Source I/O | Unchanged |
| Complete applicable approved input | All 198 records unchanged |
| Isolated protected SRS/DRS/authority files | 47 unchanged |
| Protected official files | 5,595 unchanged |

The publication-duplication blocker is resolved in the regenerated document, not
only in an in-memory preview. The gate's inventory count of 302 requirements/eight
blocks does not imply regeneration or descriptive certification of other blocks.

## Unsupported synthesis and remaining gaps

- **Current pilot:** none of the eleven functional-opening constructions is
  unsupported by the targeted source-binding checks.
- **Isolated scalar controls:** a signal update alone does not establish a
  composite function. Such evidence is retained as detail, with an explicit
  unsupported-synthesis reason rather than a fabricated introduction.
- **Extent-bounded memory initialization:** the initialization and its extent
  restriction remain intact, but a composite functional-opening projection for
  that dependency pattern is not implemented. This is a projection limitation,
  not missing approval or evidence.
- The broader writing assessment remains **UNRESOLVED (486 reported findings)**,
  including interpretation/readback limitations. The focused checks do not
  certify arbitrary natural-language synthesis or whole-workflow closure.
- Ambiguous technical identifiers and source inconsistencies remain unchanged.

No approval, snapshot, allocation, ownership, destination permission, official
document or official runtime was changed. No new gate, broad regeneration,
commit, tag or push occurred. Official SRS/DRS/IPOS verification and integration
remain a separate follow-up after the user's pilot review.
