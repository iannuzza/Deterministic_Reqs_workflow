"""Verify the complete isolated Main Controller review document, without modifying it."""

import difflib
import hashlib
import json
import re
import sys
from collections import Counter
from dataclasses import asdict
from pathlib import Path

ROOT = Path(r"C:\Users\iannuzza\.copilot\session-state\80272f99-6494-4238-9a42-55101692cf95\files\descriptive_closure_20261026\workspace")
OUTPUT = Path(__file__).resolve().parent
SNAPSHOT = "snap-8b3673edc9cf590589b8ab39"
sys.path.insert(0, str(ROOT / "scripts"))

from csv_artifacts import csv_artifact_reader
from spec_document_contract import drs_document_events, literal_publication_text
from validate_downstream_coherence import resolve_downstream_contract
from workflow_routing import _ipos_final_sections, build_ipos_claim_plan


def section_events(path, number):
    active = False
    result = []
    for event in drs_document_events(path):
        if event["kind"] == "heading" and re.match(r"^(?:\d+\.\s|\d+\.\d+\s)", event["text"]):
            active = event["text"].startswith(number + " ")
        if active:
            result.append(event)
    return result


def tail_events(path):
    events = drs_document_events(path)
    start = next(index for index, event in enumerate(events)
                 if event["kind"] == "heading" and event["text"].startswith("2. Source I/O"))
    return events[start:]


def main():
    block = ROOT / r"artifacts\stage6_digital_ipos\blocks\main-controller"
    markdown = block / "digital_ipos_main-controller.md"
    word = markdown.with_suffix(".docx")
    before_md = OUTPUT / r"before\digital_ipos_main-controller.md"
    before_word = before_md.with_suffix(".docx")
    old = before_md.read_text(encoding="utf-8")
    current = markdown.read_text(encoding="utf-8")
    tail = r"^##\s+(?:\*\*)?2\.\s+Source I/O"
    assert old[re.search(tail, old, re.M).start():] == current[re.search(tail, current, re.M).start():]
    assert tail_events(before_word) == tail_events(word)
    sections = {path.suffix: _ipos_final_sections(path) for path in (markdown, word)}
    assert _ipos_final_sections(before_md)["1.1"] == sections[".md"]["1.1"]
    assert {key: literal_publication_text(value) for key, value in sections[".md"].items()} == {
        key: literal_publication_text(value) for key, value in sections[".docx"].items()}

    expected_labels = {
        "Configuration and device supervision", "Processing coordination", "Shared BIO-path preparation",
        "ADC sampling and calibration control", "ECG acquisition", "BIA acquisition",
        "PPG acquisition and compensation coordination", "GSR acquisition and CDS handling",
        "Digital-ramp control", "Result processing", "Result storage and delivery",
        "Power, clock and reset coordination",
    }
    checked = []
    for path in (markdown, word):
        scope = section_events(path, "1.2")
        paragraphs = [event for event in scope if event["kind"] == "paragraph"]
        bullets = [event for event in paragraphs if event.get("is_list")]
        labels = [re.sub(r"^[-*+]\s+", "", event["text"]).split(". ", 1)[0] for event in bullets]
        assert len(bullets) == 12 and set(labels) == expected_labels, (path, labels)
        assert not paragraphs[0].get("is_list")
        assert not re.search(r"\bcovers\b|timed control-output updates|(?:^|[.;]\s*)state progression\b",
                             sections[path.suffix]["1.2"])
        headings = [event["text"].split(" ", 1)[1] for event in section_events(path, "1.4")
                    if event["kind"] == "heading" and re.match(r"1\.4\.\d+ ", event["text"])]
        assert headings == labels, (path, headings, labels)
        for event, label in zip(bullets, labels):
            body = re.sub(r"^[-*+]\s+", "", event["text"]).split(". ", 1)[1]
            assert len(re.split(r"(?<=[.!?])\s+(?=[A-Za-z0-9])", body)) == 1, (label, body)
            assert len(body.split()) <= 45, (label, len(body.split()))
            checked.append({"artifact": path.name, "function": label, "words": len(body.split()), "status": "PASS"})
        for phrase in ("measurement-start", "time-slot error", "boot-completion",
                       "conditional difference processing", "when disabled", "when enabled",
                       "reports progress and completion", "clock generation to its source block"):
            assert phrase in sections[path.suffix]["1.2"], (path, phrase)

    before_detail = Counter(event["text"] for event in section_events(before_word, "1.4")
                            if event["kind"] == "paragraph")
    after_detail = Counter(event["text"] for event in section_events(word, "1.4")
                           if event["kind"] == "paragraph")
    assert not (before_detail - after_detail), before_detail - after_detail
    with csv_artifact_reader(block / "descriptive_summary_audit.csv") as reader:
        rows = list(reader)
    explanations = [row for row in rows if row["decision"] == "function_explanation"]
    assert len(explanations) == 12
    assert all(json.loads(row["functional_synthesis_json"])["status"] == "SUPPORTED" for row in explanations)
    summary = next(row for row in rows if row["decision"] == "function_summary")
    assert len(json.loads(summary["summary_claims_json"])) == 12
    functional = resolve_downstream_contract(ROOT, SNAPSHOT).ipos_descriptive_input(
        ROOT, block="Main Controller", domain="digital")
    previous_input = json.loads((OUTPUT.parent / r"main-controller-final\source-scope.json").read_text(
        encoding="utf-8"))["input"]
    assert json.dumps(asdict(functional), sort_keys=True) == json.dumps(previous_input, sort_keys=True)
    plan = build_ipos_claim_plan(functional)
    assert len(functional.local_requirement_ids) == 181
    assert len(plan.evidence.records) == 198
    baseline = json.loads((OUTPUT / "baseline.json").read_text(encoding="utf-8"))
    changed = [name for name, digest in baseline["protected"].items()
               if hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != digest]
    assert not changed, changed
    contract = json.loads((block / "document_contract_report.json").read_text(encoding="utf-8"))
    assert contract["status"] == "PASS"
    generation = json.loads((ROOT / r"artifacts\orchestrator\ipos_generation_results.json").read_text(encoding="utf-8"))
    assert generation["scope"] == "main-controller" and len(generation["blocks"]) == 1
    assert generation["blocks"][0]["status"] == "PASS"
    document_diff = "".join(difflib.unified_diff(old.splitlines(keepends=True),
        current.splitlines(keepends=True), fromfile="before.md", tofile="regenerated.md", n=2))
    (OUTPUT / "document-update.diff").write_text(document_diff, encoding="utf-8")
    source_diff = []
    for relative in (r"scripts\workflow_routing.py", r"templates\IPOS_document_contract.md",
                     r"tests\test_ipos_grouped_pilot.py", r"tests\test_ipos_main_function_planning.py",
                     r"tests\test_ipos_summary_bullets.py"):
        before = OUTPUT / "before" / relative
        previous = before.read_text(encoding="utf-8") if before.is_file() else ""
        now = (ROOT / relative).read_text(encoding="utf-8")
        source_diff.extend(difflib.unified_diff(previous.splitlines(keepends=True),
            now.splitlines(keepends=True), fromfile="before/" + relative, tofile="after/" + relative, n=2))
    (OUTPUT / "source-update.diff").write_text("".join(source_diff), encoding="utf-8")
    report = {
        "snapshot_id": SNAPSHOT, "generation": "PASS", "document_contract": "PASS",
        "functions": 12, "one_to_one_summary_detail_subsections": True,
        "actual_markdown_word_bullet_checks": checked, "complete_md_docx_meaning_parity": True,
        "macro_purpose_unchanged": True, "all_previous_detail_paragraphs_preserved": True,
        "source_io_and_normative_content_unchanged": True, "normative_requirements": 181,
        "approved_input_unchanged": True, "admitted_records": 198,
        "protected_trial_files": len(baseline["protected"]), "protected_trial_changes": [],
        "focused_regressions": {"passed": 78, "failed": 0},
        "unsupported_pilot_function_synthesis": [],
        "broader_writing_assessment": {"status": contract["writing_quality"]["status"],
                                      "findings": len(contract["writing_quality"]["gaps"])},
        "preexisting_test_gap": "SRS shared-mode test raises KeyError('3.4') both before and after this change; no SRS fix attempted.",
        "official_overwrite": False, "approvals_or_snapshot_changed": False,
        "word": str(word), "markdown": str(markdown),
    }
    (OUTPUT / "verification.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in report.items()
                      if key != "actual_markdown_word_bullet_checks"}, indent=2))


if __name__ == "__main__":
    main()
