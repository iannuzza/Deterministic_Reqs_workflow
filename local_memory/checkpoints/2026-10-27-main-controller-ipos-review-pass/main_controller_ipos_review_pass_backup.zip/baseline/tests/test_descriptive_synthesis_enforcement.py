import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

from spec_document_contract import assess_descriptive_synthesis, load_descriptive_synthesis_contract
from test_spec_document_contract import _write_docx
from workflow_routing import build_ipos_functional_input, compose_ipos_overview, descriptive_writing_quality


class DescriptiveSynthesisEnforcementTests(unittest.TestCase):
    def functional(self, owner="Nimbus", extent="4.25Kbyte"):
        return build_ipos_functional_input(owner, {
            "Function": f"Execute {owner} firmware for FUSE boot/write/test and sensor elaboration, using mapped memory.",
            "Inputs": "sample data", "Outputs": "processed results",
        }, [{"source_req_id": "reset", "statement":
             f"During reset, {owner} shall write {owner} RAM with the value 0. "
             f"Only the first {extent} of {owner} RAM shall be cleared."}],
            domain="digital")

    def materialize(self, directory, functional):
        sections, _audit = compose_ipos_overview(functional)
        paragraphs = []
        for key, title in (("functionality", "1.1 Functionality"),
                           ("scope", "1.2 Supported functions and scope"),
                           ("internal_functions", "1.4 Supported block functions")):
            paragraphs.extend(["# " + title, *sections[key]])
        path = Path(directory) / "review.md"
        path.write_text("\n\n".join(paragraphs), encoding="utf-8")
        _write_docx(path.with_suffix(".docx"), paragraphs)
        return path, paragraphs

    def assess(self, path, functional):
        return assess_descriptive_synthesis(path, "IPOS",
            {"snapshot_id": "synthetic-approved", "functional_input": functional})

    def test_contracts_express_document_specific_abstraction_and_sections(self):
        policies = {document: load_descriptive_synthesis_contract(document) for document in ("SRS", "DRS", "IPOS")}
        self.assertEqual({policy["abstraction"] for policy in policies.values()},
                         {"system", "digital_integration", "block_local"})
        self.assertFalse(policies["IPOS"]["sections"]["1.4"]["required"])
        self.assertEqual(policies["SRS"]["sections"]["3.4"]["roles"], ["boundaries", "interaction", "context"])

    def test_audit_selection_alone_cannot_receive_writing_pass(self):
        report = descriptive_writing_quality("IPOS", [
            {"section": "1.1", "decision": "selected"}, {"section": "1.2", "decision": "selected"}])
        self.assertEqual(report["status"], "NOT_ASSESSED")
        self.assertTrue(all(check["status"] == "NOT_ASSESSED" for check in report["obligations"].values()))

    def test_qualified_configuration_is_not_a_literal_synthesis_exemption(self):
        from descriptive_review_proposals import requested_destination_rows
        from governed_descriptive_scope import project_shared_descriptive_uses, serialize_descriptive_destinations
        from test_descriptive_review_proposals import DescriptiveReviewProposalTests
        from test_governed_descriptive_scope import admitted

        profile, source, request = DescriptiveReviewProposalTests().configuration_profile()
        rows = requested_destination_rows(request, source, [source], profile, list(profile["block_defs"]))
        for row in rows:
            row["review_decision"] = "approved"
        source.update(serialize_descriptive_destinations(source, "shared", rows))
        sources = admitted(profile)
        for document, section in (("SRS", "3.4"), ("DRS", "3"), ("IPOS", "1.2")):
            projected = project_shared_descriptive_uses(sources, document=document,
                **({"block": "Vector Engine", "domain": "digital"} if document == "IPOS" else {}))
            evidence = {"snapshot_id": "synthetic-approved", "shared_records": projected, "functions": []}
            if document == "IPOS":
                evidence["functional_input"] = build_ipos_functional_input("Vector Engine",
                    {"Function": "Process samples", "Inputs": "samples", "Outputs": "results"},
                    domain="digital", shared_context_records=projected)
            with self.subTest(document=document), tempfile.TemporaryDirectory() as directory:
                path = Path(directory) / "review.md"
                paragraphs = ["# " + section + " Context"]
                path.write_text("\n\n".join(paragraphs), encoding="utf-8")
                _write_docx(path.with_suffix(".docx"), paragraphs)
                report = assess_descriptive_synthesis(path, document, evidence)
                self.assertEqual(report["obligations"]["bounded_synthesis"]["status"], "UNRESOLVED")
                self.assertTrue(any("human review" in gap["reason"] for gap in report["gaps"]))
                self.assertFalse(report["generation_blocking"])
                self.assertEqual(report["literal_exceptions"], [])
                literal = "Source mode/configuration context (4.2 Capture Mode). " + source["statement"]
                for artifact in ("markdown", "docx"):
                    path.write_text("\n\n".join(paragraphs + ([literal] if artifact == "markdown" else [])),
                                    encoding="utf-8")
                    _write_docx(path.with_suffix(".docx"), paragraphs + ([literal] if artifact == "docx" else []))
                    report = assess_descriptive_synthesis(path, document, evidence)
                    self.assertTrue(any(gap["obligation"] == "bounded_synthesis"
                        and gap["artifact"] == ("review.md" if artifact == "markdown" else "review.docx")
                        and "literal source text" in gap["reason"] for gap in report["gaps"]), report["gaps"])

    def test_interpretable_portions_are_synthesized_without_promoting_ambiguous_remainder(self):
        from governed_descriptive_scope import project_shared_descriptive_uses
        from test_governed_descriptive_scope import admitted, record
        from workflow_routing import shared_document_descriptive_contributions

        statement = ("The system supports measurement. The system supports data exchange. "
                     "The enclosure geometry is described in Figure 7.")
        uses = [{"use_id": document.lower(), "document": document, "block": "",
                 "domain": "system" if document == "SRS" else "digital", "role": "context",
                 "start": 0, "end": len(statement), "rationale": "Synthetic reviewed context."}
                for document in ("SRS", "DRS")]
        source = record("mixed-context", statement, evidence_scope="shared", approved_uses_json=json.dumps(uses))
        sources = admitted({"governed_source_context": {"records": [source]}})
        for document in ("SRS", "DRS"):
            projected = project_shared_descriptive_uses(sources, document=document)
            audit = []
            sections = shared_document_descriptive_contributions(projected, document=document, audit_rows=audit)
            rendered = " ".join(text for values in sections.values() for text in values)
            self.assertEqual(rendered, "The system supports measurement and data exchange.")
            self.assertNotIn(statement, rendered)
            self.assertTrue(any(row["decision"] == "projection_gap" for row in audit))
            with tempfile.TemporaryDirectory() as directory:
                path = Path(directory) / "review.md"
                paragraphs = ["# " + next(iter(sections)) + " Context", rendered]
                path.write_text("\n\n".join(paragraphs), encoding="utf-8")
                _write_docx(path.with_suffix(".docx"), paragraphs)
                report = assess_descriptive_synthesis(path, document,
                    {"snapshot_id": "synthetic-approved", "shared_records": projected, "functions": []})
                self.assertEqual(report["obligations"]["bounded_synthesis"]["status"], "UNRESOLVED", report["gaps"])
                self.assertEqual(len(report["claim_to_source"]), 4)
                self.assertEqual(report["status"], "UNRESOLVED")

    def test_shared_function_is_not_detached_from_an_unsupported_restriction(self):
        from workflow_routing import extract_srs_descriptive_facts

        for statement in (
            "The system stores samples. Except when the buffer is full.",
            "The system stores samples. (Except when the buffer is full)",
            "The system stores samples only when the buffer is available.",
            "The system stores samples. This works only in a mode described in Figure 8.",
        ):
            with self.subTest(statement=statement):
                facts, gap = extract_srs_descriptive_facts(
                    statement, source="synthetic", scope="architecture", section="3.4")
                self.assertEqual(facts, [])
                self.assertTrue(gap)

    def test_shared_object_actions_and_independent_inventory_activities_are_supported(self):
        functional = build_ipos_functional_input("Orion",
            {"Function": "Generate and receive commands, process values, and store results",
             "Inputs": "samples", "Outputs": "results"}, domain="digital")
        sections, audit = compose_ipos_overview(functional)
        self.assertEqual(sections["functionality"], [])
        self.assertIn("The Orion block processes values.", sections["scope"])
        self.assertIn("The Orion block stores results.", sections["scope"])
        self.assertNotIn("Generate and receive commands", str(sections))
        self.assertIn("The Orion block generates commands.", sections["scope"])
        self.assertIn("The Orion block receives commands.", sections["scope"])
        self.assertFalse(any("ambiguous" in row.get("reason", "") for row in audit))
        with tempfile.TemporaryDirectory() as directory:
            path, _paragraphs = self.materialize(directory, functional)
            report = self.assess(path, functional)
            self.assertEqual(report["status"], "UNRESOLVED")
            for predicate in ("process", "store"):
                self.assertTrue(any(row["meaning"]["predicate"] == predicate
                                    for row in report["claim_to_source"]))

    def test_inventory_actions_with_shared_qualifications_remain_one_dependency_bundle(self):
        from workflow_routing import bounded_functional_summary

        for source in ("Process samples only when ready, and store results",
                       "Process samples only when ready and store results"):
            projection = bounded_functional_summary(source)
            self.assertEqual(projection.responsibilities, ())
            self.assertTrue(projection.gap)

    def test_qualified_coverage_preserves_exact_portions_and_setup_dependencies(self):
        from descriptive_review_proposals import requested_destination_rows
        from governed_descriptive_scope import project_shared_descriptive_uses, serialize_descriptive_destinations
        from test_descriptive_review_proposals import DescriptiveReviewProposalTests
        from test_governed_descriptive_scope import admitted
        from workflow_routing import qualified_shared_context_coverage

        profile, source, request = DescriptiveReviewProposalTests().configuration_profile()
        rows = requested_destination_rows(request, source, [source], profile, list(profile["block_defs"]))
        for row in rows:
            row["review_decision"] = "approved"
        source.update(serialize_descriptive_destinations(source, "shared", rows))
        projected = project_shared_descriptive_uses(admitted(profile), document="DRS")[0]
        coverage = qualified_shared_context_coverage(projected)
        self.assertEqual(len(coverage), 4)
        self.assertEqual(coverage[0]["classification"], "configuration")
        for portion in coverage:
            span = portion["span"]
            self.assertEqual(source["statement"][span["start"]:span["end"]], span["text"])
        self.assertTrue(all(portion["dependencies"] for portion in coverage[1:]))
        self.assertIn("except when FIFO FULL occurs", coverage[-1]["span"]["text"])
        self.assertTrue(all(not portion["synthesized"] for portion in coverage))

    def test_historical_literal_contract_keeps_its_integrity_interpretation(self):
        from governed_descriptive_scope import project_shared_descriptive_uses
        from test_governed_descriptive_scope import admitted, fixture
        from workflow_routing import _shared_descriptive_audit, validate_shared_descriptive_artifacts

        for document, section in (("SRS", "3.1"), ("DRS", "3")):
            projected = project_shared_descriptive_uses(admitted(fixture()), document=document)
            with tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                path = root / "legacy.md"
                paragraphs = ["# " + section + " Context", projected[0]["statement"]]
                path.write_text("\n\n".join(paragraphs), encoding="utf-8")
                _write_docx(path.with_suffix(".docx"), paragraphs)
                payload = _shared_descriptive_audit(
                    projected, document=document, snapshot_id="synthetic-approved", legacy_literal=True)
                path.with_name("governed_shared_context_audit.json").write_text(
                    json.dumps(payload), encoding="utf-8")
                with patch("validate_downstream_coherence.resolve_downstream_contract") as resolver:
                    resolver.return_value.shared_descriptive_context.return_value = projected
                    self.assertEqual(validate_shared_descriptive_artifacts(
                        root, path, document=document, snapshot_id="synthetic-approved"), [])
                report = assess_descriptive_synthesis(path, document,
                    {"snapshot_id": "synthetic-approved", "shared_records": projected, "functions": []})
                self.assertEqual(report["obligations"]["bounded_synthesis"]["status"], "UNRESOLVED")

    def test_independent_checks_do_not_call_the_planner_or_composer(self):
        functional = self.functional()
        with tempfile.TemporaryDirectory() as directory:
            path, _paragraphs = self.materialize(directory, functional)
            with patch("workflow_routing.build_ipos_claim_plan", side_effect=AssertionError("planner replay")), \
                    patch("workflow_routing.compose_ipos_overview", side_effect=AssertionError("composer replay")):
                report = self.assess(path, functional)
            self.assertEqual(report["status"], "PASS", report["gaps"])
            self.assertEqual(set(report["obligations"]),
                             set(load_descriptive_synthesis_contract("IPOS")["obligations"]))
            self.assertTrue(report["claim_to_source"])

    def test_different_names_and_quantities_preserve_restrictions(self):
        for owner, extent in (("Nimbus", "4.25Kbyte"), ("Vector Engine", "7Kbyte")):
            with self.subTest(owner=owner), tempfile.TemporaryDirectory() as directory:
                functional = self.functional(owner, extent)
                path, _paragraphs = self.materialize(directory, functional)
                self.assertIn(f"Only the first {extent} of {owner} RAM", path.read_text(encoding="utf-8"))
                self.assertEqual(self.assess(path, functional)["status"], "PASS")

    def test_markdown_mutations_are_detected_without_changing_producer_audit(self):
        functional = self.functional()
        with tempfile.TemporaryDirectory() as directory:
            path, paragraphs = self.materialize(directory, functional)
            original = path.read_text(encoding="utf-8")
            for before, after, obligation in (
                ("Only the first 4.25Kbyte", "Only the first 9Kbyte", "semantic_fidelity"),
                ("nimbus initializes", "Foreign initializes", "semantic_fidelity"),
                ("Only the first 4.25Kbyte of Nimbus RAM is cleared.", "", "semantic_fidelity"),
                ("During reset, ", "", "essential_qualifications"),
                ("supports FUSE boot/write/test", "supports FUSE boot/test", "supported_function_coverage"),
                ("initializes", "does not initialize", "essential_qualifications"),
                (". Only the first", ".\n\nOnly the first", "essential_qualifications"),
                ("# 1.4 Supported block functions", "# 1.2 Supported functions and scope", "section_roles"),
            ):
                with self.subTest(mutation=before):
                    changed = original.replace(before, after)
                    self.assertNotEqual(changed, original)
                    path.write_text(changed, encoding="utf-8")
                    report = self.assess(path, functional)
                    self.assertEqual(report["obligations"][obligation]["status"], "UNRESOLVED", report["gaps"])
            path.write_text(original, encoding="utf-8")
            _write_docx(path.with_suffix(".docx"), [text.replace("4.25Kbyte", "9Kbyte") for text in paragraphs])
            report = self.assess(path, functional)
            self.assertTrue(any(row["artifact"] == "review.docx" for row in report["gaps"]))

    def test_configuration_placement_and_duplication_are_checked_in_actual_output(self):
        functional = self.functional()
        with tempfile.TemporaryDirectory() as directory:
            path, _paragraphs = self.materialize(directory, functional)
            original = path.read_text(encoding="utf-8")
            path.write_text(original.replace("# 1.4", "The depth of each Sub-FIFO is configurable by regmap.\n\n# 1.4"),
                            encoding="utf-8")
            self.assertEqual(self.assess(path, functional)["obligations"]["section_roles"]["status"], "UNRESOLVED")
            first = original.split("\n\n")[1]
            path.write_text(original + "\n\n" + first, encoding="utf-8")
            self.assertEqual(self.assess(path, functional)["obligations"]["nonduplication"]["status"], "UNRESOLVED")

    def test_unsupported_restriction_withholds_its_dependent_action(self):
        functional = build_ipos_functional_input("Orion",
            {"Function": "Process samples", "Inputs": "samples", "Outputs": "results"},
            [{"source_req_id": "reset", "statement":
              "During reset, Orion shall write Orion RAM with the value 0. "
              "Only an unspecified subset described in Figure 9 shall be cleared."}], domain="digital")
        sections, audit = compose_ipos_overview(functional)
        self.assertNotIn("initializes Orion RAM", " ".join(sections["internal_functions"]))
        self.assertTrue(any(row.get("decision") in {"projection_gap", "omitted"} for row in audit))

    def test_shared_context_does_not_grant_local_ownership(self):
        from governed_descriptive_scope import project_shared_descriptive_uses
        from test_governed_descriptive_scope import admitted, fixture
        records = admitted(fixture())
        shared = project_shared_descriptive_uses(records, document="IPOS", block="Compute Unit", domain="digital")
        functional = build_ipos_functional_input("Compute Unit",
            {"Function": "Process samples", "Inputs": "samples", "Outputs": "results"}, domain="digital",
            descriptive_source_records=[row for row in records if row.get("mapped_block") == "Compute Unit"],
            shared_context_records=shared)
        sections, audit = compose_ipos_overview(functional)
        self.assertNotIn("The system supports measurement.", " ".join(text for values in sections.values() for text in values))
        self.assertTrue(any("functional ownership" in row.get("reason", "") for row in audit))

    def test_integration_classification_does_not_invent_other_family_members(self):
        from run_drs_gen_spec_agent import _drs_top_level_overview
        prose = _drs_top_level_overview([("Unit A", "Unit B", "control transactions")])
        self.assertIn("control exchange", prose)
        for absent in ("interrupt", "configuration", "status", "clock", "host"):
            self.assertNotIn(absent, prose)


if __name__ == "__main__":
    unittest.main()
