"""Local trial isolation, exact-delta receipts and protected-file verification."""

import argparse
import difflib
import hashlib
import json
import shutil
import sqlite3
from pathlib import Path

BASE = Path(__file__).resolve().parent
OFFICIAL = Path(r"C:\Users\iannuzza\LOCAL_PROJ\Github_copilot_proj\Deterministic_Reqs_workflow")
PRIOR = OFFICIAL.parent / "review_srs_20261026_1437"
WORKSPACE = BASE / "workspace"
IGNORE = shutil.ignore_patterns("__pycache__", "*.pyc", "~$*", "*-wal", "*-shm")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def protected():
    for directory in (".github", "scripts", "templates", "tests", "docs", "config", "data", "specs", "artifacts"):
        root = OFFICIAL / directory
        for path in root.rglob("*"):
            relative = path.relative_to(OFFICIAL)
            if not path.is_file() or set(relative.parts) & {"__pycache__", "validation", "reviews"}:
                continue
            if path.name.startswith("~$") or path.suffix == ".pyc":
                continue
            yield relative, path


def setup():
    if (BASE / "baseline.json").exists() or WORKSPACE.exists():
        raise RuntimeError("Trial already initialized; do not overwrite a baseline")
    hashes = {str(relative): digest(path) for relative, path in protected()}
    (BASE / "baseline.json").write_text(json.dumps(hashes, indent=2) + "\n", encoding="utf-8")
    for name in (".github", "scripts", "templates", "tests", "docs"):
        shutil.copytree(OFFICIAL / name, BASE / "before" / name, ignore=IGNORE)
    for name in (".github", "scripts", "templates", "tests"):
        shutil.copytree(OFFICIAL / name, WORKSPACE / name, ignore=IGNORE)
    for name in ("config", "specs"):
        shutil.copytree(PRIOR / name, WORKSPACE / name, ignore=IGNORE)
    for directory in (PRIOR / "artifacts").iterdir():
        if directory.is_dir() and directory.name not in {"validation", "reviews"}:
            shutil.copytree(directory, WORKSPACE / "artifacts" / directory.name, ignore=IGNORE)
    destination = WORKSPACE / "data" / "canonical" / "canonical_store.sqlite"
    destination.parent.mkdir(parents=True, exist_ok=True)
    source = PRIOR / "data" / "canonical" / "canonical_store.sqlite"
    with sqlite3.connect(source.as_uri() + "?mode=ro", uri=True) as source_db:
        with sqlite3.connect(destination) as target_db:
            source_db.backup(target_db)
    shutil.copytree(PRIOR / "artifacts" / "reviews" / "system_requirements_specification" / "pilot_final",
                    BASE / "prior_srs_review", ignore=IGNORE)
    for name in ("workflow_routing.py", "run_srs_gen_spec_agent.py", "run_drs_gen_spec_agent.py",
                 "spec_document_contract.py", "governed_descriptive_scope.py", "generate_ipos_specs.py"):
        relative = Path("scripts") / name
        diff = difflib.unified_diff(
            (OFFICIAL / relative).read_text(encoding="utf-8").splitlines(keepends=True),
            (PRIOR / relative).read_text(encoding="utf-8").splitlines(keepends=True),
            fromfile="official-before/" + str(relative), tofile="prior-trial/" + str(relative))
        (BASE / (name + ".prior.diff")).write_text("".join(diff), encoding="utf-8")
    print(f"Protected baseline: {len(hashes)} files. Isolated workspace: {WORKSPACE}")


def receipt():
    hashes = json.loads((BASE / "baseline.json").read_text(encoding="utf-8"))
    changed = []
    for relative, original in hashes.items():
        path = OFFICIAL / relative
        if not path.exists() or digest(path) != original:
            changed.append(relative)
    source_prefixes = ("scripts\\", "tests\\", "templates\\", "docs\\", ".github\\")
    permitted = [value for value in changed if value.startswith(source_prefixes)]
    protected_changes = [value for value in changed if value not in permitted]
    diff_lines = []
    for directory in (".github", "scripts", "templates", "tests", "docs"):
        for path in (OFFICIAL / directory).rglob("*"):
            if not path.is_file() or path.suffix not in {".py", ".md"} or "__pycache__" in path.parts:
                continue
            relative = path.relative_to(OFFICIAL)
            before = BASE / "before" / relative
            old = before.read_text(encoding="utf-8").splitlines(keepends=True) if before.exists() else []
            new = path.read_text(encoding="utf-8").splitlines(keepends=True)
            delta = list(difflib.unified_diff(old, new, fromfile="before/" + str(relative),
                                            tofile="after/" + str(relative)))
            if delta:
                diff_lines.extend(delta)
                if str(relative) not in permitted:
                    permitted.append(str(relative))
    (BASE / "integration.diff").write_text("".join(diff_lines), encoding="utf-8")
    result = {"baseline_count": len(hashes), "changed_source_files": permitted,
              "protected_changes": protected_changes, "status": "PASS" if not protected_changes else "FAIL"}
    (BASE / "protection_verification.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
    if protected_changes:
        raise RuntimeError("Protected official content changed")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=("setup", "receipt"))
    args = parser.parse_args()
    {"setup": setup, "receipt": receipt}[args.command]()
