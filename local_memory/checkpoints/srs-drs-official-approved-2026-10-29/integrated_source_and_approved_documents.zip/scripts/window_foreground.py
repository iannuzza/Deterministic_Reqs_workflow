"""Exact-window activation without persistent topmost windows."""

import ctypes
from ctypes import wintypes
from functools import lru_cache
from pathlib import Path
import subprocess
import tempfile


@lru_cache(maxsize=1)
def _user32():
    api = ctypes.WinDLL("user32", use_last_error=True)
    signatures = {
        "IsWindow": ([wintypes.HWND], wintypes.BOOL),
        "IsIconic": ([wintypes.HWND], wintypes.BOOL),
        "ShowWindow": ([wintypes.HWND, ctypes.c_int], wintypes.BOOL),
        "BringWindowToTop": ([wintypes.HWND], wintypes.BOOL),
        "SetForegroundWindow": ([wintypes.HWND], wintypes.BOOL),
        "GetForegroundWindow": ([], wintypes.HWND),
        "GetAncestor": ([wintypes.HWND, wintypes.UINT], wintypes.HWND),
        "FlashWindow": ([wintypes.HWND, wintypes.BOOL], wintypes.BOOL),
        "IsWindowVisible": ([wintypes.HWND], wintypes.BOOL),
        "GetWindowThreadProcessId": ([wintypes.HWND, ctypes.POINTER(wintypes.DWORD)], wintypes.DWORD),
        "GetClassNameW": ([wintypes.HWND, wintypes.LPWSTR, ctypes.c_int], ctypes.c_int),
    }
    for name, (arguments, result) in signatures.items():
        function = getattr(api, name)
        function.argtypes = arguments
        function.restype = result
    return api


def foreground_window(hwnd: int) -> bool:
    """Restore and activate one HWND; Windows may deny foreground permission."""
    api = _user32()
    if not api.IsWindow(hwnd):
        raise OSError("The selected window is no longer available")
    if api.IsIconic(hwnd):
        api.ShowWindow(hwnd, 9)  # SW_RESTORE
    api.BringWindowToTop(hwnd)
    api.SetForegroundWindow(hwnd)
    activated = api.GetForegroundWindow() == hwnd
    if not activated:
        api.FlashWindow(hwnd, True)
    return activated


def tk_window_handle(widget_id: int) -> int:
    hwnd = _user32().GetAncestor(widget_id, 2)  # GA_ROOT includes Tk's native frame.
    if not hwnd:
        raise OSError("The selected GUI window has no native frame")
    return hwnd


class _ProcessEntry(ctypes.Structure):
    _fields_ = [
        ("dwSize", wintypes.DWORD),
        ("cntUsage", wintypes.DWORD),
        ("th32ProcessID", wintypes.DWORD),
        ("th32DefaultHeapID", ctypes.c_size_t),
        ("th32ModuleID", wintypes.DWORD),
        ("cntThreads", wintypes.DWORD),
        ("th32ParentProcessID", wintypes.DWORD),
        ("pcPriClassBase", wintypes.LONG),
        ("dwFlags", wintypes.DWORD),
        ("szExeFile", wintypes.WCHAR * 260),
    ]


def _process_family(process_id: int) -> set[int]:
    api = ctypes.WinDLL("kernel32", use_last_error=True)
    api.CreateToolhelp32Snapshot.argtypes = [wintypes.DWORD, wintypes.DWORD]
    api.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
    api.Process32FirstW.argtypes = [wintypes.HANDLE, ctypes.POINTER(_ProcessEntry)]
    api.Process32FirstW.restype = wintypes.BOOL
    api.Process32NextW.argtypes = [wintypes.HANDLE, ctypes.POINTER(_ProcessEntry)]
    api.Process32NextW.restype = wintypes.BOOL
    api.CloseHandle.argtypes = [wintypes.HANDLE]
    api.CloseHandle.restype = wintypes.BOOL
    snapshot = api.CreateToolhelp32Snapshot(2, 0)
    if snapshot == ctypes.c_void_p(-1).value:
        raise ctypes.WinError(ctypes.get_last_error())
    parents = {}
    entry = _ProcessEntry()
    entry.dwSize = ctypes.sizeof(entry)
    try:
        available = api.Process32FirstW(snapshot, ctypes.byref(entry))
        while available:
            parents[entry.th32ProcessID] = entry.th32ParentProcessID
            available = api.Process32NextW(snapshot, ctypes.byref(entry))
        code = ctypes.get_last_error()
        if code != 18:  # ERROR_NO_MORE_FILES
            raise ctypes.WinError(code)
    finally:
        api.CloseHandle(snapshot)
    family = {process_id}
    while True:
        children = {pid for pid, parent in parents.items() if parent in family}
        if children <= family:
            return family
        family.update(children)


def pdf_window_handle(process_id: int) -> int | None:
    """Find an unambiguous Acrobat frame belonging to the /n launch, not its title."""
    family = _process_family(process_id)
    api = _user32()
    windows = []
    callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
    api.EnumWindows.argtypes = [callback_type, wintypes.LPARAM]
    api.EnumWindows.restype = wintypes.BOOL

    def inspect(hwnd, _data):
        pid = wintypes.DWORD()
        api.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if pid.value in family and api.IsWindowVisible(hwnd):
            class_name = ctypes.create_unicode_buffer(256)
            api.GetClassNameW(hwnd, class_name, len(class_name))
            if class_name.value == "AcrobatSDIWindow":
                windows.append(hwnd)
        return True

    if not api.EnumWindows(callback_type(inspect), 0):
        raise ctypes.WinError(ctypes.get_last_error())
    return windows[0] if len(windows) == 1 else None


_OFFICE_WINDOW_SCRIPT = """
On Error Resume Next
Dim target, kind, app, documents, document, view, attempt, hwnd
target = LCase(CStr(WScript.Arguments(0)))
kind = CStr(WScript.Arguments(1))
For attempt = 1 To 40
    Err.Clear
    Set app = Nothing
    If kind = "excel" Then
        Set app = GetObject(, "Excel.Application")
    Else
        Set app = GetObject(, "Word.Application")
    End If
    If Not app Is Nothing Then
        If kind = "excel" Then
            Set documents = app.Workbooks
        Else
            Set documents = app.Documents
        End If
        For Each document In documents
            Err.Clear
            If LCase(CStr(document.FullName)) = target Then
                Set view = document.Windows(1)
                hwnd = view.Hwnd
                If Err.Number = 0 And hwnd <> 0 Then
                    WScript.Echo CStr(hwnd)
                    WScript.Quit 0
                End If
            End If
        Next
    End If
    WScript.Sleep 250
Next
WScript.Quit 2
"""


def office_window_handle(path: Path, kind: str) -> int:
    """Resolve the exact already-open file without opening or activating a document."""
    if kind not in {"excel", "word"}:
        raise ValueError(f"Unsupported Office application: {kind}")
    with tempfile.NamedTemporaryFile(mode="w", suffix=".vbs", delete=False, encoding="utf-8") as handle:
        script_path = Path(handle.name)
        handle.write(_OFFICE_WINDOW_SCRIPT)
    try:
        result = subprocess.run(
            ["cscript.exe", "//NoLogo", str(script_path), str(path.resolve()), kind],
            capture_output=True,
            text=True,
            timeout=15,
            creationflags=subprocess.CREATE_NO_WINDOW,
        )
        if result.returncode != 0:
            detail = result.stderr.strip() or result.stdout.strip() or "exact document window not found"
            raise OSError(f"Cannot locate the selected {kind} window: {detail}")
        hwnd = int(result.stdout.strip())
        if not hwnd:
            raise OSError("Office returned an empty document window handle")
        return hwnd if hwnd > 0 else hwnd + (1 << 32)
    finally:
        script_path.unlink(missing_ok=True)
