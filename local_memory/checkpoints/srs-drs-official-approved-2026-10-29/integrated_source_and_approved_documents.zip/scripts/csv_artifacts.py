"""Read CSV artifacts while retaining complete source and audit fields."""

from __future__ import annotations

import csv
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator


@contextmanager
def csv_artifact_reader(path: Path, *, encoding: str = "utf-8-sig") -> Iterator[csv.DictReader]:
    previous_limit = csv.field_size_limit()
    try:
        csv.field_size_limit(max(previous_limit, path.stat().st_size))
        with path.open("r", encoding=encoding, newline="") as handle:
            yield csv.DictReader(handle)
    finally:
        csv.field_size_limit(previous_limit)
