"""Deterministic destination discovery; only explicit human decisions admit uses."""

from __future__ import annotations

import hashlib
import json
import re
from typing import Mapping, Sequence

from governed_descriptive_scope import (
    DESTINATION_FIELDS, DOCUMENT_ROLES, SRS_DESTINATION_MEANINGS, descriptive_destination_rows,
    descriptive_scope, review_classification,
    descriptive_excerpt_status,
    explicit_functional_source_support,
)

PROPOSAL_FIELDS = (*DESTINATION_FIELDS, "review_decision", "proposal_reason", "support_status", "proposal_fingerprint")
VISIBLE_DESCRIPTIVE_FIELDS = {
    "record_id", "statement", "source_file", "section", "printed_page",
    "review_decision", "mapped_block", "domain", "classification",
}
VISIBLE_PROPOSAL_FIELDS = {
    "record_id", "document", "block", "role", "excerpt", "rationale",
    "review_decision", "proposal_reason", "support_status",
}
LEVEL_CHOICES = {"System": "SRS", "Digital": "DRS", "Analog": "ARS"}


def _srs_destination_support(record: Mapping, excerpt: str, role: str) -> str:
    from workflow_routing import functional_meaning_role, srs_source_evidence_model

    model = srs_source_evidence_model(dict(record, statement=excerpt))
    roles = SRS_DESTINATION_MEANINGS.get(role, ())
    if not model.propositions:
        return "projection_gap"
    return "ready" if any(functional_meaning_role(value.meaning) in roles
                          for value in model.propositions) else "unsupported_interpretation"


def _srs_semantic_destinations(record: Mapping) -> list[dict]:
    from workflow_routing import functional_meaning_role, srs_source_evidence_model

    model = srs_source_evidence_model(record)
    groups = {}
    for proposition in model.propositions:
        semantic_role = functional_meaning_role(proposition.meaning)
        for role, meanings in SRS_DESTINATION_MEANINGS.items():
            if role == "context" or semantic_role not in meanings:
                continue
            # Complete mode bodies keep setup, behaviour and exceptions inseparable.
            start, end = ((0, len(record["statement"])) if role == "operating_concept" else
                          (min(span.start for span in proposition.spans),
                           max(span.end for span in proposition.spans)))
            groups.setdefault((role, start, end), []).append(proposition.proposition_id)
    purposes = [(key, values) for key, values in groups.items() if key[0] == "purpose"]
    if purposes:
        groups = {key: values for key, values in groups.items() if key[0] != "purpose"}
        groups[("purpose", min(key[1] for key, _values in purposes),
                max(key[2] for key, _values in purposes))] = [
                    identity for _key, values in purposes for identity in values]
    # A flattened source list may have no punctuation at its semantic boundary.
    # Keep the complete source rather than authorizing a clipped qualification.
    bounded = {}
    for (role, start, end), identities in groups.items():
        first = start if not start or record["statement"][:start].rstrip().endswith((".", "!", "?")) else 0
        last = (end if end == len(record["statement"]) or record["statement"][:end].endswith((".", "!", "?"))
                else len(record["statement"]))
        bounded.setdefault((role, first, last), []).extend(identities)
    groups = bounded
    return [{"role": role, "start": start, "end": end, "proposition_ids": identities}
            for (role, start, end), identities in groups.items()]


def with_descriptive_scope_review(evidence: Mapping, *, functional_roles: Sequence[str],
                                  rationale: str) -> dict:
    """Bind an explicit review-only entity distinction without changing approved inventory."""
    owners = {row["owner"] for row in evidence.get("inventory", ())}
    if (evidence.get("document") not in {"SRS", "DRS"} or not rationale.strip()
            or not evidence.get("snapshot_id") or not evidence.get("architecture_fingerprint")
            or len(set(functional_roles)) != len(functional_roles) or set(functional_roles) - owners):
        raise ValueError("Descriptive scope review requires a bound SRS/DRS scope and unique known entities")
    scope = {
        "snapshot_id": evidence["snapshot_id"],
        "architecture_fingerprint": evidence["architecture_fingerprint"],
        "functional_roles": list(functional_roles), "rationale": rationale,
        "authority": False, "decision": "user_confirmed_descriptive_scope",
    }
    scope["review_fingerprint"] = _hash(scope)
    return {**evidence, "descriptive_scope_review": scope}


def synthesized_destination_proposal(model, *, document: str, section: str,
                                    proposition_ids: Sequence[str], text: str) -> dict:
    """Expose supported prose for review without creating an approved use or widening its source scope."""
    from dataclasses import asdict
    from spec_document_contract import load_descriptive_synthesis_contract

    policy = load_descriptive_synthesis_contract(document)
    if section not in policy["sections"] or not text.strip() or not proposition_ids:
        raise ValueError("Synthesis review requires a contract section, prose and supporting propositions")
    by_id = {value.proposition_id: value for value in model.propositions}
    records = {value.record_id: value for value in model.records}
    if len(set(proposition_ids)) != len(proposition_ids) or set(proposition_ids) - by_id.keys():
        raise ValueError("Synthesis review has duplicate or unknown supporting propositions")
    spans = tuple(dict.fromkeys(span for identity in proposition_ids for span in by_id[identity].spans))
    if any(span.record_id not in records
           or records[span.record_id].text[span.start:span.end] != span.text for span in spans):
        raise ValueError("Synthesis review provenance differs from the admitted evidence")
    row = {
        "document": document, "section": section, "proposed_text": text,
        "proposition_ids": list(proposition_ids), "spans": [asdict(span) for span in spans],
        "review_decision": "pending", "authority": False,
        "support_status": "supported_prose_requires_destination_review",
        "authorization_request": (
            "Review the traced propositions and proposed prose for " + document + " section " + section
            + "; authorize the destination explicitly through the existing descriptive review workflow. "
            "This proposal does not approve reuse, alter source excerpts or change the snapshot."
        ),
    }
    if document == "SRS":
        from governed_descriptive_scope import DOCUMENT_SECTIONS
        role = next((role for role, target in DOCUMENT_SECTIONS["SRS"].items() if target == section), None)
        requests = []
        for source_id in dict.fromkeys(span.record_id for span in spans):
            bound = json.loads(records[source_id].provenance[1])
            if bound.get("record_type") != "governed_shared_use" or role is None:
                continue
            binding = json.loads(bound["provenance_json"])
            original, use = binding["record"], binding["approved_use"]
            relevant = [span for span in spans if span.record_id == source_id]
            start = use["start"] + min(span.start for span in relevant)
            end = use["start"] + max(span.end for span in relevant)
            if role == "operating_concept":
                start, end = 0, len(original["statement"])
            excerpt = original["statement"][start:end]
            requests.append({"record_id": original["record_id"], "document": document, "block": "",
                "domain": "system", "role": role, "start": start, "end": end, "excerpt": excerpt,
                "rationale": "Supported interpretation proposed for explicit " + section + " review.",
                "support_status": _srs_destination_support(original, excerpt, role),
                "review_decision": "pending"})
        row["destination_requests"] = requests
    row["proposal_fingerprint"] = _hash(row)
    return row


def _hash(value) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=True).encode("utf-8")).hexdigest()


def _source_binding(record: Mapping) -> dict:
    value = {key: value for key, value in record.items()
             if key not in {"approved_uses_json", "review_decision", "admission_state", "snapshot_id"}}
    value["evidence_scope"] = review_classification(record)
    return value


def _binding(record: Mapping, records: Sequence[Mapping], profile: Mapping, catalogue: Sequence[str],
             policy: int = 4) -> str:
    local = sorted((_source_binding(value) for value in records
                    if value.get("review_decision") == "approved" and descriptive_scope(value) == "block_local"),
                   key=lambda value: value["record_id"])
    return _hash({"parent": _source_binding(record), "local": local,
                  "blocks": profile.get("block_defs", {}), "catalogue": list(catalogue), "policy": policy})


def _seal(row: Mapping, record: Mapping, records: Sequence[Mapping], profile: Mapping,
          catalogue: Sequence[str], kind: str, *, policy: int = 4) -> str:
    return kind + ":" + _hash({
        "binding": _binding(record, records, profile, catalogue, policy),
        "row": {key: value for key, value in row.items()
                if key not in {"review_decision", "rationale", "proposal_fingerprint"}},
    })


def _named(text: str, name: str) -> bool:
    tokens = re.findall(r"[a-z0-9]+", name.casefold())
    return bool(tokens) and bool(re.search(r"(?<!\w)" + r"[\W_]*".join(map(re.escape, tokens)) + r"(?!\w)",
                                          text, re.IGNORECASE))


def _contains_local_section(parent: Mapping, local: Mapping) -> bool:
    section = str(parent.get("section") or "")
    revision = parent.get("source_revision_id")
    return bool(section and revision and parent.get("source_file")
                and local.get("source_file") == parent["source_file"]
                and local.get("source_revision_id") == revision
                and str(local.get("section") or "").startswith(section + "."))


def _local_evidence(records: Sequence[Mapping], profile: Mapping, block: str) -> list[Mapping]:
    return [value for value in records if value.get("review_decision") == "approved"
            and value.get("mapped_block") == block
            and value.get("domain") in {"digital", "analog"} and block in profile.get("block_defs", {})]


def _context_domain(row: Mapping, record: Mapping) -> str:
    domain = str(row.get("domain") or record.get("domain") or "")
    return domain if domain in {"digital", "analog", "system", "mixed_signal"} else ""


def _unchanged_context_decision(old: Mapping, new: Mapping, record: Mapping, records: Sequence[Mapping],
                                profile: Mapping, catalogue: Sequence[str],
                                previous_profile: Mapping | None = None) -> bool:
    if old.get("role") != "context" or old.get("review_decision") not in {"approved", "rejected"}:
        return False
    if any(str(old.get(key, "")) != str(new.get(key, "")) for key in
           ("record_id", "document", "block", "role", "excerpt", "start", "end", "supporting_record_ids")):
        return False
    normalized = dict(old)
    for key in ("start", "end"):
        if not str(normalized.get(key, "")).isdigit():
            return False
        normalized[key] = int(normalized[key])
    fingerprint = str(old.get("proposal_fingerprint", ""))
    kind = fingerprint.partition(":")[0]
    return any(fingerprint == _seal(normalized, record, records, candidate, catalogue, kind, policy=policy)
               for candidate in (profile, previous_profile) if candidate is not None for policy in (2, 3))


def _block_selections(text: str, catalogue: Sequence[str]) -> list[str]:
    names = [(tuple(name.casefold().split()), name) for name in catalogue if name not in LEVEL_CHOICES]
    selected = []
    for part in re.split(r"[,;]", text):
        words = tuple(part.casefold().split())
        if not words:
            raise ValueError("Empty block choice; use exact catalogue names separated by commas or spaces.")
        exact = [name for tokens, name in names if tokens == words]
        if len(exact) == 1:
            selected.append(exact[0])
            continue
        paths = {len(words): [()]}
        for index in range(len(words) - 1, -1, -1):
            paths[index] = [
                (name, *tail) for tokens, name in names
                if words[index:index + len(tokens)] == tokens
                for tail in paths.get(index + len(tokens), [])
            ][:2]
        if len(paths[0]) != 1:
            raise ValueError("Unknown or ambiguous block list; separate exact catalogue block names with commas: " + part)
        selected.extend(paths[0][0])
    return list(dict.fromkeys(selected))


def requested_destination_rows(row: Mapping, record: Mapping, records: Sequence[Mapping],
                               profile: Mapping, catalogue: Sequence[str]) -> list[dict]:
    """Expand explicit, independent document and block lists into reviewable uses."""
    documents = list(dict.fromkeys(re.split(r"[,;\s]+", str(row.get("document") or "").strip().upper())))
    documents = [value for value in documents if value]
    if any(value not in DOCUMENT_ROLES for value in documents):
        raise ValueError("Unknown document level; choose SRS, DRS, ARS or IPOS: " + str(row.get("document")))
    block_text = str(row.get("block") or "").strip()
    blocks = _block_selections(block_text, catalogue) if block_text else []
    if (not documents and not blocks) or ("IPOS" in documents and not blocks):
        raise ValueError("Select document levels and/or concrete blocks; IPOS requires a block.")
    statement = str(record["statement"])
    excerpt = str(row.get("excerpt") or "")
    if (not str(row.get("start", "")).isdigit() or not str(row.get("end", "")).isdigit()
            or not excerpt):
        raise ValueError("Keep the source excerpt and offsets unchanged when editing destinations.")
    start, end = int(row["start"]), int(row["end"])
    if not 0 <= start < end <= len(statement) or statement[start:end] != excerpt:
        raise ValueError("Destination excerpt differs from immutable source: " + record["record_id"])
    role = str(row.get("role") or "")
    result = []

    def add(document, block, domain, support=(), status="ready"):
        if role not in DOCUMENT_ROLES[document]:
            status = "unsupported_descriptive_role"
        elif document == "SRS" and role != "context" and status == "ready":
            status = _srs_destination_support(record, excerpt, role)
        value = dict(
            record_id=record["record_id"], document=document, block=block, domain=domain, role=role,
            excerpt=excerpt, start=start, end=end, rationale=str(row.get("rationale") or ""),
            supporting_record_ids=";".join(value["record_id"] for value in support),
            review_decision="pending", proposal_reason="Explicit human-selected destination; evidence checks still apply.",
            support_status=descriptive_excerpt_status(record, excerpt, role, status, document=document),
        )
        value["use_id"] = "requested-" + _hash({key: value[key] for key in
            ("document", "block", "domain", "role", "start", "end", "supporting_record_ids")})[:16]
        value["proposal_fingerprint"] = _seal(value, record, records, profile, catalogue, "requested")
        result.append(value)

    for document in documents:
        if document != "IPOS":
            add(document, "", {"SRS": "system", "DRS": "digital", "ARS": "analog"}[document])
    for block in blocks:
        local = [value for value in _local_evidence(records, profile, block)
                 if value["record_id"] != record["record_id"]]
        if not local:
            domain = _context_domain(row, record) if role == "context" else ""
            if role == "functions" and explicit_functional_source_support(excerpt, block):
                domain = _context_domain(row, record)
            status = ("needs_architecture_profile" if block not in profile.get("block_defs", {}) else
                      "ready" if domain else "needs_context_domain" if role == "context" else "needs_local_evidence")
            if role == "functions" and block in profile.get("block_defs", {}) and domain in {"digital", "analog"}:
                status = "ready"
            add("IPOS", block, domain, status=status)
            continue
        for domain in sorted({value["domain"] for value in local}):
            support = [value for value in local if value["domain"] == domain]
            if role == "functions":
                support = [value for value in support if excerpt in str(value["statement"])]
            add("IPOS", block, domain, support,
                status="ready" if support or explicit_functional_source_support(excerpt, block)
                else "needs_functional_evidence")
    return result


def destination_proposals(record: Mapping, records: Sequence[Mapping], profile: Mapping,
                          catalogue: Sequence[str]) -> list[dict]:
    if review_classification(record) != "shared" or record.get("review_decision") == "rejected":
        return []
    statement = str(record["statement"])
    excerpt = statement.strip()
    start, end = statement.find(excerpt), statement.find(excerpt) + len(excerpt)
    headings = str(record.get("section_context_json") or "")
    candidates = []

    def add(document, block="", domain="", role="context", support=(), reason="", status="ready",
            text=excerpt, first=start, last=end):
        row = dict(record_id=record["record_id"], document=document, block=block, domain=domain, role=role,
                   excerpt=text, start=first, end=last, rationale=reason,
                   supporting_record_ids=";".join(support), review_decision="pending",
                   proposal_reason=reason, support_status=descriptive_excerpt_status(
                       record, text, role, status, document=document))
        row["use_id"] = "auto-" + _hash({key: row[key] for key in
                                       ("document", "block", "domain", "role", "start", "end", "supporting_record_ids")})[:16]
        row["proposal_fingerprint"] = _seal(row, record, records, profile, catalogue, "auto")
        candidates.append(row)

    if record.get("domain") == "system" or re.search(r"\b(?:top[- ]?level|system|functional modes|operating modes)\b",
                                                     headings, re.IGNORECASE):
        add("SRS", domain="system", reason="Source heading or reviewed domain identifies system-level context.")
    for domain, document in (("digital", "DRS"), ("analog", "ARS")):
        if record.get("domain") in {domain, "mixed_signal"}:
            add(document, domain=domain, reason="Reviewed source domain identifies this subsystem context.")
    for block in catalogue:
        local = [value for value in _local_evidence(records, profile, block)
                 if value["record_id"] != record["record_id"]]
        hierarchy = any(_contains_local_section(record, value) for value in local)
        if block in LEVEL_CHOICES or not (_named(excerpt, block) or hierarchy):
            continue
        if not local:
            domain = _context_domain({}, record)
            status = ("needs_architecture_profile" if block not in profile.get("block_defs", {}) else
                      "ready" if domain else "needs_context_domain")
            add("IPOS", block=block, domain=domain,
                reason="Named actor is a pending context destination only; explicit human review authorizes reuse.",
                status=status)
            continue
        for domain in sorted({value["domain"] for value in local}):
            support = [value for value in local if value["domain"] == domain]
            exact = [value for value in support if str(value["statement"]).strip() in statement]
            if exact:
                for value in exact:
                    text = str(value["statement"]).strip()
                    first = statement.index(text)
                    add("IPOS", block, domain, "functions", (value["record_id"],),
                        "Literal functional passage is also present in approved same-block local evidence.",
                        text=text, first=first, last=first + len(text))
            else:
                add("IPOS", block, domain, support=tuple(value["record_id"] for value in support),
                    reason=("Same-revision source section contains an approved local block section; context only."
                            if hierarchy else
                            "Explicit named actor plus approved local evidence; context only, not functional ownership."))
    if record.get("domain") == "system" or any(row["document"] == "SRS" for row in candidates):
        for semantic in _srs_semantic_destinations(record):
            first, last = semantic["start"], semantic["end"]
            add("SRS", domain="system", role=semantic["role"], text=statement[first:last],
                first=first, last=last,
                reason="Supported source interpretation; explicit destination review required: " +
                       ", ".join(semantic["proposition_ids"]))
    if not candidates:
        add("", reason="No documented hierarchy level or supported block relationship could be established.",
            status="needs_scope_evidence")
    return candidates


def legacy_destination_rows(record: Mapping, records: Sequence[Mapping], profile: Mapping,
                            catalogue: Sequence[str], baselines: Sequence[Mapping]) -> list[dict]:
    admitted = [row for baseline in baselines if baseline.get("record_id") == record["record_id"]
                and baseline.get("review_decision") == "approved" for row in descriptive_destination_rows(baseline)]
    result = []
    for row in descriptive_destination_rows(record):
        known = row in admitted
        row.update(review_decision="approved" if known else "pending",
                   proposal_reason="Existing reviewed destination; unchanged." if known else
                   "Existing working-review destination; explicit confirmation required.",
                   support_status="ready")
        row["proposal_fingerprint"] = _seal(row, record, records, profile, catalogue, "existing" if known else "working")
        result.append(row)
    return result


def _destination_references(record: Mapping, records: Sequence[Mapping], profile: Mapping,
                            catalogue: Sequence[str], baselines: Sequence[Mapping]) -> dict:
    references = {}
    for baseline in baselines:
        if baseline.get("record_id") == record["record_id"]:
            original = dict(record, approved_uses_json=baseline.get("approved_uses_json", "[]"))
            references.update((row["use_id"], row) for row in
                              legacy_destination_rows(original, records, profile, catalogue, baselines))
    current = legacy_destination_rows(record, records, profile, catalogue, baselines)
    if not current:
        current = destination_proposals(record, records, profile, catalogue)
    references.update((row["use_id"], row) for row in current)
    references.update((row["use_id"], row) for row in
                      destination_proposals(record, records, profile, catalogue) if row["role"] != "context")
    return references


def refresh_destination_proposals(records: Sequence[Mapping], existing: Sequence[Mapping],
                                 profile: Mapping, catalogue: Sequence[str], baselines: Sequence[Mapping],
                                 *, previous_profile: Mapping | None = None) -> list[dict]:
    result = []
    previous = {(row["record_id"], row["use_id"]): row for row in existing}
    for record in records:
        legacy = legacy_destination_rows(record, records, profile, catalogue, baselines)
        legacy = [row for row in legacy if not str(previous.get((row["record_id"], row["use_id"]), {}).get(
                      "proposal_fingerprint", "")).startswith(("auto:", "requested:"))]
        candidates = destination_proposals(record, records, profile, catalogue)
        if review_classification(record) != "shared":
            # Do not silently erase approved shared decisions when a classification changes.
            result.extend(row for row in existing if row["record_id"] == record["record_id"]
                          and row.get("review_decision") == "approved")
            continue
        reference = _destination_references(record, records, profile, catalogue, baselines)
        reference.update((row["use_id"], row) for row in legacy or candidates)
        previous_rows = [row for row in existing if row["record_id"] == record["record_id"]]

        def edited_targets(row):
            original = reference.get(row["use_id"])
            return original is not None and any(str(row[key]) != str(original[key])
                                                for key in ("document", "block", "role"))
        if any(str(row.get("proposal_fingerprint", "")).startswith("requested:") or edited_targets(row)
               for row in previous_rows):
            selected = {}
            for old in previous_rows:
                requested = str(old.get("proposal_fingerprint", "")).startswith("requested:") or edited_targets(old)
                if requested:
                    refreshed = requested_destination_rows(old, record, records, profile, catalogue)
                else:
                    refreshed = [reference[old["use_id"]]] if old["use_id"] in reference else []
                for value in refreshed:
                    if (value["proposal_fingerprint"] == old.get("proposal_fingerprint")
                            or _unchanged_context_decision(
                                old, value, record, records, profile, catalogue, previous_profile)):
                        value.update(review_decision=old["review_decision"], rationale=old["rationale"])
                    key = tuple(str(value.get(field, "")) for field in
                                ("document", "block", "domain", "role", "start", "end", "supporting_record_ids"))
                    selected.setdefault(key, value)
            result.extend(selected.values())
            selected_keys = {tuple(str(row.get(field, "")) for field in
                                  ("document", "block", "domain", "role", "start", "end"))
                             for row in selected.values()}
            for candidate in candidates:
                key = tuple(str(candidate.get(field, "")) for field in
                            ("document", "block", "domain", "role", "start", "end"))
                if candidate["role"] != "context" and key not in selected_keys:
                    old = previous.get((candidate["record_id"], candidate["use_id"]), {})
                    if old.get("proposal_fingerprint") == candidate["proposal_fingerprint"]:
                        candidate.update(review_decision=old["review_decision"], rationale=old["rationale"])
                    result.append(candidate)
            continue
        if legacy:
            result.extend(legacy)
            known = {(row["document"], row["block"], row["role"], int(row["start"]), int(row["end"]))
                     for row in legacy}
            candidates = [row for row in candidates if row["role"] != "context"
                          and (row["document"], row["block"], row["role"], row["start"], row["end"]) not in known]
        for candidate in candidates:
            old = previous.get((candidate["record_id"], candidate["use_id"]), {})
            if not old:
                old = next((value for value in previous_rows if _unchanged_context_decision(
                    value, candidate, record, records, profile, catalogue, previous_profile)), {})
            if (old.get("proposal_fingerprint") == candidate["proposal_fingerprint"]
                    or _unchanged_context_decision(
                        old, candidate, record, records, profile, catalogue, previous_profile)):
                for key in ("review_decision", "rationale"):
                    if key in old:
                        candidate[key] = old[key]
            result.append(candidate)
    return result


def accepted_destination_rows(record: Mapping, records: Sequence[Mapping], rows: Sequence[Mapping],
                              profile: Mapping, catalogue: Sequence[str], baselines: Sequence[Mapping],
                              *, discovery: bool = False) -> list[dict]:
    expected = {(record["record_id"], identity): row for identity, row in
                _destination_references(record, records, profile, catalogue, baselines).items()}
    selected = []
    seen = set()
    for row in rows:
        key = (row["record_id"], row["use_id"])
        if key in seen:
            raise ValueError("Duplicate shared destination: " + str(key))
        seen.add(key)
        kind = str(row.get("proposal_fingerprint", ""))
        decision = row.get("review_decision")
        if decision not in {"pending", "approved", "rejected"}:
            raise ValueError("Invalid destination review decision: " + str(key))
        if discovery and (kind.startswith("requested:") or
                          key in expected and any(str(row[field]) != str(expected[key][field])
                                                  for field in ("document", "block", "role"))):
            continue
        if decision == "rejected":
            continue
        if decision == "pending":
            if discovery and str(row.get("proposal_fingerprint", "")).startswith("working:"):
                selected.append(dict(row))
                continue
            if not discovery and record.get("review_decision") == "approved" and review_classification(record) == "shared":
                raise ValueError("Shared destinations await human accept/reject review: " + record["record_id"])
            continue
        if discovery:
            selected.append(dict(row))
            continue
        reference = expected.get(key)
        if kind.startswith("requested:"):
            reference = next((value for value in requested_destination_rows(row, record, records, profile, catalogue)
                              if value["use_id"] == row["use_id"]), None)
        if reference is None and str(row.get("proposal_fingerprint", "")).startswith("working:"):
            if row["proposal_fingerprint"] == _seal(row, record, records, profile, catalogue, "working"):
                reference = row
        if reference is None or any(str(row.get(field, "")) != str(reference.get(field, ""))
                                    for field in PROPOSAL_FIELDS if field not in {"review_decision", "rationale"}):
            raise ValueError("Shared destination proposal changed; refresh and review again: " + str(key))
        if row["support_status"] == "unsupported_descriptive_excerpt":
            raise ValueError(
                "Shared destination excerpt is unsuitable for descriptive reuse: "
                f'{record["record_id"]}, {row["document"]}, {row["block"] or "(document level)"} '
                "[unsupported_descriptive_excerpt]. The selected excerpt contains normative/structural content "
                "or register steps without complete source-mode context. Review a suitable exact source "
                "excerpt or reject this destination. "
                "This is not a missing block-local evidence finding."
            )
        if row["support_status"] == "projection_gap":
            raise ValueError(
                "Source interpretation requires a reusable adapter rule, not missing evidence: "
                + record["record_id"] + " [projection_gap]. Approval cannot substitute for interpretation.")
        if row["support_status"] != "ready":
            raise ValueError(
                "Shared destination lacks supporting evidence: "
                f'{record["record_id"]}, {row["document"]}, {row["block"] or "(document level)"} '
                f'[{row["support_status"]}]. Supply the missing evidence through architecture review '
                "or reject this destination; selecting approved does not override the evidence checks."
            )
        selected.append(dict(row))
    return selected
