#!/usr/bin/env python3
"""Generate deterministic digital or analog IPOS requirements from a frozen snapshot."""

from __future__ import annotations

import argparse
import csv
import json
import shutil
import subprocess
import warnings
import re
from datetime import date, datetime
from pathlib import Path

from approved_snapshot_resolver import resolve_complete_authoritative_input
from workflow_routing import (
    approved_snapshot_candidate_rows,
    build_ipos_claim_plan,
    build_ipos_functional_input,
    build_ipos_normalized_records,
    build_ipos_semantic_units,
    compose_ipos_overview,
    write_ipos_descriptive_audit,
    write_ipos_structural_audit,
    ipos_claim_preflight_findings,
    apply_shared_spec_markdown_formatting,
    apply_ipos_document_navigation,
    apply_unique_spec_heading_anchors,
    spec_anchor_slug,
    apply_docx_common_spec_formatting,
    GENERATED_SPEC_VERSION,
    apply_docx_authored_requirement_formatting,
    apply_docx_ipos_requirement_style_guard,
    document_author_name,
    document_version_for_snapshot,
    document_version_history_markdown,
)
from spec_document_contract import (
    write_materialization_audit, IPOS_TEMPLATE, load_ipos_contract, ipos_document_contract_report,
)
from allocation_ledger import read_csv, refresh_ledger
from requirement_allocation_policy import BLOCK_LOCAL_ANALOG, BLOCK_LOCAL_DIGITAL
from validate_downstream_coherence import (
    DownstreamCoherenceError,
    ipos_authored_requirement_id,
    resolve_downstream_contract,
    validate_generation_inputs,
)


CONFIG = {
    "digital": {
        "upstream": "DRS",
        "prefix": "IPOS-DIG-REQ",
        "trace": "artifacts/stage5_drs/drs_traceability_matrix.csv",
        "output_dir": "artifacts/stage6_digital_ipos",
        "title": "Digital IPOS - {block_name}",
        "docx": "digital_ipos_requirements_specification.docx",
    },
    "analog": {
        "upstream": "ARS",
        "prefix": "IPOS-ANA-REQ",
        "trace": "artifacts/stage4_ars/ars_traceability_matrix.csv",
        "output_dir": "artifacts/stage7_analog_ipos",
        "title": "Analog IPOS - {block_name}",
        "docx": "analog_ipos_requirements_specification.docx",
    },
}

DOCX_REFERENCE_TEMPLATE = Path("templates/MPT_IPOS_template.docx")


DIGITAL_ARCHITECTURE_TERMS = (
    "i2c", "spi", "ahb", "axi", "apb", "uart", "jtag", "serial",
    "protocol", "bus", "processor", "cpu", "microprocessor", "core", "digital",
)
ANALOG_TERMS = (
    "analog", "sensor", "temperature", "adc", "conversion", "sampling",
    "hysteresis", "relay", "voltage", "noise", "calibration", "afe",
)
POWER_TERMS = ("power", "supply", "voltage", "brown-out", "polarity")
DIGITAL_TERMS = (
    "control", "dsp", "uart", "host", "firmware", "command", "protocol", "gpio",
    "led", "button", "event", "schedule", "mode", "state machine", "telemetry",
    "nvm", "memory", "register", "interrupt", "fifo", "test", "debug",
)


def _read_csv(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        raise RuntimeError(f"Required upstream traceability artifact is missing: {path}")
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return [{key: (value or "").strip() for key, value in row.items()} for row in csv.DictReader(handle)]


def _inventory_blocks(repo_root: Path, kind: str) -> list[str]:
    """Return all concrete inventory blocks applicable to one IPOS domain."""
    inventory_path = repo_root / "artifacts/stage2_mirco_arc/block_inventory.csv"
    if not inventory_path.exists():
        return []
    blocks: list[str] = []
    for row in _read_csv(inventory_path):
        name = row.get("Block", "").strip()
        entity_kind = row.get("Entity kind", "concrete_block").strip().casefold()
        function = row.get("Function", "").casefold()
        if not name or name.casefold() == "unassigned" or entity_kind != "concrete_block":
            continue
        analog_score = sum(term in function for term in ANALOG_TERMS)
        power_score = sum(term in function for term in POWER_TERMS)
        digital_score = sum(term in function for term in DIGITAL_TERMS)
        is_analog = (
            "convert" in function and ("adc" in function or "analog" in function)
        ) or (
            analog_score > digital_score and analog_score >= 2
        ) or (
            power_score > digital_score and power_score >= 2
        )
        if (kind == "analog" and is_analog) or (kind == "digital" and not is_analog):
            blocks.append(name)
    return sorted(dict.fromkeys(blocks), key=str.casefold)


def _digital_inventory_blocks(repo_root: Path) -> list[str]:
    return _inventory_blocks(repo_root, "digital")


def _analog_inventory_blocks(repo_root: Path) -> list[str]:
    return _inventory_blocks(repo_root, "analog")


def _block_slug(block_name: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", block_name.casefold()).strip("-")
    return slug or "unnamed-block"


def _ipos_requirement_id(block_name: str, sequence: int) -> str:
    return ipos_authored_requirement_id(block_name, sequence)


def _block_docx_name(kind: str, block_name: str) -> str:
    return f"{kind}_ipos_{_block_slug(block_name)}.docx"


def _block_markdown_name(kind: str, block_name: str) -> str:
    return f"{kind}_ipos_{_block_slug(block_name)}.md"


def _block_inventory_record(repo_root: Path, block_name: str, *, snapshot_id: str = "") -> dict[str, str]:
    if snapshot_id:
        return resolve_downstream_contract(repo_root, snapshot_id).ipos_inventory(repo_root, block=block_name)
    path = repo_root / "artifacts/stage2_mirco_arc/block_inventory.csv"
    if not path.exists():
        return {}
    return next((row for row in _read_csv(path) if row.get("Block", "").strip() == block_name), {})


def _require_ipos_claim_preflights(
    repo_root: Path,
    kind: str,
    block_names: list[str],
    rows: list[dict[str, str]],
    candidate_rows: list[dict[str, str]],
    *, snapshot_id: str = "",
) -> None:
    failures = []
    downstream = resolve_downstream_contract(repo_root, snapshot_id) if snapshot_id and block_names else None
    for block_name in block_names:
        local_rows = [row for row in rows if row["mapped_block"] == block_name]
        inventory = _block_inventory_record(repo_root, block_name, snapshot_id=snapshot_id)
        functional_input = build_ipos_functional_input(
            block_name, inventory, local_rows,
            domain=kind, materialized=bool(local_rows),
            provenance=("approved snapshot:" + snapshot_id,
                        inventory.get("_synthesis_source", "artifacts/stage2_mirco_arc/block_inventory.csv")),
            candidate_requirement_rows=candidate_rows,
            descriptive_source_records=downstream.descriptive_context(
                repo_root, block=block_name, domain=kind) if downstream is not None else (),
            shared_context_records=downstream.shared_descriptive_context(
                repo_root, document="IPOS", block=block_name, domain=kind) if downstream is not None else (),
        )
        if snapshot_id:
            from ipos_blocker_review import apply_descriptive_omissions
            functional_input = apply_descriptive_omissions(repo_root, snapshot_id=snapshot_id, functional_input=functional_input)
        findings = ipos_claim_preflight_findings(functional_input)
        from validate_downstream_coherence import classify_descriptive_findings
        findings = classify_descriptive_findings(findings)["hard_findings"]
        if findings:
            plan = build_ipos_claim_plan(functional_input)
            unresolved_records = sorted({span.record_id for disposition in plan.dispositions
                                         if disposition.decision == "unresolved" for span in disposition.spans})
            failures.append(block_name + ": " + "; ".join(findings)
                            + "\n  Unresolved source records: " + ", ".join(unresolved_records))
    if failures:
        raise RuntimeError(
            f"IPOS claim preflight blocked {len(failures)}/{len(block_names)} {kind} blocks before IPOS output writes:\n"
            + "\n".join(failures)
        )


def _write_ipos_document(
    repo_root: Path,
    config: dict[str, str],
    kind: str,
    title: str,
    output_dir: Path,
    block_name: str,
    rows: list[dict[str, str]],
    snapshot_id: str,
    require_docx: bool = True,
    candidate_requirement_rows: list[dict[str, str]] | None = None,
) -> None:
    document_contract = load_ipos_contract(repo_root / IPOS_TEMPLATE)
    source_port_path = repo_root / "artifacts/stage2_mirco_arc/source_port_catalog.csv"
    source_ports = []
    if source_port_path.exists():
        source_ports = [
            port
            for port in _read_csv(source_port_path)
            if port.get("Owner", "").strip() == block_name
            and port.get("Ownership status", "").strip().casefold() == "approved"
        ]

    inventory = _block_inventory_record(repo_root, block_name, snapshot_id=snapshot_id)
    downstream = resolve_downstream_contract(repo_root, snapshot_id)
    if candidate_requirement_rows is None:
        candidate_requirement_rows = approved_snapshot_candidate_rows(
            downstream.requirement_input, downstream, domain=kind)
    functional_input = build_ipos_functional_input(
        block_name,
        inventory,
        rows,
        domain=kind,
        materialized=bool(rows),
        provenance=(
            "approved snapshot:" + snapshot_id,
            inventory.get("_synthesis_source", "artifacts/stage2_mirco_arc/block_inventory.csv"),
        ),
        candidate_requirement_rows=candidate_requirement_rows,
        descriptive_source_records=downstream.descriptive_context(
            repo_root, block=block_name, domain=kind),
        shared_context_records=downstream.shared_descriptive_context(
            repo_root, document="IPOS", block=block_name, domain=kind),
    )
    from ipos_blocker_review import apply_descriptive_omissions
    functional_input = apply_descriptive_omissions(repo_root, snapshot_id=snapshot_id, functional_input=functional_input)
    preflight_findings = ipos_claim_preflight_findings(functional_input)
    from validate_downstream_coherence import classify_descriptive_findings
    classified = classify_descriptive_findings(preflight_findings)
    preflight_findings = classified["hard_findings"]
    if preflight_findings:
        raise RuntimeError("IPOS claim preflight blocked materialization: " + "; ".join(preflight_findings[:10]))
    template_path = repo_root / DOCX_REFERENCE_TEMPLATE
    if not template_path.is_file():
        raise RuntimeError(f"IPOS DOCX reference template is missing: {template_path}")
    if shutil.which("pandoc") is None:
        raise RuntimeError("pandoc is required for IPOS DOCX generation but is not available on PATH")
    output_dir.mkdir(parents=True, exist_ok=True)
    overview_sections, ipos_audit = compose_ipos_overview(
        functional_input,
        document_contract=document_contract,
    )
    write_ipos_descriptive_audit(output_dir / "descriptive_summary_audit.csv", ipos_audit)
    write_ipos_structural_audit(output_dir / "descriptive_structure_audit.json", functional_input)
    from dataclasses import asdict
    output_dir.joinpath("responsibility_synthesis_audit.json").write_text(json.dumps(
        [asdict(value) for value in build_ipos_claim_plan(functional_input).evidence.responsibilities],
        indent=2), encoding="utf-8")
    markdown_path = output_dir / _block_markdown_name(kind, block_name)
    document_version = document_version_for_snapshot(markdown_path, snapshot_id)
    document_author = document_author_name()
    lines = [
        f"# {title}",
        "",
        f"- Snapshot: `{snapshot_id}`",
        "",
        f"Author: {document_author}",
        "",
        "## 0. Document Navigation",
        "",
        "### 0.1 Table of contents",
        "- [1. Block overview](#1-block-overview)",
        "- [2. Source I/O](#2-source-io)",
        "- [3. Block requirements](#3-block-requirements)",
        "",
        "### 0.2 Document control",
        "#### Table 1. Version history",
        *document_version_history_markdown(
            markdown_path, snapshot_id, document_version, date.today().isoformat(),
            f"Snapshot {snapshot_id} {kind} IPOS block baseline", document_author,
        ),
        "",
        "### 0.3 Requirement navigation",
        "#### Table. Requirement navigation",
        "| Requirement | Internal link |",
        "|---|---|",
        *[
            f"| {row['ipos_req_id']} | [Go to requirement](#{spec_anchor_slug(row['ipos_req_id'])}) |"
            for row in rows
        ],
        "",
        "## 1. Block overview",
        "",
    ]
    for section, key in zip(document_contract["sections"], overview_sections):
        entries = overview_sections[key]
        if entries:
            lines.extend(["### " + section["title"], ""])
            for entry in entries:
                lines.extend([entry, ""])
    lines.extend(["## 2. Source I/O", ""])
    if source_ports:
        lines.extend([
            "The following approved source I/O entries are owned by this block.",
            "",
            "#### Table. Source I/O",
            "| Port name | Direction | Type / details | Table | Source page |",
            "|---|---|---|---|---|",
        ])
        for port in source_ports:
            lines.append(
                "| " + " | ".join([
                    port.get("Port name", ""),
                    port.get("Direction", ""),
                    port.get("Type / details", "").replace("|", "\\|"),
                    port.get("Table title", ""),
                    port.get("Source page", ""),
                ]) + " |"
            )
    else:
        lines.append("No approved source I/O entries are assigned to this block in the current architecture snapshot.")
    lines.append("")
    if not rows:
        lines.extend([
            "## 3. Block requirements",
            "",
            "### 2.1 Scope status",
            "",
            "Not applicable: no approved upstream requirements are mapped to this block in the selected snapshot.",
            "",
        ])
    lines.extend(["## 3. Block requirements", ""])
    for row in rows:
        lines.extend([
            "",
            f"#### {row['ipos_req_id']}",
            row["requirement_statement"],
            "",
            f"Covers: {row['covers_upstream_req_id']}",
            "",
            "[End]",
            "",
        ])

    lines = apply_unique_spec_heading_anchors(
        apply_shared_spec_markdown_formatting(apply_ipos_document_navigation(lines), preserve_authored_text=True)
    )
    markdown_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    docx_path = output_dir / config["docx"]
    _convert_ipos_markdown_to_docx(markdown_path, template_path, docx_path, repo_root)
    apply_docx_authored_requirement_formatting(docx_path, ("IPOS",))
    apply_docx_ipos_requirement_style_guard(docx_path, authored_requirements={row["ipos_req_id"]: row["requirement_statement"] for row in rows})
    apply_docx_common_spec_formatting(docx_path)
    from workflow_routing import write_descriptive_writing_quality
    write_descriptive_writing_quality(markdown_path, "IPOS", ipos_audit,
                                     functional_input=functional_input, repo_root=repo_root)
    write_materialization_audit(
        output_dir / "materialization_audit.json",
        "IPOS",
        build_ipos_normalized_records(functional_input),
        build_ipos_semantic_units(functional_input, overview_sections, ipos_audit),
        markdown_path,
        docx_path,
    )
    report = ipos_document_contract_report(repo_root, markdown_path, output_dir / "descriptive_summary_audit.csv", functional_input)
    (output_dir / "document_contract_report.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    if report["status"] != "PASS":
        raise RuntimeError("IPOS document contract blocked publication; see " + str(output_dir / "document_contract_report.json"))


def _convert_ipos_markdown_to_docx(markdown_path: Path, template_path: Path, docx_path: Path, repo_root: Path) -> None:
    result = subprocess.run(
        [
            "pandoc",
            str(markdown_path),
            "--from",
            "markdown+pipe_tables+header_attributes+raw_html",
            "--to",
            "docx",
            "--reference-doc",
            str(template_path),
            "-o",
            str(docx_path),
        ],
        cwd=repo_root,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        details = (result.stderr or result.stdout or "Pandoc returned no diagnostic output.").strip()
        lock_path = docx_path.with_name(f"~${docx_path.name[2:]}")
        lock_note = (
            f" Office lock detected at {lock_path}; close the document in Word and, "
            "if no Office process is using it, remove the stale lock before retrying."
            if lock_path.exists()
            else ""
        )
        raise RuntimeError(
            f"IPOS md->docx conversion failed with exit code {result.returncode}: "
            f"{details}{lock_note}"
        )


def generate(repo_root: Path, kind: str, *, snapshot_id: str | None = None, use_latest_approved: bool = False, legacy: bool = False, regenerate_downstream: bool = False, block: str | None = None) -> Path:
    config = CONFIG[kind]
    if legacy:
        raise ValueError("IPOS generation no longer permits legacy or fallback input paths.")
    if regenerate_downstream and not snapshot_id:
        raise ValueError("regenerate_downstream requires snapshot_id")
    if not snapshot_id and not use_latest_approved:
        raise ValueError("Authoritative IPOS generation requires snapshot_id or use_latest_approved.")
    context = json.loads((repo_root / "config" / "project_context.json").read_text(encoding="utf-8"))
    snapshot, selection = resolve_complete_authoritative_input(
        repo_root,
        "6" if kind == "digital" else "7",
        project_id=str(context.get("project_name") or repo_root.name),
        snapshot_id=snapshot_id,
    )
    downstream_contract = resolve_downstream_contract(repo_root, snapshot.snapshot_id)
    coherence = validate_generation_inputs(repo_root, snapshot.snapshot_id, upstream_stages=(config["upstream"],))
    if coherence["decision"] != "PASS":
        raise RuntimeError(f"Downstream snapshot coherence blocked {kind} IPOS generation: {coherence['finding_count']} findings")
    (repo_root / "artifacts" / "traceability_reports").mkdir(parents=True, exist_ok=True)
    (repo_root / "artifacts" / "traceability_reports" / f"{kind}_ipos_snapshot_selection.json").write_text(
        json.dumps(selection, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    if not block:
        refresh_ledger(repo_root, snapshot_id=snapshot.snapshot_id, source_rows=snapshot.rows)
    source_ids = {
        (row.get("source_req_id") or row.get("id") or "").strip()
        for row in snapshot.rows
        if (row.get("source_req_id") or row.get("id") or "").strip()
    }
    canonical_by_source = {
        (row.get("source_req_id") or row.get("id") or "").strip(): row.get("canonical_id") or row.get("id") or ""
        for row in snapshot.rows
    }
    upstream_rows = _read_csv(repo_root / config["trace"])
    ledger_rows = read_csv(repo_root / "artifacts/traceability_reports/requirement_allocation_ledger.csv")
    source_by_id = {
        (row.get("source_req_id") or row.get("id") or "").strip(): row
        for row in snapshot.rows
        if (row.get("source_req_id") or row.get("id") or "").strip()
    }
    allocation_by_source = {
        str(row.get("source_req_id") or row.get("id") or "").strip(): downstream_contract.allocation(
            str(row.get("source_req_id") or row.get("id") or "").strip()
        )
        for row in snapshot.rows
        if str(row.get("source_req_id") or row.get("id") or "").strip()
    }
    records = []
    block_sequences: dict[str, int] = {}
    emitted_sources: set[str] = set()
    expected_class = BLOCK_LOCAL_DIGITAL if kind == "digital" else BLOCK_LOCAL_ANALOG
    for upstream in upstream_rows:
        upstream_id = (upstream.get(f"{config['upstream'].lower()}_req_id") or "").strip()
        source_id = (upstream.get("source_req_id") or "").strip()
        metadata = allocation_by_source.get(source_id, {})
        if (
            not upstream_id
            or not source_id
            or source_id not in source_ids
            or metadata.get("allocation_class") != expected_class
        ):
            continue
        approved_statement = (source_by_id[source_id].get("requirement_statement")
                              or source_by_id[source_id].get("statement") or "").strip()
        if (upstream.get("requirement_statement") or "").strip() != approved_statement:
            raise DownstreamCoherenceError("IPOS upstream requirement text conflicts with approved snapshot: " + source_id)
        mapped_block = (metadata.get("approved_block") or "Unassigned").strip()
        block_sequences[mapped_block] = block_sequences.get(mapped_block, 0) + 1
        emitted_sources.add(source_id)
        records.append({
            "ipos_req_id": _ipos_requirement_id(mapped_block, block_sequences[mapped_block]),
            "source_req_id": source_id,
            "canonical_id": canonical_by_source[source_id],
            "covers_upstream_req_id": upstream_id,
            "mapped_block": mapped_block,
            "requirement_statement": (source_by_id[source_id].get("requirement_statement")
                                      or source_by_id[source_id].get("statement") or "").strip(),
            "snapshot_id": snapshot.snapshot_id,
            "source_artifact": str(snapshot.source_path.relative_to(repo_root)).replace("\\", "/"),
            "allocation_class": metadata.get("allocation_class", ""),
            "owning_target": metadata.get("owning_target", ""),
            "lineage_mode": metadata.get("lineage_mode", ""),
            "source_origin_req_ids": metadata.get("source_origin_req_ids", ""),
            "hierarchy_parent_req_ids": metadata.get("hierarchy_parent_req_ids", ""),
            "owning_domain": metadata.get("owning_domain", ""),
        })

    # A block-local source requirement may legitimately bypass DRS/ARS. The
    # shared ledger is the only authority for this direct allocation decision.
    for ledger in ledger_rows:
        source_id = ledger.get("req_id", "").strip()
        if not source_id or source_id in emitted_sources or ledger.get("hierarchy_or_coverage_class") != expected_class:
            continue
        mapped_block = ledger.get("owning_block", "").strip()
        source = source_by_id.get(source_id, {})
        metadata = allocation_by_source.get(source_id, {})
        if not mapped_block or source_id not in source_ids:
            continue
        block_sequences[mapped_block] = block_sequences.get(mapped_block, 0) + 1
        records.append({
            "ipos_req_id": _ipos_requirement_id(mapped_block, block_sequences[mapped_block]),
            "source_req_id": source_id,
            "canonical_id": canonical_by_source[source_id],
            "covers_upstream_req_id": source_id,
            "mapped_block": mapped_block,
            "requirement_statement": (source.get("requirement_statement") or source.get("statement") or "").strip(),
            "snapshot_id": snapshot.snapshot_id,
            "source_artifact": str(snapshot.source_path.relative_to(repo_root)).replace("\\", "/"),
            "lineage_mode": metadata.get("lineage_mode", ""),
            "allocation_class": metadata.get("allocation_class", ""),
            "owning_target": metadata.get("owning_target", ""),
            "source_origin_req_ids": metadata.get("source_origin_req_ids", ""),
            "hierarchy_parent_req_ids": metadata.get("hierarchy_parent_req_ids", ""),
            "owning_domain": metadata.get("owning_domain", ""),
        })

    mapped_blocks = {
        row["mapped_block"] for row in records if row["mapped_block"] != "Unassigned"
    }
    inventory_blocks = set(_inventory_blocks(repo_root, kind))
    invalid_blocks = sorted(mapped_blocks - inventory_blocks, key=str.casefold)
    if invalid_blocks:
        raise RuntimeError(
            f"{kind.capitalize()} IPOS received block ownership outside the applicable "
            "concrete inventory scope: " + ", ".join(invalid_blocks)
        )
    # Materialize an IPOS document only when the selected snapshot maps at
    # least one approved block-local requirement to its concrete block.
    block_names = sorted(mapped_blocks, key=str.casefold)
    if block:
        selected_block = next((name for name in block_names if _block_slug(name) == _block_slug(block)), None)
        if not selected_block:
            raise RuntimeError(f"Requested IPOS generation block is not materialized by the approved snapshot: {block}")
        block_names = [selected_block]
    materialized_block_names = sorted(mapped_blocks, key=str.casefold)
    candidate_rows = approved_snapshot_candidate_rows(snapshot, downstream_contract, domain=kind)
    review_results = []
    if kind == "digital":
        from ipos_blocker_review import assess_ipos_blocks
        (repo_root / "artifacts/orchestrator").mkdir(parents=True, exist_ok=True)
        review_results = assess_ipos_blocks(repo_root, snapshot_id=snapshot.snapshot_id, kind=kind,
                                            blocks=block_names, rows=records, candidate_rows=candidate_rows,
                                            descriptive_source_records=downstream_contract.descriptive_context(repo_root, domain=kind),
                                            shared_context_by_block={
                                                name: downstream_contract.shared_descriptive_context(
                                                    repo_root, document="IPOS", block=name, domain=kind)
                                                for name in block_names})
        block_names = [value["block"] for value in review_results if value["status"] == "READY"]
    _require_ipos_claim_preflights(repo_root, kind, block_names, records, candidate_rows, snapshot_id=snapshot.snapshot_id)

    output_dir = repo_root / config["output_dir"]
    output_dir.mkdir(parents=True, exist_ok=True)
    legacy_root_docx = output_dir / config["docx"]
    if not block and legacy_root_docx.exists():
        legacy_root_docx.unlink()
    block_root = output_dir / "blocks"
    block_root.mkdir(parents=True, exist_ok=True)
    trace_path = output_dir / "ipos_traceability_matrix.csv"
    fields = [
        "ipos_req_id", "source_req_id", "canonical_id", "covers_upstream_req_id",
        "mapped_block", "requirement_statement", "snapshot_id", "source_artifact", "allocation_class",
        "owning_target", "lineage_mode", "source_origin_req_ids", "hierarchy_parent_req_ids", "owning_domain",
    ]
    if not block:
        with trace_path.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=fields)
            writer.writeheader()
            writer.writerows(records)
    if not block:
        desired_block_dirs = {_block_slug(block_name) for block_name in materialized_block_names}
        for existing_dir in block_root.iterdir():
            if existing_dir.is_dir() and existing_dir.name not in desired_block_dirs:
                try:
                    shutil.rmtree(existing_dir)
                except OSError:
                    pass
    for index, block_name in enumerate(block_names, start=1):
        activity = f"Generate IPOS document {index}/{len(block_names)}: {block_name}"
        started_at = datetime.now().astimezone()
        print(
            f"[IPOS_ACTIVITY] START | {started_at.isoformat(timespec='seconds')} | {activity}",
            flush=True,
        )
        outcome = "failed"
        block_rows = [row for row in records if row["mapped_block"] == block_name]
        block_dir = output_dir / "blocks" / _block_slug(block_name)
        legacy_markdown = block_dir / "ipos_requirements_specification.md"
        if legacy_markdown.exists():
            legacy_markdown.unlink()
        block_config = dict(config)
        block_config["docx"] = _block_docx_name(kind, block_name)
        try:
            document_writer = _write_ipos_document
            if kind == "digital":
                from ipos_blocker_review import publish_ipos_document
                document_writer = lambda *args, **kwargs: publish_ipos_document(_write_ipos_document, *args, **kwargs)
            document_writer(
                repo_root,
                block_config,
                kind,
                config["title"].format(block_name=block_name),
                block_dir,
                block_name,
                block_rows,
                snapshot.snapshot_id,
                require_docx=not legacy,
                candidate_requirement_rows=candidate_rows,
            )
            outcome = "complete"
            if kind == "digital":
                next(value for value in review_results if value["block"] == block_name)["status"] = "PASS"
        except Exception as exc:
            if kind != "digital":
                raise
            from ipos_blocker_review import publication_failure_review
            failure = publication_failure_review(repo_root, snapshot_id=snapshot.snapshot_id, kind=kind,
                       block=block_name, rows=block_rows, candidate_rows=candidate_rows, failure=exc)
            review_results = [failure if value["block"] == block_name else value for value in review_results]
        finally:
            finished_at = datetime.now().astimezone()
            elapsed = str(finished_at - started_at).split(".", 1)[0]
            print(
                f"[IPOS_ACTIVITY] END | {finished_at.isoformat(timespec='seconds')} | "
                f"{activity} | {outcome} | elapsed={elapsed}",
                flush=True,
            )
    if kind == "digital":
        result = {"snapshot_id": snapshot.snapshot_id, "scope": block or "all", "blocks": review_results,
                  "status": "BLOCKED" if any(value["status"] == "BLOCKED" for value in review_results) else "PASS",
                  "authority": False, "gate_override": False}
        result_path = repo_root / "artifacts/orchestrator/ipos_generation_results.json"
        result_path.write_text(json.dumps(result, indent=2, ensure_ascii=True) + "\n", encoding="utf-8")
    return trace_path


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate deterministic IPOS from an approved Stage 2B snapshot.")
    parser.add_argument("--kind", choices=tuple(CONFIG), required=True)
    selector = parser.add_mutually_exclusive_group(required=True)
    selector.add_argument("--snapshot-id", help="Explicit approved canonical snapshot ID")
    selector.add_argument("--use-latest-approved", action="store_true", help="Explicitly select the latest approved snapshot")
    parser.add_argument("--regenerate-downstream", action="store_true", help="Regenerate from the explicit approved snapshot before coherence validation passes")
    parser.add_argument("--block", help="Regenerate one approved materialized IPOS block without modifying other IPOS artifacts")
    args = parser.parse_args()
    if args.regenerate_downstream and not args.snapshot_id:
        parser.error("--regenerate-downstream requires --snapshot-id")
    print(f"Generated {generate(Path(__file__).resolve().parents[1], args.kind, snapshot_id=args.snapshot_id, use_latest_approved=args.use_latest_approved, regenerate_downstream=args.regenerate_downstream, block=args.block)}")
    if args.kind == "digital":
        result_path = Path(__file__).resolve().parents[1] / "artifacts/orchestrator/ipos_generation_results.json"
        result = json.loads(result_path.read_text(encoding="utf-8"))
        if result["status"] == "BLOCKED":
            print("Digital IPOS: BLOCKED/PARTIAL; ready blocks generated, blocked blocks require saved/closed review.")
            return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
