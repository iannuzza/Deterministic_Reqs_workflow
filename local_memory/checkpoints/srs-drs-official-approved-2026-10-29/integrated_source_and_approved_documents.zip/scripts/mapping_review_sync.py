"""Synchronize the editable Stage 2 mapping workbook into its authoritative CSV."""

from __future__ import annotations

import csv
import json
import os
import re
import shutil
import posixpath
import zipfile
from copy import deepcopy
from xml.etree import ElementTree
from pathlib import Path
from tempfile import NamedTemporaryFile, TemporaryDirectory
from xml.sax.saxutils import escape, quoteattr

from openpyxl import load_workbook
from openpyxl.styles import PatternFill
from openpyxl.styles import Protection, Alignment
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.worksheet.cell_range import MultiCellRange
from requirement_allocation_policy import requires_hierarchy_parent
from approved_snapshot_resolver import validate_governed_source_context, validate_governed_source_review
from governed_descriptive_scope import (
    CLASSIFICATION_FIELD, DESCRIPTIVE_REVIEW_FIELDS, DESCRIPTIVE_SCOPE_FIELDS,
    DESCRIPTIVE_SCOPES, DESTINATION_FIELDS,
    descriptive_block_choices, review_classification, serialize_descriptive_destinations,
)
from descriptive_review_proposals import (
    LEVEL_CHOICES, PROPOSAL_FIELDS, VISIBLE_DESCRIPTIVE_FIELDS, VISIBLE_PROPOSAL_FIELDS,
    accepted_destination_rows, legacy_destination_rows, refresh_destination_proposals,
)


DESCRIPTIVE_SHEET = "Descriptive Content Review"
DESTINATIONS_SHEET = "Shared Evidence Destinations"


def architecture_review_profile(draft: dict, profile: dict, *, workbook_path: Path) -> dict:
    """Stage catalogue-listed draft definitions; persistence requires explicit approval."""
    result = deepcopy(profile)
    current = result.setdefault("block_defs", {})
    candidates = draft.get("block_defs", {})
    if not isinstance(current, dict) or not isinstance(candidates, dict):
        raise ValueError("Architecture block_defs must be a mapping.")
    workbook = load_workbook(workbook_path, read_only=True, data_only=False)
    try:
        catalogue = set(_review_catalogue(workbook)) - set(LEVEL_CHOICES) - {"Unassigned"}
    finally:
        workbook.close()
    for name, definition in candidates.items():
        if name in catalogue and name not in current:
            if not isinstance(definition, dict):
                raise ValueError("Invalid draft architecture block definition: " + str(name))
            current[name] = deepcopy(definition)
    return result


def _review_catalogue(workbook) -> list[str]:
    if "Approved Block Choices" not in workbook.sheetnames:
        raise ValueError("The canonical Approved Block Choices catalogue is missing.")
    sheet = workbook["Approved Block Choices"]
    values = [str(row[0].value) for row in sheet.iter_rows(min_row=2) if row[0].value not in (None, "")]
    if not values or len(values) != len(set(values)):
        raise ValueError("Approved Block Choices is empty or contains duplicate choices.")
    return values


def write_descriptive_review_sheet(workbook_path: Path, draft: dict) -> None:
    records = draft.get("governed_source_context", {}).get("records", [])
    workbook = load_workbook(workbook_path)
    try:
        if DESCRIPTIVE_SHEET in workbook.sheetnames:
            raise ValueError("Descriptive review sheet already exists; do not overwrite reviewer decisions.")
        sheet = workbook.create_sheet(DESCRIPTIVE_SHEET)
        if "Approved Block Choices" not in workbook.sheetnames:
            choices = workbook.create_sheet("Approved Block Choices")
            choices.append(["approved_block choices"])
            for name in [*LEVEL_CHOICES, *descriptive_block_choices(draft)]:
                choices.append([name])
            choices.sheet_state = "hidden"
        fields = list(DESCRIPTIVE_REVIEW_FIELDS) + sorted({
            field for record in records for field in record if field not in DESCRIPTIVE_REVIEW_FIELDS
        })
        sheet.append(fields)
        for record in records:
            defaults = {"evidence_scope": "block_local", "approved_uses_json": "[]"}
            sheet.append([json.dumps(record[field], sort_keys=True) if isinstance(record.get(field), (dict, list))
                          else str(record.get(field, defaults.get(field, ""))) for field in fields])
        for row in sheet.iter_rows(min_row=2):
            for field, cell in zip(fields, row):
                cell.data_type = "s"
                cell.protection = Protection(locked=field not in DESCRIPTIVE_REVIEW_FIELDS)
                cell.alignment = Alignment(wrap_text=True, vertical="top")
                if field in DESCRIPTIVE_REVIEW_FIELDS:
                    cell.fill = PatternFill("solid", fgColor="FFF2CC")
        for column, field in enumerate(fields, 1):
            sheet.column_dimensions[get_column_letter(column)].width = 75 if field == "statement" else 28
        sheet.freeze_panes = "E2"
        sheet.auto_filter.ref = sheet.dimensions
        sheet.protection.sheet = False
        for column, options in ((1, "pending,approved,rejected"), (3, "digital,analog,mixed_signal,system")):
            validation = DataValidation(type="list", formula1='"' + options + '"', allow_blank=False)
            validation.showErrorMessage = True
            sheet.add_data_validation(validation)
            if records:
                validation.add(f"{get_column_letter(column)}2:{get_column_letter(column)}{len(records) + 1}")
        workbook.save(workbook_path)
    finally:
        workbook.close()
    with TemporaryDirectory() as directory:
        upgrade_descriptive_review_fields(
            workbook_path, draft, draft, backup_path=Path(directory) / "initial_review.xlsx",
        )


def _read_destination_rows(workbook, originals: dict) -> dict:
    sheet = workbook[DESTINATIONS_SHEET]
    if tuple(cell.value for cell in sheet[1][:len(DESTINATION_FIELDS)]) != DESTINATION_FIELDS:
        raise ValueError("Shared destination columns differ from the governed schema.")
    grouped = {identity: [] for identity in originals}
    proposal_format = tuple(cell.value for cell in sheet[1][:len(PROPOSAL_FIELDS)]) == PROPOSAL_FIELDS
    fields = PROPOSAL_FIELDS if proposal_format else DESTINATION_FIELDS
    for cells in sheet.iter_rows(min_row=2, max_col=len(fields)):
        if not any(cell.value not in (None, "") for cell in cells):
            continue
        if any(cell.data_type == "f" for cell in cells):
            raise ValueError("Formulas are not allowed in shared destinations.")
        values = {field: "" if cell.value is None else str(cell.value)
                  for field, cell in zip(fields, cells)}
        identity = values["record_id"]
        if identity not in originals:
            raise ValueError("Unknown descriptive destination record: " + identity)
        grouped[identity].append(values)
    return grouped


def _descriptive_review_error(findings: list[str], headers: list[str], row_numbers: dict[str, int]) -> str:
    instructions = {
        "governed_source_context_invalid_domain": (
            "domain", "choose digital, analog, mixed_signal or system as the source domain, not SRS/DRS/ARS/IPOS"),
        "governed_source_context_unknown_owner": ("mapped_block", "choose a concrete owner in the architecture profile"),
        "governed_source_context_invalid_review_decision": ("review_decision", "choose pending, approved or rejected"),
    }
    messages = []
    for finding in findings:
        code, _, identity = finding.partition(":")
        if code in instructions and identity in row_numbers:
            field, instruction = instructions[code]
            address = f"{get_column_letter(headers.index(field) + 1)}{row_numbers[identity]}"
            messages.append(f"{DESCRIPTIVE_SHEET}!{address} ({field}): {instruction}. [{finding}]")
        else:
            messages.append(finding)
    return "\n".join(messages)


def reviewed_descriptive_context(workbook_path: Path, draft: dict, profile: dict, *, for_proposals: bool = False) -> dict | None:
    context = draft.get("governed_source_context")
    if context is None:
        return None
    lock_path = workbook_path.with_name("~$" + workbook_path.name)
    if lock_path.exists():
        raise ValueError("Save and close the architecture workbook before descriptive admission.")
    workbook = load_workbook(workbook_path, data_only=False)
    try:
        if DESCRIPTIVE_SHEET not in workbook.sheetnames:
            raise ValueError("Architecture workbook is missing Descriptive Content Review.")
        sheet = workbook[DESCRIPTIVE_SHEET]
        headers = [str(cell.value or "") for cell in sheet[1]]
        review_fields = set(DESCRIPTIVE_REVIEW_FIELDS)
        structured = DESTINATIONS_SHEET in workbook.sheetnames
        if structured != (CLASSIFICATION_FIELD in headers):
            raise ValueError("Incomplete structured descriptive review; upgrade the workbook.")
        if structured:
            review_fields.add(CLASSIFICATION_FIELD)
        if not (set(headers) & set(DESCRIPTIVE_SCOPE_FIELDS)):
            review_fields -= set(DESCRIPTIVE_SCOPE_FIELDS)
        expected_fields = review_fields | {
            field for record in context["records"] for field in record
        }
        if len(headers) != len(set(headers)) or set(headers) != expected_fields:
            raise ValueError("Descriptive review columns differ from the draft.")
        originals = {record["record_id"]: record for record in context["records"]}
        if len(originals) != len(context["records"]):
            raise ValueError("Duplicate descriptive candidate in draft.")
        destinations = _read_destination_rows(workbook, originals) if structured else {}
        reviewed = {}
        row_numbers = {}
        for cells in sheet.iter_rows(min_row=2):
            if not any(cell.value is not None for cell in cells):
                continue
            if any(cell.data_type == "f" for cell in cells):
                raise ValueError("Formulas are not allowed in descriptive review.")
            values = {field: "" if cell.value is None else str(cell.value) for field, cell in zip(headers, cells)}
            identity = values.get("record_id")
            if identity not in originals or identity in reviewed:
                raise ValueError("Unknown or duplicate descriptive candidate.")
            original = originals[identity]
            row_numbers[identity] = cells[0].row
            for field in expected_fields - review_fields:
                expected = original.get(field, "")
                expected = json.dumps(expected, sort_keys=True) if isinstance(expected, (dict, list)) else str(expected)
                if values[field] != expected:
                    raise ValueError("Descriptive candidate text/provenance was changed: " + identity)
            edits = {field: values[field].strip() for field in review_fields}
            if structured:
                classification = edits.pop(CLASSIFICATION_FIELD)
                if classification not in DESCRIPTIVE_SCOPES:
                    raise ValueError("Classification must be block_local or shared: " + identity)
                if classification != review_classification(dict(original, **edits)):
                    edits["evidence_scope"] = classification
            for field, default in (("evidence_scope", "block_local"), ("approved_uses_json", "[]")):
                if field not in original and edits.get(field) in {"", default}:
                    edits.pop(field, None)
            reviewed[identity] = dict(original, **edits)
        if set(reviewed) != set(originals):
            raise ValueError("Descriptive review is missing candidates.")
        records = [reviewed[record["record_id"]] for record in context["records"]]
        review_findings = [
            finding for record in records
            for finding in validate_governed_source_review(record, profile.get("block_defs", {}))
        ]
        if review_findings:
            raise ValueError(_descriptive_review_error(review_findings, headers, row_numbers))
        if structured:
            catalogue = _review_catalogue(workbook)
            baselines = [*context["records"], *profile.get("governed_source_context", {}).get("records", [])]
            for record in records:
                rows = destinations[record["record_id"]]
                if rows and "review_decision" in rows[0]:
                    rows = accepted_destination_rows(record, records, rows, profile, catalogue, baselines,
                                                     discovery=for_proposals)
                record.update(serialize_descriptive_destinations(record, review_classification(record), rows))
                for field, default in (("evidence_scope", "block_local"), ("approved_uses_json", "[]")):
                    if field not in originals[record["record_id"]] and record.get(field) in {"", default}:
                        record.pop(field, None)
        result = dict(context, records=records)
        validation_records = records
        if for_proposals:
            validation_records = [
                dict(record, review_decision="pending") if review_classification(record) == "shared" else record
                for record in records
            ]
        findings = validate_governed_source_context(
            dict(profile, governed_source_context=dict(context, records=validation_records)))
        if findings:
            raise ValueError(_descriptive_review_error(findings, headers, row_numbers))
        return result
    finally:
        workbook.close()


def _review_cell_xml(address: str, value, style: str = "") -> str:
    return (f'<c r="{address}"' + (f' s="{style}"' if style else "")
            + ' t="inlineStr"><is><t xml:space="preserve">' + escape(str(value)).replace("\r", "&#13;") + '</t></is></c>')


def _destination_sheet_xml(rows: list[dict], edit_style: str) -> str:
    last = max(2, len(rows) + 1)
    data = ['<row r="1">' + "".join(
        _review_cell_xml(f"{get_column_letter(index)}1", field)
        for index, field in enumerate(PROPOSAL_FIELDS, 1)
    ) + "</row>"]
    for number in range(2, last + 1):
        values = rows[number - 2] if number - 2 < len(rows) else {}
        cells = "".join(_review_cell_xml(
            f"{get_column_letter(index)}{number}", values.get(field, ""),
            edit_style if field in {"review_decision", "rationale"} else "",
        ) for index, field in enumerate(PROPOSAL_FIELDS, 1))
        data.append(f'<row r="{number}">{cells}</row>')
    decision_column = get_column_letter(PROPOSAL_FIELDS.index("review_decision") + 1)
    columns = "".join(f'<col min="{index}" max="{index}" width="{90 if field == "excerpt" else 35}" '
                      f'customWidth="1" hidden="{0 if field in VISIBLE_PROPOSAL_FIELDS else 1}"/>'
                      for index, field in enumerate(PROPOSAL_FIELDS, 1))
    return (
        '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
        f'<dimension ref="A1:O{last}"/><sheetViews><sheetView workbookViewId="0">'
        '<pane xSplit="1" ySplit="1" topLeftCell="B2" activePane="bottomRight" state="frozen"/>'
        '</sheetView></sheetViews><cols>' + columns + '</cols><sheetData>' + "".join(data) + '</sheetData>'
        f'<autoFilter ref="A1:O{last}"/><dataValidations count="1">'
        f'<dataValidation type="list" errorStyle="stop" showErrorMessage="1" showDropDown="0" allowBlank="0" '
        f'sqref="{decision_column}2:{decision_column}{last}"><formula1>"pending,approved,rejected"</formula1>'
        '</dataValidation></dataValidations></worksheet>'
    )


def _mapped_block_validation_xml(headers: list[str], last_row: int, catalogue: list[str]) -> str:
    column = get_column_letter(headers.index("mapped_block") + 1)
    formula = f'INDIRECT("\'Approved Block Choices\'!$A$2:$A${max(2, len(catalogue) + 1)}")'
    return (f'<dataValidation type="list" errorStyle="stop" showErrorMessage="1" showDropDown="0" allowBlank="1" '
            f'sqref="{column}2:{column}{max(last_row, 2)}" errorTitle="Invalid mapped block" '
            'error="Choose an approved architecture block; leave blank for shared evidence.">'
            f'<formula1>{escape(formula)}</formula1></dataValidation>')


def _update_mapped_block_dropdown(xml: str, headers: list[str], last_row: int, catalogue: list[str]) -> str:
    namespace = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
    root = ElementTree.fromstring(xml)
    container = root.find(namespace + "dataValidations")
    expected = ElementTree.fromstring(_mapped_block_validation_xml(headers, last_row, catalogue))
    column = get_column_letter(headers.index("mapped_block") + 1)
    target = f"{column}2:{column}{max(last_row, 2)}"
    entries = list(container) if container is not None else []
    matching = [value for value in entries if MultiCellRange(value.get("sqref", "")) == MultiCellRange(target)]
    if len(matching) == 1:
        actual = matching[0]
        formula = actual.find(namespace + "formula1")
        if actual.attrib == expected.attrib and formula is not None and formula.text == expected.find("formula1").text:
            return xml
    for entry in matching:
        entries.remove(entry)
    replacements = [ElementTree.tostring(value, encoding="unicode").replace("ns0:", "").replace(":ns0", "")
                    for value in entries]
    replacements.append(_mapped_block_validation_xml(headers, last_row, catalogue))
    replacement = f'<dataValidations count="{len(replacements)}">' + "".join(replacements) + "</dataValidations>"
    if container is not None:
        return re.sub(r"<dataValidations\b[^>]*>.*?</dataValidations>", lambda match: replacement, xml, count=1, flags=re.S)
    boundary = next(value for value in ("<pageMargins", "<pageSetup", "<headerFooter", "<extLst", "</worksheet>") if value in xml)
    return xml.replace(boundary, replacement + boundary, 1)


def _simplify_descriptive_columns(xml: str, headers: list[str]) -> str:
    namespace = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
    old = ElementTree.fromstring(xml).find(namespace + "cols")
    columns = []
    for index, field in enumerate(headers, 1):
        attributes = next((dict(column.attrib) for column in old
                           if int(column.get("min")) <= index <= int(column.get("max"))), {}) if old is not None else {}
        attributes.update(min=str(index), max=str(index), hidden="0" if field in VISIBLE_DESCRIPTIVE_FIELDS else "1")
        if field == "record_id":
            attributes.update(width="45", customWidth="1")
        columns.append("<col " + " ".join(key + "=" + quoteattr(value) for key, value in attributes.items()) + "/>")
    replacement = "<cols>" + "".join(columns) + "</cols>"
    if old is not None:
        return re.sub(r"<cols\b[^>]*>.*?</cols>", lambda match: replacement, xml, count=1, flags=re.S)
    return xml.replace("<sheetData>", replacement + "<sheetData>", 1)


def _structured_review_updates(archive, context: dict, profile: dict, catalogue: list[str],
                               destination_rows: list[dict]) -> dict[str, bytes]:
    namespace = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
    relations = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    book_xml = archive.read("xl/workbook.xml").decode("utf-8")
    book = ElementTree.fromstring(book_xml)
    sheets = book.find("{" + namespace + "}sheets")
    sheet = next(value for value in sheets if value.get("name") == DESCRIPTIVE_SHEET)
    links_xml = archive.read("xl/_rels/workbook.xml.rels").decode("utf-8")
    links = ElementTree.fromstring(links_xml)
    target = next(value.get("Target") for value in links if value.get("Id") == sheet.get("{" + relations + "}id"))
    if target is None:
        raise ValueError("Descriptive worksheet package address is missing.")
    member = posixpath.normpath(posixpath.join("xl", target)) if not target.startswith("/") else target.lstrip("/")
    xml = archive.read(member).decode("utf-8")
    root = ElementTree.fromstring(xml)
    rows = root.find("{" + namespace + "}sheetData")
    if rows is None or not len(rows):
        raise ValueError("Descriptive review sheet is empty.")
    strings = []
    if "xl/sharedStrings.xml" in archive.namelist():
        strings = ["".join(value.itertext()) for value in ElementTree.fromstring(archive.read("xl/sharedStrings.xml"))]

    def cell_text(cell):
        if cell.get("t") == "s":
            return strings[int(cell.find("{" + namespace + "}v").text)]
        return "".join(value.text or "" for value in cell.iter("{" + namespace + "}t"))

    headers = [cell_text(cell) for cell in rows[0]]
    destination = next((value for value in sheets if value.get("name") == DESTINATIONS_SHEET), None)
    if destination is not None:
        target = next(value.get("Target") for value in links if value.get("Id") == destination.get("{" + relations + "}id"))
        if target is None:
            raise ValueError("Shared destination worksheet package address is missing.")
        destination_member = posixpath.normpath(posixpath.join("xl", target)) if not target.startswith("/") else target.lstrip("/")
        destination_xml = archive.read(destination_member).decode("utf-8")
        edit_style = next((row[0].get("s", "") for row in list(rows)[1:] if len(row)), "")
        updated_destination = _destination_sheet_xml(destination_rows, edit_style)
        updated_xml = _update_mapped_block_dropdown(
            _simplify_descriptive_columns(xml, headers), headers, max(int(row.get("r", "0")) for row in rows), catalogue)
        updates = {}
        for name, old, new in ((member, xml, updated_xml), (destination_member, destination_xml, updated_destination)):
            if old != new:
                ElementTree.fromstring(new)
                updates[name] = new.encode("utf-8")
        return updates
    extra = [field for field in (*DESCRIPTIVE_SCOPE_FIELDS, CLASSIFICATION_FIELD) if field not in headers]
    all_headers = headers + extra
    records = {record["record_id"]: record for record in context["records"]}
    identity_column = get_column_letter(all_headers.index("record_id") + 1)
    edit_style = next((row[0].get("s", "") for row in list(rows)[1:] if len(row)), "")
    locked_style = next((cell.get("s", "") for row in list(rows)[1:] for cell in row
                         if cell.get("r", "").startswith(identity_column) and cell.get("r", "")[len(identity_column):].isdigit()), "")
    for row in rows:
        number = int(row.get("r", "0"))
        record = next((records.get(cell_text(cell)) for cell in row if cell.get("r") == f"{identity_column}{number}"), None)
        if number != 1 and record is None:
            continue
        defaults = dict(record or {}, evidence_scope=(record or {}).get("evidence_scope", "block_local"),
                        approved_uses_json=(record or {}).get("approved_uses_json", "[]"),
                        classification=review_classification(record or {}))
        addition = "".join(_review_cell_xml(
            f"{get_column_letter(all_headers.index(field) + 1)}{number}",
            field if number == 1 else defaults[field],
            "" if number == 1 else edit_style if field == CLASSIFICATION_FIELD else locked_style,
        ) for field in extra)
        pattern = r'(<row\b[^>]*\br="' + str(number) + r'"[^>]*>)(.*?)(</row>)'
        xml, count = re.subn(pattern, lambda match: match[1] + match[2] + addition + match[3], xml, flags=re.S)
        if count != 1:
            raise ValueError("Unsupported descriptive worksheet row encoding.")
    last_row = max(int(row.get("r", "0")) for row in rows)
    extent = f"A1:{get_column_letter(len(all_headers))}{last_row}"
    xml = re.sub(r'(<(?:dimension|autoFilter)\b[^>]*\bref=")[^"]+(")',
                 lambda match: match[1] + extent + match[2], xml)
    hidden = {all_headers.index(field) + 1 for field in DESCRIPTIVE_SCOPE_FIELDS}
    columns = []
    old_cols = root.find("{" + namespace + "}cols")
    for column in old_cols if old_cols is not None else ():
        low, high = int(column.get("min")), int(column.get("max"))
        cuts = sorted({low, high + 1, *(value for index in hidden for value in (index, index + 1) if low <= value <= high)})
        for start, stop in zip(cuts, cuts[1:]):
            attributes = dict(column.attrib, min=str(start), max=str(stop - 1))
            if start in hidden:
                attributes["hidden"] = "1"
            columns.append("<col " + " ".join(key + "=" + quoteattr(value) for key, value in attributes.items()) + "/>")
    for index in hidden:
        if old_cols is None or not any(int(column.get("min")) <= index <= int(column.get("max")) for column in old_cols):
            columns.append(f'<col min="{index}" max="{index}" hidden="1"/>')
    classification_column = get_column_letter(all_headers.index(CLASSIFICATION_FIELD) + 1)
    columns.append(f'<col min="{all_headers.index(CLASSIFICATION_FIELD) + 1}" max="{all_headers.index(CLASSIFICATION_FIELD) + 1}" width="28" customWidth="1"/>')
    column_xml = "<cols>" + "".join(columns) + "</cols>"
    if old_cols is not None:
        xml = re.sub(r"<cols\b[^>]*>.*?</cols>", lambda match: column_xml, xml, count=1, flags=re.S)
    else:
        xml = xml.replace("<sheetData>", column_xml + "<sheetData>", 1)
    for field in DESCRIPTIVE_SCOPE_FIELDS:
        column = get_column_letter(all_headers.index(field) + 1)
        pattern = r'(<c\b[^>]*\br="' + column + r'([2-9]\d*|1\d+)"[^>]*)(>)'
        xml = re.sub(pattern, lambda match: re.sub(r' s="[^"]*"', "", match[1])
                     + (f' s="{locked_style}"' if locked_style else "") + match[3], xml)
    # Replace only this sheet's standard validation container; extensions stay byte-for-byte.
    validations = root.find("{" + namespace + "}dataValidations")
    kept = []
    for validation in validations if validations is not None else ():
        formula = validation.find("{" + namespace + "}formula1")
        if formula is not None and any(value in (formula.text or "") for value in ("multi_block", "multi_level", "block_local")):
            continue
        kept.append(ElementTree.tostring(validation, encoding="unicode").replace("ns0:", "").replace(":ns0", ""))
    kept.append(f'<dataValidation type="list" errorStyle="stop" showErrorMessage="1" showDropDown="0" allowBlank="0" '
                f'sqref="{classification_column}2:{classification_column}{max(last_row, 2)}">'
                '<formula1>"' + ",".join(DESCRIPTIVE_SCOPES) + '"</formula1></dataValidation>')
    container = f'<dataValidations count="{len(kept)}">' + "".join(kept) + "</dataValidations>"
    if validations is not None:
        xml = re.sub(r"<dataValidations\b[^>]*>.*?</dataValidations>", lambda match: container, xml, count=1, flags=re.S)
    else:
        boundary = next(value for value in ("<pageMargins", "<pageSetup", "<headerFooter", "<extLst", "</worksheet>") if value in xml)
        xml = xml.replace(boundary, container + boundary, 1)
    new_number = max([int(match.group(1)) for name in archive.namelist()
                      if (match := re.fullmatch(r"xl/worksheets/sheet(\d+)\.xml", name))] + [0]) + 1
    new_member = f"xl/worksheets/sheet{new_number}.xml"
    relation_id = "rId" + str(max([int(value.get("Id")[3:]) for value in links
                                 if re.fullmatch(r"rId\d+", value.get("Id", ""))] + [0]) + 1)
    sheet_id = max(int(value.get("sheetId")) for value in sheets) + 1
    book_xml = book_xml.replace("</sheets>", f'<sheet xmlns:r="{relations}" name="{DESTINATIONS_SHEET}" sheetId="{sheet_id}" r:id="{relation_id}"/></sheets>', 1)
    links_xml = links_xml.replace("</Relationships>",
                                  f'<Relationship Id="{relation_id}" Type="{relations}/worksheet" Target="/{new_member}"/></Relationships>', 1)
    types = archive.read("[Content_Types].xml").decode("utf-8")
    types = types.replace("</Types>", f'<Override PartName="/{new_member}" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>', 1)
    updates = {
        member: _update_mapped_block_dropdown(_simplify_descriptive_columns(xml, all_headers), all_headers, last_row, catalogue),
        "xl/workbook.xml": book_xml, "xl/_rels/workbook.xml.rels": links_xml,
        "[Content_Types].xml": types,
        new_member: _destination_sheet_xml(destination_rows, edit_style),
    }
    for value in updates.values():
        ElementTree.fromstring(value)
    return {name: value.encode("utf-8") for name, value in updates.items()}


def upgrade_descriptive_review_fields(
    workbook_path: Path, draft: dict, profile: dict, *, backup_path: Path, prepare_proposals: bool = False,
    previous_profile: dict | None = None,
) -> bool:
    """Add two-category review and explicit destination rows without expanding authority."""
    if workbook_path.with_name("~$" + workbook_path.name).exists():
        raise ValueError("Save and close Excel before preparing shared destinations.")
    before = workbook_path.read_bytes()
    before_review = reviewed_descriptive_context(workbook_path, draft, profile, for_proposals=True)
    if before_review is None:
        raise ValueError("The architecture draft has no descriptive review context.")
    if workbook_path.read_bytes() != before:
        raise ValueError("Workbook changed during review readback; no changes installed.")
    workbook = load_workbook(workbook_path, data_only=False)
    try:
        catalogue = _review_catalogue(workbook)
        grouped = _read_destination_rows(workbook, {record["record_id"]: record for record in before_review["records"]}) \
            if DESTINATIONS_SHEET in workbook.sheetnames else {}
        existing = [row for rows in grouped.values() for row in rows]
    finally:
        workbook.close()
    baselines = [*draft.get("governed_source_context", {}).get("records", []),
                 *profile.get("governed_source_context", {}).get("records", [])]
    if prepare_proposals:
        destination_rows = refresh_destination_proposals(
            before_review["records"], existing, profile, catalogue, baselines, previous_profile=previous_profile)
    elif existing and "review_decision" in existing[0]:
        destination_rows = existing
    else:
        destination_rows = [row for record in before_review["records"]
                            for row in legacy_destination_rows(record, before_review["records"], profile, catalogue, baselines)]
    with zipfile.ZipFile(workbook_path) as archive:
        updates = _structured_review_updates(archive, before_review, profile, catalogue, destination_rows)
        for name in archive.namelist():
            tag = "workbookProtection" if name == "xl/workbook.xml" else "sheetProtection"
            if name != "xl/workbook.xml" and not (name.startswith("xl/worksheets/") and name.endswith(".xml")):
                continue
            original = archive.read(name)
            xml = updates.get(name, original).decode("utf-8")
            xml = re.sub(r"<(?:\w+:)?" + tag + r"\b[^>]*(?:/>|>.*?</(?:\w+:)?" + tag + r">)",
                         "", xml, flags=re.S)
            if xml.encode("utf-8") != original:
                updates[name] = xml.encode("utf-8")
        if not updates:
            return False
        with NamedTemporaryFile(suffix=".xlsx", dir=workbook_path.parent, delete=False) as temporary:
            temporary_path = Path(temporary.name)
        try:
            with zipfile.ZipFile(temporary_path, "w", compression=zipfile.ZIP_DEFLATED) as output:
                for info in archive.infolist():
                    output.writestr(info, updates.get(info.filename, archive.read(info.filename)))
                for name, value in updates.items():
                    if name not in archive.namelist():
                        output.writestr(name, value)
            after_review = reviewed_descriptive_context(temporary_path, draft, profile, for_proposals=True)
            def review_content(context):
                return [dict((key, value) for key, value in record.items() if key not in DESCRIPTIVE_SCOPE_FIELDS)
                        for record in context["records"]]
            if (review_content(after_review) != review_content(before_review) if prepare_proposals
                    else after_review != before_review):
                raise ValueError("Review-field upgrade changed existing candidates or decisions.")
            if workbook_path.with_name("~$" + workbook_path.name).exists() or workbook_path.read_bytes() != before:
                raise ValueError("Workbook changed or opened during preparation; no changes installed.")
            if backup_path.exists():
                raise ValueError("Review backup already exists; choose a new backup path.")
            backup_path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(workbook_path, backup_path)
            if workbook_path.read_bytes() != before:
                raise ValueError("Workbook changed during backup; no changes installed.")
        except (OSError, ValueError, KeyError, zipfile.BadZipFile):
            temporary_path.unlink(missing_ok=True)
            raise
    try:
        os.replace(temporary_path, workbook_path)
    finally:
        temporary_path.unlink(missing_ok=True)
    return True


def prepare_shared_destinations(workbook_path: Path, draft: dict, profile: dict, *, backup_path: Path) -> dict:
    previous_profile = profile
    profile = architecture_review_profile(draft, profile, workbook_path=workbook_path)
    changed = upgrade_descriptive_review_fields(
        workbook_path, draft, profile, backup_path=backup_path, prepare_proposals=True, previous_profile=previous_profile)
    workbook = load_workbook(workbook_path, data_only=False)
    try:
        catalogue = _review_catalogue(workbook)
        grouped = _read_destination_rows(
            workbook, {record["record_id"]: record for record in draft["governed_source_context"]["records"]})
        rows = [row for values in grouped.values() for row in values]
    finally:
        workbook.close()
    return {
        "changed": changed, "destinations": len(rows),
        "pending": sum(row.get("review_decision") == "pending" for row in rows),
        "blocked": sum(row.get("support_status") != "ready" for row in rows),
        "catalogue_profile_gaps": [name for name in catalogue
                                   if name not in LEVEL_CHOICES and name not in profile.get("block_defs", {})],
    }


EDITABLE_FIELDS = {
    "approved_classification",
    "review_decision",
    "approved_block",
    "allocation_class",
    "owning_target",
    "allocation_rationale",
    "lineage_mode",
    "source_origin_req_ids",
    "hierarchy_parent_req_ids",
    "lineage_candidate_parent_req_ids",
    "owning_domain",
    "reviewer_notes",
}
ALLOWED_REVIEW_DECISIONS = {
    "approved",
    "reassigned",
    "rejected",
    "pending_review",
    "needs_clarification",
}


def _row_is_valid(record: dict[str, str]) -> bool:
    allocation_targets = {
        "system_level": "srs",
        "top_digital_architecture": "drs",
        "top_analog_architecture": "ars",
        "block_local_digital": "digital ipos",
        "block_local_analog": "analog ipos",
        "descriptive_only": "none",
    }
    classification = (record.get("approved_classification") or "").strip().casefold()
    block = (record.get("approved_block") or "").strip()
    allocation_class = (record.get("allocation_class") or "").strip().casefold()
    owning_target = (record.get("owning_target") or "").strip().casefold()
    rationale = (record.get("allocation_rationale") or "").strip()
    lineage_mode = (record.get("lineage_mode") or "").strip()
    source_origin_req_ids = (record.get("source_origin_req_ids") or "").strip()
    hierarchy_parent_req_ids = (record.get("hierarchy_parent_req_ids") or "").strip()
    if classification not in {"analog", "digital", "system"} or not block:
        return False
    if allocation_class not in allocation_targets or owning_target != allocation_targets[allocation_class]:
        return False
    if not rationale or rationale.startswith("REVIEW_REQUIRED:") or not lineage_mode or not source_origin_req_ids:
        return False
    if allocation_class in {"block_local_digital", "block_local_analog"} and lineage_mode in {"normal_hierarchical", "split_lineage"} and not hierarchy_parent_req_ids:
        return False
    return not (block.casefold() in {"system", "digital", "analog"} and block.casefold() != classification)


def _explicit_parent_candidates(record: dict[str, str], approved_ids: set[str]) -> list[str]:
    """Return only explicit approved requirement IDs from Covers references."""
    statement = record.get("requirement_statement") or ""
    candidates = {
        candidate.strip()
        for covered in re.findall(r"\[\s*Covers\s*:\s*([^\]]+)\]", statement, flags=re.IGNORECASE)
        for candidate in re.split(r"[,;\s]+", covered)
        if candidate.strip() in approved_ids
        and candidate.strip() != (record.get("requirement_id") or "").strip()
    }
    return sorted(candidates)


def _restore_mapping_validations(workbook, worksheet, headers: list[str]) -> None:
    choices = workbook["Approved Block Choices"] if "Approved Block Choices" in workbook.sheetnames else None
    if choices is None:
        raise ValueError("Mapping workbook is missing the Approved Block Choices sheet.")

    worksheet.data_validations.dataValidation = []
    choice_ranges = {
        "approved_block": "A",
        "approved_classification": "B",
        "allocation_class": "C",
        "owning_target": "D",
        "allocation_rationale": "E",
        "lineage_mode": "F",
        "review_decision": "G",
    }
    for field_name, choice_column in choice_ranges.items():
        if field_name not in headers:
            continue
        values = [
            choices.cell(row=row_number, column=ord(choice_column) - ord("A") + 1).value
            for row_number in range(2, choices.max_row + 1)
            if choices.cell(row=row_number, column=ord(choice_column) - ord("A") + 1).value not in (None, "")
        ]
        if not values:
            continue
        field_column = get_column_letter(headers.index(field_name) + 1)
        last_choice_row = len(values) + 1
        validation = DataValidation(
            type="list",
            formula1=f"'Approved Block Choices'!${choice_column}$2:${choice_column}${last_choice_row}",
            allow_blank=field_name == "approved_block",
        )
        validation.errorTitle = f"Invalid {field_name}"
        validation.error = "Choose a value from the drop-down list."
        validation.errorStyle = "stop"
        validation.promptTitle = field_name.replace("_", " ").title()
        validation.prompt = "Choose a value from the approved review choices."
        validation.showErrorMessage = True
        validation.showInputMessage = True
        worksheet.add_data_validation(validation)
        validation.add(f"{field_column}2:{field_column}{worksheet.max_row}")


def sync_mapping_workbook_to_csv(workbook_path: Path, csv_path: Path) -> int:
    """Import the user-edited workbook into the tool-managed CSV."""
    with csv_path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        fieldnames = reader.fieldnames or []
        baseline_records = list(reader)
    if not fieldnames or "requirement_id" not in fieldnames:
        raise ValueError("Mapping review CSV is missing the requirement_id column.")

    workbook = load_workbook(workbook_path, data_only=False)
    try:
        worksheet = workbook["Architecture Mapping Review"]
        rows = list(worksheet.iter_rows(values_only=True))
    finally:
        workbook.close()
    if not rows:
        raise ValueError("Mapping review workbook is empty.")
    headers = [str(value or "").strip() for value in rows[0]]
    if headers != fieldnames:
        raise ValueError("Mapping review workbook columns do not match the generated CSV.")

    baseline_by_id = {(record.get("requirement_id") or "").strip(): record for record in baseline_records}
    workbook_by_id: dict[str, dict[str, str]] = {}
    for row in rows[1:]:
        values = ["" if value is None else str(value).strip() for value in row]
        if not any(values):
            continue
        record = dict(zip(fieldnames, values))
        requirement_id = record.get("requirement_id", "").strip()
        if not requirement_id:
            raise ValueError("Mapping review workbook contains a row without requirement_id.")
        if requirement_id in workbook_by_id:
            raise ValueError(f"Mapping review workbook duplicates requirement_id: {requirement_id}")
        if requirement_id not in baseline_by_id:
            raise ValueError(f"Mapping review workbook contains unknown requirement_id: {requirement_id}")
        workbook_by_id[requirement_id] = record
    missing = sorted(set(baseline_by_id) - set(workbook_by_id))
    if missing:
        raise ValueError("Mapping review workbook is missing requirement IDs: " + ", ".join(missing[:10]))

    synchronized: list[dict[str, str]] = []
    for baseline in baseline_records:
        requirement_id = (baseline.get("requirement_id") or "").strip()
        record = workbook_by_id[requirement_id]
        workbook_decision = (record.get("review_decision") or "").strip()
        baseline_decision = (baseline.get("review_decision") or "").strip()
        record["review_decision"] = workbook_decision or baseline_decision or "pending_review"
        if record["review_decision"].casefold() not in ALLOWED_REVIEW_DECISIONS:
            raise ValueError(
                f"Unsupported review_decision for {requirement_id}: {record['review_decision']}"
            )
        workbook_by_id[requirement_id]["review_decision"] = record["review_decision"]
        approved_ids = {
            candidate_id
            for candidate_id, candidate in baseline_by_id.items()
            if (candidate.get("review_decision") or "").strip().casefold() in {"approved", "reassigned"}
        }
        candidates = _explicit_parent_candidates(record, approved_ids)
        if "lineage_candidate_parent_req_ids" in fieldnames:
            record["lineage_candidate_parent_req_ids"] = ";".join(candidates)
        if (
            not (record.get("hierarchy_parent_req_ids") or "").strip()
            and requires_hierarchy_parent(
                (record.get("allocation_class") or "").strip(),
                (record.get("lineage_mode") or "").strip(),
            )
            and len(candidates) == 1
            and record["review_decision"].casefold() in {"approved", "reassigned"}
        ):
            record["hierarchy_parent_req_ids"] = candidates[0]
        changed = any(
            (record.get(field) or "").strip() != (baseline.get(field) or "").strip()
            for field in EDITABLE_FIELDS - {"review_decision"}
        )
        if changed and record["review_decision"].casefold() in {"pending", "pending_review"} and _row_is_valid(record):
            record["review_decision"] = "approved"
        synchronized.append(record)
    with NamedTemporaryFile(
        mode="w", encoding="utf-8", newline="", dir=csv_path.parent,
        prefix=csv_path.name + ".", suffix=".tmp", delete=False,
    ) as temporary:
        writer = csv.DictWriter(temporary, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(synchronized)
        temporary_path = Path(temporary.name)
    temporary_path.replace(csv_path)

    with csv_path.open("r", encoding="utf-8-sig", newline="") as handle:
        persisted = {(row.get("requirement_id") or "").strip(): row for row in csv.DictReader(handle)}
    synchronized_by_id = {
        (record.get("requirement_id") or "").strip(): record for record in synchronized
    }
    mismatched = [
        requirement_id for requirement_id, record in workbook_by_id.items()
        if any(
            persisted.get(requirement_id, {}).get(field, "").strip()
            != synchronized_by_id[requirement_id].get(field, "").strip()
            for field in fieldnames
        )
    ]
    if mismatched:
        raise RuntimeError("Mapping workbook synchronization did not persist approved_block values: " + ", ".join(mismatched[:10]))

    workbook = load_workbook(workbook_path, data_only=False)
    try:
        worksheet = workbook["Architecture Mapping Review"]
        headers = [str(cell.value or "").strip() for cell in worksheet[1]]
        decision_column = headers.index("review_decision") + 1
        approved_fill = PatternFill("solid", fgColor="C6EFCE")
        pending_fill = PatternFill("solid", fgColor="FFC7CE")
        for row_number in range(2, worksheet.max_row + 1):
            decision = str(worksheet.cell(row_number, decision_column).value or "").strip().casefold()
            row_fill = approved_fill if decision == "approved" else pending_fill
            for column_number, field_name in enumerate(headers, start=1):
                if field_name in EDITABLE_FIELDS:
                    worksheet.cell(row_number, column_number).fill = row_fill
        _restore_mapping_validations(workbook, worksheet, headers)
        workbook.save(workbook_path)
    finally:
        workbook.close()
    return len(synchronized)
