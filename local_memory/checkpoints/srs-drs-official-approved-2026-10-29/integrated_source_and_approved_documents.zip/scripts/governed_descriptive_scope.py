"""Approved descriptive applicability, separate from functional ownership."""

from __future__ import annotations

import hashlib
import json
import re
from typing import Mapping, Sequence


DESCRIPTIVE_SCOPE_FIELDS = ("evidence_scope", "approved_uses_json")
DESCRIPTIVE_REVIEW_FIELDS = (
    "review_decision", "mapped_block", "domain", "review_rationale", *DESCRIPTIVE_SCOPE_FIELDS,
)
DESCRIPTIVE_SCOPES = ("block_local", "shared")
LEGACY_SHARED_SCOPES = ("multi_block", "multi_level")
CLASSIFICATION_FIELD = "classification"
DESTINATION_FIELDS = (
    "record_id", "use_id", "document", "block", "domain", "role", "excerpt",
    "start", "end", "rationale", "supporting_record_ids",
)
DOCUMENT_SECTIONS = {
    "SRS": {"purpose": "3.1", "functions": "3.2", "organization": "3.3", "context": "3.4",
            "operating_concept": "3.5"},
    "DRS": {"context": "3", "organization": "3", "functions": "3.1"},
    "ARS": {"context": "3", "organization": "3", "functions": "3.1"},
    "IPOS": {"context": "1.2", "functions": "1.4"},
}
DOCUMENT_ROLES = {document: tuple(roles) for document, roles in DOCUMENT_SECTIONS.items()}
SRS_DESTINATION_MEANINGS = {
    "purpose": ("purpose",), "functions": ("main_functions",),
    "organization": ("organization",), "context": ("boundaries", "interaction", "context"),
    "operating_concept": ("behavior", "restriction"),
}
SHARED_CONTEXT_AUTHORIZATION = "explicit_shared_destination_v1"
CONFIGURATION_CONTEXT_POLICY = "mode_configuration_context_v1"
SEMANTIC_SOURCE_POLICY = "mixed_source_semantic_projection_v1"


def semantic_source_context(record: Mapping, excerpt: str, role: str, document: str) -> dict | None:
    """Admit mixed source for interpretation only, never literal SRS rendering."""
    if document != "SRS" or role != "context" or excerpt != str(record.get("statement") or "").strip():
        return None
    headings = json.loads(record.get("section_context_json") or "[]")
    if any(isinstance(value, list) and len(value) == 2
           and re.search(r"\b(?:mode|configuration)s?\b", str(value[1]), re.I) for value in headings):
        return None
    instruction = re.search(r"\b(?:set|clear|write|read)\b.{0,80}\b(?:bit|register|address)\b", excerpt, re.I)
    if instruction is None or not excerpt[:instruction.start()].strip():
        return None
    return {"policy": SEMANTIC_SOURCE_POLICY,
            "content_sha256": hashlib.sha256(excerpt.encode("utf-8")).hexdigest()}


def explicit_functional_source_support(excerpt: str, block: str) -> bool:
    """Require an explicit actor/action, not accessibility, wiring or a mention."""
    from workflow_routing import NormalizedSourceRecord, _project_explicit_descriptive_clause

    storage = re.fullmatch(
        r"All the data are stored inside (?:a|the)\s+" + re.escape(block)
        + r"\s+that can be configured as:\s*.+", excerpt, re.I | re.S)
    if storage:
        return True
    source = NormalizedSourceRecord(
        "source-support-check", excerpt, "admitted_context", "block_local",
        ("source-support-check",), "retained", "source interpretation only; no destination authority")
    facts, reason = _project_explicit_descriptive_clause(
        source, excerpt, owner=block, domain="", require_actor=True)
    return bool(facts) and not reason and all(fact.action != "be" and not fact.negative for fact in facts)


def configuration_context(record: Mapping, excerpt: str, role: str) -> dict | None:
    """Keep setup and behavior inseparable under an immutable source-mode heading."""
    if (role not in {"context", "operating_concept"} or excerpt != str(record.get("statement") or "").strip()
            or not re.search(r"\b(?:set|clear)\b.{0,80}\b(?:bit|register)\b", excerpt, re.I | re.S)
            or re.search(r"\b(?:shall|must|required to)\b|Covers:|^\s*#|\|", excerpt, re.I | re.M)):
        return None
    headings = json.loads(record.get("section_context_json") or "[]")
    if (not isinstance(headings, list) or not headings
            or any(not isinstance(value, list) or len(value) != 2
                   or any(not isinstance(part, str) or not part.strip() for part in value)
                   for value in headings)):
        return None
    if not any(re.search(r"\b(?:modes?|configurations?|operating states?)\b", title, re.I)
               for _number, title in headings):
        return None
    return {"policy": CONFIGURATION_CONTEXT_POLICY, "headings": headings}


def descriptive_excerpt_status(record: Mapping, excerpt: str, role: str, status: str,
                               *, document: str = "") -> str:
    if semantic_source_context(record, excerpt, role, document) is not None:
        return status
    if (re.search(r"\b(?:shall|must|required to)\b|Covers:|^\s*#|\|", excerpt, re.I | re.M)
            or (configuration_context(record, str(record.get("statement") or "").strip(), role) is not None
                and excerpt != str(record["statement"]).strip())
            or (re.search(r"\b(?:set|clear)\b.{0,80}\b(?:bit|register)\b", excerpt, re.I | re.S)
                and configuration_context(record, excerpt, role) is None)):
        return "unsupported_descriptive_excerpt"
    return status


def qualified_shared_context_text(record: Mapping) -> str | None:
    """Render a verified qualified projection literally, never as block behavior."""
    provenance = json.loads(record["provenance_json"])
    qualification = provenance["approved_use"].get("context_qualification")
    if qualification is None:
        return None
    validate_projected_shared_use(
        record, document=record["consumer_document"], block=record["consumer_block"], domain=record["domain"])
    headings = "; ".join(number + " " + title for number, title in qualification["headings"])
    return "Source mode/configuration context (" + headings + "). " + record["statement"]


def qualified_shared_context_synthesis_gap(record: Mapping) -> str | None:
    if qualified_shared_context_text(record) is None:
        return None
    from workflow_routing import shared_descriptive_evidence_model
    model = shared_descriptive_evidence_model((record,), document=record["consumer_document"],
        owner=record["consumer_block"], domain=record["domain"])
    if not model.unresolved_contexts:
        return None
    return ("projection_gap: " + "; ".join(dict.fromkeys(value.reason for value in model.unresolved_contexts))
            + "; unresolved portions require human review; supported propositions remain eligible")


def is_explicit_shared_context(use: Mapping) -> bool:
    return (use.get("document") == "IPOS" and use.get("role") == "context"
            and use.get("context_authorization") == SHARED_CONTEXT_AUTHORIZATION)


def descriptive_scope(record: Mapping) -> str:
    return str(record.get("evidence_scope") or "block_local")


def descriptive_block_choices(profile: Mapping) -> list[str]:
    return sorted(name for name in profile.get("block_defs", {}) if name != "Unassigned")


def review_classification(record: Mapping) -> str:
    scope = descriptive_scope(record)
    return "shared" if scope in LEGACY_SHARED_SCOPES else scope


def descriptive_uses(record: Mapping) -> list[dict]:
    raw = record.get("approved_uses_json") or "[]"
    if not isinstance(raw, str):
        raise ValueError("approved_uses_json must be JSON text")
    uses = json.loads(raw)
    if not isinstance(uses, list) or any(not isinstance(use, dict) for use in uses):
        raise ValueError("approved_uses_json must contain a list of use objects")
    return uses


def descriptive_destination_rows(record: Mapping) -> list[dict]:
    """Expose exact existing uses as reviewable cells, without expanding scope."""
    return [{
        "record_id": record["record_id"], "use_id": use["use_id"],
        "document": use["document"], "block": use.get("block", ""),
        "domain": use["domain"], "role": use["role"],
        "excerpt": record["statement"][use["start"]:use["end"]],
        "start": use["start"], "end": use["end"], "rationale": use["rationale"],
        "supporting_record_ids": ";".join(use.get("supporting_record_ids", [])),
    } for use in descriptive_uses(record)]


def serialize_descriptive_destinations(record: Mapping, classification: str, rows: Sequence[Mapping]) -> dict:
    """Compile explicit rows into the existing governed serialization."""
    if classification not in DESCRIPTIVE_SCOPES:
        raise ValueError("Classification must be block_local or shared: " + str(record["record_id"]))
    if classification == "block_local" and rows:
        raise ValueError("Block-local evidence cannot have shared destinations: " + str(record["record_id"]))
    previous = {use["use_id"]: use for use in descriptive_uses(record)}
    uses = []
    seen = set()
    for row in rows:
        identity = str(row.get("use_id") or "").strip()
        if not identity or identity in seen:
            raise ValueError("Missing or duplicate destination use_id: " + str(record["record_id"]))
        seen.add(identity)
        excerpt = str(row.get("excerpt") or "")
        statement = str(record["statement"])
        start, end = row.get("start", ""), row.get("end", "")
        if start in ("", None) and end in ("", None):
            positions = [offset for offset in range(len(statement)) if excerpt and statement.startswith(excerpt, offset)]
            if len(positions) != 1:
                raise ValueError("Excerpt must match source exactly once, or specify start/end: " + identity)
            start, end = positions[0], positions[0] + len(excerpt)
        else:
            if not all(str(value).isdigit() for value in (start, end)):
                raise ValueError("Destination start/end must be integer character offsets: " + identity)
            start, end = int(start), int(end)
        if not excerpt or not 0 <= start < end <= len(statement) or statement[start:end] != excerpt:
            raise ValueError("Destination excerpt differs from immutable source: " + identity)
        use = dict(previous.get(identity, {}))
        use.update({field: str(row.get(field) or "").strip()
                    for field in ("use_id", "document", "domain", "role", "rationale")})
        use.update(start=start, end=end)
        block = str(row.get("block") or "").strip()
        if block or "block" in use or identity not in previous:
            use["block"] = block
        raw_supports = str(row.get("supporting_record_ids") or "").strip()
        supports = [value.strip() for value in raw_supports.split(";")] if raw_supports else []
        if any(not value for value in supports):
            raise ValueError("Empty supporting evidence ID: " + identity)
        if supports or "supporting_record_ids" in use:
            use["supporting_record_ids"] = supports
        if (use["document"] == "IPOS" and use["role"] == "context" and not supports
                and row.get("review_decision") == "approved" and row.get("support_status") == "ready"):
            use["context_authorization"] = SHARED_CONTEXT_AUTHORIZATION
        elif use["role"] != "context":
            use.pop("context_authorization", None)
        qualification = configuration_context(record, excerpt, use["role"])
        if (qualification is not None and row.get("review_decision") == "approved"
                and row.get("support_status") == "ready"):
            use["context_qualification"] = qualification
        else:
            use.pop("context_qualification", None)
        semantic = semantic_source_context(record, excerpt, use["role"], use["document"])
        if semantic is not None and row.get("review_decision") == "approved" and row.get("support_status") == "ready":
            use["semantic_projection_only"] = semantic
        else:
            use.pop("semantic_projection_only", None)
        uses.append(use)
    # Keep legacy bytes/aliases when nothing was changed, including unfrozen
    # workbook decisions. Existing snapshot identities and approval hashes survive.
    if classification == review_classification(record) and uses == descriptive_uses(record):
        return {field: record[field] for field in DESCRIPTIVE_SCOPE_FIELDS if field in record}
    return {"evidence_scope": classification, "approved_uses_json": json.dumps(uses, sort_keys=True)}


def shared_scope_findings(record: Mapping, records: Sequence[Mapping], block_defs: Mapping) -> list[str]:
    """Validate explicitly reviewed uses; a blank owner never means wildcard."""
    identity = str(record.get("record_id") or "")
    prefix = "governed_source_context_"
    scope = descriptive_scope(record)
    if scope not in (*DESCRIPTIVE_SCOPES, *LEGACY_SHARED_SCOPES):
        return [prefix + "invalid_evidence_scope:" + identity]
    try:
        uses = descriptive_uses(record)
    except (ValueError, TypeError):
        return [prefix + "invalid_approved_uses:" + identity]
    if scope == "block_local":
        return [prefix + "local_record_has_shared_uses:" + identity] if uses else []
    if record.get("review_decision", "pending") != "approved":
        return []
    findings = []
    if record.get("mapped_block") and record["mapped_block"] not in block_defs:
        findings.append(prefix + "unknown_source_owner:" + identity)
    if not uses:
        findings.append(prefix + "shared_record_missing_uses:" + identity)
    by_id = {value.get("record_id"): value for value in records}
    seen = set()
    for use in uses:
        use_id = use.get("use_id")
        if not isinstance(use_id, str) or not use_id.strip() or use_id in seen:
            findings.append(prefix + "invalid_use_identity:" + identity)
        elif "::" in use_id:
            findings.append(prefix + "invalid_use_identity:" + identity)
        seen.add(str(use_id))
        document = use.get("document")
        block = use.get("block", "")
        domain = use.get("domain")
        start, end = use.get("start"), use.get("end")
        statement = str(record.get("statement") or "")
        valid_span = (type(start) is int and type(end) is int and 0 <= start < end <= len(statement))
        if not valid_span:
            findings.append(prefix + "invalid_use_span:" + identity)
        elif not statement[start:end].strip() or statement[start:end] != statement[start:end].strip():
            findings.append(prefix + "invalid_use_excerpt:" + identity)
        # Exact sentence/paragraph boundaries prevent a reviewed use from dropping
        # a trailing condition or carving a new assertion out of a clause.
        elif ((start and statement[start - 1] not in "\r\n"
               and not (statement[start - 1].isspace() and statement[:start].rstrip().endswith((".", "!", "?"))))
              or (end < len(statement) and statement[end] not in "\r\n"
                  and not statement[start:end].endswith((".", "!", "?")))):
            findings.append(prefix + "partial_sentence_use:" + identity)
        if ("context_qualification" in use
                or configuration_context(record, statement.strip(), str(use.get("role"))) is not None):
            qualification = configuration_context(record, statement[start:end], str(use.get("role"))) if valid_span else None
            if qualification is None or use.get("context_qualification") != qualification:
                findings.append(prefix + "invalid_configuration_context:" + identity)
        if "semantic_projection_only" in use:
            semantic = (semantic_source_context(record, statement[start:end], str(use.get("role")),
                                                str(document)) if valid_span else None)
            if semantic is None or use["semantic_projection_only"] != semantic:
                findings.append(prefix + "invalid_semantic_source_context:" + identity)
        if not isinstance(document, str) or document not in DOCUMENT_ROLES:
            findings.append(prefix + "invalid_use_document:" + identity)
            continue
        if use.get("role") not in DOCUMENT_ROLES[document]:
            findings.append(prefix + "invalid_use_role:" + identity)
        if not isinstance(use.get("rationale"), str) or not use["rationale"].strip():
            findings.append(prefix + "missing_use_rationale:" + identity)
        if document == "IPOS":
            explicit_context = is_explicit_shared_context(use)
            if (not isinstance(block, str) or block not in block_defs
                    or not isinstance(domain, str)
                    or domain not in ({"digital", "analog", "system", "mixed_signal"} if explicit_context
                                      else {"digital", "analog"})):
                findings.append(prefix + "invalid_use_owner:" + identity)
            functional_source = (use.get("role") == "functions" and valid_span
                                 and explicit_functional_source_support(statement[start:end], block))
            supports = use.get("supporting_record_ids", [] if explicit_context or functional_source else None)
            if (not isinstance(supports, list) or (not supports and not (explicit_context or functional_source))
                    or any(not isinstance(value, str) for value in supports)
                    or len(set(supports)) != len(supports)):
                findings.append(prefix + "missing_local_cross_reference:" + identity)
                continue
            local = []
            for support_id in supports:
                support = by_id.get(support_id, {})
                if (support_id == identity or not support.get("mapped_block")
                        or support.get("review_decision") != "approved"
                        or support.get("mapped_block") != block or support.get("domain") != domain):
                    findings.append(prefix + "invalid_local_cross_reference:" + identity + ":" + support_id)
                else:
                    local.append(str(support.get("statement") or ""))
            if (use.get("role") == "functions" and valid_span and not functional_source
                    and not any(statement[start:end] in text for text in local)):
                findings.append(prefix + "functional_use_not_in_local_evidence:" + identity)
        elif block or domain != {"SRS": "system", "DRS": "digital", "ARS": "analog"}[document]:
            findings.append(prefix + "invalid_document_use_scope:" + identity)
        elif use.get("supporting_record_ids"):
            findings.append(prefix + "unexpected_document_cross_reference:" + identity)
    if uses and scope == "multi_block":
        if any(use.get("document") != "IPOS" for use in uses) or len({str(use.get("block")) for use in uses}) < 2:
            findings.append(prefix + "multi_block_requires_distinct_blocks:" + identity)
    if uses and scope == "multi_level" and len({str(use.get("document")) for use in uses}) < 2:
        findings.append(prefix + "multi_level_requires_distinct_levels:" + identity)
    return list(dict.fromkeys(findings))


def project_shared_descriptive_uses(
    records: Sequence[Mapping], *, document: str, block: str = "", domain: str = "",
) -> tuple[dict, ...]:
    """Select literal approved excerpts without reassigning their source owner."""
    if document not in DOCUMENT_ROLES:
        raise ValueError("Unknown descriptive consumer: " + document)
    projected = []
    by_id = {record["record_id"]: record for record in records}
    for record in records:
        if descriptive_scope(record) == "block_local":
            continue
        if (record.get("review_decision") != "approved"
                or record.get("admission_state") != "admitted" or not record.get("snapshot_id")):
            raise ValueError("Shared descriptive evidence is not snapshot-admitted: " + record["record_id"])
        for use in descriptive_uses(record):
            if use["document"] != document or use.get("block", "") != block:
                continue
            explicit_context = is_explicit_shared_context(use)
            if domain and use["domain"] != domain and not (
                    explicit_context and use["domain"] in {"system", "mixed_signal"}):
                continue
            support_ids = dict.fromkeys(
                identity for approved_use in descriptive_uses(record)
                for identity in approved_use.get("supporting_record_ids", [])
            )
            supports = [by_id[identity] for identity in support_ids]
            if any(value.get("admission_state") != "admitted"
                   or value.get("snapshot_id") != record["snapshot_id"] for value in supports):
                raise ValueError("Shared/local descriptive evidence snapshot mismatch: " + record["record_id"])
            identity = record["record_id"] + "::" + use["use_id"]
            excerpt = record["statement"][use["start"]:use["end"]]
            provenance = {
                "record": dict(record), "approved_use": use,
                "supporting_records": [dict(value) for value in supports],
            }
            projected.append({
                "record_id": identity, "parent_record_id": record["record_id"],
                "statement": excerpt, "source": record["source_file"],
                "scope": "system" if document == "SRS" else "block_local" if document == "IPOS" else "architecture",
                "record_type": "governed_shared_use", "evidence_kind": "descriptive",
                "evidence_scope": descriptive_scope(record), "consumer_document": document,
                "consumer_block": block, "domain": domain or use["domain"], "role": use["role"],
                "snapshot_id": record["snapshot_id"], "admission_state": "admitted",
                "content_sha256": hashlib.sha256(excerpt.encode("utf-8")).hexdigest(),
                "provenance_json": json.dumps(provenance, sort_keys=True),
            })
    return tuple(projected)


def validate_projected_shared_use(record: Mapping, *, document: str, block: str = "", domain: str = "") -> None:
    """Reconstruct every projection from its approved source and cross-references."""
    try:
        provenance = json.loads(record["provenance_json"])
        source = provenance["record"]
        supports = provenance["supporting_records"]
        sources = [source, *supports]
        blocks = {value["mapped_block"]: {} for value in supports if value.get("mapped_block")}
        if source.get("mapped_block"):
            blocks[source["mapped_block"]] = {}
        blocks.update({use.get("block"): {} for use in descriptive_uses(source) if use.get("block")})
        findings = shared_scope_findings(source, sources, blocks)
        if findings:
            raise ValueError("; ".join(findings))
        for value in sources:
            if (value.get("review_decision") != "approved"
                    or hashlib.sha256(value["statement"].encode("utf-8")).hexdigest() != value["content_sha256"]):
                raise ValueError("Changed or unapproved shared/local source")
        expected = project_shared_descriptive_uses(sources, document=document, block=block, domain=domain)
        if dict(record) not in expected:
            raise ValueError("Projection differs from approved source/use")
    except (KeyError, TypeError, json.JSONDecodeError) as error:
        raise ValueError("Invalid shared descriptive projection") from error
