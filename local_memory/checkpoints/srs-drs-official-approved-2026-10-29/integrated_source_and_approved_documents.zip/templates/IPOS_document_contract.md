# IPOS Executable Document Contract

This presentation contract applies to Digital and Analog block-local IPOS.
It creates no approval, ownership, allocation or requirement authority.
The existing approved snapshot resolver supplies all technical scope.
The generator invokes the shared semantic core before rendering; the
orchestrator coordinates only. Unknown or unimplemented rules block execution.

```yaml ipos-document-contract
version: 1
document_type: IPOS
profile: block_local_v1
mandatory_rules: [section_roles, functional_claims, information_gain, semantic_fidelity, publication_quality, materialization]
interpretation: admitted_normative_clauses_v1
synthesis: explicit_functional_claims_v1
detail_policy: preserve_essential_block_detail_v1
gap_policy: required_sections_with_audited_omissions_v1
essential_sources: {purpose: ["inventory:function"], capabilities: ["inventory:main_functions", "inventory:inputs", "inventory:outputs"]}
rendering: scoped_explanatory_prose_v1
descriptive_synthesis:
  version: 1
  abstraction: block_local
  obligations: [semantic_fidelity, section_roles, supported_function_coverage, essential_qualifications, nonduplication, bounded_synthesis]
  sections:
    "1.1": {roles: [purpose], required: true}
    "1.2": {roles: [main_functions, boundaries, context], required: true}
    "1.3": {roles: [organization], required: false}
    "1.4": {roles: [behavior, interaction, restriction], required: false}
    "1.5": {roles: [interaction], required: false}
  detail_roles: [configuration, procedure, implementation]
  literal_policy: preserve_authorized_use_without_synthesis_credit
  gap_policy: existing_descriptive_residuals
paragraph: {
required: [responsibility, supported_behavior],
when_supported: [condition, effect, result, dependency, exception],
claim_scope: [initiation, behavior, result, exception, local_interaction]
}
sections: [
{role: purpose, title: "1.1 Functionality", required: true, information_gain: true},
{role: capabilities, title: "1.2 Supported functions and scope", required: true, information_gain: true},
{role: organization, title: "1.3 Internal structure", required: false, information_gain: true},
{role: functions, title: "1.4 Supported block functions", required: false, information_gain: true},
{role: architecture, title: "1.5 General architecture", required: false, information_gain: true}
]
validation_hooks: [semantic_fidelity, publication_quality, materialization]
```

Purpose explains overall responsibility. Capabilities contribute distinct
supported responsibilities, boundaries or restrictions, not copies of purpose.
Organization requires explicit containment and cannot be inferred from names.
Functional descriptions explain supported behavior and effects, retaining
conditions and dependencies. Titles disclose claim scope and do not promote
initiation-only evidence into full lifecycle coverage. Architecture requires
explicit local interactions rather than co-occurring signals or labels.

Every admitted span has a preserved, justified-excluded or unresolved
disposition. Independent complete meaning is retained; dependent meaning with
an unresolved essential restriction is withheld. Gaps remain in derived audits
and block clean acceptance only when they prevent a required section or affect
an explicit dependency of its essential sources. Unsupported independent detail
is withheld and reported, never completed or printed with uncertainty markers.
Essential sources are declared above; their dependency closure is mandatory.
The number of modal verbs in an independent requirement does not add an
essential source. Unsupported compound detail keeps its exact normative text,
provenance and explicit omission audit, without claiming descriptive materialization.
Every retained claim still requires independent source-fidelity verification.
No rule authorizes inferred completion of sources.
Exact normative statements, IDs, Covers and source I/O remain unchanged.

Complete inventory activities may supply one nominal macro-purpose when supported
by admitted same-owner functional requirement evidence or local responsibility
descriptions, never merely by unrelated configuration requirements. Where explicit
local responsibility descriptions exist, section 1.2 explains those responsibilities
and their interactions instead of repeating each inventory activity from 1.1.
Incomplete activities do not establish a macro-purpose.
Explicit same-owner responsibility descriptions can explain named local functions.
A state-machine name or instantiation list alone does not establish a function,
and starting another actor's operation never establishes execution ownership.
Guarded state progression and mode-dependent interactions belong in section 1.4.
Group complete retained behaviors by their supported function or operating context;
group numbering is navigation, not an inferred execution sequence. Names from an
explicit same-owner instantiation list can qualify grouping labels, not establish
new functions or transfer execution ownership. Keep complete passive storage
relationships and their guards, including technical identifiers in block detail.
Examples illustrate presentation only, never a project-specific function catalogue.
Generation, blocker review and validation use identical selected-snapshot inventory
and provenance; mutable inventory exports cannot replace that binding.

Complete same-owner requirements contribute to the functional descriptions even
when their relationships contain signal/register identifiers. Compound assertions
retain their explicit actors, conditions, alternatives and ordering; unknown or
truncated constructions remain audited gaps. A standalone condition can qualify
the next assertion only through an exact same-record span binding.
Trailing parenthetical verification instructions are retained in the normative
source and audit, not presented as functional behavior; their preceding quantities
and data relationships remain in the description.
The responsibility introduction is a derived synopsis of retained functional
families, linked to their source records and contributors. Section 1.4 retains
the distinct behavior; a family name or synopsis alone earns no detailed-coverage
credit. Channel-to-signal associations are derived from explicit channel-enabling
statements and guide presentation only, never ownership or capability admission.

Section 1.2 opens with a short explanation of how the supported responsibilities
complement one another, followed by readable bullets with meaningful function
labels and one concise role-and-purpose sentence each. Reuse the supported
functional constructions and admitted local responsibilities, not activity-label
lists or a fixed block catalogue. Each supported function has a corresponding
1.4 subsection using the same label; its fuller explanation and qualified detail
remain there. Explicit same-owner coordination descriptions may establish a
separate processing-coordination function, never execution by the requested peer.
Audit summarized projections separately from literally rendered relationships.
Keep mixed-purpose 1.1 projections intact, and materialize overview and bullet
units separately so Markdown and Word lists carry identical meaning.

Each materialized 1.4 group begins with a short, higher-level functional
description of its purpose, activities and established result. Complementary
admitted meanings must establish that description; activity-label lists,
individual requirement paraphrases and generic introductory wrappers do not.
Relevant signal, register, state and numeric detail follows the description.
If complementary functional synthesis is unsupported, report its exact missing
relationship in the writing audit rather than inventing or padding a paragraph.
Meaning, approved ownership and the primary relationship determine placement;
incidental words in a guard cannot override a data transformation or destination.
Exact-actor associations may connect weakly labeled detail to an unambiguous
supported function, never infer an owner or normalize technical identifiers.
The existing responsibility and semantic-unit records audit this composition.
Introductory projections may omit pure register-reference annotations, never
logical comparisons, guards or alternative conditions. A projection that
omits reference detail retains the complete relationship beneath it; unchanged
relationships are partitioned into the introduction without duplication.
Independent assessment checks orientation activities against admitted meanings
without giving orientation sentences functional-coverage credit.
If the source does not support a complete explanation, retain an explicit writing
gap instead of adding generic filler. These are implementations of the existing
paragraph, information-gain and semantic-fidelity obligations, not new gates.

The renderer consumes structured claims, never raw source fragments. Its bounded
paraphrases must preserve role, polarity, modality, guards, quantities, effects,
directed dependencies and exact technical identifiers. Semantic fidelity,
publication quality and materialization are separate mandatory checks against
the admitted evidence and actual Markdown/DOCX. Composer or hash agreement
alone cannot establish acceptance. No legacy rendering fallback is permitted.