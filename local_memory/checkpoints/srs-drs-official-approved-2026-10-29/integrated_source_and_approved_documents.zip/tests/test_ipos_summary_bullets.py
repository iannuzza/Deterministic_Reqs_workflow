import json
import re
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

from test_ipos_functional_openings import FunctionalOpeningTests
from test_ipos_grouped_pilot import GroupedIPOSPilotTests
from csv_artifacts import csv_artifact_reader
from spec_document_contract import drs_document_events, validate_materialization_chain, write_materialization_audit
from workflow_routing import (
    build_ipos_functional_input, build_ipos_normalized_records, build_ipos_semantic_units,
    compose_ipos_overview, validate_ipos_descriptive_output, write_ipos_descriptive_audit,
)


class ResponsibilityBulletTests(unittest.TestCase):
    def test_summary_has_overview_and_meaningful_bullets_without_classification_labels(self):
        functional = GroupedIPOSPilotTests().functional()
        sections, rows = compose_ipos_overview(functional)
        self.assertFalse(sections["scope"][0].startswith("- "))
        bullets = [entry for entry in sections["scope"] if entry.startswith("- ")]
        self.assertGreaterEqual(len(bullets), 1)
        text = "\n".join(sections["scope"])
        self.assertNotRegex(text, r"\bcovers\b|state progression|timed control-output updates|control-output sequencing")
        for bullet in bullets:
            self.assertRegex(bullet, r"^- \*\*[^*]+\.\*\* .+\.$")
            self.assertEqual(len(re.split(r"(?<=[.!?])\s+(?=[A-Za-z0-9])",
                bullet.split("** ", 1)[1])), 1)
        summary = next(row for row in rows if row["decision"] == "function_summary")
        self.assertTrue(json.loads(summary["summary_units_json"]))
        self.assertTrue(json.loads(summary["summarized_projection_ids"]))

    def test_analog_processing_role_describes_result_and_preserves_exclusion(self):
        functional = FunctionalOpeningTests().example("analog", "Charge Reader")
        sections, _ = compose_ipos_overview(functional)
        text = "\n".join(sections["scope"])
        self.assertIn("Result processing", text)
        self.assertIn("averaging", text)
        self.assertIn("accumul", text)
        self.assertNotIn("state progression", text)
        self.assertNotIn("performs subtraction", text)

    def test_section_14_is_not_changed_by_responsibility_summary_views(self):
        functional = GroupedIPOSPilotTests().functional()
        sections, _ = compose_ipos_overview(functional)
        self.assertIn("18-bit data", "\n".join(sections["internal_functions"]))
        self.assertIn("Reset state immediately", "\n".join(sections["internal_functions"]))
        self.assertIn("if no fold_between_frames", "\n".join(sections["internal_functions"]))

    def test_independent_status_events_keep_their_guard_and_belong_to_supervision(self):
        functional = build_ipos_functional_input("Cycle Manager", {"Function": "Control measurements."}, [
            {"source_req_id": "boot", "statement": "When Cycle_FSM is in BOOT State, Cycle_FSM shall wait for the Compute Core to complete the BOOT Phase."},
            {"source_req_id": "ready", "statement": "When the BOOT Phase is ended, Cycle_FSM shall go to IDLE State."},
            {"source_req_id": "begin", "statement": "Every Time a new measurement cycle starts (Cycle_FSM goes in OPERATIVE from another state), the event_irq shall be set to 1 for at least 2 clock cycles."},
            {"source_req_id": "fault", "statement": "When in OPERATIVE, if the time slot counter reaches its limit, Cycle_FSM shall go into the error state and raise an interrupt (slot_fault_irq) to the host."},
        ], domain="digital", descriptive_source_records=[{
            "record_id": "supervision", "statement": "The Cycle_FSM is in charge of identify the working state.",
            "admission_state": "admitted", "snapshot_id": "synthetic-approved",
            "mapped_block": "Cycle Manager", "domain": "digital",
        }])
        sections, rows = compose_ipos_overview(functional)
        summary = next(row for row in rows if row["decision"] == "function_summary")
        bullet = json.loads(summary["summary_claims_json"])[0]
        self.assertIn("reports measurement-start and time-slot error events", bullet["text"])
        self.assertEqual(bullet["label"], "Configuration and device supervision")
        detail = "\n".join(sections["internal_functions"])
        self.assertIn("at least 2 clock cycles", detail)
        self.assertIn("if the time slot counter reaches its limit", detail)
        self.assertNotIn("Power, clock and reset coordination", detail)

    def test_write_only_coordinator_does_not_invent_dsp_or_an_alternative_path(self):
        functional = build_ipos_functional_input("Transfer Manager", {"Function": "Control measurements."}, [],
            domain="digital", descriptive_source_records=[{
                "record_id": "routing-role",
                "statement": "The second FSM called Route_FSM, is in charge of identify the selected signal. "
                             "The Route_FSM is also in charge to start writing to the local bus.",
                "admission_state": "admitted", "snapshot_id": "synthetic-approved",
                "mapped_block": "Transfer Manager", "domain": "digital",
            }])
        sections, _ = compose_ipos_overview(functional)
        scope = "\n".join(sections["scope"])
        self.assertIn("initiates result writes", scope)
        self.assertNotIn("DSP", scope)
        self.assertNotIn(", or", scope)
        self.assertNotIn("peer-operation requests", "\n".join(sections["internal_functions"]))

    def test_real_markdown_word_bullets_and_production_audit_materialize_in_order(self):
        for domain in ("digital", "analog"):
            owner = "Reading Accumulator"
            statements = [
                f"When capture_ok is high, {owner} shall accumulate sensor readings until batch_limit is reached.",
                f"When tally is equal to 9, {owner} shall average the collected sample readings.",
                f"If reject_subtraction is set to 1, {owner} shall not subtract the background reading.",
                "Once the average is computed, if no join_windows option is selected, the data shall be written inside the sample memory using the host interface.",
                "If the join_windows option is selected, after the average is computed, the obtained data shall be written inside the sample memory using the host interface.",
            ]
            functional = build_ipos_functional_input(owner,
                {"Function": "Acquire samples, process measurements, and write records."},
                [{"source_req_id": str(index), "statement": text} for index, text in enumerate(statements)],
                domain=domain)
            with self.subTest(domain=domain), tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                sections, rows = compose_ipos_overview(functional)
                paragraphs = []
                for key, title in (("functionality", "1.1 Functionality"),
                                   ("scope", "1.2 Supported functions and scope"),
                                   ("internal_functions", "1.4 Supported block functions")):
                    paragraphs.extend(["### " + title, *sections[key]])
                markdown = root / "example.md"
                markdown.write_text("\n\n".join(paragraphs), encoding="utf-8")
                word = markdown.with_suffix(".docx")
                subprocess.run(["pandoc", str(markdown), "--to=docx", "--output", str(word)],
                               check=True, capture_output=True, text=True)
                audit = root / "descriptive.csv"
                write_ipos_descriptive_audit(audit, rows)
                with csv_artifact_reader(audit) as reader:
                    persisted = list(reader)
                summary = next(row for row in persisted if row["decision"] == "function_summary")
                self.assertEqual(len(json.loads(summary["summary_claims_json"])), 2)
                self.assertEqual(sum(event.get("is_list", False) for event in drs_document_events(word)), 2)
                self.assertEqual(validate_ipos_descriptive_output(markdown, audit, owner,
                    functional.local_requirement_evidence, functional.local_requirement_ids, (), functional), [])
                units = build_ipos_semantic_units(functional, sections, persisted)
                self.assertTrue(units[0].section.startswith("1.1"))
                records = build_ipos_normalized_records(functional)
                materialization = root / "materialization.json"
                write_materialization_audit(materialization, "IPOS", records, units, markdown, word)
                self.assertEqual(validate_materialization_chain(materialization, "IPOS", records, markdown, word), [])
                original = markdown.read_text(encoding="utf-8")
                markdown.write_text(original.replace("sample averaging", "data encryption", 1), encoding="utf-8")
                self.assertTrue(validate_ipos_descriptive_output(markdown, audit, owner,
                    functional.local_requirement_evidence, functional.local_requirement_ids, (), functional))


if __name__ == "__main__":
    unittest.main()
