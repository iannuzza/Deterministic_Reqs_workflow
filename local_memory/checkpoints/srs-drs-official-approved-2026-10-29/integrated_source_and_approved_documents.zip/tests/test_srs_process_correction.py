import copy
import json
import shutil
import tempfile
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

from openpyxl import Workbook, load_workbook

from approved_snapshot_resolver import resolve_governed_descriptive_context, validate_governed_source_context
from descriptive_review_proposals import requested_destination_rows, accepted_destination_rows
from governed_descriptive_scope import project_shared_descriptive_uses, serialize_descriptive_destinations
from mapping_review_sync import (
    DESTINATIONS_SHEET, prepare_shared_destinations, reviewed_descriptive_context,
    write_descriptive_review_sheet,
)
from spec_document_contract import assess_descriptive_synthesis, descriptive_section_paragraphs, load_descriptive_synthesis_contract
from test_governed_descriptive_scope import record
from test_spec_document_contract import _write_docx
from workflow_routing import (
    SRS_SYSTEM_OVERVIEW_HEADINGS, compose_srs_system_overview, shared_document_descriptive_contributions,
    srs_source_evidence_model,
)

ROOT = Path(__file__).resolve().parents[1]


class SRSProcessCorrectionTests(unittest.TestCase):
    def profile(self, name="LYRA7", mode="Survey Mode", count=3, store="Buffer", *, setup=False):
        purpose = (f"{name} is an environmental measurement device. "
                   f"{name} collects and processes different types of measurements: pressure and humidity.")
        command = ("Set ROUTE bit in Route_Control register to 2 and FORMAT to 5 in Data_Control. "
                   if setup else "")
        behavior = (command +
            f"Sensor Interface samples up to {count} AMBER signals from Converter, average and stores data in {store}. "
            f"Sensor Interface samples VIOLET signal from Converter and stores VIOLET data raw in {store}. "
            f"Raw data are always available in {store} after stored. (Except when {store} FULL occurs)")
        records = [
            record("identity", purpose, evidence_scope="shared", approved_uses_json="[]",
                   section="2", section_context_json='[["2", "Product overview"]]'),
            record("operation", behavior, evidence_scope="shared", approved_uses_json="[]",
                   section="4.2", section_context_json=json.dumps([["4", "Operating modes"], ["4.2", mode]])),
        ]
        return {"block_defs": {}, "governed_source_context": {"version": 1, "records": records}}

    def review(self, root, profile):
        path = root / "review.xlsx"
        book = Workbook()
        book.save(path)
        book.close()
        write_descriptive_review_sheet(path, profile)
        prepared = prepare_shared_destinations(path, profile, profile, backup_path=root / "backup.xlsx")
        self.assertGreater(prepared["pending"], 0)
        with self.assertRaisesRegex(ValueError, "await human"):
            reviewed_descriptive_context(path, profile, profile)
        book = load_workbook(path)
        sheet = book[DESTINATIONS_SHEET]
        fields = {cell.value: cell.column for cell in sheet[1]}
        roles = set()
        for row in range(2, sheet.max_row + 1):
            role = sheet.cell(row, fields["role"]).value
            roles.add(role)
            sheet.cell(row, fields["review_decision"]).value = (
                "approved" if role in {"purpose", "operating_concept"} else "rejected")
        self.assertTrue({"purpose", "operating_concept"}.issubset(roles))
        book.save(path)
        book.close()
        context = reviewed_descriptive_context(path, profile, profile)
        admitted_profile = dict(profile, governed_source_context=context)
        self.assertEqual(validate_governed_source_context(admitted_profile), [])
        repeated = prepare_shared_destinations(path, profile, profile, backup_path=root / "repeat.xlsx")
        self.assertEqual(repeated["pending"], 0)
        self.assertEqual(reviewed_descriptive_context(path, profile, profile), context)
        from canonical_store import fingerprint
        snapshot = {"project_id": "synthetic", "metadata_json": json.dumps({
            "profiles": {"architecture": fingerprint(admitted_profile)}})}
        connection = MagicMock()
        connection.execute.return_value.fetchall.return_value = [
            {"profile_payload_json": json.dumps(admitted_profile)}]
        # Exercise the real profile hash check; only synthetic snapshot/profile storage is stubbed.
        with patch("approved_snapshot_resolver.resolve_approved_snapshot", return_value=snapshot), \
                patch("approved_profile_resolver.connect", return_value=connection):
            sources = resolve_governed_descriptive_context(
                root, snapshot_id="fixed-synthetic", project_id="synthetic")
        shared = project_shared_descriptive_uses(sources, document="SRS")
        return {"snapshot_id": "fixed-synthetic", "document": "SRS",
                "shared_records": list(shared), "source_records": list(sources),
                "inventory": [], "functions": [], "function_decomposition": []}, context

    def assess(self, root, evidence, sections, *, markdown_change=None, word_change=None):
        parts = [line for heading, paragraphs in sections.items() for line in ["### " + heading, *paragraphs]]
        text = "\n\n".join(parts)
        path = root / "srs.md"
        path.write_text(markdown_change(text) if markdown_change else text, encoding="utf-8")
        _write_docx(path.with_suffix(".docx"), (word_change(text) if word_change else text).split("\n\n"))
        with patch("workflow_routing.compose_srs_system_overview", side_effect=AssertionError("producer")), \
                patch("workflow_routing.srs_section_explanation_claim", side_effect=AssertionError("producer")):
            return assess_descriptive_synthesis(path, "SRS", evidence)

    def test_workbook_to_snapshot_to_explanation_with_unrelated_names_and_quantities(self):
        for name, mode, count, store, setup in (
                ("LYRA7", "Survey Mode", 3, "Buffer", False),
                ("HELIOS2", "Capture Mode", 11, "Queue", True)):
            with self.subTest(name=name), tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                profile = self.profile(name, mode, count, store, setup=setup)
                original = copy.deepcopy(profile)
                evidence, context = self.review(root, profile)
                self.assertEqual(profile, original)
                for before, after in zip(profile["governed_source_context"]["records"], context["records"]):
                    for field in ("statement", "content_sha256", "source_spans_json", "mapped_block", "domain"):
                        self.assertEqual(before[field], after[field])
                sections = compose_srs_system_overview(evidence["shared_records"], evidence=evidence)
                purpose = " ".join(sections[SRS_SYSTEM_OVERVIEW_HEADINGS[0]])
                operation = " ".join(sections[SRS_SYSTEM_OVERVIEW_HEADINGS[4]])
                for phrase in (name, "environmental measurement device", "pressure and humidity"):
                    self.assertIn(phrase, purpose)
                for phrase in (mode, f"up to {count}", store, "stores the raw samples",
                               "measurement acquisition with sample storage", "except when"):
                    self.assertIn(phrase, operation)
                self.assertNotIn("Route_Control", operation)
                self.assertFalse(sections[SRS_SYSTEM_OVERVIEW_HEADINGS[3]])
                report = self.assess(root, evidence, sections)
                rows = [row for row in report["meaning_dispositions"] if row.get("section") in {"3.1", "3.5"}]
                self.assertTrue(rows)
                self.assertTrue(all(row["disposition"] == "synthesized" for row in rows), rows)
                self.assertTrue(report["source_records_examined"])
                self.assertEqual(report["scope_examination"], "NOT CHECKED")
                self.assertEqual(report["obligations"]["essential_qualifications"]["status"], "PASS", report["gaps"])

    def test_independent_word_and_markdown_mutations_are_not_satisfied_by_ids_or_headings(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            evidence, _context = self.review(root, self.profile(setup=True))
            sections = compose_srs_system_overview(evidence["shared_records"], evidence=evidence)
            changes = (
                ("up to 3", "up to 8"), ("except when Buffer FULL occurs", ""),
                ("with the configuration specified for Survey Mode applied, ", ""),
                ("stores the raw samples", "stores the samples"),
                ("The system", "The host"), ("measurement acquisition with sample storage", "wiring"),
            )
            for before, after in changes:
                for word_only in (False, True):
                    with self.subTest(before=before, word_only=word_only):
                        change = lambda text: text.replace(before, after).replace(before[:1].lower() + before[1:], after)
                        original = "\n\n".join(text for values in sections.values() for text in values)
                        self.assertNotEqual(change(original), original)
                        report = self.assess(root, evidence, sections,
                            word_change=change if word_only else None,
                            markdown_change=None if word_only else change)
                        self.assertEqual(report["system_abstraction_assessment"][
                            "behavior_and_essential_qualifications"]["status"], "UNRESOLVED", report["gaps"])

    def test_semantic_approval_is_not_interpretation_and_changed_role_needs_review(self):
        profile = self.profile()
        source = profile["governed_source_context"]["records"][0]
        request = {"document": "SRS", "block": "", "role": "operating_concept",
                   "excerpt": source["statement"], "start": 0, "end": len(source["statement"]),
                   "rationale": "Attempted unrelated role"}
        rows = requested_destination_rows(request, source, [source], profile, [])
        self.assertEqual(rows[0]["support_status"], "unsupported_interpretation")
        rows[0]["review_decision"] = "approved"
        with self.assertRaisesRegex(ValueError, "supporting evidence"):
            accepted_destination_rows(source, [source], rows, profile, [], [])
        self.assertTrue(srs_source_evidence_model(source).propositions)
        self.assertEqual(source["approved_uses_json"], "[]")

    def test_complementary_approved_sources_are_aggregated_not_dropped_as_substrings(self):
        sources = [
            record("product-role", "RIGEL4 is an environmental measurement device.",
                   evidence_scope="shared", approved_uses_json="[]"),
            record("application-role", "RIGEL4 is designed for remote monitoring.",
                   evidence_scope="shared", approved_uses_json="[]"),
        ]
        profile = {"block_defs": {}, "governed_source_context": {"version": 1, "records": sources}}
        for source in sources:
            request = {"document": "SRS", "block": "", "role": "purpose", "start": 0,
                       "end": len(source["statement"]), "excerpt": source["statement"], "rationale": "Synthetic review"}
            rows = requested_destination_rows(request, source, sources, profile, [])
            rows[0]["review_decision"] = "approved"
            accepted = accepted_destination_rows(source, sources, rows, profile, [], [])
            source.update(serialize_descriptive_destinations(source, "shared", accepted))
        admitted = [dict(source, snapshot_id="synthetic", admission_state="admitted") for source in sources]
        uses = project_shared_descriptive_uses(admitted, document="SRS")
        paragraphs = shared_document_descriptive_contributions(uses, document="SRS")["3.1"]
        self.assertEqual(len(paragraphs), 1)
        self.assertIn("environmental measurement device and designed for remote monitoring", paragraphs[0])
        self.assertFalse(any(source["statement"] in paragraphs[0] for source in sources))

    def test_role_edit_invalidates_destination_approval_but_not_source_approval(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            _evidence, context = self.review(root, self.profile())
            path = root / "review.xlsx"
            book = load_workbook(path)
            sheet = book[DESTINATIONS_SHEET]
            fields = {cell.value: cell.column for cell in sheet[1]}
            row = next(row for row in range(2, sheet.max_row + 1)
                       if sheet.cell(row, fields["role"]).value == "purpose")
            sheet.cell(row, fields["role"]).value = "operating_concept"
            book.save(path)
            book.close()
            profile = self.profile()
            with self.assertRaisesRegex(ValueError, "refresh and review"):
                reviewed_descriptive_context(path, profile, profile)
            refreshed = prepare_shared_destinations(path, profile, profile, backup_path=root / "role_edit.xlsx")
            self.assertGreater(refreshed["pending"], 0)
            discovery = reviewed_descriptive_context(path, profile, profile, for_proposals=True)
            self.assertEqual([row["review_decision"] for row in discovery["records"]],
                             [row["review_decision"] for row in context["records"]])

    def test_duplicate_source_records_produce_one_explanation_with_both_source_links(self):
        statement = ("RIGEL4 is an environmental measurement device. "
                     "RIGEL4 is designed for remote monitoring.")
        sources = [record(identity, statement, evidence_scope="shared", approved_uses_json="[]")
                   for identity in ("short-extraction", "overlapping-extraction")]
        profile = {"block_defs": {}, "governed_source_context": {"version": 1, "records": sources}}
        for source in sources:
            request = {"document": "SRS", "block": "", "role": "purpose", "start": 0,
                       "end": len(statement), "excerpt": statement, "rationale": "Synthetic duplicate review"}
            rows = requested_destination_rows(request, source, sources, profile, [])
            rows[0]["review_decision"] = "approved"
            accepted = accepted_destination_rows(source, sources, rows, profile, [], [])
            source.update(serialize_descriptive_destinations(source, "shared", accepted))
        admitted = [dict(source, snapshot_id="synthetic", admission_state="admitted") for source in sources]
        evidence = {"snapshot_id": "synthetic", "document": "SRS", "source_records": admitted,
                    "shared_records": list(project_shared_descriptive_uses(admitted, document="SRS")),
                    "inventory": [], "functions": [], "function_decomposition": []}
        sections = compose_srs_system_overview(evidence["shared_records"], evidence=evidence)
        paragraphs = sections[SRS_SYSTEM_OVERVIEW_HEADINGS[0]]
        self.assertEqual(len(paragraphs), 1)
        self.assertEqual(paragraphs[0].count("environmental measurement device"), 1)
        self.assertEqual(paragraphs[0].count("remote monitoring"), 1)
        with tempfile.TemporaryDirectory() as directory:
            report = self.assess(Path(directory), evidence, sections)
        meanings = [row for row in report["meaning_dispositions"] if row.get("section") == "3.1"]
        self.assertTrue(meanings)
        self.assertTrue(all(row["disposition"] == "synthesized" for row in meanings), meanings)
        for source in sources:
            self.assertIn(source["record_id"], json.dumps(meanings))

    def test_accessibility_and_wiring_do_not_establish_execution_or_a_system_outcome(self):
        for statement in ("Measurements are accessible to the Fusion Unit.",
                          "The Buffer is wired to the Compute Unit.",
                          "The Controller coordinates the Processor."):
            source = record("relationships", statement, evidence_scope="shared", approved_uses_json="[]")
            model = srs_source_evidence_model(source)
            self.assertFalse(any(value.meaning.predicate in {"execute", "compute", "process"}
                                 for value in model.propositions))
            self.assertTrue(model.unresolved_contexts or model.propositions)

    def test_missing_authorization_is_not_missing_evidence_or_final_coverage(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            evidence, _context = self.review(root, self.profile())
            evidence["shared_records"] = []
            sections = {heading: [] for heading in SRS_SYSTEM_OVERVIEW_HEADINGS[:5]}
            # Keep source evidence but remove its destination uses, as in a new project's pending review.
            evidence["source_records"] = [
                dict(source, approved_uses_json="[]") for source in evidence["source_records"]]
            report = self.assess(root, evidence, sections)
            rows = report["meaning_dispositions"]
            self.assertTrue(any(row.get("gap_class") == "missing_authorization" for row in rows))
            self.assertFalse(any(row["final_coverage_credit"] for row in rows))
            self.assertEqual(report["system_abstraction_assessment"][
                "implementation_syntax_exclusion"]["status"], "NOT_CHECKED")

    def test_contract_roles_are_reviewable_without_cross_document_permission_broadening(self):
        from governed_descriptive_scope import DOCUMENT_SECTIONS, SRS_DESTINATION_MEANINGS

        policy = load_descriptive_synthesis_contract("SRS")
        for role, target in DOCUMENT_SECTIONS["SRS"].items():
            self.assertTrue(set(SRS_DESTINATION_MEANINGS[role]).issubset(policy["sections"][target]["roles"]))
        self.assertTrue(all("operating_concept" not in roles for document, roles in DOCUMENT_SECTIONS.items()
                            if document != "SRS"))

    def test_supported_scope_is_not_declared_absent_when_interpretation_is_unknown(self):
        source = record("unfamiliar", "An unresolved diagram caption without an attributable system relationship.",
                        evidence_scope="shared", approved_uses_json="[]", snapshot_id="synthetic")
        evidence = {"snapshot_id": "synthetic", "shared_records": [], "source_records": [source],
                    "inventory": [], "functions": []}
        with tempfile.TemporaryDirectory() as directory:
            report = self.assess(Path(directory), evidence, {heading: [] for heading in SRS_SYSTEM_OVERVIEW_HEADINGS[:5]})
        self.assertTrue(report["meaning_dispositions"])
        self.assertTrue(all(row["gap_class"] == "unsupported_interpretation"
                            for row in report["meaning_dispositions"]))
        self.assertFalse(any(row["final_coverage_credit"] for row in report["meaning_dispositions"]))
        self.assertEqual(report["scope_examination"], "NOT CHECKED")

    @unittest.skipUnless(shutil.which("pandoc"), "Existing DOCX converter is unavailable")
    def test_active_srs_writer_and_docx_converter_use_authorized_sections(self):
        from run_srs_gen_spec_agent import _write_srs_markdown, _convert_markdown_to_docx

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            evidence, _context = self.review(root, self.profile(setup=True))
            path = root / "active.md"
            with patch("run_srs_gen_spec_agent._structured_srs_low_power_records", return_value=[]):
                _write_srs_markdown(
                    output_path=path, template_path=ROOT / "templates" / "SRS_gen_AI_template_prompt.md",
                    source_spec="synthetic.pdf", project_name="Independent Synthetic Project",
                    document_author="Test author", requirements=[], srs_id_map={}, req_to_block={},
                    block_inventory_rows=[], interface_rows=[], source_port_rows=[], interaction_rows=[],
                    connection_matrix_srs_ids={}, function_rows=[], descriptive_records=[],
                    block_requirements={}, unmapped_requirements=[], user_specific_requirements=[],
                    non_block_context_rows=[], crosscheck_decision="PASS", missing_inputs=[], mode_rows=[],
                    approved_srs_source_ids=set(), snapshot_id="fixed-synthetic",
                    contract_fingerprint="synthetic", document_version="1.0",
                    overview_records=evidence["shared_records"], responsibility_evidence=evidence)
            _convert_markdown_to_docx(path, path.with_suffix(".docx"),
                                      ROOT / "templates" / "MPT_IPOS_template.docx", root)
            report = assess_descriptive_synthesis(path, "SRS", evidence)
            policy = load_descriptive_synthesis_contract("SRS")
            for artifact in (path, path.with_suffix(".docx")):
                actual = descriptive_section_paragraphs(artifact, policy)
                self.assertTrue(actual["3.1"])
                self.assertTrue(actual["3.5"])
                self.assertIn("measurement acquisition with sample storage", " ".join(actual["3.5"]))
            self.assertEqual(report["obligations"]["essential_qualifications"]["status"], "PASS", report["gaps"])


if __name__ == "__main__":
    unittest.main()
