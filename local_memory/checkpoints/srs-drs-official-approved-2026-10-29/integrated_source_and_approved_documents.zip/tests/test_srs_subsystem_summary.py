import copy
import json
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

from spec_document_contract import stable_payload_hash
import test_responsibility_synthesis as responsibility_tests
from workflow_routing import (
    compose_srs_support_content,
    load_srs_subsystem_summary,
    validate_srs_support_content,
    validate_srs_subsystem_summary,
)


class SRSSubsystemSummaryTests(unittest.TestCase):
    def setUp(self):
        helper = responsibility_tests.ResponsibilitySynthesisTests()
        self.evidence = {**helper.evidence(), "document": "SRS"}
        self.evidence["shared_records"] = list(helper.projected(
            "The digital engine supports sample processing and data collection.", "SRS", "Overview"))
        record = self.evidence["shared_records"][0]
        self.summary = {
            "version": 1, "document": "SRS", "section": "5",
            "snapshot_id": self.evidence["snapshot_id"],
            "architecture_fingerprint": self.evidence["architecture_fingerprint"],
            "review": {"decision": "accepted", "accepted_at": "2026-10-28",
                       "scope": "Descriptive content only."},
            "source_owners": ["Cedar", "Maple"],
            "shared_sources": [{"record_id": record["record_id"],
                                "content_sha256": record["content_sha256"]}],
            "paragraphs": ["The digital subsystem processes sampled data.",
                           "Cedar and Maple provide the approved conversion functions."],
        }
        self.summary["paragraphs_sha256"] = stable_payload_hash(self.summary["paragraphs"])

    def test_reviewed_summary_is_materialized_before_the_catalog_with_provenance(self):
        original = copy.deepcopy(self.summary)
        validate_srs_subsystem_summary(self.summary, self.evidence)
        sections, audit = compose_srs_support_content(
            "Synthetic", self.summary["snapshot_id"], [], [], [], subsystem_summary=self.summary)
        self.assertEqual(sections["5"], self.summary["paragraphs"])
        self.assertEqual(list(sections).index("5") + 1, list(sections).index("5.1"))
        units = [row for row in audit["units"] if row["section"] == "5"]
        self.assertEqual([row["text"] for row in units], self.summary["paragraphs"])
        records = {row["record_id"]: row for row in audit["records"]}
        for unit in units:
            record = records[unit["source_record_ids"][0]]
            self.assertEqual(record["authority_tier"], "admitted_context")
            self.assertIn("config/srs_digital_subsystem_summary.json", record["provenance"])
            self.assertIn(self.summary["shared_sources"][0]["record_id"],
                          json.loads(record["text"])["summary"]["shared_sources"][0]["record_id"])
        self.assertEqual(self.summary, original)

    def test_old_callers_do_not_invent_a_summary(self):
        sections, _audit = compose_srs_support_content("Synthetic", "snapshot", [], [], [])
        self.assertEqual(sections["3"], [])
        self.assertEqual(sections["5"], [])

    def test_system_and_digital_introductions_reuse_validation_without_mixing_sections(self):
        overview = {**copy.deepcopy(self.summary), "section": "3",
                    "paragraphs": ["The system combines acquisition and processing.",
                                   "An external host reads measurement results."]}
        overview["paragraphs_sha256"] = stable_payload_hash(overview["paragraphs"])
        validate_srs_subsystem_summary(overview, self.evidence, section="3")
        sections, audit = compose_srs_support_content(
            "Synthetic", self.summary["snapshot_id"], [], [], [],
            subsystem_summary=self.summary, system_overview_summary=overview)
        self.assertEqual(sections["3"], overview["paragraphs"])
        self.assertEqual(sections["5"], self.summary["paragraphs"])
        records = {row["record_id"]: row for row in audit["records"]}
        units = [row for row in audit["units"] if row["section"] == "3"]
        self.assertEqual([unit["text"] for unit in units], overview["paragraphs"])
        for unit in units:
            self.assertIn("config/srs_system_overview_summary.json",
                          records[unit["source_record_ids"][0]]["provenance"])
        with self.assertRaises(ValueError):
            validate_srs_subsystem_summary(overview, self.evidence)
        with self.assertRaises(ValueError):
            compose_srs_support_content("Synthetic", overview["snapshot_id"], [], [], [],
                                        subsystem_summary=overview)
        changed = {**overview, "paragraphs": ["Unreviewed introduction."]}
        with self.assertRaises(ValueError):
            validate_srs_subsystem_summary(changed, self.evidence, section="3")

    def test_system_overview_owner_scope_is_not_limited_to_digital_or_unbounded(self):
        overview = {**self.summary, "section": "3"}
        evidence = copy.deepcopy(self.evidence)
        evidence["inventory"][0]["domains"] = ["analog"]
        validate_srs_subsystem_summary(overview, evidence, section="3")
        with self.assertRaises(ValueError):
            validate_srs_subsystem_summary(self.summary, evidence)
        evidence["inventory"][0]["applicable"] = False
        with self.assertRaises(ValueError):
            validate_srs_subsystem_summary(overview, evidence, section="3")
        with self.assertRaises(ValueError):
            validate_srs_subsystem_summary(overview, self.evidence, section="3.1")

    def test_system_overview_loader_requires_its_own_rule_file_and_reviewed_binding(self):
        overview = {**self.summary, "section": "3"}
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "templates").mkdir()
            (root / "config").mkdir()
            template = root / "templates" / "SRS_gen_AI_template_prompt.md"
            template.write_text(
                "```yaml srs-document-contract\nversion: 1\ndocument_type: SRS\n"
                "system_overview_summary: reviewed_source_bound_prose_v1\n"
                "subsystem_summary: reviewed_source_bound_prose_v1\n```\n", encoding="utf-8")
            path = root / "config" / "srs_system_overview_summary.json"
            path.write_text(json.dumps(overview), encoding="utf-8")
            (root / "config" / "srs_digital_subsystem_summary.json").write_text(
                json.dumps(self.summary), encoding="utf-8")
            contract = Mock()
            contract.synthesis_evidence.return_value = self.evidence
            with patch("validate_downstream_coherence.resolve_downstream_contract", return_value=contract):
                self.assertEqual(load_srs_subsystem_summary(
                    root, overview["snapshot_id"], section="3"), overview)
                self.assertEqual(load_srs_subsystem_summary(root, self.summary["snapshot_id"]), self.summary)
                path.write_text(json.dumps({**overview, "snapshot_id": "other"}), encoding="utf-8")
                with self.assertRaises(ValueError):
                    load_srs_subsystem_summary(root, overview["snapshot_id"], section="3")
                path.unlink()
                with self.assertRaises(FileNotFoundError):
                    load_srs_subsystem_summary(root, overview["snapshot_id"], section="3")
            with self.assertRaises(ValueError):
                load_srs_subsystem_summary(root, overview["snapshot_id"], section="4")

    def test_system_overview_is_checked_in_actual_markdown_and_word(self):
        from docx import Document

        overview = {**copy.deepcopy(self.summary), "section": "3",
                    "paragraphs": ["The system combines acquisition and processing.",
                                   "An external host reads measurement results."]}
        overview["paragraphs_sha256"] = stable_payload_hash(overview["paragraphs"])
        sections, audit = compose_srs_support_content(
            "Synthetic", self.summary["snapshot_id"], [], [], [],
            subsystem_summary=self.summary, system_overview_summary=overview)
        paragraphs = ["Snapshot ID: " + self.summary["snapshot_id"]]
        for section, entries in sections.items():
            level = "## " if section in {"3", "5"} else "### "
            paragraphs.extend([level + section + ". Overview" if section in {"3", "5"}
                               else level + section + " Content", *entries])
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            output = root / "artifacts" / "stage3_srs"
            output.mkdir(parents=True)
            markdown = output / "system.md"
            markdown.write_text("\n\n".join(paragraphs), encoding="utf-8")
            word = markdown.with_suffix(".docx")
            subprocess.run(["pandoc", str(markdown), "--to=docx", "--output", str(word)],
                           check=True, capture_output=True, text=True)
            (output / "descriptive_srs_content_audit.json").write_text(
                json.dumps(audit), encoding="utf-8")
            self.assertEqual(validate_srs_support_content(markdown), [])
            original = markdown.read_text(encoding="utf-8")
            markdown.write_text(original.replace(overview["paragraphs"][0], "Unreviewed overview."),
                                encoding="utf-8")
            self.assertIn("srs_content_missing_from_markdown:3", validate_srs_support_content(markdown))
            markdown.write_text(original, encoding="utf-8")
            document = Document(word)
            paragraph = next(row for row in document.paragraphs if row.text == overview["paragraphs"][1])
            paragraph.text = "Different host responsibility."
            document.save(word)
            self.assertIn("srs_content_missing_from_docx:3", validate_srs_support_content(markdown))

    def test_changed_review_content_or_scope_is_rejected(self):
        for field, value in (
            ("version", 2),
            ("version", True),
            ("document", "DRS"),
            ("section", "3.5"),
            ("snapshot_id", "another-snapshot"),
            ("architecture_fingerprint", "another-profile"),
            ("review", {"decision": "pending", "accepted_at": "2026-10-28", "scope": "pending"}),
            ("source_owners", ["Unknown Block"]),
            ("source_owners", ["Cedar", "Cedar"]),
            ("shared_sources", [{"record_id": "not-an-authorized-SRS-use", "content_sha256": "wrong"}]),
            ("paragraphs", ["Unreviewed replacement prose."]),
        ):
            with self.subTest(field=field, value=value):
                summary = {**self.summary, field: value}
                with self.assertRaises(ValueError):
                    validate_srs_subsystem_summary(summary, self.evidence)
        for statement in ("The subsystem shall collect samples.", "Covers: REQ-01", "[End]"):
            summary = {**self.summary, "paragraphs": [statement],
                       "paragraphs_sha256": stable_payload_hash([statement])}
            with self.subTest(statement=statement), self.assertRaises(ValueError):
                validate_srs_subsystem_summary(summary, self.evidence)

    def test_source_hash_and_authorized_consumer_are_checked(self):
        changed = copy.deepcopy(self.evidence)
        changed["shared_records"][0]["content_sha256"] = "changed"
        with self.assertRaises(ValueError):
            validate_srs_subsystem_summary(self.summary, changed)
        changed = copy.deepcopy(self.evidence)
        changed["shared_records"][0]["consumer_document"] = "DRS"
        with self.assertRaises(ValueError):
            validate_srs_subsystem_summary(self.summary, changed)
        changed = copy.deepcopy(self.evidence)
        changed["inventory"][0]["applicable"] = False
        with self.assertRaises(ValueError):
            validate_srs_subsystem_summary(self.summary, changed)

    def test_loader_enforces_contract_and_never_uses_a_stale_summary(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "templates").mkdir()
            (root / "config").mkdir()
            template = root / "templates" / "SRS_gen_AI_template_prompt.md"
            template.write_text(
                "```yaml srs-document-contract\nversion: 1\ndocument_type: SRS\n"
                "subsystem_summary: reviewed_source_bound_prose_v1\n```\n", encoding="utf-8")
            summary = root / "config" / "srs_digital_subsystem_summary.json"
            summary.write_text(json.dumps(self.summary), encoding="utf-8")
            contract = Mock()
            contract.synthesis_evidence.return_value = self.evidence
            with patch("validate_downstream_coherence.resolve_downstream_contract", return_value=contract):
                self.assertEqual(load_srs_subsystem_summary(root, self.summary["snapshot_id"]), self.summary)
                changed = {**self.evidence, "snapshot_id": "new-snapshot"}
                contract.synthesis_evidence.return_value = changed
                with self.assertRaises(ValueError):
                    load_srs_subsystem_summary(root, "new-snapshot")
                summary.unlink()
                with self.assertRaises(FileNotFoundError):
                    load_srs_subsystem_summary(root, "new-snapshot")
            template.write_text(
                "```yaml srs-document-contract\nversion: 1\ndocument_type: SRS\n"
                "subsystem_summary: unknown-rule\n```\n", encoding="utf-8")
            with self.assertRaises(ValueError):
                load_srs_subsystem_summary(root, self.summary["snapshot_id"])


if __name__ == "__main__":
    unittest.main()
