import copy
import json
import tempfile
import unittest
from dataclasses import replace
from pathlib import Path
from unittest.mock import patch

from spec_document_contract import (
    assess_descriptive_synthesis, load_descriptive_synthesis_contract,
    validate_descriptive_synthesis_contract,
)
import test_responsibility_synthesis as responsibility_tests
from test_spec_document_contract import _write_docx
from workflow_routing import (
    DescriptiveContext, DescriptiveFunctionalClaim, SRS_SYSTEM_OVERVIEW_HEADINGS, abstract_srs_evidence_model,
    compose_srs_system_overview, shared_descriptive_evidence_model,
    shared_document_descriptive_contributions, system_mode_capability_projections,
    realize_descriptive_functional_claim, srs_implementation_syntax,
)


class SRSAbstractionTests(unittest.TestCase):
    def setUp(self):
        self.helper = responsibility_tests.ResponsibilitySynthesisTests()
        self.uses = self.helper.mode("SRS")
        self.structure = {"inventory": [
            {"owner": actor, "applicable": True, "entity_kind": "concrete_block",
             "source": "approved architecture", "statement": "", "domains": ["digital"]}
            for actor in ("Timing Hub", "Compute Unit")]}

    def text(self, uses=None, document="SRS"):
        return " ".join(shared_document_descriptive_contributions(
            self.uses if uses is None else uses, document=document,
            structural_evidence=self.structure).get(
                "3.5" if document == "SRS" else "3", ()))

    def test_setup_syntax_is_excluded_but_behavior_and_configuration_guard_survive(self):
        original = copy.deepcopy(self.uses)
        text = self.text()
        for syntax in ("CAPTURE", "FILTER", "Mode_Control", "Stream_Control", "=2", "=7"):
            self.assertNotIn(syntax, text)
        for behavior in ("In Capture Mode", "configuration specified for Capture Mode applied",
                         "ALPHA and BETA", "GAMMA", "DELTA", "averages the samples",
                         "stores the raw samples", "user's configuration",
                         "after storage, except when FIFO FULL occurs"):
            self.assertIn(behavior, text)
        self.assertNotIn("Communication between", text)
        self.assertNotIn("disabled", text)
        self.assertEqual(self.uses, original)

    def test_drs_and_ipos_source_meanings_keep_the_exact_implementation_guard(self):
        for document in ("DRS", "IPOS"):
            uses = self.helper.mode(document)
            model = shared_descriptive_evidence_model(
                uses, document=document, owner="Compute Unit" if document == "IPOS" else "")
            self.assertEqual(len(model.propositions), 5)
            for proposition in model.propositions:
                self.assertIn("CAPTURE=2", proposition.meaning.contexts[0].text)
                self.assertIn("FILTER=7", proposition.meaning.contexts[0].text)
        self.assertIn("CAPTURE=2", self.text(self.helper.mode("DRS"), "DRS"))

    def test_internal_interaction_is_audited_without_an_invented_system_consequence(self):
        raw = shared_descriptive_evidence_model(self.uses, document="SRS")
        audit = []
        projected = abstract_srs_evidence_model(raw, audit_rows=audit, structural_evidence=self.structure)
        self.assertEqual(len(raw.propositions), 5)
        self.assertEqual(len(projected.propositions), 4)
        excluded = [row for row in audit if row["projected_meaning"] is None]
        self.assertEqual(len(excluded), 1)
        self.assertEqual(excluded[0]["behavior_preservation"], "detail_only_no_consequence_inferred")
        self.assertIn("requires its own authorized use", excluded[0]["detail_location"])

    def test_external_interaction_is_not_assumed_to_be_internal(self):
        raw = shared_descriptive_evidence_model(self.uses, document="SRS")
        interaction = raw.propositions[0]
        external = replace(interaction, meaning=replace(interaction.meaning,
            subject="Communication between the system and external host", contexts=()))
        projected = abstract_srs_evidence_model(
            replace(raw, propositions=(external,)), structural_evidence=self.structure)
        self.assertEqual(projected.propositions, (external,))
        unknown = abstract_srs_evidence_model(replace(raw, propositions=(interaction,)))
        self.assertFalse(unknown.propositions)
        self.assertIn("interaction scope unresolved", unknown.unresolved_contexts[0].reason)

    def test_projection_is_idempotent_and_missing_provenance_is_unresolved(self):
        raw = shared_descriptive_evidence_model(self.uses, document="SRS")
        projected = abstract_srs_evidence_model(raw, structural_evidence=self.structure)
        self.assertEqual(abstract_srs_evidence_model(projected, structural_evidence=self.structure), projected)
        unbound = replace(raw, records=tuple(replace(row, provenance=()) for row in raw.records),
                          propositions=(raw.propositions[1],))
        result = abstract_srs_evidence_model(unbound, structural_evidence=self.structure)
        self.assertFalse(result.propositions)
        self.assertIn("unresolved configuration condition", result.unresolved_contexts[0].reason)

    def test_unknown_configuration_condition_is_unresolved_not_unconditional(self):
        raw = shared_descriptive_evidence_model(self.uses, document="SRS")
        proposition = raw.propositions[1]
        changed = replace(proposition, meaning=replace(proposition.meaning,
            contexts=(DescriptiveContext("atom", "When UNKNOWN_BIT=1"),)))
        model = replace(raw, propositions=(changed,))
        audit = []
        projected = abstract_srs_evidence_model(model, audit_rows=audit)
        self.assertFalse(projected.propositions)
        self.assertTrue(projected.unresolved_contexts)
        self.assertEqual(audit[0]["source_meaning"]["objects"], changed.meaning.objects)
        self.assertIn("unresolved configuration condition", audit[0]["reason"])

    def test_heading_without_unique_setup_never_becomes_configuration_equivalence(self):
        text = self.uses[0]["statement"]
        text = text.replace("This will cut", "Set OTHER bit in Other_Control register to 3 and "
                            "MASK to 9 in Other_Stream. This will cut")
        uses = self.helper.projected(text, "SRS", "Capture Mode")
        self.assertFalse(self.text(uses))
        self.assertTrue(shared_descriptive_evidence_model(uses, document="SRS").unresolved_contexts)

    def test_addresses_or_programming_actions_cannot_silently_discard_a_behavior(self):
        raw = shared_descriptive_evidence_model(self.uses, document="SRS")
        proposition = raw.propositions[1]
        for object_text in ("measurements at address 0x30", "measurements after writing register DATA"):
            candidate = replace(proposition, meaning=replace(
                proposition.meaning, objects=(object_text,)))
            audit = []
            result = abstract_srs_evidence_model(replace(raw, propositions=(candidate,)), audit_rows=audit)
            self.assertFalse(result.propositions)
            self.assertTrue(result.unresolved_contexts)
            self.assertEqual(audit[0]["behavior_preservation"], "unresolved")
            self.assertEqual(audit[0]["source_meaning"]["objects"], (object_text,))

    def test_bit_syntax_is_distinct_from_high_level_measurement_quantities(self):
        for text in ("bit 7 is cleared", "bits [7:0] are 0b0010", "CONTROL=0x10", "write bit ENABLE"):
            self.assertTrue(srs_implementation_syntax(text), text)
        for text in ("The device acquires 3 measurements at a fixed bit rate.",
                     "The system provides SPI host register access."):
            self.assertFalse(srs_implementation_syntax(text), text)

    def assess(self, text, *, word_text=None, section="3.5"):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "system.md"
            evidence = {"snapshot_id": "approved-synthetic", "shared_records": self.uses,
                        "functions": [], **self.structure}
            capability = system_mode_capability_projections(evidence)[0][1]
            prefix = ["# 3.2 Main System Capabilities", realize_descriptive_functional_claim(
                DescriptiveFunctionalClaim("test-capability", "main_functions", (), (capability,), (), ())),
                "# " + next(heading for heading in SRS_SYSTEM_OVERVIEW_HEADINGS
                             if heading.startswith(section + " "))]
            path.write_text("\n\n".join([*prefix, text]), encoding="utf-8")
            _write_docx(path.with_suffix(".docx"), [*prefix, text if word_text is None else word_text])
            with patch("workflow_routing.shared_document_descriptive_contributions",
                       side_effect=AssertionError("independent assessor must not call composer")):
                return assess_descriptive_synthesis(path, "SRS", evidence)

    def test_independent_readback_separates_exclusion_preservation_and_placement(self):
        text = self.text()
        report = self.assess(text)
        assessment = report["system_abstraction_assessment"]
        self.assertEqual(assessment["implementation_syntax_exclusion"]["status"], "PASS")
        self.assertEqual(assessment["behavior_and_essential_qualifications"]["status"], "PASS")
        self.assertTrue(any(row["section"] == "3.5" for row in report["claim_to_source"]))
        self.assertFalse(any(row.get("gap_class") == "missing_authorization"
                             and row.get("section") == "3.5" for row in report["gaps"]))
        misplaced = self.assess(text, section="3.4")
        self.assertTrue(any(row["obligation"] == "section_roles"
                            and row["section"] == "3.4" for row in misplaced["gaps"]))
        mutations = (
            ("With the configuration specified for Capture Mode applied, ", ""),
            ("except when FIFO FULL occurs", ""),
            ("stores the raw samples", "stores the samples"),
            ("according to the user's configuration", ""),
            ("Capture Mode", "Other Mode"),
        )
        for before, after in mutations:
            changed = text.replace(before, after).replace(before[:1].lower() + before[1:], after)
            self.assertNotEqual(changed, text)
            for word_only in (False, True):
                with self.subTest(before=before, word_only=word_only):
                    result = self.assess(text if word_only else changed,
                                         word_text=changed if word_only else None)
                    self.assertEqual(result["system_abstraction_assessment"][
                        "behavior_and_essential_qualifications"]["status"], "UNRESOLVED")
        contaminated = self.assess(text + " The system writes register CONTROL at address 0x30.")
        self.assertEqual(contaminated["system_abstraction_assessment"][
            "implementation_syntax_exclusion"]["status"], "UNRESOLVED")

    def test_syntax_assessment_needs_actual_prose_but_not_expected_claims(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "system.md"
            evidence = {"snapshot_id": "approved-synthetic", "shared_records": [], "functions": []}
            missing = assess_descriptive_synthesis(path, "SRS", evidence)
            self.assertEqual(missing["system_abstraction_assessment"][
                "implementation_syntax_exclusion"]["status"], "NOT_CHECKED")
            text = "The system writes register CONTROL."
            path.write_text("# 3.4 External Interfaces and System Boundaries\n\n" + text, encoding="utf-8")
            _write_docx(path.with_suffix(".docx"), ["# 3.4 External Interfaces and System Boundaries", text])
            contaminated = assess_descriptive_synthesis(path, "SRS", evidence)
            self.assertEqual(contaminated["system_abstraction_assessment"][
                "implementation_syntax_exclusion"]["status"], "UNRESOLVED")
            self.assertEqual(len(contaminated["system_abstraction_assessment"][
                "implementation_syntax_exclusion"]["findings"]), 2)

    def test_optionality_and_inclusive_alternatives_are_not_abstracted_away(self):
        statement = ("In this mode it is possible to turn on the Vector Engine to work with "
                     "raw data and/or filtered data.")
        uses = self.helper.projected(statement, "SRS", "Observe Mode")
        text = self.text(uses)
        self.assertIn("can be enabled", text)
        self.assertIn("raw data, filtered data, or both", text)
        self.assertIn("Observe Mode", text)
        self.uses = uses
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "optional.md"
            for before, after in (("", ""), ("can be enabled", "is enabled"),
                                  ("raw data, filtered data, or both", "raw data and filtered data")):
                changed = text.replace(before, after) if before else text
                for word_only in (False, True):
                    path.write_text("# 3.5 Operating Concept\n\n" +
                                    (text if word_only else changed), encoding="utf-8")
                    _write_docx(path.with_suffix(".docx"),
                                ["# 3.5 Operating Concept", changed])
                    result = assess_descriptive_synthesis(path, "SRS", {
                        "snapshot_id": "approved-synthetic", "shared_records": uses, "functions": []})
                    self.assertEqual(result["system_abstraction_assessment"][
                        "behavior_and_essential_qualifications"]["status"],
                        "UNRESOLVED" if before else "PASS", (before, word_only, result["gaps"]))

    def test_contract_places_operating_context_without_duplicate_boundary_prose(self):
        original = copy.deepcopy(self.uses)
        evidence = self.helper.evidence()
        evidence["shared_records"] = self.uses
        proposals = []
        sections = compose_srs_system_overview(
            self.uses, evidence=evidence, proposal_rows=proposals)
        self.assertIn("configuration specified for Capture Mode applied",
                      " ".join(sections[SRS_SYSTEM_OVERVIEW_HEADINGS[4]]))
        self.assertNotIn("configuration specified for Capture Mode applied",
                         " ".join(sections[SRS_SYSTEM_OVERVIEW_HEADINGS[3]]))
        self.assertFalse(any(row["section"] == "3.5" for row in proposals))
        self.assertEqual(self.uses, original)

    def test_contract_places_supported_identity_without_changing_source_use(self):
        uses = self.helper.projected(
            "PulseSense is an Analog Front End Device with embedded processing capabilities. "
            "PulseSense collects and processes different types of Vital Signals: \u2022 ALPHA \u2022 BETA",
            "SRS", "Device identity")
        original = copy.deepcopy(uses)
        evidence = self.helper.evidence()
        evidence["shared_records"] = uses
        sections = compose_srs_system_overview(uses, evidence=evidence)
        purpose = " ".join(sections[SRS_SYSTEM_OVERVIEW_HEADINGS[0]])
        self.assertIn("PulseSense", purpose)
        self.assertIn("Analog Front End Device", purpose)
        self.assertIn("ALPHA", purpose)
        self.assertIn("BETA", purpose)
        self.assertNotIn(purpose, " ".join(sections[SRS_SYSTEM_OVERVIEW_HEADINGS[3]]))
        self.assertEqual(uses, original)
        self.assertTrue(all(row["role"] == "context" for row in uses))

    def test_contract_without_semantic_placement_keeps_original_destination(self):
        policy = load_descriptive_synthesis_contract("SRS")
        policy.pop("context_placement")
        evidence = self.helper.evidence()
        evidence["shared_records"] = self.uses
        proposals = []
        with patch("spec_document_contract.load_descriptive_synthesis_contract", return_value=policy):
            sections = compose_srs_system_overview(
                self.uses, evidence=evidence, proposal_rows=proposals)
        self.assertFalse(sections[SRS_SYSTEM_OVERVIEW_HEADINGS[4]])
        self.assertIn("configuration specified for Capture Mode applied",
                      " ".join(sections[SRS_SYSTEM_OVERVIEW_HEADINGS[3]]))
        self.assertTrue(any(row["section"] == "3.5" for row in proposals))

    def test_semantic_placement_never_admits_another_document_consumer(self):
        with self.assertRaises(ValueError):
            shared_document_descriptive_contributions(self.helper.mode("DRS"), document="SRS")

    def test_operating_storage_property_is_not_register_configuration(self):
        from governed_descriptive_scope import project_shared_descriptive_uses
        from test_governed_descriptive_scope import admitted, record

        statement = (
            "All the data are stored inside a Sample FIFO that can be configured as: "
            "\u2022 Single Queue: Classic FIFO, the First Data that is written inside the Memory "
            "is also the First that is read. \u2022 Split Queue: "
            "The FIFO is split up to 4 Sub-FIFO (one for each Channels plus one for results). "
            "The depth of each Sub-FIFO is configurable by Storage_Control. "
            "Each Sub-FIFO behaves as a Classic FIFO")
        source = record("storage-evidence", statement, evidence_scope="shared",
            section_context_json=json.dumps([["3", "Storage"], ["3.1", "Store organization"]]))
        source["approved_uses_json"] = json.dumps([{
            "use_id": "approved", "document": "SRS", "block": "", "domain": "system",
            "role": "context", "start": 0, "end": len(statement),
            "rationale": "Reviewed storage behavior.",
        }])
        uses = project_shared_descriptive_uses(admitted({
            "governed_source_context": {"version": 1, "records": [source]},
        }), document="SRS", domain="system")
        text = self.text(uses)
        self.assertIn("configurable storage depth", text)
        self.assertIn("first-in first-out storage", text)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "storage.md"
            for value, contaminated in (
                (text, False),
                (text + " The system writes register CONTROL at address 0x30.", True),
            ):
                path.write_text("# 3.5 Operating Concept\n\n" + value, encoding="utf-8")
                _write_docx(path.with_suffix(".docx"), ["# 3.5 Operating Concept", value])
                report = assess_descriptive_synthesis(path, "SRS", {
                    "snapshot_id": "approved-synthetic", "shared_records": uses,
                    "functions": [], **self.structure})
                rejected = any(row["reason"] == "technical/configuration detail in functional prose"
                               and row["section"] == "3.5" for row in report["gaps"])
                self.assertEqual(rejected, contaminated)

    def test_semantic_placement_contract_rejects_unknown_or_cross_document_policy(self):
        policy = load_descriptive_synthesis_contract("SRS")
        policy.pop("contract_sha256")
        self.assertEqual(validate_descriptive_synthesis_contract({
            "document_type": "SRS", "descriptive_synthesis": policy}), policy)
        for document, value in (("DRS", "semantic_system_overview_v1"),
                                ("IPOS", "semantic_system_overview_v1"),
                                ("SRS", "unrestricted")):
            with self.subTest(document=document, value=value), self.assertRaises(ValueError):
                validate_descriptive_synthesis_contract({
                    "document_type": document,
                    "descriptive_synthesis": {**policy, "context_placement": value}})
        incomplete = copy.deepcopy(policy)
        incomplete["sections"].pop("3.5")
        with self.assertRaises(ValueError):
            validate_descriptive_synthesis_contract({
                "document_type": "SRS", "descriptive_synthesis": incomplete})


if __name__ == "__main__":
    unittest.main()
