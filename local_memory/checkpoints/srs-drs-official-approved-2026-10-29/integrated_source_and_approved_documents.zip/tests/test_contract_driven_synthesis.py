import copy
import json
import shutil
import tempfile
import unittest
from dataclasses import replace
from pathlib import Path
from unittest.mock import patch

from spec_document_contract import assess_descriptive_synthesis
import test_responsibility_synthesis as responsibility_tests
from test_spec_document_contract import _write_docx
from workflow_routing import (
    SRS_SYSTEM_OVERVIEW_HEADINGS,
    compose_document_responsibilities,
    compose_srs_system_overview,
    functional_meaning_role,
    shared_descriptive_evidence_model,
)


class ContractDrivenSynthesisTests(unittest.TestCase):
    def uses(self, statement, document="SRS", role="context"):
        helper = responsibility_tests.ResponsibilitySynthesisTests()
        uses = helper.projected(statement, document, "Device overview")
        if role != "context" or document == "ARS":
            from test_governed_descriptive_scope import admitted
            from governed_descriptive_scope import project_shared_descriptive_uses
            provenance = json.loads(uses[0]["provenance_json"])
            source = provenance["record"]
            use = provenance["approved_use"]
            use["role"] = role
            if document == "ARS":
                use["domain"] = "analog"
            source["approved_uses_json"] = json.dumps([use])
            uses = project_shared_descriptive_uses(
                admitted({"governed_source_context": {"version": 1, "records": [source]}}),
                document=document)
        return uses

    def evidence(self, uses=()):
        evidence = responsibility_tests.ResponsibilitySynthesisTests().evidence()
        evidence["shared_records"] = list(uses)
        for row in evidence["inventory"]:
            row.update(entity_kind="concrete_block", scope="allocated_owner", domains=["digital"])
        return evidence

    def test_identity_is_interpreted_before_unrelated_unsupported_detail(self):
        uses = self.uses(
            "AURORA9 is an environmental measurement device with embedded processing. "
            "The private register table requires a separate interpretation.")
        model = shared_descriptive_evidence_model(uses, document="SRS")
        purposes = [p for p in model.propositions if functional_meaning_role(p.meaning) == "purpose"]
        self.assertEqual(len(purposes), 1)
        self.assertEqual(purposes[0].meaning.subject, "AURORA9")
        self.assertIn("environmental measurement device", purposes[0].meaning.objects[0])
        self.assertTrue(model.unresolved_contexts)
        self.assertNotIn("private register", purposes[0].spans[0].text)

    def test_explicit_organization_and_application_lists_keep_exact_spans(self):
        uses = self.uses(
            "AURORA9 collects and processes different types of measurements: "
            "\u2022 pressure \u2022 temperature and humidity. "
            "The system comprises the Sensing domain and the Processing domain.")
        model = shared_descriptive_evidence_model(uses, document="SRS")
        self.assertFalse(model.unresolved_contexts)
        actions = {p.meaning.predicate for p in model.propositions}
        self.assertTrue({"collect", "process", "comprise"}.issubset(actions))
        organization = [p for p in model.propositions if p.meaning.relation == "containment"]
        self.assertEqual(len(organization), 1)
        self.assertEqual(organization[0].meaning.objects,
                         ("the Sensing domain", "the Processing domain"))
        for proposition in model.propositions:
            for span in proposition.spans:
                self.assertEqual(uses[0]["statement"][span.start:span.end], span.text)

    def test_supported_purpose_is_proposed_without_forging_destination_authority(self):
        uses = self.uses(
            "AURORA9 is an environmental measurement device with embedded processing. "
            "The system is designed for remote environmental monitoring.")
        original = copy.deepcopy(uses)
        proposed, audit = [], []
        sections = compose_srs_system_overview(
            uses, evidence=self.evidence(uses), proposal_rows=proposed, audit_rows=audit)
        self.assertEqual(sections[SRS_SYSTEM_OVERVIEW_HEADINGS[0]], [])
        self.assertTrue(any(row["section"] == "3.1" for row in proposed))
        purpose = next(row for row in proposed if row["section"] == "3.1")
        self.assertIn("environmental", purpose["proposed_text"])
        self.assertEqual(purpose["review_decision"], "pending")
        self.assertFalse(purpose["authority"])
        self.assertTrue(purpose["proposition_ids"])
        self.assertTrue(purpose["authorization_request"])
        self.assertEqual(uses, original)
        self.assertTrue(sections[SRS_SYSTEM_OVERVIEW_HEADINGS[1]])
        self.assertTrue(all("domain contributes" in text for text in sections[SRS_SYSTEM_OVERVIEW_HEADINGS[2]]))

    def test_authorized_purpose_uses_coordinated_plan_not_whole_record_rejection(self):
        uses = self.uses(
            "AURORA9 is an environmental measurement device with embedded processing. "
            "The private register table requires a separate interpretation.", role="purpose")
        sections = compose_srs_system_overview(uses, evidence=self.evidence(uses))
        purpose = " ".join(sections[SRS_SYSTEM_OVERVIEW_HEADINGS[0]])
        self.assertIn("environmental measurement", purpose)
        self.assertNotIn("private register", purpose)
        self.assertNotIn("not specified", " ".join(
            text for heading in SRS_SYSTEM_OVERVIEW_HEADINGS[:5] for text in sections[heading]))

    def test_complete_proposed_srs_has_role_specific_sections_without_authorizing_them(self):
        uses = self.uses(
            "AURORA9 is a measurement device. "
            "AURORA9 collects and processes measurements: pressure and temperature. "
            "The system comprises the Sensing domain and the Processing domain.")
        original = copy.deepcopy(uses)
        reviewed, proposals = {}, []
        authorized = compose_srs_system_overview(
            uses, evidence=self.evidence(uses), proposal_rows=proposals, review_sections=reviewed)
        self.assertFalse(authorized[SRS_SYSTEM_OVERVIEW_HEADINGS[0]])
        self.assertNotIn("The system comprises", " ".join(authorized[SRS_SYSTEM_OVERVIEW_HEADINGS[2]]))
        purpose = " ".join(reviewed[SRS_SYSTEM_OVERVIEW_HEADINGS[0]])
        self.assertIn("collects and processes", purpose)
        self.assertEqual(purpose.count("pressure"), 1)
        self.assertTrue(reviewed[SRS_SYSTEM_OVERVIEW_HEADINGS[2]])
        self.assertNotIn("measurement device", " ".join(reviewed[SRS_SYSTEM_OVERVIEW_HEADINGS[3]]))
        self.assertTrue(all(not row["authority"] and row["review_decision"] == "pending" for row in proposals))
        self.assertEqual(uses, original)

    def test_shared_mode_context_is_expressed_once_with_all_dependencies(self):
        from workflow_routing import shared_document_descriptive_contributions
        helper = responsibility_tests.ResponsibilitySynthesisTests()
        for document, section in (("SRS", "3.4"), ("DRS", "3")):
            uses = helper.mode(document)
            text = " ".join(shared_document_descriptive_contributions(uses, document=document)[section])
            self.assertEqual(text.count("In Capture Mode"), 1)
            self.assertEqual(text.count("CAPTURE=2"), 0 if document == "SRS" else 1)
            if document == "SRS":
                self.assertNotIn("FILTER=7", text)
                self.assertIn("configuration specified for Capture Mode applied", text)
            else:
                self.assertIn("FILTER=7", text)
            for detail in ("raw samples", "user's configuration", "except when FIFO FULL occurs"):
                self.assertIn(detail, text)

    def test_main_actor_list_does_not_claim_exhaustive_domain_composition(self):
        from workflow_routing import shared_document_descriptive_contributions
        uses = self.uses("The main blocks in digital domain are: Cedar and Maple.", document="DRS")
        text = " ".join(shared_document_descriptive_contributions(uses, document="DRS")["3"])
        self.assertIn("among its main actors", text)
        self.assertNotIn("comprises", text)
        self.assertIn("Cedar", text)
        self.assertIn("Maple", text)

    def test_complete_domain_catalogue_consolidates_partial_lists_and_preserves_descriptors(self):
        from workflow_routing import document_domain_catalogues, shared_document_descriptive_contributions
        for document in ("SRS", "DRS"):
            with self.subTest(document=document):
                uses = self.uses("The main blocks in digital domain are: Cedar 32-bit processor and Maple data collector.",
                                 document=document)
                evidence = self.evidence(uses)
                evidence["inventory"].append({**evidence["inventory"][0], "owner": "Aspen"})
                original = copy.deepcopy(evidence)
                catalogues, consolidated = document_domain_catalogues(evidence, document=document)
                self.assertEqual(len(consolidated), 1)
                if document == "SRS":
                    reviewed = {}
                    compose_srs_system_overview(uses, evidence=evidence, review_sections=reviewed)
                    text = " ".join(item for values in reviewed.values() for item in values)
                    self.assertNotIn("The digital domain includes", text)
                    self.assertNotIn("implementation blocks:", text)
                    self.assertNotIn("32-bit processor", text)
                    self.assertTrue(reviewed["3.3 Main Architectural Domains and Subsystems"])
                else:
                    sections = shared_document_descriptive_contributions(
                        uses, document=document, structural_evidence=evidence)
                    text = " ".join([*sections.get("3", ()), *catalogues.values()])
                    self.assertEqual(text.count("The digital domain includes"), 1)
                    for detail in ("Cedar (32-bit processor)", "Maple (data collector)", "Aspen"):
                        self.assertIn(detail, text)
                self.assertEqual(evidence, original)

    def test_domain_consolidation_does_not_drop_unresolved_or_qualified_membership(self):
        from workflow_routing import document_domain_catalogues, shared_document_descriptive_contributions
        uses = self.uses("The main blocks in digital domain are: Cedar and Unmapped.", document="DRS")
        evidence = self.evidence(uses)
        _, consolidated = document_domain_catalogues(evidence, document="DRS")
        self.assertFalse(consolidated)
        text = " ".join(shared_document_descriptive_contributions(
            uses, document="DRS", structural_evidence=evidence)["3"])
        self.assertIn("Unmapped", text)

    def test_independent_validator_detects_partial_membership_beside_complete_catalogue(self):
        from workflow_routing import document_domain_catalogues
        for document, section in (("SRS", "3.3"), ("DRS", "3")):
            evidence = self.evidence()
            catalogues, _ = document_domain_catalogues(evidence, document=document)
            with tempfile.TemporaryDirectory() as directory:
                path = Path(directory) / "review.md"
                path.write_text("## " + section + " Architecture\n\n" + catalogues["digital"]
                                + "\n\nThe digital domain includes Cedar among its main actors.\n",
                                encoding="utf-8")
                _write_docx(path.with_suffix(".docx"), path.read_text(encoding="utf-8").splitlines())
                report = assess_descriptive_synthesis(path, document, evidence)
                self.assertTrue(any(gap["reason"] == ("block inventory does not establish domain responsibilities"
                                    if document == "SRS" else "domain membership is repeated instead of consolidated")
                                    for gap in report["gaps"]))

    def test_drs_functional_themes_and_block_purposes_are_uniform_finite_prose(self):
        texts, audit = compose_document_responsibilities(self.evidence(), document="DRS")
        self.assertFalse(any(text.startswith("- ") for text in texts))
        self.assertFalse(any("responsibility comprises" in text for text in texts))
        self.assertTrue(any(text.startswith("#### Cedar") for text in texts))
        self.assertEqual(len([row for row in audit if row.get("role") == "block_purpose"]), 2)

    def test_drs_has_one_actual_purpose_paragraph_per_concrete_local_owner(self):
        evidence = self.evidence()
        evidence["inventory"].extend([
            {**evidence["inventory"][0], "owner": "Boundary Link", "entity_kind": "interface"},
            {**evidence["inventory"][0], "owner": "Analog Peer",
             "scope": "approved_function_boundary", "domains": ["analog"]},
        ])
        texts, audit = compose_document_responsibilities(evidence, document="DRS")
        purpose = [row for row in audit if row.get("role") == "block_purpose"]
        self.assertEqual([row["owner"] for row in purpose], ["Cedar", "Maple"])
        for row in purpose:
            self.assertIn(row["rendered_summary"], texts)
            self.assertFalse(row["rendered_summary"].lstrip().startswith("-"))
            self.assertIn("converts input currents to samples", row["rendered_summary"])
            self.assertTrue(row["proposition_ids"])
        self.assertFalse(any(row.get("role") == "block_purpose" and
                             row["owner"] in {"Boundary Link", "Analog Peer"} for row in audit))

    def test_system_projection_keeps_observable_local_test_and_notification_without_calibration(self):
        evidence = self.evidence()
        evidence["function_decomposition"] = []
        evidence["inventory"][0]["statement"] = "Perform memory self-test."
        evidence["inventory"][1]["statement"] = "Generate event notifications."
        text = " ".join(compose_document_responsibilities(evidence, document="SRS")[0])
        self.assertIn("The device performs memory self-test", text)
        self.assertIn("The device generates event notifications", text)
        for unsupported in ("calibration", "Cedar", "Maple", "across", "responsibility comprises"):
            self.assertNotIn(unsupported, text)

    def test_ipos_peer_processing_of_owned_data_does_not_become_a_local_capability(self):
        from workflow_routing import build_ipos_functional_input, compose_ipos_overview
        uses = responsibility_tests.ResponsibilitySynthesisTests().projected(
            "In this mode it is possible to turn on SideProcessor to work with raw data "
            "and/or Compute Unit elaborated Data.", "IPOS", "Normal Mode")
        functional = build_ipos_functional_input("Compute Unit",
            {"Function": "Execute firmware for FUSE boot/write/test and signal elaboration."},
            domain="digital", shared_context_records=uses)
        sections, audit = compose_ipos_overview(functional)
        self.assertNotIn("SideProcessor", " ".join(text for values in sections.values() for text in values))
        self.assertIn("FUSE boot/write/test", " ".join(sections["scope"]))
        self.assertNotIn("signal elaboration", " ".join(sections["scope"]))
        self.assertTrue(any("no directly supported local function" in row["reason"] for row in audit))

    def test_system_organization_uses_explicit_function_membership_not_connection_presence(self):
        from workflow_routing import system_domain_responsibilities
        evidence = self.evidence()
        evidence["inventory"][1]["domains"] = ["analog"]
        evidence["interactions"] = [{"source": "Cedar", "destination": "Maple", "exchange": "access"}]
        roles = system_domain_responsibilities(evidence)
        self.assertEqual({domain for domain, _meaning, _sources in roles}, {"analog", "digital"})
        self.assertTrue(all(sources == ("architecture-function:1",) for _domain, _meaning, sources in roles))
        evidence["function_decomposition"] = []
        self.assertFalse(system_domain_responsibilities(evidence))

    def test_measurement_capability_preserves_its_qualified_operating_dependency(self):
        from workflow_routing import system_mode_capability_projections
        uses = responsibility_tests.ResponsibilitySynthesisTests().mode("SRS")
        evidence = self.evidence(uses)
        projections = system_mode_capability_projections(evidence)
        self.assertEqual(len(projections), 1)
        self.assertIn("GAMMA measurement acquisition with raw sample storage", projections[0][1].objects)
        reviewed = {}
        compose_srs_system_overview(uses, evidence=evidence, review_sections=reviewed)
        parts = [value for heading, values in reviewed.items() for value in ["### " + heading, *values]]
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "review.md"
            for changed in (False, True):
                text = "\n\n".join(parts)
                if changed:
                    text = text.replace("configuration specified for Capture Mode applied",
                                        "configuration specified for Other Mode applied")
                path.write_text(text, encoding="utf-8")
                _write_docx(path.with_suffix(".docx"), text.splitlines())
                report = assess_descriptive_synthesis(path, "SRS", evidence)
                self.assertEqual(any(gap["reason"] == "cross-section operating dependency missing or changed"
                                     for gap in report["gaps"]), changed)

    def test_digital_overview_projects_objective_not_parallel_measurement_descriptions(self):
        from workflow_routing import drs_overview_plan, shared_document_descriptive_contributions
        uses = self.uses("NOVA is a measurement device. "
            "The optical channel (LUMA) is designed as an optical transceiver, stimulating up to five emitters "
            "and measuring the return signal on up to three inputs. "
            "The NOVA features an advanced digital engine, composed of multiple IPs able to reduce "
            "external host processing workload, reducing bus congestion, providing meta-data useful "
            "for final application, both in time and frequency domain.", document="DRS")
        text, audit = drs_overview_plan(self.evidence(uses))
        actual = " ".join(text)
        self.assertIn("host processing workload", actual)
        self.assertIn("frequency", actual)
        self.assertNotIn("optical transceiver", actual)
        self.assertTrue(any(row["disposition"] == "retained_source_context_or_detail" for row in audit))

    def test_missing_digital_objective_retains_supported_context_with_explicit_gap(self):
        from workflow_routing import drs_overview_plan, shared_document_descriptive_contributions
        for identity in ("", "NOVA is a measurement device. "):
            with self.subTest(identity=bool(identity)):
                uses = self.uses(identity + "The system supports measurement. The system supports data exchange.",
                                 document="DRS")
                paragraphs, audit = drs_overview_plan(self.evidence(uses))
                self.assertEqual(paragraphs, shared_document_descriptive_contributions(
                    uses, document="DRS")["3"])
                self.assertTrue(any(row["disposition"] == "unresolved"
                                    and "objective not established" in row["reason"] for row in audit))

    def test_digital_objective_requires_prose_in_approved_section_in_both_formats(self):
        from workflow_routing import (
            _shared_descriptive_audit, drs_overview_plan, validate_shared_descriptive_artifacts,
        )
        uses = self.uses(
            "NOVA is a measurement device. "
            "The NOVA features an advanced digital engine, composed of multiple IPs able to reduce "
            "external host processing workload, reducing bus congestion, providing meta-data useful "
            "for final application, both in time and frequency domain.", document="DRS")
        paragraphs, _ = drs_overview_plan(self.evidence(uses))
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            markdown = root / "document.md"
            (root / "governed_shared_context_audit.json").write_text(json.dumps(
                _shared_descriptive_audit(uses, document="DRS", snapshot_id="snapshot")), encoding="utf-8")
            for placement in ("prose", "wrong_section", "table"):
                with self.subTest(placement=placement):
                    lines = ["## 3 System Overview"]
                    if placement == "wrong_section":
                        lines.extend(["Other context.", "### 3.1 Digital organization"])
                    lines.extend(paragraphs if placement != "table" else [
                        "Other context.", "| Context |", "| --- |", "| " + " ".join(paragraphs) + " |"])
                    markdown.write_text("\n\n".join(lines), encoding="utf-8")
                    _write_docx(markdown.with_suffix(".docx"), lines)
                    with patch("validate_downstream_coherence.resolve_downstream_contract") as resolve:
                        resolve.return_value.shared_descriptive_context.return_value = uses
                        findings = validate_shared_descriptive_artifacts(
                            root, markdown, document="DRS", snapshot_id="snapshot")
                    missing = [value for value in findings
                               if value.startswith("shared_descriptive_excerpt_missing_or_changed:")]
                    self.assertEqual(len(missing), 0 if placement == "prose" else 2)

    def test_actual_system_prose_checks_reject_cosmetic_abstraction_and_preserve_outcomes(self):
        evidence = self.evidence()
        texts, _ = compose_document_responsibilities(evidence, document="SRS")
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "review.md"
            for text, expected_issue in (
                ("The acquisition responsibility comprises current conversion across the device.",
                 "integration or implementation prose is not a device capability"),
                ("The device supports collection.", "supported functional responsibility not recovered"),
                (" ".join(texts), None),
            ):
                paragraphs = ["### 3.2 Main System Capabilities", text]
                organization = compose_srs_system_overview([], evidence=evidence)[SRS_SYSTEM_OVERVIEW_HEADINGS[2]]
                paragraphs.extend(["### 3.3 Architecture", *organization])
                path.write_text("\n\n".join(paragraphs), encoding="utf-8")
                _write_docx(path.with_suffix(".docx"), paragraphs)
                with patch("workflow_routing.compose_document_responsibilities", side_effect=AssertionError("producer")):
                    report = assess_descriptive_synthesis(path, "SRS", evidence)
                if expected_issue:
                    self.assertTrue(any(gap["reason"] == expected_issue for gap in report["gaps"]))
                else:
                    self.assertFalse(any(gap["readiness_impact"] == "functional_coverage" for gap in report["gaps"]))
    def test_independent_assessor_rejects_lists_as_block_purpose_paragraphs(self):
        evidence = self.evidence()
        evidence.pop("requirements")
        evidence["functions"] = evidence["inventory"]
        paragraphs = [
            "# 3. Top Level Overview", "# 3.1 Digital Main Functions",
            "- Cedar: conversion of input currents to samples.",
            "- Maple: conversion of input currents to samples.",
        ]
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "review.md"
            path.write_text("\n\n".join(paragraphs), encoding="utf-8")
            _write_docx(path.with_suffix(".docx"), paragraphs)
            with patch("workflow_routing.compose_document_responsibilities",
                       side_effect=AssertionError("producer must not be called")):
                report = assess_descriptive_synthesis(path, "DRS", evidence)
            self.assertTrue(any("concrete block purpose paragraph" in gap["reason"]
                                for gap in report["gaps"]), report["gaps"])
            self.assertEqual(report["readability"]["status"], "NOT_ASSESSED")

    def test_block_purpose_readback_rejects_owner_object_and_label_mutations(self):
        evidence = self.evidence()
        evidence.pop("requirements")
        evidence["functions"] = evidence["inventory"]
        paragraphs = ["# 3. Top Level Overview", "# 3.1 Digital Main Functions",
                      "Cedar converts input currents to samples.",
                      "Maple converts input currents to samples."]
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "review.md"
            for changed in (paragraphs, [p.replace("Cedar converts", "Cedar: conversion of") for p in paragraphs],
                            [p.replace("Cedar converts", "Boundary Link converts") for p in paragraphs],
                            [p.replace("currents", "voltages") for p in paragraphs]):
                path.write_text("\n\n".join(changed), encoding="utf-8")
                _write_docx(path.with_suffix(".docx"), changed)
                with patch("workflow_routing.compose_document_responsibilities",
                           side_effect=AssertionError("producer")):
                    report = assess_descriptive_synthesis(path, "DRS", evidence)
                purpose_gaps = [gap for gap in report["gaps"]
                                if "concrete block purpose paragraph" in gap["reason"]]
                self.assertEqual(bool(purpose_gaps), changed != paragraphs)

    def test_qualified_identity_is_not_simplified_to_unconditional_purpose(self):
        for statement in (
            "AURORA9 is a recorder only when enabled.",
            "AURORA9 is a recorder without external power.",
            "The system comprises the Sensing domain unless bypassed.",
        ):
            with self.subTest(statement=statement):
                model = shared_descriptive_evidence_model(self.uses(statement), document="SRS")
                self.assertTrue(model.unresolved_contexts)
                self.assertFalse(any(functional_meaning_role(p.meaning) == "purpose"
                                     for p in model.propositions))

    def test_dependent_restriction_cannot_be_detached_from_new_overview_meaning(self):
        for document in ("SRS", "DRS", "IPOS"):
            for restriction in ("Only when enabled.", "Unless the safety interlock is active.",
                                "This function is available only with external power."):
                with self.subTest(document=document, restriction=restriction):
                    uses = self.uses("AURORA9 is a recorder. " + restriction, document=document)
                    model = shared_descriptive_evidence_model(
                        uses, document=document, owner="Compute Unit" if document == "IPOS" else "")
                    self.assertFalse(model.propositions)
                    self.assertTrue(model.unresolved_contexts)
                    self.assertEqual(model.unresolved_contexts[0].spans[0].text, uses[0]["statement"])

    def test_unestablished_concrete_digital_ownership_is_an_explicit_finding(self):
        evidence = self.evidence()
        evidence.pop("requirements")
        evidence["functions"] = evidence["inventory"]
        evidence["inventory"][0].update(scope="approved_function_boundary", domains=[])
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "review.md"
            paragraphs = ["# 3. Top Level Overview", "# 3.1 Digital Main Functions",
                          "Maple converts input currents to samples."]
            path.write_text("\n\n".join(paragraphs), encoding="utf-8")
            _write_docx(path.with_suffix(".docx"), paragraphs)
            report = assess_descriptive_synthesis(path, "DRS", evidence)
            self.assertTrue(any("ownership is not established" in gap["reason"]
                                and gap["source"] == evidence["inventory"][0]["source"]
                                for gap in report["gaps"]))

    def test_table_preservation_restores_missing_owner_but_rejects_changed_content(self):
        from spec_document_contract import (
            drs_markdown_events, drs_table_inventory, preserve_drs_overview_tables,
        )
        original = ["## 3. Top Level Overview", "### 3.1 Digital Main Functions",
                    "#### Exchange", "| Source | Destination |", "|---|---|", "| Cedar | Maple |", "",
                    "#### Supply", "| Domain | Function |", "|---|---|", "| Core | Retain samples |", "",
                    "#### Standby", "| Owner | Function |", "|---|---|", "| Maple | Wake |", ""]
        baseline = drs_table_inventory(drs_markdown_events("\n".join(original)))
        missing = original[:7] + original[12:]
        restored = preserve_drs_overview_tables(missing, baseline)
        self.assertEqual(drs_table_inventory(drs_markdown_events("\n".join(restored))), baseline)
        self.assertEqual(preserve_drs_overview_tables(restored, baseline), restored)
        changed = [line.replace("Cedar | Maple", "Cedar | Foreign") for line in missing]
        with self.assertRaisesRegex(ValueError, "differs"):
            preserve_drs_overview_tables(changed, baseline)

    def test_entity_kind_keeps_legacy_nonmapping_metadata_behavior(self):
        from validate_downstream_coherence import approved_entity_kind
        for metadata in (None, "", [], {}):
            self.assertEqual(approved_entity_kind("Cedar", {"Cedar": metadata}), "concrete_block")
        self.assertEqual(approved_entity_kind("Cedar", {"Cedar": {"entity_kind": "interface"}}), "interface")
        self.assertEqual(approved_entity_kind("Unassigned", {}), "unassigned")

    def processing_evidence(self):
        evidence = self.evidence()
        evidence["requirements"] = []
        evidence["function_decomposition"] = []
        evidence["inventory"] = [
            {**evidence["inventory"][0], "owner": name, "statement": statement,
             "source": "approved architecture:" + name}
            for name, statement in (
                ("Timing Unit", "Generate control signals, perform DSP elaboration on converter outputs, "
                                "and write elaborated results to defined addresses."),
                ("Compute Engine", "Process measurement samples."),
                ("Reducer", "Perform sample averaging."),
                ("Spectral Unit", "Perform frequency-domain signal processing."),
                ("Link Endpoint", "Route processing data."),
            )
        ]
        evidence["interactions"] = [
            {"From block": "Link Endpoint", "To block": "Compute Engine",
             "Signal/control": "XBAR connection"},
        ]
        return evidence

    def test_processing_contributors_follow_activities_not_names_or_connectivity(self):
        from workflow_routing import document_processing_claims, realize_descriptive_functional_claim
        evidence = self.processing_evidence()
        for inventory in (evidence["inventory"], list(reversed(evidence["inventory"]))):
            with self.subTest(order=[row["owner"] for row in inventory]):
                evidence["inventory"] = inventory
                claims = document_processing_claims(evidence)
                actors = {meaning.subject for claim in claims for meaning in claim.meanings}
                self.assertEqual(actors, {"Timing Unit", "Compute Engine", "Reducer", "Spectral Unit"})
                prose = " ".join(realize_descriptive_functional_claim(claim) for claim in claims)
                self.assertIn("Timing Unit performs DSP elaboration on converter outputs", prose)
                self.assertNotIn("Generate control", prose)
                self.assertNotIn("defined addresses", prose)
                self.assertNotIn("Link Endpoint", prose)

    def test_processing_contribution_does_not_turn_analog_or_interface_into_digital_dsp(self):
        from workflow_routing import document_processing_claims
        evidence = self.processing_evidence()
        evidence["inventory"][0]["domains"] = ["analog"]
        evidence["inventory"][1]["entity_kind"] = "interface"
        actors = {meaning.subject for claim in document_processing_claims(evidence) for meaning in claim.meanings}
        self.assertEqual(actors, {"Reducer", "Spectral Unit"})

    def test_processing_classification_distinguishes_elaboration_from_data_transfer(self):
        from workflow_routing import DescriptiveMeaning, descriptive_processing_meaning
        for action, obj, expected in (
            ("process", "data", True), ("filter", "digital signals", True),
            ("elaborate", "custom DSP functions", True),
            ("perform", "data transfer", False), ("route", "processing data", False),
        ):
            with self.subTest(action=action, obj=obj):
                self.assertEqual(descriptive_processing_meaning(
                    DescriptiveMeaning("behavior", "Arbitrary Unit", action, (obj,))), expected)

    def test_processing_theme_acceptance_does_not_use_producer_selection(self):
        from workflow_routing import document_processing_claims, realize_descriptive_functional_claim
        evidence = self.processing_evidence()
        purposes = [
            row["owner"] + " " + row["statement"].split(", ")[0].lower() + "."
            for row in evidence["inventory"]
        ]
        claims = document_processing_claims(evidence)
        contributions = [realize_descriptive_functional_claim(claim) for claim in claims]
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "review.md"

            def assess(texts):
                parts = ["## 3. Top Level Overview", "The digital system processes measurements.",
                         "### 3.1 Digital Main Functions", *purposes,
                         "#### Digital processing blocks", *texts]
                path.write_text("\n\n".join(parts), encoding="utf-8")
                _write_docx(path.with_suffix(".docx"), parts)
                with patch("workflow_routing.document_processing_claims", side_effect=AssertionError("producer")):
                    return assess_descriptive_synthesis(path, "DRS", evidence)

            clean = assess(contributions)
            self.assertFalse([gap for gap in clean["gaps"] if gap["readiness_impact"] == "processing_coverage"])
            for omitted in contributions:
                report = assess([text for text in contributions if text != omitted])
                self.assertTrue(any(gap["readiness_impact"] == "processing_coverage"
                                    for gap in report["gaps"]))

    def test_processing_requirement_allocation_does_not_replace_the_actual_actor(self):
        from workflow_routing import document_processing_claims
        evidence = self.processing_evidence()
        evidence["requirements"] = [{
            "source_req_id": "req-private", "canonical_id": "canonical-private",
            "requirement_statement": "The private accelerator shall perform sample averaging.",
            "source": "approved snapshot", "applicable": True,
            "allocation": {"approved_block": "Timing Unit", "owning_target": "Digital IPOS"},
        }]
        claims = document_processing_claims(evidence)
        self.assertFalse(any("private accelerator" in meaning.subject
                             for claim in claims for meaning in claim.meanings))

    def test_processing_contribution_preserves_an_explicit_requirement_condition(self):
        from workflow_routing import document_processing_claims, realize_descriptive_functional_claim
        evidence = self.processing_evidence()
        evidence["inventory"][0]["statement"] = "Generate control signals."
        evidence["requirements"] = [{
            "source_req_id": "req-guarded", "canonical_id": "canonical-guarded",
            "requirement_statement": "When enabled, Timing Unit shall process measurement samples.",
            "source": "approved snapshot", "applicable": True,
            "allocation": {"approved_block": "Timing Unit", "owning_target": "Digital IPOS"},
        }]
        claims = document_processing_claims(evidence)
        guarded = [claim for claim in claims if any(meaning.subject == "Timing Unit" for meaning in claim.meanings)]
        self.assertEqual(len(guarded), 1)
        self.assertIn("When enabled", realize_descriptive_functional_claim(guarded[0]))
        self.assertTrue(guarded[0].spans)

    def test_structure_membership_does_not_require_a_normative_allocation(self):
        from workflow_routing import structural_owner_rows
        evidence = self.evidence(self.uses(
            "The main blocks in digital domain are: Cedar, Maple and Aspen 32-bit processor."))
        evidence["inventory"].extend([
            {**evidence["inventory"][0], "owner": "Aspen", "applicable": False,
             "scope": "approved_function_boundary", "domains": [], "statement": "Process samples."},
            {**evidence["inventory"][0], "owner": "Endpoint", "entity_kind": "interface"},
        ])
        self.assertEqual({row["owner"] for row in structural_owner_rows(evidence, domain="digital")},
                         {"Cedar", "Maple", "Aspen"})

    def test_reviewed_functional_role_does_not_mutate_the_frozen_inventory(self):
        from descriptive_review_proposals import with_descriptive_scope_review
        from workflow_routing import structural_owner_rows
        evidence = {**self.evidence(), "document": "SRS"}
        original = copy.deepcopy(evidence)
        reviewed = with_descriptive_scope_review(evidence, functional_roles=["Cedar"],
                                                 rationale="Retain descriptive role, not a real block.")
        self.assertEqual(evidence, original)
        self.assertEqual(reviewed["inventory"], original["inventory"])
        self.assertFalse(reviewed["descriptive_scope_review"]["authority"])
        self.assertEqual([row["owner"] for row in structural_owner_rows(reviewed, domain="digital")], ["Maple"])
        reviewed["descriptive_scope_review"]["snapshot_id"] = "another-snapshot"
        with self.assertRaisesRegex(ValueError, "does not match"):
            structural_owner_rows(reviewed, domain="digital")

    def test_parallel_channel_capabilities_retain_actors_limits_and_definition_scope(self):
        statement = (
            "The optical channel (LUMA) is designed as an optical transceiver, stimulating up to five emitters "
            "and measuring the return signal on up to three separate inputs. "
            "The signal chain rejects offsets from ambient light, eliminating the need for external cancellation. "
            "The VOLT signal acquisition is designed to support low noise measurement in the presence of interferers. "
            "The VOLT signal chain has several complementary features supporting VOLT measurement, "
            "such as driven reference and lead off detection. "
            "The IMP signal chain is designed for impedance measurements with a configurable excitation path. "
            "IMP channel delivers both the real and the imaginary parts of the impedance. "
            "Finally, the last Activity (ACT), also called Response (RSP) refers to changes in conductance."
        )
        for document in ("SRS", "DRS"):
            with self.subTest(document=document):
                model = shared_descriptive_evidence_model(self.uses(statement, document), document=document)
                self.assertFalse(model.unresolved_contexts)
                subjects = {value.meaning.subject for value in model.propositions}
                self.assertIn("IMP channel", subjects)
                self.assertNotIn("The system", subjects)
                self.assertTrue(any("Activity (ACT)" in subject for subject in subjects))
                optical = [p for p in model.propositions if p.meaning.subject == "The optical channel (LUMA)"]
                self.assertEqual(len(optical), 2)
                self.assertEqual(len(optical[1].spans), 2)
                self.assertIn("up to five emitters", optical[0].meaning.qualifiers[0])
                self.assertIn("up to three separate inputs", optical[0].meaning.qualifiers[0])

    def test_proposed_capability_headings_do_not_inherit_the_previous_function_topic(self):
        uses = self.uses(
            "The optical channel (LUMA) is designed as an optical transceiver, stimulating up to five emitters "
            "and measuring the return signal on up to three separate inputs. "
            "The VOLT signal acquisition is designed to support low noise measurement.")
        evidence = self.evidence(uses)
        sections = {}
        compose_srs_system_overview(uses, evidence=evidence, review_sections=sections)
        capabilities = sections["3.2 Main System Capabilities"]
        self.assertIn("#### **LUMA**", capabilities)
        self.assertIn("#### **VOLT**", capabilities)
        luma = capabilities.index("#### **LUMA**")
        volt = capabilities.index("#### **VOLT**")
        self.assertTrue(any("optical transceiver" in text for text in capabilities[luma:volt]))
        self.assertTrue(any("low noise measurement" in text for text in capabilities[volt:]))

    def test_processing_theme_projects_firmware_elaboration_without_repeating_boot_purpose(self):
        from workflow_routing import document_processing_claims, realize_descriptive_functional_claim
        evidence = self.processing_evidence()
        evidence["inventory"][0]["statement"] = "Execute embedded firmware for memory boot and signal elaboration."
        claim = next(value for value in document_processing_claims(evidence)
                     if value.meanings[0].subject == "Timing Unit")
        text = realize_descriptive_functional_claim(claim)
        self.assertIn("embedded firmware for signal elaboration", text)
        self.assertNotIn("memory boot", text)
        self.assertIn("memory boot", claim.spans[0].text)

    def test_unsupported_inventory_purpose_exposes_a_qualified_role_as_a_separate_proposal(self):
        from workflow_routing import document_block_role_proposals
        evidence = {**self.evidence(), "document": "DRS"}
        evidence["inventory"].append({
            **evidence["inventory"][0], "owner": "Aspen", "domains": [],
            "profile_classification": "Digital", "scope": "approved_function_boundary",
            "statement": "Connection Matrix Destination Source", "applicable": False,
        })
        evidence["shared_records"] = responsibility_tests.ResponsibilitySynthesisTests().projected(
            "In this mode it is possible to turn on Aspen to work with raw samples and/or processed metadata.",
            "DRS", "Normal Mode")
        proposals = document_block_role_proposals(evidence)
        self.assertEqual(len(proposals), 1)
        self.assertEqual(proposals[0]["owner"], "Aspen")
        self.assertEqual(proposals[0]["section"], "3.1")
        self.assertFalse(proposals[0]["authority"])
        self.assertIn("In Normal Mode", proposals[0]["proposed_text"])
        self.assertIn("or both", proposals[0]["proposed_text"])

    def test_active_processing_theme_does_not_depend_on_selected_connection_records(self):
        import run_drs_gen_spec_agent as generator
        from spec_document_contract import DRS_TEMPLATE, drs_document_events, load_drs_contract
        evidence = self.processing_evidence()
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "review.md"
            generator._write_drs_markdown(
                path, "approved source", "AURORA9", "Review", "approved-synthetic", "review",
                [], {}, [], {}, [], {}, [], {}, [], [], [], "PASS", [], {}, set(), {}, [], [],
                load_drs_contract(Path(__file__).resolve().parents[1] / DRS_TEMPLATE),
                review_overview_only=True, responsibility_evidence=evidence)
            events = drs_document_events(path)
            start = next(index for index, event in enumerate(events)
                         if event["kind"] == "heading" and event["text"] == "Digital processing blocks")
            stop = next((index for index in range(start + 1, len(events))
                         if events[index]["kind"] == "heading" and events[index]["level"] <= 4), len(events))
            processing = " ".join(event["text"] for event in events[start + 1:stop]
                                  if event["kind"] == "paragraph")
            for name in ("Timing Unit", "Compute Engine", "Reducer", "Spectral Unit"):
                self.assertIn(name, processing)
            self.assertNotIn("Link Endpoint", processing)

    def resource_evidence(self):
        evidence = {**self.processing_evidence(), "document": "DRS"}
        evidence["inventory"].extend([
            {**evidence["inventory"][0], "owner": "Ledger", "statement": "Implement configuration registers."},
            {**evidence["inventory"][0], "owner": "Queue", "statement": "Provide stream storage and memory access."},
        ])
        evidence["interactions"] = [
            {"From block": user, "To block": resource, "Signal/control": "XBAR connection"}
            for user in ("Timing Unit", "Compute Engine") for resource in ("Ledger", "stream")
        ]
        return evidence

    def test_shared_resources_identify_users_and_do_not_invent_an_arbitration_policy(self):
        from workflow_routing import shared_resource_relations, shared_arbitration_policies
        evidence = self.resource_evidence()
        resources = shared_resource_relations(evidence)
        self.assertEqual({row["owner"] for row in resources}, {"Ledger", "Queue"})
        self.assertTrue(all(set(row["users"]) == {"Timing Unit", "Compute Engine"} for row in resources))
        self.assertFalse(shared_arbitration_policies(evidence))
        evidence["shared_records"] = self.uses(
            "Ledger uses a round-robin arbitration policy. Queue uses a fixed-priority arbitration policy.",
            document="DRS")
        self.assertEqual({value.subject for value in shared_arbitration_policies(evidence)}, {"Ledger", "Queue"})

    def test_drs_overview_complement_is_mapping_bound_and_does_not_change_block_purposes(self):
        from workflow_routing import drs_overview_plan, shared_document_descriptive_contributions
        evidence = self.resource_evidence()
        evidence["shared_records"] = self.uses(
            "AURORA9 is a measurement device.", document="DRS")
        evidence["function_decomposition"] = [
            {"top_function": "Measurement coordination", "subfunctions": "capture scheduling",
             "blocks_involved": "Timing Unit"},
            {"top_function": "Result delivery", "subfunctions": "host readback", "blocks_involved": "Queue"},
            {"top_function": "Unscoped private behavior", "subfunctions": "internal activity",
             "blocks_involved": "Unknown owner"},
        ]
        before = compose_document_responsibilities(evidence, document="DRS")
        overview = shared_document_descriptive_contributions(evidence["shared_records"], document="DRS").get("3", [])
        paragraphs, audit = drs_overview_plan(evidence)
        self.assertEqual(paragraphs[:-1], overview)
        self.assertEqual(len(paragraphs), len(overview) + 1)
        self.assertIn("measurement coordination and result delivery", paragraphs[-1])
        self.assertNotIn("Unscoped", paragraphs[-1])
        self.assertFalse(any(owner in paragraphs[-1] for owner in ("Timing Unit", "Queue")))
        self.assertNotIn("capture scheduling", paragraphs[-1])
        self.assertEqual(before, compose_document_responsibilities(evidence, document="DRS"))
        mapped = [row for row in audit if row.get("reason", "").startswith("complementary_domain")]
        self.assertEqual(mapped[0]["source_record_ids"], ["architecture-function:1", "architecture-function:2"])
        self.assertFalse(mapped[0]["normative_covers_created"])
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "overview.md"
            source = ";".join(mapped[0]["source_record_ids"])
            for text, recovered in ((paragraphs[-1], True),
                                    (paragraphs[-1].replace("measurement coordination and ", ""), False),
                                    (paragraphs[-1].replace("combines", "ignores"), False)):
                parts = ["## 3. Top Level Overview", text, "### 3.1 Digital Main Functions", *before[0]]
                path.write_text("\n\n".join(parts), encoding="utf-8")
                _write_docx(path.with_suffix(".docx"), parts)
                with patch("workflow_routing.drs_overview_plan", side_effect=AssertionError("producer")):
                    assessment = assess_descriptive_synthesis(path, "DRS", evidence)
                self.assertEqual(not any(gap["source"] == source for gap in assessment["gaps"]), recovered)
        evidence["function_decomposition"] = []
        self.assertEqual(drs_overview_plan(evidence)[0], overview)

    def test_drs_identity_grammar_preserves_supported_meaning_fields(self):
        from workflow_routing import DescriptiveMeaning, drs_overview_presentation_meaning
        meaning = DescriptiveMeaning("responsibility", "The device", "be",
            ("a measurement device with embedded process capabilities",),
            qualifiers=("in capture mode",), modality="may")
        corrected = drs_overview_presentation_meaning(meaning)
        self.assertEqual(corrected.objects, ("a measurement device with embedded processing capabilities",))
        self.assertEqual(replace(corrected, objects=meaning.objects), meaning)
        self.assertEqual(drs_overview_presentation_meaning(corrected), corrected)

    def test_policy_clarification_is_visible_only_in_explicit_drs_technical_review(self):
        from workflow_routing import ARBITRATION_POLICY_GAP
        from spec_document_contract import apply_clean_document_presentation, validate_clean_document_presentation
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "review.md"
            lines = ["Snapshot ID: approved-synthetic", "### 3.1 Digital Main Functions",
                     "#### Arbitration, control, and shared resources", ARBITRATION_POLICY_GAP]
            for enabled in (False, True):
                retained = apply_clean_document_presentation(lines, path, "DRS", technical_policy_review=enabled)
                self.assertEqual(ARBITRATION_POLICY_GAP in retained, enabled)
                path.write_text("\n\n".join(retained), encoding="utf-8")
                _write_docx(path.with_suffix(".docx"), retained)
                self.assertEqual(validate_clean_document_presentation(path), [])
            changed = lines + ["Other behavior: need clarification."]
            retained = apply_clean_document_presentation(changed, path, "DRS", technical_policy_review=True)
            self.assertNotIn(changed[-1], retained)

    def test_publication_audit_keeps_integer_source_lines_for_all_document_types(self):
        from spec_document_contract import apply_clean_document_presentation
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "review.md"
            for document in ("SRS", "DRS", "ARS"):
                with self.subTest(document=document):
                    apply_clean_document_presentation(
                        ["Snapshot ID: approved-synthetic", "### 3.5 Limits and TBD"], path, document)
                    audit = json.loads(path.with_name("descriptive_publication_audit.json").read_text(encoding="utf-8"))
                    self.assertEqual(audit["omissions"][0]["input_line"], 2)

    def test_common_bus_policy_note_is_audited_only_in_drs_section_42(self):
        from workflow_routing import COMMON_BUS_ARBITRATION_POLICY_GAP
        from spec_document_contract import apply_clean_document_presentation, validate_clean_document_presentation
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "policy.md"
            for document, section in (("DRS", "4.2"), ("DRS", "3.1"), ("SRS", "4.2"), ("ARS", "4.2")):
                with self.subTest(document=document, section=section):
                    lines = ["Snapshot ID: synthetic", "### " + section + " Resources",
                             COMMON_BUS_ARBITRATION_POLICY_GAP, "Other behavior to be clarified"]
                    retained = apply_clean_document_presentation(lines, path, document)
                    self.assertEqual(COMMON_BUS_ARBITRATION_POLICY_GAP in retained,
                                     document == "DRS" and section == "4.2")
                    self.assertNotIn(lines[-1], retained)
                    path.write_text("\n\n".join(retained), encoding="utf-8")
                    _write_docx(path.with_suffix(".docx"), retained)
                    self.assertEqual(validate_clean_document_presentation(path), [])
            lines = ["Snapshot ID: synthetic", "### 4.2 Resources", COMMON_BUS_ARBITRATION_POLICY_GAP]
            retained = apply_clean_document_presentation(lines, path, "DRS")
            path.write_text("\n\n".join(retained), encoding="utf-8")
            _write_docx(path.with_suffix(".docx"), retained)
            audit = json.loads(path.with_name("descriptive_publication_audit.json").read_text(encoding="utf-8"))
            self.assertEqual(audit["technical_policy_gaps"][0]["section"], "4.2")
            path.write_text("\n\n".join(retained).replace("4.2 Resources", "4.3 Resources"), encoding="utf-8")
            self.assertIn("publication_inline_marker:policy.md", validate_clean_document_presentation(path))

    def test_full_drs_42_arbitration_note_is_conditional_on_approved_policy_evidence(self):
        import run_drs_gen_spec_agent as generator
        from spec_document_contract import DRS_TEMPLATE, descriptive_section_paragraphs, load_drs_contract
        from workflow_routing import COMMON_BUS_ARBITRATION_POLICY_GAP
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "review.md"
            for policy, missing in (
                ("", True),
                ("Ledger uses a round-robin arbitration policy.", True),
                ("Ledger uses a round-robin arbitration policy. Queue uses a fixed-priority arbitration policy.", False),
            ):
                with self.subTest(policy=policy):
                    evidence = self.resource_evidence()
                    evidence["shared_records"] = self.uses(policy, document="DRS") if policy else []
                    generator._write_drs_markdown(
                        path, "approved source", "AURORA9", "Review", "approved-synthetic", "review",
                        [], {}, [], {}, [], {}, [], {}, [], [], [], "PASS", [], {}, set(), {}, [], [],
                        load_drs_contract(Path(__file__).resolve().parents[1] / DRS_TEMPLATE),
                        responsibility_evidence=evidence)
                    paragraphs = descriptive_section_paragraphs(path, {"sections": {"4.2": {}}})["4.2"]
                    self.assertEqual(COMMON_BUS_ARBITRATION_POLICY_GAP in paragraphs, missing)
                    if not missing:
                        self.assertTrue(any("Ledger uses a round-robin arbitration policy" in text for text in paragraphs))
                        self.assertTrue(any("Queue uses a fixed-priority arbitration policy" in text for text in paragraphs))

    def test_active_resource_theme_keeps_the_policy_gap_after_publication_cleanup(self):
        import run_drs_gen_spec_agent as generator
        from spec_document_contract import DRS_TEMPLATE, load_drs_contract
        from workflow_routing import ARBITRATION_POLICY_GAP
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "review.md"
            generator._write_drs_markdown(
                path, "approved source", "AURORA9", "Review", "approved-synthetic", "review",
                [], {}, [], {}, [], {}, [], {}, [], [], [], "PASS", [], {}, set(), {}, [], [],
                load_drs_contract(Path(__file__).resolve().parents[1] / DRS_TEMPLATE),
                review_overview_only=True, responsibility_evidence=self.resource_evidence())
            text = path.read_text(encoding="utf-8")
            self.assertIn("Ledger is a shared register resource", text)
            self.assertIn("Queue is a shared memory and storage resource", text)
            self.assertIn("Timing Unit and Compute Engine", text)
            self.assertIn(ARBITRATION_POLICY_GAP, text)

    def test_independent_resource_review_detects_removed_user_or_policy_clarification(self):
        from workflow_routing import ARBITRATION_POLICY_GAP, COMMON_BUS_ARBITRATION_POLICY_GAP, shared_resource_relations
        evidence = self.resource_evidence()
        texts = [
            row["owner"] + " is a shared " + " and ".join(row["kinds"])
            + " resource with documented integration paths connecting " + " and ".join(row["users"]) + "."
            for row in shared_resource_relations(evidence)
        ]
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "review.md"

            def assess(values, policy_section=""):
                parts = ["## 3. Top Level Overview", "The digital system processes measurements.",
                         "### 3.1 Digital Main Functions",
                         "#### Arbitration, control, and shared resources", *values]
                if policy_section:
                    parts.extend(["### " + policy_section + " Resources", COMMON_BUS_ARBITRATION_POLICY_GAP])
                path.write_text("\n\n".join(parts), encoding="utf-8")
                _write_docx(path.with_suffix(".docx"), parts)
                with patch("workflow_routing.shared_resource_meaning", side_effect=AssertionError("producer")):
                    return assess_descriptive_synthesis(path, "DRS", evidence)

            clean = assess([*texts, ARBITRATION_POLICY_GAP])
            self.assertFalse(any(gap["readiness_impact"] == "policy_coverage" for gap in clean["gaps"]))
            deleted_policy = assess(texts)
            self.assertTrue(any(gap["readiness_impact"] == "policy_coverage" for gap in deleted_policy["gaps"]))
            visible_in_42 = assess(texts, policy_section="4.2")
            self.assertFalse(any(gap["readiness_impact"] == "policy_coverage" for gap in visible_in_42["gaps"]))
            self.assertTrue(any(gap["readiness_impact"] == "source_policy_clarification" for gap in visible_in_42["gaps"]))
            misplaced = assess(texts, policy_section="4.3")
            self.assertTrue(any(gap["readiness_impact"] == "policy_coverage" for gap in misplaced["gaps"]))
            deleted_user = assess([text.replace(" and Compute Engine", "") for text in texts] + [ARBITRATION_POLICY_GAP])
            self.assertTrue(any(gap["source"].startswith("shared-resource:")
                                and gap["obligation"] in {"semantic_fidelity", "essential_qualifications"}
                                for gap in deleted_user["gaps"]))

    def test_shared_domain_containment_is_not_a_block_boundary_or_local_function(self):
        from workflow_routing import build_ipos_claim_plan, build_ipos_functional_input, compose_ipos_overview
        uses = self.uses("The digital domain comprises Cedar and Maple.", document="IPOS")
        functional = build_ipos_functional_input(
            "Compute Unit", {"Function": "Process samples.", "Inputs": "samples", "Outputs": "results"},
            domain="digital", shared_context_records=uses)
        plan = build_ipos_claim_plan(functional)
        self.assertFalse(any("unsupported_claim_role" in decision.findings for decision in plan.decisions))
        containment = [claim for claim in plan.claims
                       if any(meaning.relation == "containment" for meaning in claim.meanings)]
        self.assertTrue(containment)
        self.assertTrue(all(claim.role == "organization" for claim in containment))
        sections, _audit = compose_ipos_overview(functional)
        self.assertNotIn("Cedar", str(sections))
        self.assertNotIn("Maple", str(sections))

    def test_partial_information_gain_does_not_repeat_an_independent_meaning(self):
        from workflow_routing import (
            DescriptiveFunctionalClaim, DescriptiveMeaning, _ipos_functional_presentation,
            build_ipos_claim_plan, build_ipos_functional_input,
        )
        for domain in ("digital", "analog"):
            functional = build_ipos_functional_input("Cedar", {"Function": "Process samples."}, domain=domain)
            base = build_ipos_claim_plan(functional)
            first = DescriptiveMeaning("behavior", "Cedar", "process", ("samples",))
            second = DescriptiveMeaning("behavior", "Cedar", "store", ("results",))
            one = DescriptiveFunctionalClaim("first", "main_functions", ("one",), (first,), (), ())
            two = DescriptiveFunctionalClaim("second", "functions", ("two", "three"),
                                            (first, second), (), ())
            projected, _ = _ipos_functional_presentation(replace(base, claims=(one, two)), functional)
            self.assertEqual(projected["first"][0].meanings, (first,))
            self.assertEqual(projected["second"][0].meanings, (second,))
            self.assertEqual(projected["second"][0].proposition_ids, ("three",))

    def test_ars_shared_rendering_remains_compatible_without_a_new_contract(self):
        from workflow_routing import shared_document_descriptive_contributions
        from spec_document_contract import load_descriptive_synthesis_contract
        uses = self.uses("AURORA9 is an environmental measurement device.", document="ARS")
        model = shared_descriptive_evidence_model(uses, document="ARS")
        self.assertFalse(model.propositions)
        self.assertTrue(model.unresolved_contexts)
        self.assertFalse(any(shared_document_descriptive_contributions(uses, document="ARS").values()))
        with self.assertRaisesRegex(ValueError, "Unsupported descriptive document"):
            load_descriptive_synthesis_contract("ARS")

    def test_active_drs_writer_preserves_separate_theme_tables_and_their_owners(self):
        import run_drs_gen_spec_agent as generator
        from spec_document_contract import DRS_TEMPLATE, drs_document_events, drs_table_inventory, load_drs_contract
        rows = [
            {"From block": "Cedar", "To block": "Maple", "Signal/control": "AHB read/write bus"},
            {"From block": "Maple", "To block": "Cedar", "Signal/control": "processing result data"},
        ]
        records = generator._top_digital_coverage_records(rows, [], [])
        with tempfile.TemporaryDirectory() as directory:
            tables = []
            for label, evidence in (("before", None), ("after", self.evidence())):
                path = Path(directory) / (label + ".md")
                generator._write_drs_markdown(
                    path, "approved source", "AURORA9", "Review", "approved-synthetic", "review",
                    [], {}, [], {}, [], {}, [], {}, [], records, [], "PASS", [], {}, set(), {}, [], [],
                    load_drs_contract(Path(__file__).resolve().parents[1] / DRS_TEMPLATE),
                    review_overview_only=True, responsibility_evidence=evidence)
                tables.append(drs_table_inventory(drs_document_events(path)))
            self.assertTrue(tables[0])
            self.assertEqual(tables[0], tables[1])
            if shutil.which("pandoc") is not None:
                import run_srs_gen_spec_agent as srs
                root = Path(__file__).resolve().parents[1]
                srs._convert_markdown_to_docx(path, path.with_suffix(".docx"),
                                             root / "templates" / "MPT_IPOS_template.docx", root)
                events = drs_document_events(path.with_suffix(".docx"))
                self.assertTrue(any(event["kind"] == "heading" and event["text"] == "Cedar"
                                    for event in events))
                self.assertTrue(any(event["kind"] == "paragraph"
                                    and event["text"].startswith("Cedar converts input currents")
                                    and not event.get("is_list") for event in events))


if __name__ == "__main__":
    unittest.main()
