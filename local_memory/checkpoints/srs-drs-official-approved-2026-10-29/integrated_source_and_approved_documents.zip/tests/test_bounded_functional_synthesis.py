import hashlib
import json
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

from run_drs_gen_spec_agent import _drs_function_summary, drs_synthesis_rows
from spec_document_contract import _drs_integrity_metadata
from sysml_generation_service import resolve_sysml_descriptive_model
from validate_downstream_coherence import classify_descriptive_findings, document_writing_residuals
from workflow_routing import (
    bounded_functional_summary,
    build_ipos_claim_plan,
    build_ipos_functional_input,
    compose_ipos_overview,
    compose_srs_system_overview,
    compose_technical_block_purpose,
    descriptive_writing_quality,
    functional_summary_findings,
    ipos_claim_preflight_findings,
    ipos_derivative_residuals,
)


class BoundedFunctionalSynthesisTests(unittest.TestCase):
    def functional(self, name="Compute", function="Process samples, using mapped memory and reset handling."):
        return build_ipos_functional_input(
            name, {"Function": function, "Inputs": "samples", "Outputs": "results"},
            [{"source_req_id": "R1",
              "statement": f"During reset, {name} shall write {name} RAM with the value 0. "
                           f"Only the first 2Kbyte of {name} RAM shall be cleared, "
                           "from address 0x000 to address 0x7FF."}], domain="digital")

    def test_responsibilities_are_synthesized_and_mechanisms_are_accounted_for(self):
        source = "Acquire samples, process data, and write results, using mapped memory."
        projection = bounded_functional_summary(source)
        self.assertEqual(projection.responsibilities, ("Acquire samples", "process data", "write results"))
        self.assertEqual(projection.mechanisms, ("mapped memory",))
        self.assertEqual(compose_technical_block_purpose("Unit", source, synthesize=True), "")
        prose = compose_technical_block_purpose("Unit", source, synthesize=True, include_functions=True)
        self.assertNotIn("mapped memory", prose)
        self.assertEqual(functional_summary_findings(source, prose), [])
        altered = prose.replace("processes data and ", "")
        self.assertNotEqual(altered, prose)
        self.assertTrue(functional_summary_findings(source, altered))
        self.assertTrue(functional_summary_findings(source, prose + " It encrypts samples."))

    def test_mechanism_qualifiers_are_not_silently_removed(self):
        for source in ("Process samples, using memory only when ready.",
                       "Process samples, using memory to encrypt results.",
                       "An unclear collection of fragments",
                       "Process samples; coordinate unspecified behavior"):
            with self.subTest(source=source):
                self.assertTrue(bounded_functional_summary(source).gap)
                self.assertEqual(compose_technical_block_purpose("Unit", source, synthesize=True), "")

    def test_conditions_and_alternatives_remain_in_the_responsibility(self):
        source = "Acquire samples only when ready or enabled"
        prose = compose_technical_block_purpose("Unit", source, synthesize=True)
        self.assertEqual(functional_summary_findings(source, prose), [])
        self.assertTrue(functional_summary_findings(source, prose.replace("only when ready or enabled", "")))

    def test_drs_scoped_summary_does_not_append_uninterpreted_source_context(self):
        block = SimpleNamespace(name="Unit", function="Process samples, using mapped memory.")
        prose = _drs_function_summary(block, [], [{"statement": "Uninterpreted paragraph."}], synthesize=True)
        self.assertEqual(prose, "The Unit block processes samples.")
        self.assertNotIn("Uninterpreted", prose)

    def test_drs_writing_residuals_do_not_invalidate_existing_integrity_metadata(self):
        original = {"version": 1, "markdown_sha256": "bound", "rules": {"technical_prose": "PASS"}}
        unresolved = {**original, "rules": {"technical_prose": "UNRESOLVED"},
                      "writing_quality": {"status": "UNRESOLVED", "authority": False}}
        self.assertEqual(_drs_integrity_metadata(original), _drs_integrity_metadata(unresolved))
        self.assertEqual(unresolved["rules"]["technical_prose"], "UNRESOLVED")
        for mutation in ({**unresolved, "markdown_sha256": "changed"},
                         {**unresolved, "rules": {"technical_prose": "FAIL"}}):
            self.assertNotEqual(_drs_integrity_metadata(original), _drs_integrity_metadata(mutation))

    def test_drs_unparsed_stage1_description_remains_a_writing_gap(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            output = root / "artifacts/stage5_drs"
            output.mkdir(parents=True)
            (output / "digital_requirements_specification.md").write_text(
                "## 3. Top Level Overview\nThe Digital Top is the digital integration layer.\n"
                "### 3.1 Digital Main Functions\n", encoding="utf-8")
            (output / "descriptive_summary_audit.csv").write_text(
                "section,decision,source,statement\n"
                "DRS Stage 1 source descriptions,retained,source:unparsed,Uninterpreted paragraph.\n",
                encoding="utf-8")
            with patch("run_drs_gen_spec_agent._read_block_inventory", return_value=[]), \
                    patch("run_drs_gen_spec_agent._read_interface_rows", return_value=[]), \
                    patch("run_drs_gen_spec_agent._source_interface_tables_by_block", return_value={}):
                rows = drs_synthesis_rows(root)
            self.assertTrue(any(row["section"] == "3.1" and row["decision"] == "projection_gap"
                                and row["source"] == "source:unparsed" for row in rows))
            self.assertEqual(descriptive_writing_quality("DRS", rows)["status"], "UNRESOLVED")

    def test_ipos_restriction_is_linked_and_remains_with_its_action(self):
        functional = self.functional()
        plan = build_ipos_claim_plan(functional)
        self.assertTrue(any(edge.dependency_id.startswith("restriction:") for edge in plan.evidence.dependencies))
        sections, audit = compose_ipos_overview(functional)
        behavior = " ".join(sections["internal_functions"])
        self.assertIn("Only the first 2Kbyte of Compute RAM is cleared.", behavior)
        self.assertIn("RAM to 0", behavior)
        self.assertNotIn("0x", behavior)
        self.assertNotIn("mapped memory", " ".join(sections["functionality"]))
        self.assertEqual(classify_descriptive_findings(ipos_claim_preflight_findings(functional))["hard_findings"], [])
        self.assertEqual(descriptive_writing_quality("IPOS", audit)["status"], "UNRESOLVED")
        self.assertTrue(any("bounded initialization" in row.get("reason", "") for row in audit))

    def test_unsupported_purpose_is_a_visible_nonblocking_projection_gap(self):
        functional = self.functional(function="Unclear prose without a supported action")
        sections, audit = compose_ipos_overview(functional)
        self.assertEqual(sections["functionality"], [])
        self.assertTrue(any(row["decision"] == "projection_gap" for row in audit))
        writing = descriptive_writing_quality("IPOS", audit)
        self.assertEqual(writing["status"], "UNRESOLVED")
        self.assertFalse(writing["generation_blocking"])
        findings = classify_descriptive_findings(ipos_claim_preflight_findings(functional))
        self.assertEqual(findings["hard_findings"], [])
        self.assertTrue(findings["residuals"])
        self.assertTrue(any(row["kind"] == "projection_gap" for row in ipos_derivative_residuals(functional)))
        contract = SimpleNamespace(snapshot_id="snapshot-test",
                                   ipos_descriptive_input=lambda *args, **kwargs: functional)
        model = resolve_sysml_descriptive_model(Path("."), contract, block="Compute", domain="digital")
        self.assertTrue(model["residuals"])
        self.assertFalse(model["authority"])

    def test_project_names_and_quantities_do_not_select_a_production_exception(self):
        for name in ("Compute", "Signal Engine", "Processor"):
            functional = self.functional(name=name)
            sections, _audit = compose_ipos_overview(functional)
            self.assertIn("2Kbyte", " ".join(sections["internal_functions"]))
            self.assertEqual(classify_descriptive_findings(ipos_claim_preflight_findings(functional))["hard_findings"], [])

    def test_srs_does_not_copy_uninterpreted_boundary_or_mode_prose(self):
        audit = []
        sections = compose_srs_system_overview([
            {"statement": "The system boundary has a complicated unexplained operating arrangement.",
             "source": "source:1", "scope": "system"},
            {"statement": "Calibration Mode has a complicated unexplained operating arrangement.",
             "source": "source:2", "scope": "system"},
        ], mode_rows=[{"mode": "Calibration Mode", "evidence": "source"}], audit_rows=audit)
        prose = "\n".join(text for section, texts in sections.items()
                          if section.startswith(("3.4", "3.5")) for text in texts)
        self.assertNotIn("complicated unexplained", prose)
        self.assertEqual(descriptive_writing_quality("SRS", audit)["status"], "UNRESOLVED")

    def test_literal_context_cannot_satisfy_a_synthesis_obligation(self):
        report = descriptive_writing_quality("IPOS", [
            {"target_section": "1.2 Supported functions", "decision": "selected_context",
             "source_record_id": "approved-use", "reason": "approved literal context"}])
        self.assertEqual(report["status"], "UNRESOLVED")
        self.assertFalse(report["literal_exceptions"][0]["satisfies_synthesis"])

    def test_unsupported_omission_cannot_receive_writing_quality_pass(self):
        report = descriptive_writing_quality("IPOS", [
            {"target_section": "1.1 Purpose", "decision": "selected"},
            {"target_section": "1.2 Supported functions", "decision": "selected"},
            {"decision": "omitted", "source_record_id": "source-context:unparsed",
             "reason": "omitted_nonessential:unsupported compound descriptive construction; source retained"},
        ])
        self.assertEqual(report["status"], "UNRESOLVED")
        self.assertEqual(report["gaps"][0]["source"], "source-context:unparsed")
        self.assertFalse(report["generation_blocking"])

    def test_document_gaps_are_scoped_to_their_existing_readiness_target(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            output = root / "artifacts/stage3_srs"
            output.mkdir(parents=True)
            markdown = output / "system_requirements_specification.md"
            markdown.write_text("Scoped system proof", encoding="utf-8")
            report = {"document": "SRS", "authority": False,
                      "markdown_sha256": hashlib.sha256(markdown.read_bytes()).hexdigest(),
                      "gaps": [{"section": "3.2", "reason": "unsupported construction"}]}
            (output / "descriptive_writing_quality.json").write_text(json.dumps(report), encoding="utf-8")
            residuals = document_writing_residuals(root, "SRS")
            self.assertEqual(residuals[0]["kind"], "projection_gap")
            self.assertEqual(residuals[0]["readiness_impact"], "requires_assessment")
            self.assertEqual(document_writing_residuals(root, "DRS"), [])
            markdown.write_text("Changed system proof", encoding="utf-8")
            self.assertIn("does not bind", document_writing_residuals(root, "SRS")[0]["reason"])


if __name__ == "__main__":
    unittest.main()
