import json
import re
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

from test_spec_document_contract import _write_docx
from workflow_routing import (
    build_ipos_functional_input, compose_ipos_overview, ipos_functional_groups,
    build_ipos_claim_plan, validate_ipos_descriptive_output, _ipos_functional_presentation,
    _ipos_channel_signal_associations,
    write_ipos_descriptive_audit,
)
from csv_artifacts import csv_artifact_reader


class IPOSExplanatoryCompositionTests(unittest.TestCase):
    def functional(self, domain="digital", owner="Measurement Sequencer"):
        statements = [
            "When the rising ramp reaches half its value, ramp_half_done shall go high.",
            "When a clock pulse is received, the result shall be obtained dividing by the number of repeated frames the accumulated data to obtain a 17 bit data.",
            "When CHARGE channel is selected, the data shall be written inside the sample memory using the host interface.",
            "After an acquisition is started, Sample_Phases shall wait for conversion_done sampling the new data on the falling edge of the clock.",
            "When the Sample_Phases fsm is ready and an acquisition is required, sample_start shall stay high for sample_count+1 cycles.",
            "When reset_n is asserted low, the Cycle_FSM shall return in Reset state immediately.",
            "When the receiver is ready, start_compensation shall be set to 1 to start the compensation algorithm.",
            "When injection_enable is equal to 1, ck_a and ck_b shall be generated from Timing Generator block.",
        ]
        return build_ipos_functional_input(owner,
            {"Function": "Control acquisitions, process samples, and write results.",
             "Inputs": "sample data", "Outputs": "measurement results"},
            [{"source_req_id": "REQ-" + str(index), "statement": text}
             for index, text in enumerate(statements)],
            domain=domain, descriptive_source_records=[{
                "record_id": "function-role", "statement":
                    "The Cycle_FSM is in charge of identify the working state.",
                "admission_state": "admitted", "snapshot_id": "synthetic-approved",
                "mapped_block": owner, "domain": domain,
            }])

    def groups(self, sections):
        groups = []
        for entry in sections["internal_functions"]:
            if entry.startswith("#### "):
                groups.append([entry, []])
            else:
                groups[-1][1].append(entry)
        return groups

    def materialize(self, directory, functional):
        sections, audit = compose_ipos_overview(functional)
        paragraphs = []
        for key, title in (("functionality", "1.1 Functionality"),
                           ("scope", "1.2 Supported functions and scope"),
                           ("internal_functions", "1.4 Supported block functions")):
            paragraphs.extend(["### " + title, *sections[key]])
        path = Path(directory) / "pilot.md"
        path.write_text("\n\n".join(paragraphs), encoding="utf-8")
        _write_docx(path.with_suffix(".docx"), paragraphs)
        audit_path = path.with_suffix(".csv")
        write_ipos_descriptive_audit(audit_path, audit)
        return path, audit_path, paragraphs, sections, audit

    def findings(self, path, audit, functional):
        return validate_ipos_descriptive_output(path, audit, functional.block,
            functional.local_requirement_evidence, functional.local_requirement_ids, (), functional)

    def test_both_domains_have_two_or_three_evidence_backed_intro_sentences(self):
        for domain, owner in (("digital", "Measurement Sequencer"), ("analog", "Charge Front End")):
            with self.subTest(domain=domain):
                sections, audit = compose_ipos_overview(self.functional(domain, owner))
                self.assertEqual(len(sections["functionality"]), 1)
                groups = self.groups(sections)
                self.assertTrue(groups)
                by_heading = {row["group_heading"]: row for row in audit if row["decision"] == "function_explanation"}
                for title, paragraphs in groups:
                    synthesis = json.loads(by_heading[title.removeprefix("#### ")]["functional_synthesis_json"])
                    if synthesis["status"] == "UNSUPPORTED":
                        self.assertTrue(synthesis["unsupported"])
                        continue
                    sentences = re.split(r"(?<=[.!?])\s+(?=[A-Za-z0-9])", paragraphs[0].strip())
                    self.assertIn(len(sentences), (2, 3), (title, paragraphs[0]))
                    self.assertNotIn(paragraphs[0], sections["scope"])
                    self.assertNotRegex(paragraphs[0], r"(?i)approved|following details|local behavior|this section")
                explanations = [row for row in audit if row["decision"] == "function_explanation"]
                self.assertEqual(len(explanations), len(groups))
                for row in explanations:
                    responsibility = json.loads(row["responsibility_json"])
                    self.assertTrue(responsibility["proposition_ids"])
                    self.assertTrue(responsibility["spans"])
                    self.assertEqual(responsibility["approved_owners"], [owner])

    def test_production_audit_writer_preserves_explanation_linkage(self):
        functional = self.functional()
        with tempfile.TemporaryDirectory() as directory:
            _path, audit_path, _paragraphs, _sections, rows = self.materialize(directory, functional)
            expected = [row for row in rows if row["decision"] == "function_explanation"]
            with csv_artifact_reader(audit_path) as reader:
                actual = [row for row in reader if row["decision"] == "function_explanation"]
            self.assertEqual(len(expected), len(actual))
            for want, got in zip(expected, actual):
                self.assertEqual({key: got[key] for key in want}, want)

    def test_placement_follows_primary_behavior_not_incidental_condition_words(self):
        functional = self.functional()
        plan = build_ipos_claim_plan(functional)
        presentation, _ = _ipos_functional_presentation(plan, functional)
        groups = ipos_functional_groups(functional, presentation)
        assignment = {span.record_id: title for title, claims in groups
                      for claim in claims for span in claim.spans}
        self.assertIn("ramp", assignment["requirement:Measurement Sequencer:REQ-0"].lower())
        self.assertIn("result", assignment["requirement:Measurement Sequencer:REQ-1"].lower())
        self.assertIn("storage", assignment["requirement:Measurement Sequencer:REQ-2"].lower())
        self.assertNotIn("CHARGE", assignment["requirement:Measurement Sequencer:REQ-2"])

    def test_shared_enable_suffix_and_review_tags_do_not_establish_a_channel(self):
        functional = build_ipos_functional_input("Control Core", {"Function": "Control measurements."}, [
            {"source_req_id": "one", "statement": "[Covers: BASE-1] In Order to enable a PRESSURE Channel Operation, the user shall select the PRESSURE channel and set CTRL_EN."},
            {"source_req_id": "two", "statement": "[Covers: BASE-2] In Order to enable a CURRENT Channel Operation, the user shall select the CURRENT channel and set CTRL_EN."},
            {"source_req_id": "three", "statement": "When enable is high, output_control shall go low."},
        ], domain="digital")
        associations = _ipos_channel_signal_associations(functional)
        self.assertNotIn("en", associations)
        self.assertNotIn("ctrl", associations)
        self.assertEqual(associations["pressure"], "PRESSURE")
        self.assertEqual(associations["current"], "CURRENT")

    def test_independently_worded_analog_path_preserves_quantities_polarity_and_external_source(self):
        functional = build_ipos_functional_input("Charge Sampler",
            {"Function": "Acquire charges, process samples, and write results."}, [
                {"source_req_id": "settling", "statement": "After supply settling has finished, Charge Sampler shall sample differential input for 9 clock cycles."},
                {"source_req_id": "window", "statement": "When in Sampling State, the sampling switch shall remain closed for 7 clock cycles."},
                {"source_req_id": "reset", "statement": "When reset_n is asserted low, the output_voltage shall go to 0."},
                {"source_req_id": "readout", "statement": "Once conversion_done is high, the data shall be written inside the result register using the analog readout interface."},
                {"source_req_id": "inhibit", "statement": "When inhibit is set to 1, the output switch shall not remain closed."},
                {"source_req_id": "clock", "statement": "When drive_enable is set to 1, clock_out shall be generated from Shared Oscillator block."},
            ], domain="analog")
        with tempfile.TemporaryDirectory() as directory:
            path, audit, _paragraphs, sections, _rows = self.materialize(directory, functional)
            self.assertEqual(self.findings(path, audit, functional), [])
            content = " ".join(sections["internal_functions"])
            for phrase in ("9 clock cycles", "7 clock cycles", "reset_n is asserted low",
                           "does not remain closed", "generated from Shared Oscillator block"):
                self.assertIn(phrase, content)
            self.assertNotIn("Charge Sampler generates", content)
            for _heading, paragraphs in self.groups(sections):
                row = next(row for row in _rows if row.get("group_heading") == _heading.removeprefix("#### "))
                if json.loads(row["functional_synthesis_json"])["status"] == "SUPPORTED":
                    self.assertIn(len(re.split(r"(?<=[.!?])\s+(?=[A-Za-z0-9])", paragraphs[0])), (2, 3))

    def test_editorial_projection_preserves_identifiers_values_and_guard_direction(self):
        functional = build_ipos_functional_input("Timing Core", {"Function": "Control measurements."}, [
            {"source_req_id": "delay", "statement": "If short_delay is set to 0. At least after 180ms that reset_hold is gone low, startup_done shall go low."},
            {"source_req_id": "cycle", "statement": "When the offset algorithm is enabled, it shall be performed every time a new measurements cycle starts."},
        ], domain="digital")
        sections, _ = compose_ipos_overview(functional)
        text = " ".join(sections["internal_functions"])
        self.assertIn("at least 180ms after reset_hold goes low", text)
        self.assertIn("short_delay is set to 0", text)
        self.assertIn("new measurement cycle", text)
        self.assertNotIn("180us", text)
        self.assertNotIn("reset_hold goes high", text)

    def test_actual_prose_and_audit_reject_filler_ownership_changes_and_duplicate_intros(self):
        functional = self.functional()
        with tempfile.TemporaryDirectory() as directory:
            path, audit, paragraphs, sections, _rows = self.materialize(directory, functional)
            self.assertEqual(self.findings(path, audit, functional), [])
            intro = self.groups(sections)[0][1][0]
            for artifact, before, after in (
                ("markdown", intro, "This function supports the approved local behavior."),
                ("docx", "generated from Timing Generator block", "generated by Measurement Sequencer"),
                ("markdown", intro, intro + "\n\n" + intro),
                ("docx", "Reset state immediately", "Reset state eventually"),
            ):
                with self.subTest(artifact=artifact, after=after):
                    changed = [value.replace(before, after) for value in paragraphs]
                    self.assertNotEqual(changed, paragraphs)
                    path.write_text("\n\n".join(changed if artifact == "markdown" else paragraphs), encoding="utf-8")
                    _write_docx(path.with_suffix(".docx"), changed if artifact == "docx" else paragraphs)
                    self.assertTrue(self.findings(path, audit, functional))


if __name__ == "__main__":
    unittest.main()
