import copy
import json
import re
import tempfile
import unittest
import sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

from governed_descriptive_scope import (
    SHARED_CONTEXT_AUTHORIZATION, configuration_context, project_shared_descriptive_uses,
)
from spec_document_contract import assess_descriptive_synthesis, document_synthesis_evidence, load_descriptive_synthesis_contract
from test_governed_descriptive_scope import admitted, record
from test_spec_document_contract import _write_docx
from workflow_routing import (
    build_ipos_claim_plan, build_ipos_functional_input, compose_document_responsibilities,
    compose_ipos_overview, document_responsibility_model, extract_srs_descriptive_facts,
    shared_descriptive_evidence_model, shared_document_descriptive_contributions,
)


class ResponsibilitySynthesisTests(unittest.TestCase):
    def mode(self, document="SRS", *, name="Capture Mode", setup="CAPTURE", first="2", second="7"):
        statement = (
            f"Set {setup} bit in Mode_Control register to {first} and FILTER to {second} in Stream_Control. "
            "This will cut the communication between Timing Hub and Compute Unit. "
            "Input Interface samples ALPHA and BETA signals from Converter, average and stores data in FIFO. "
            "Input Interface samples GAMMA signal from Converter and stores GAMMA data raw in FIFO. "
            "Input Interface samples DELTA signal from Converter, average (according to the user's configuration) "
            "and stores data in FIFO. "
            "Raw data are always available in FIFO after stored. (Except when FIFO FULL occurs)"
        )
        return self.projected(statement, document, name)

    def projected(self, statement, document, name):
        source = record("mode-evidence", statement, evidence_scope="shared",
            section_context_json=json.dumps([["4", "Operating modes"], ["4.2", name]]))
        block = "Compute Unit" if document == "IPOS" else ""
        domain = "digital" if document != "SRS" else "system"
        use = {"use_id": "approved", "document": document, "block": block, "domain": domain,
               "role": "context", "start": 0, "end": len(statement), "rationale": "Reviewed complete context."}
        qualification = configuration_context(source, statement, "context")
        if qualification:
            use["context_qualification"] = qualification
        if document == "IPOS":
            use["context_authorization"] = SHARED_CONTEXT_AUTHORIZATION
        source["approved_uses_json"] = json.dumps([use])
        return project_shared_descriptive_uses(
            admitted({"governed_source_context": {"version": 1, "records": [source]}}),
            document=document, block=block, domain=domain)

    def evidence(self, first="Cedar", second="Maple"):
        requirements = []
        inventory = []
        for index, owner in enumerate((first, second), start=1):
            requirements.append({
                "source_req_id": f"req-{index}", "canonical_id": f"canonical-{index}",
                "requirement_statement": f"When enabled, {owner} shall convert input currents to samples.",
                "source": "approved snapshot", "applicable": True,
                "allocation": {"approved_block": owner, "owning_target": "Digital IPOS"},
            })
            inventory.append({
                "owner": owner, "statement": "Convert input currents to samples.",
                "inputs": "currents", "outputs": "samples", "source": "approved architecture",
                "applicable": True, "entity_kind": "concrete_block",
                "scope": "allocated_owner", "domains": ["digital"],
            })
        return {
            "snapshot_id": "approved-synthetic", "architecture_fingerprint": "approved-functions",
            "requirements": requirements, "inventory": inventory, "shared_records": [],
            "local_records": [], "descriptive_scope": [], "interactions": [],
            "function_decomposition": [{"top_function": "Channel acquisition",
                "subfunctions": "current conversion; sampled-data collection",
                "blocks_involved": first + "; " + second}],
        }

    def test_complete_mode_semantics_preserve_conditions_results_and_exception(self):
        for document in ("SRS", "DRS", "IPOS"):
            uses = self.mode(document)
            model = shared_descriptive_evidence_model(uses, document=document,
                owner="Compute Unit" if document == "IPOS" else "", domain="digital" if document == "IPOS" else "")
            self.assertEqual(model.unresolved_contexts, ())
            self.assertEqual(len(model.propositions), 5)
            for proposition in model.propositions:
                self.assertIn("CAPTURE=2", proposition.meaning.contexts[0].text)
                self.assertIn("FILTER=7", proposition.meaning.contexts[0].text)
                self.assertEqual(len(proposition.spans), 2)
            available = model.propositions[-1].meaning
            self.assertIn("always available", available.objects[0])
            self.assertIn("except when FIFO FULL occurs", available.qualifiers[0])
            self.assertIn("according to the user's configuration", model.propositions[-2].meaning.results[0])

    def test_independent_readback_accepts_actual_mode_prose_and_rejects_mutations(self):
        uses = self.mode("DRS")
        sections = shared_document_descriptive_contributions(uses, document="DRS")
        text = "\n\n".join(sections["3"])
        evidence = {"snapshot_id": "approved-synthetic", "shared_records": uses, "functions": []}
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "review.md"

            def assess(value, *, word_only=False):
                path.write_text("# 3. Context\n\n" + (text if word_only else value), encoding="utf-8")
                _write_docx(path.with_suffix(".docx"), ["# 3. Context", value])
                with patch("workflow_routing.compose_document_responsibilities", side_effect=AssertionError("producer")):
                    return assess_descriptive_synthesis(path, "DRS", evidence)

            report = assess(text)
            self.assertEqual(report["obligations"]["semantic_fidelity"]["status"], "PASS", report["gaps"])
            self.assertEqual(report["obligations"]["essential_qualifications"]["status"], "PASS", report["gaps"])
            for old, new in (("CAPTURE=2", "CAPTURE=9"), ("FILTER=7", "FILTER=1"),
                             ("except when FIFO FULL occurs", ""), ("stores the raw samples", "stores the samples"),
                             ("Input Interface", "Compute Unit"), ("in FIFO", "in EXTERNAL")):
                for word_only in (False, True):
                    with self.subTest(old=old, word_only=word_only):
                        changed = re.sub(re.escape(old), new, text, flags=re.I)
                        self.assertNotEqual(changed, text)
                        mutated = assess(changed, word_only=word_only)
                        self.assertTrue(any(gap["obligation"] in {"semantic_fidelity", "essential_qualifications"}
                                            for gap in mutated["gaps"]))

    def test_ambiguous_setup_does_not_strip_guards_or_guess_an_antecedent(self):
        original = self.mode()[0]["statement"]
        variants = (
            original.replace("This will cut", "That will cut"),
            original.replace("This will cut", "Set OTHER bit in Other_Control register to 3 and MASK to 9 "
                             "in Other_Stream. This will cut"),
        )
        for value in variants:
            uses = self.projected(value, "SRS", "Capture Mode")
            model = shared_descriptive_evidence_model(uses, document="SRS")
            self.assertTrue(model.unresolved_contexts)
            self.assertFalse(any(p.meaning.relation == "interaction" for p in model.propositions))
            if "Set OTHER" in value:
                self.assertFalse(model.propositions)

    def test_heading_bound_optionality_and_inclusive_alternatives(self):
        statement = "In this mode is possible to turn on the Vector Engine to work with raw data and/or filtered data."
        uses = self.projected(statement, "DRS", "Observe Mode")
        text = shared_document_descriptive_contributions(uses, document="DRS")["3"][0]
        self.assertIn("In Observe Mode, vector Engine can be enabled", text)
        self.assertIn("raw data, filtered data, or both", text)
        unresolved = self.projected(statement, "DRS", "Overview")
        self.assertFalse(shared_descriptive_evidence_model(unresolved, document="DRS").propositions)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "optional.md"
            for before, after in (("", ""), ("can be enabled", "is enabled"),
                                  (", or both", " and both"), ("Observe Mode", "Other Mode")):
                value = text if not before else text.replace(before, after)
                path.write_text("# 3. Context\n\n" + value, encoding="utf-8")
                _write_docx(path.with_suffix(".docx"), ["# 3. Context", value])
                report = assess_descriptive_synthesis(path, "DRS", {
                    "snapshot_id": "approved-synthetic", "shared_records": uses, "functions": []})
                self.assertEqual(report["obligations"]["essential_qualifications"]["status"],
                                 "UNRESOLVED" if before else "PASS", report["gaps"])

    def test_unsupported_exception_only_withholds_its_potentially_dependent_bundle(self):
        facts, gap = extract_srs_descriptive_facts(
            "The system supports acquisition. The system supports transfer. Except in an unspecified case.",
            source="approved", scope="architecture", section="3.4")
        self.assertEqual([value.objects for value in facts], [("acquisition",)])
        self.assertTrue(gap)

    def test_complementary_records_share_a_governed_responsibility_not_just_a_word(self):
        for names in (("Cedar", "Maple"), ("Quartz Engine", "River Converter")):
            evidence = self.evidence(*names)
            model = document_responsibility_model(evidence, document="SRS")
            responsibility = model.responsibilities[0]
            members = {value.proposition_id: value for value in model.propositions}
            self.assertEqual(len(responsibility.proposition_ids), 5)
            self.assertEqual(len({span.record_id for span in responsibility.spans}), 5)
            for identity in responsibility.proposition_ids[1:]:
                self.assertIn(members[identity].owner, names)
            texts, _ = compose_document_responsibilities(evidence, document="SRS")
            self.assertEqual(texts, [
                "", "#### **Channel acquisition**", "",
                "The device supports current conversion and sampled-data collection."])
            changed = copy.deepcopy(evidence)
            changed["function_decomposition"][0]["blocks_involved"] = "Unrelated Unit"
            model = document_responsibility_model(changed, document="SRS")
            self.assertEqual(len(model.responsibilities[0].proposition_ids), 1)

    def test_missing_or_ambiguous_function_binding_does_not_get_a_terminology_match(self):
        evidence = self.evidence()
        evidence["function_decomposition"].append({
            "top_function": "Auxiliary acquisition", "subfunctions": "current conversion",
            "blocks_involved": "Cedar; Maple",
        })
        model = document_responsibility_model(evidence, document="SRS")
        self.assertTrue(all(len(value.proposition_ids) == 1 for value in model.responsibilities))
        self.assertTrue(any("multiple approved responsibilities" in value.reason for value in model.unresolved_contexts))

    def test_conversion_scope_from_complementary_inventory_changes_the_final_prose(self):
        evidence = self.evidence("Cedar", "Maple")
        evidence["function_decomposition"][0]["subfunctions"] = "Cedar conversion; sampled-data collection"
        text = "\n".join(compose_document_responsibilities(evidence, document="SRS")[0])
        self.assertIn("conversion of input currents to samples", text)
        self.assertNotIn("Cedar", text)
        changed = copy.deepcopy(evidence)
        changed["inventory"][0]["statement"] = "Convert configured voltages to words."
        other = "\n".join(compose_document_responsibilities(changed, document="SRS")[0])
        self.assertIn("conversion of configured voltages to words", other)
        self.assertNotEqual(other, text)
        changed["function_decomposition"][0]["blocks_involved"] = "Maple"
        self.assertNotIn(" of configured voltages", "\n".join(compose_document_responsibilities(changed, document="SRS")[0]))

    def test_collection_is_compared_with_the_snapshot_not_with_the_composer_selection(self):
        expected = self.evidence()
        changed = copy.deepcopy(expected)
        changed["requirements"].pop()
        texts = compose_document_responsibilities(changed, document="SRS")[0]
        policy = load_descriptive_synthesis_contract("SRS")
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "scope.md"
            path.write_text("# 3.2 Main functions\n\n" + "\n\n".join(texts), encoding="utf-8")
            _write_docx(path.with_suffix(".docx"), ["# 3.2 Main functions", *texts])
            with patch("validate_downstream_coherence.resolve_downstream_contract") as resolve, \
                    patch("spec_document_contract.load_descriptive_synthesis_contract", return_value=policy):
                resolve.return_value.synthesis_evidence.return_value = expected
                report = assess_descriptive_synthesis(path, "SRS", changed, repo_root=Path(directory))
            self.assertEqual(report["collection_completeness"], "UNRESOLVED")
            self.assertTrue(any(gap["readiness_impact"] == "collection_completeness" for gap in report["gaps"]))
            self.assertFalse(report["generation_blocking"])

    def test_responsibility_prose_is_independently_checked_with_its_complementary_scope(self):
        evidence = self.evidence()
        evidence["function_decomposition"][0]["subfunctions"] = "Cedar conversion; sampled-data collection"
        for document, heading in (("SRS", "3.2 Main functions"), ("DRS", "3.1 Digital main functions")):
            text = "\n\n".join(compose_document_responsibilities(evidence, document=document)[0])
            organization = ""
            if document == "SRS":
                from workflow_routing import compose_srs_system_overview, SRS_SYSTEM_OVERVIEW_HEADINGS
                organization = "\n\n# 3.3 Architecture\n\n" + "\n\n".join(compose_srs_system_overview(
                    [], evidence=evidence)[SRS_SYSTEM_OVERVIEW_HEADINGS[2]])
            with tempfile.TemporaryDirectory() as directory:
                path = Path(directory) / "functions.md"
                for value in (text, text.replace("input currents", "pressure"), text.replace(
                        "sampled-data collection" if document == "SRS" else "to samples", "")):
                    body = "# " + heading + "\n\n" + value + organization
                    path.write_text(body, encoding="utf-8")
                    _write_docx(path.with_suffix(".docx"), body.splitlines())
                    with patch("workflow_routing.compose_document_responsibilities", side_effect=AssertionError("producer")):
                        report = assess_descriptive_synthesis(path, document, evidence)
                    statuses = [report["obligations"][name]["status"]
                                for name in ("semantic_fidelity", "essential_qualifications")]
                    if value == text:
                        self.assertEqual(statuses, ["PASS", "PASS"], report["gaps"])
                    else:
                        self.assertIn("UNRESOLVED", statuses)

    def test_snapshot_inventory_does_not_depend_on_live_csv_or_shared_use_domain(self):
        import generate_ipos_specs as generator
        from requirement_corpus import RequirementInput
        from validate_downstream_coherence import DownstreamContract
        root = Path("isolated")
        requirement_input = RequirementInput("6", "approved-synthetic", "corpus", "snapshot", root, (), {}, {})
        contract = DownstreamContract(requirement_input, {})
        profile = {"fingerprint": "approved-profile", "payload": {"block_defs": {
            "Quartz Engine": {"function": "Process samples.", "inputs": "samples", "outputs": "results"}}}}
        with patch.object(generator, "resolve_downstream_contract", return_value=contract), \
                patch("validate_downstream_coherence.snapshot_architecture_context", return_value=profile) as architecture, \
                patch.object(generator, "_read_csv", side_effect=AssertionError("live inventory")):
            result = generator._block_inventory_record(root, "Quartz Engine", snapshot_id="approved-synthetic")
            architecture.assert_called_once_with(root, contract)
            self.assertEqual(result["Function"], "Process samples.")
            self.assertEqual(result["_synthesis_source"], "snapshot architecture profile:approved-profile:Quartz Engine")
            profile["payload"]["block_defs"]["quartz engine"] = {}
            with self.assertRaisesRegex(generator.DownstreamCoherenceError, "missing or ambiguous"):
                generator._block_inventory_record(root, "Quartz Engine", snapshot_id="approved-synthetic")

    def test_active_ipos_generator_rejects_upstream_text_as_technical_authority(self):
        import generate_ipos_specs as generator
        source = {"source_req_id": "approved-req", "canonical_id": "canonical-req",
                  "requirement_statement": "Quartz Engine shall process samples."}
        upstream = {"source_req_id": source["source_req_id"], "drs_req_id": "DRS-7",
                    "requirement_statement": "Foreign Engine shall discard samples."}
        snapshot = SimpleNamespace(snapshot_id="approved-synthetic", rows=[source])
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "config").mkdir()
            (root / "config" / "project_context.json").write_text("{}", encoding="utf-8")
            with patch.object(generator, "resolve_complete_authoritative_input", return_value=(snapshot, {})), \
                    patch.object(generator, "resolve_downstream_contract") as contract, \
                    patch.object(generator, "validate_generation_inputs", return_value={"decision": "PASS"}), \
                    patch.object(generator, "_read_csv", return_value=[upstream]), \
                    patch.object(generator, "read_csv", return_value=[]), \
                    patch.object(generator, "_write_ipos_document") as writer:
                contract.return_value.allocation.return_value = {
                    "allocation_class": generator.BLOCK_LOCAL_DIGITAL, "approved_block": "Quartz Engine"}
                with self.assertRaisesRegex(generator.DownstreamCoherenceError, "conflicts with approved snapshot"):
                    generator.generate(root, "digital", snapshot_id=snapshot.snapshot_id, block="Quartz Engine")
                writer.assert_not_called()

    def test_boundary_peer_evidence_does_not_require_a_domain_local_block_purpose(self):
        inventory = [{"owner": "Cedar", "applicable": True, "scope": "allocated_owner"},
                     {"owner": "Maple", "applicable": True, "scope": "approved_function_boundary"}]
        with patch("validate_downstream_coherence.resolve_downstream_contract") as contract:
            contract.return_value.synthesis_evidence.return_value = {"inventory": inventory}
            evidence = document_synthesis_evidence(Path("isolated"), "DRS", "approved-synthetic")
        self.assertEqual(evidence["inventory"], inventory)
        self.assertEqual([row["owner"] for row in evidence["functions"]], ["Cedar"])

    def test_digital_objective_is_interpreted_without_losing_capability_or_results(self):
        source = ("The AURORA9 features an advanced digital engine, composed of multiple IPs able to reduce "
                  "external controller processing workload, reducing link congestion, providing metadata useful "
                  "for final application, both in spatial and spectral domain.")
        uses = self.projected(source, "DRS", "Device overview")
        model = shared_descriptive_evidence_model(uses, document="DRS")
        self.assertFalse(model.unresolved_contexts)
        meaning = model.propositions[0].meaning
        self.assertEqual(meaning.modality, "can")
        self.assertEqual(meaning.contexts[0].text, "Within AURORA9")
        text = shared_document_descriptive_contributions(uses, document="DRS")["3"][0]
        self.assertIn("can reduce external controller processing workload", text)
        self.assertIn("reduce link congestion", text)
        self.assertIn("both spatial and spectral domains", text)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "objective.md"
            for changed in (text, text.replace("can reduce", "reduces"), text.replace("spectral", "temporal")):
                path.write_text("# 3. Overview\n\n" + changed, encoding="utf-8")
                _write_docx(path.with_suffix(".docx"), ["# 3. Overview", changed])
                report = assess_descriptive_synthesis(path, "DRS", {"shared_records": uses})
                self.assertEqual(report["obligations"]["essential_qualifications"]["status"],
                                 "PASS" if changed == text else "UNRESOLVED", report["gaps"])

    def test_context_ownership_is_checked_independently_of_presentation_selection(self):
        from workflow_routing import shared_descriptive_evidence_model, realize_descriptive_functional_claim, DescriptiveFunctionalClaim
        uses = self.mode("IPOS")
        functional = build_ipos_functional_input("Compute Unit", {"Function": "Process samples."},
                                                domain="digital", shared_context_records=uses)
        sections, _ = compose_ipos_overview(functional)
        model = shared_descriptive_evidence_model(uses, document="IPOS", owner="Compute Unit", domain="digital")
        foreign = next(p for p in model.propositions if p.meaning.predicate == "acquire")
        injected = realize_descriptive_functional_claim(
            DescriptiveFunctionalClaim("foreign", "boundaries", (), (foreign.meaning,), (), ()))
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "context.md"
            paragraphs = ["# 1.1 Purpose", *sections["functionality"], "# 1.2 Scope", *sections["scope"], injected]
            path.write_text("\n\n".join(paragraphs), encoding="utf-8")
            _write_docx(path.with_suffix(".docx"), paragraphs)
            with patch("workflow_routing._ipos_functional_presentation", side_effect=AssertionError("producer")):
                report = assess_descriptive_synthesis(path, "IPOS", {"functional_input": functional})
            self.assertTrue(any(gap["readiness_impact"] == "functional_ownership" for gap in report["gaps"]))
            self.assertTrue(any(not row["applicable"] for row in report["context_applicability"]))

    def test_joint_actions_with_list_objects_keep_a_shared_target_as_one_responsibility(self):
        from workflow_routing import bounded_functional_summary
        source = "Aggregate and route Timer, Stream, and Host event status to configured alert outputs."
        summary = bounded_functional_summary(source)
        self.assertFalse(summary.gap)
        self.assertEqual(summary.responsibilities,
            ("Provide aggregation and routing of Timer, Stream, and Host event status to configured alert outputs",))
        guarded = bounded_functional_summary(source.replace("to configured", "only when READY is high to configured"))
        self.assertTrue(guarded.gap)

    def test_active_drs_writing_assessment_does_not_require_the_old_generic_sentence(self):
        import run_drs_gen_spec_agent as generator
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            output = root / "artifacts" / "stage5_drs"
            output.mkdir(parents=True)
            (output / "digital_requirements_specification.md").write_text(
                "Snapshot ID: approved-synthetic\n\n## 3. Overview\nSupported device role.\n", encoding="utf-8")
            with patch("spec_document_contract.document_synthesis_evidence", return_value={}), \
                    patch("spec_document_contract.assess_descriptive_synthesis", return_value={"gaps": []}) as check:
                self.assertEqual(generator.drs_synthesis_rows(root), [])
                check.assert_called_once()

    def test_active_drs_writer_does_not_repeat_a_rendered_inventory_contribution(self):
        import run_drs_gen_spec_agent as generator
        from spec_document_contract import DRS_TEMPLATE, load_drs_contract
        evidence = self.evidence("Timing Unit", "Support Unit")
        evidence["requirements"] = []
        evidence["inventory"] = evidence["inventory"][:1]
        evidence["inventory"][0]["statement"] = "Sequence reset release for startup."
        evidence["function_decomposition"] = [{"top_function": "Startup coordination",
            "subfunctions": "reset-release coordination", "blocks_involved": "Timing Unit"}]
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "drs.md"
            with patch.object(generator, "assemble_low_power_descriptive", return_value=(
                    {"Sequencing and domain control": ["Timing Unit sequences reset release for startup.",
                        "Interaction: Timing Unit -> Control Unit (power/clock status)"]}, [])), \
                    patch.object(generator, "_drs_topic_narrative", side_effect=AssertionError("duplicate legacy purpose")):
                generator._write_drs_markdown(
                    path, "approved synthetic source", "AURORA9", "Review", "approved-synthetic", "review",
                    [], {}, [], {}, [], {}, [], {}, [], [], [], "PASS", [], {}, set(), {}, [], [],
                    load_drs_contract(Path(__file__).resolve().parents[1] / DRS_TEMPLATE),
                    review_overview_only=True, responsibility_evidence=evidence)
            text = path.read_text(encoding="utf-8")
            self.assertIn("Timing Unit sequences reset release for startup.", text)
            self.assertEqual(text.count("reset release for startup"), 1)
            self.assertNotIn("digital integration layer", text)

    def test_register_map_endpoint_is_not_mistaken_for_configuration_detail(self):
        statement = "Provide the serial access path into the register map."
        evidence = {"inventory": [{"owner": "Serial Unit", "statement": statement,
                                   "source": "approved serial purpose", "applicable": True}]}
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "drs.md"
            for suffix in ("", " at 0x21"):
                prose = "Serial Unit: the serial access path into the register map" + suffix + "."
                path.write_text("# 3 Overview\n\n" + prose, encoding="utf-8")
                _write_docx(path.with_suffix(".docx"), ["# 3 Overview", prose])
                report = assess_descriptive_synthesis(path, "DRS", evidence)
                details = [gap for gap in report["gaps"] if gap["reason"] ==
                           "technical/configuration detail in functional prose"]
                self.assertEqual(bool(details), bool(suffix))
            prose = "Memory Unit: the one-time-programmable memory interface."
            path.write_text("# 3 Overview\n\n" + prose, encoding="utf-8")
            _write_docx(path.with_suffix(".docx"), ["# 3 Overview", prose])
            report = assess_descriptive_synthesis(path, "DRS", evidence)
            self.assertFalse(any(gap["reason"] == "technical/configuration detail in functional prose"
                                 for gap in report["gaps"]))

    def test_conflicting_approved_actions_remain_findings_not_majority_votes(self):
        evidence = self.evidence()
        negative = copy.deepcopy(evidence["requirements"][0])
        negative["source_req_id"] = "negative"
        negative["requirement_statement"] = negative["requirement_statement"].replace("shall convert", "shall not convert")
        evidence["requirements"].append(negative)
        model = document_responsibility_model(evidence, document="SRS")
        self.assertTrue(any("conflicting approved propositions" in value.reason for value in model.unresolved_contexts))

    def test_ipos_operation_association_uses_explicit_actor_and_named_operation(self):
        functional = build_ipos_functional_input("Quartz Engine",
            {"Function": "Execute firmware for FUSE boot/write/test and signal elaboration, using mapped memory."},
            [{"source_req_id": "boot", "statement":
              "During FUSE boot operation, Quartz Engine shall copy fuse data into startup storage."}],
            domain="digital")
        model = build_ipos_claim_plan(functional).evidence
        self.assertEqual([value.label for value in model.responsibilities], ["FUSE boot"])
        self.assertEqual(len(model.responsibilities[0].spans), 2)
        changed = build_ipos_functional_input("Quartz Engine", {"Function": functional.function},
            [{"source_req_id": "boot", "statement":
              "During FUSE boot operation, Foreign Engine shall copy fuse data into startup storage."}], domain="digital")
        self.assertEqual(build_ipos_claim_plan(changed).evidence.responsibilities, ())

    def test_approved_foreign_mode_context_does_not_become_a_local_purpose_or_action(self):
        uses = self.mode("IPOS")
        functional = build_ipos_functional_input("Compute Unit", {"Function": "Process samples."},
                                                domain="digital", shared_context_records=uses)
        sections, _ = compose_ipos_overview(functional)
        self.assertNotIn("Input Interface", " ".join(sections["functionality"]))
        self.assertNotIn("Input Interface", " ".join(sections["internal_functions"]))
        self.assertNotIn("input Interface", " ".join(sections["scope"]))
        self.assertIn("communication between Timing Hub and Compute Unit", " ".join(sections["internal_functions"]))

    def test_boot_responsibility_combines_inventory_and_guarded_memory_transfer(self):
        statement = ("During FUSE boot operation, Quartz Engine shall copy the content of the FUSE memory "
                     "into the FUSE registers, following the procedure to access FUSE memory.")
        functional = build_ipos_functional_input("Quartz Engine",
            {"Function": "Execute firmware for FUSE boot/write/test and signal elaboration, using mapped memory."},
            [{"source_req_id": "boot", "statement": statement}], domain="digital")
        sections, _ = compose_ipos_overview(functional)
        text = "\n\n".join(sections["internal_functions"])
        self.assertIn("loads the FUSE registers from the FUSE memory", text)
        self.assertIn("During FUSE boot operation", text)
        self.assertIn("following the procedure to access FUSE memory", text)
        self.assertNotIn(statement.replace("shall ", ""), text)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "boot.md"
            for value in (text, text.replace("following the procedure to access FUSE memory", "")):
                paragraphs = ["# 1.1 Functionality", *sections["functionality"],
                              "# 1.2 Scope", *sections["scope"], "# 1.4 Behavior", value]
                path.write_text("\n\n".join(paragraphs), encoding="utf-8")
                _write_docx(path.with_suffix(".docx"), [
                    line for paragraph in paragraphs for line in paragraph.split("\n\n")])
                report = assess_descriptive_synthesis(path, "IPOS",
                    {"snapshot_id": "approved-synthetic", "functional_input": functional})
                self.assertEqual(report["obligations"]["essential_qualifications"]["status"],
                                 "PASS" if value == text else "UNRESOLVED", report["gaps"])


if __name__ == "__main__":
    unittest.main()
