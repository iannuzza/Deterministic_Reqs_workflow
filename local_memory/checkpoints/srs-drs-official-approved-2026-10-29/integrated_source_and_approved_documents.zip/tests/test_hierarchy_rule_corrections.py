import copy
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from approved_snapshot_resolver import validate_governed_source_context
from descriptive_review_proposals import destination_proposals, requested_destination_rows
from governed_descriptive_scope import (
    descriptive_destination_rows, explicit_functional_source_support, project_shared_descriptive_uses,
    serialize_descriptive_destinations, shared_scope_findings,
)
from test_governed_descriptive_scope import record
from validate_downstream_coherence import DownstreamContract
from workflow_routing import (
    SRS_SYSTEM_OVERVIEW_HEADINGS, abstract_srs_evidence_model, shared_descriptive_evidence_model,
    shared_document_descriptive_contributions, validate_srs_system_overview,
    srs_source_evidence_model,
)


class HierarchyRuleCorrectionTests(unittest.TestCase):
    def approve(self, source, profile, *, document, role, block="", excerpt=None):
        text = source["statement"] if excerpt is None else excerpt
        start = source["statement"].index(text)
        rows = requested_destination_rows(
            {"document": document, "block": block, "domain": source["domain"], "role": role,
             "start": start, "end": start + len(text), "excerpt": text,
             "rationale": "Synthetic explicitly reviewed use."},
            source, profile["governed_source_context"]["records"], profile, list(profile["block_defs"]))
        self.assertTrue(all(row["support_status"] == "ready" for row in rows), rows)
        for row in rows:
            row["review_decision"] = "approved"
        return dict(source, **serialize_descriptive_destinations(source, "shared", rows))

    def test_owned_source_reuse_preserves_owner_and_validates_projection(self):
        source = record("clock-control", "Clock Manager controls startup.", "Clock Manager", "digital")
        profile = {"block_defs": {"Clock Manager": {}},
                   "governed_source_context": {"version": 1, "records": [source]}}
        original = copy.deepcopy(source)
        reviewed = self.approve(source, profile, document="DRS", role="context")
        profile["governed_source_context"]["records"] = [reviewed]
        self.assertEqual(validate_governed_source_context(profile), [])
        self.assertEqual(reviewed["mapped_block"], "Clock Manager")
        for field in ("statement", "content_sha256", "source_spans_json", "review_decision"):
            self.assertEqual(reviewed[field], original[field])
        projected = project_shared_descriptive_uses(
            [dict(reviewed, snapshot_id="fixed", admission_state="admitted")], document="DRS")
        self.assertEqual(len(projected), 1)
        meanings = shared_descriptive_evidence_model(projected, document="DRS").propositions
        self.assertEqual(len(meanings), 1)
        self.assertEqual(meanings[0].meaning.subject, "Clock Manager")
        contract = DownstreamContract.__new__(DownstreamContract)
        contract.snapshot_id = "fixed"
        contract.expected = {"owned": {"approved_block": "Clock Manager", "owning_target": "Digital IPOS"}}
        with patch("validate_downstream_coherence.resolve_governed_descriptive_context",
                   return_value=(reviewed,)), patch("validate_downstream_coherence._project_id", return_value="test"):
            self.assertEqual(contract.descriptive_context(Path("."), block="Clock Manager", domain="digital"),
                             (reviewed,))
        reviewed["mapped_block"] = "Unknown"
        self.assertTrue(validate_governed_source_context(profile))

    def test_explicit_actor_action_does_not_need_duplicate_local_text(self):
        source = record("shared", "The Buffer Unit stores samples.", evidence_scope="shared",
                        domain="digital", approved_uses_json="[]")
        profile = {"block_defs": {"Buffer Unit": {}},
                   "governed_source_context": {"version": 1, "records": [source]}}
        reviewed = self.approve(source, profile, document="IPOS", block="Buffer Unit", role="functions")
        self.assertEqual(shared_scope_findings(reviewed, [reviewed], profile["block_defs"]), [])
        for text in ("Samples are accessible to the Buffer Unit.",
                     "The Collector is wired to the Buffer Unit.",
                     "The Buffer Unit is wired to the Collector.",
                     "The Collector stores samples for the Buffer Unit."):
            self.assertFalse(explicit_functional_source_support(text, "Buffer Unit"), text)
        self.assertTrue(explicit_functional_source_support(
            "All the data are stored inside a Sample Queue that can be configured as: one queue or partitions.",
            "Sample Queue"))
        self.assertFalse(explicit_functional_source_support(
            "All the data are stored inside a Sample Queue that can be configured as: one queue or partitions.",
            "Compute Unit"))

    def test_parser_limit_is_not_reported_as_absent_source_evidence(self):
        source = record("unknown", "A novel construction awaits a supported adapter.",
                        evidence_scope="shared", approved_uses_json="[]")
        profile = {"block_defs": {}}
        rows = requested_destination_rows(
            {"document": "SRS", "block": "", "role": "functions", "start": 0,
             "end": len(source["statement"]), "excerpt": source["statement"], "rationale": "Test."},
            source, [source], profile, [])
        self.assertEqual(rows[0]["support_status"], "projection_gap")

    def test_flattened_list_candidate_passes_actual_source_span_validation(self):
        statement = ("VEGA8 is a sensing device. VEGA8 collects and processes different types of measurements: "
                     "\u2022 pressure \u2022 humidity The optical channel is designed to support optical measurements.")
        source = record("flattened", statement, evidence_scope="shared", approved_uses_json="[]")
        profile = {"block_defs": {}, "governed_source_context": {"version": 1, "records": [source]}}
        candidates = [row for row in destination_proposals(source, [source], profile, [])
                      if row["role"] == "purpose"]
        self.assertTrue(candidates)
        for row in candidates:
            row["review_decision"] = "approved"
        reviewed = dict(source, **serialize_descriptive_destinations(source, "shared", candidates))
        self.assertEqual(shared_scope_findings(reviewed, [reviewed], {}), [])
        self.assertEqual(reviewed["statement"], statement)

    def test_mixed_source_is_semantic_only_and_never_literal_fallback(self):
        statement = ("VEGA8 is a sensing device. Set ACCESS bit in Route register to 1. "
                     "The user must follow the programming procedure.")
        source = record("mixed", statement, evidence_scope="shared", approved_uses_json="[]")
        profile = {"block_defs": {}, "governed_source_context": {"version": 1, "records": [source]}}
        reviewed = self.approve(source, profile, document="SRS", role="context")
        self.assertEqual(shared_scope_findings(reviewed, [reviewed], {}), [])
        projected = project_shared_descriptive_uses(
            [dict(reviewed, snapshot_id="fixed", admission_state="admitted")], document="SRS")
        audit = []
        paragraphs = shared_document_descriptive_contributions(projected, document="SRS", audit_rows=audit)
        prose = " ".join(text for values in paragraphs.values() for text in values)
        self.assertNotIn("ACCESS", prose)
        self.assertNotIn("must", prose)
        self.assertTrue(any("unresolved" in str(row).lower() for row in audit))
        with self.assertRaisesRegex(ValueError, "cannot be rendered literally"):
            shared_document_descriptive_contributions(projected, document="SRS", _legacy_literal=True)
        use = json.loads(reviewed["approved_uses_json"])[0]
        use["semantic_projection_only"]["content_sha256"] = "0" * 64
        changed = dict(reviewed, approved_uses_json=json.dumps([use]))
        self.assertTrue(shared_scope_findings(changed, [changed], {}))

    def test_register_concept_is_not_concrete_programming_syntax(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "srs.md"
            for text, expected in (
                    ("The host accesses configuration and status through a register interface.", False),
                    ("Set the control register to select a channel.", True),
                    ("The field occupies bit 2.", True),
                    ("The target uses register CONTROL.", True),
                    ("Use register CHANNEL_CTRL at address 0x40.", True)):
                body = ["## 3. System Overview"]
                for index, heading in enumerate(SRS_SYSTEM_OVERVIEW_HEADINGS):
                    body.extend(["### " + heading, text if index == 3 else "Description."])
                body.append("## 4. Requirements")
                path.write_text("\n\n".join(body), encoding="utf-8")
                findings = validate_srs_system_overview(path)
                self.assertEqual("srs_system_overview_contains_implementation_detail" in findings, expected)

    def test_access_exclusivity_and_default_survive_register_syntax_abstraction(self):
        for bank, serial, bus in (("SENSOR_BANK", "LINK/R", "FABRIC"),
                                  ("MEASUREMENTS", "WIRE", "BUS-Q")):
            with self.subTest(bank=bank):
                statement = (
                    f"The {bank} registers are accessible by {serial} direct access and {bus} interface, "
                    f"while the others are only by {bus}. "
                    f"To reduce power consumption, the {bus} interface is disabled by default.")
                source = record("access", statement, evidence_scope="shared", approved_uses_json="[]")
                original = copy.deepcopy(source)
                profile = {"block_defs": {}, "governed_source_context": {"version": 1, "records": [source]}}
                raw = srs_source_evidence_model(source)
                self.assertEqual(len(raw.propositions), 3)
                abstraction = []
                model = abstract_srs_evidence_model(raw, audit_rows=abstraction)
                self.assertEqual(len(model.propositions), 3)
                self.assertFalse(model.unresolved_contexts)
                self.assertTrue(any(row["excluded_syntax"] for row in abstraction))
                reviewed = self.approve(source, profile, document="SRS", role="context")
                projected = project_shared_descriptive_uses(
                    [dict(reviewed, snapshot_id="fixed", admission_state="admitted")], document="SRS")
                sections = shared_document_descriptive_contributions(projected, document="SRS")
                prose = " ".join(sections["3.4"])
                self.assertNotIn(bank, prose)
                self.assertIn("source-specified register bank", prose)
                self.assertIn(serial, prose)
                self.assertIn("only through the " + bus, prose)
                self.assertIn("disabled by default", prose)
                self.assertIn("reduce power consumption", prose)
                self.assertNotIn("executes", prose)
                self.assertEqual(source, original)

    def test_access_parser_does_not_drop_unknown_restrictions_or_merge_multiple_banks(self):
        for tail in (" except when locked", " only after startup", " unless permission is granted"):
            source = record("guard", "The DATA registers are accessible by LINK direct access and BUS interface, "
                            "while the others are only by BUS" + tail + ".")
            self.assertFalse(srs_source_evidence_model(source).propositions)
        source = record("banks",
            "The BANK_A registers are accessible by LINK direct access and BUS interface, "
            "while the others are only by BUS. "
            "The BANK_B registers are accessible by WIRE direct access and MESH interface, "
            "while the others are only by MESH.")
        model = abstract_srs_evidence_model(srs_source_evidence_model(source))
        self.assertTrue(model.unresolved_contexts)
        self.assertFalse(any("source-specified register bank" == value.meaning.subject.removeprefix("The ")
                             for value in model.propositions))


if __name__ == "__main__":
    unittest.main()
