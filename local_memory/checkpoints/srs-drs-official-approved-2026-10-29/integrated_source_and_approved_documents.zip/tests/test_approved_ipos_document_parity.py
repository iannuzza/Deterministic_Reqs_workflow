import json
import subprocess
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

from spec_document_contract import drs_document_events
from workflow_routing import (
    IPOSFunctionalInput,
    build_ipos_normalized_records,
    compose_ipos_overview,
)


class ApprovedIPOSDocumentParityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        root = Path(__file__).resolve().parents[1]
        checkpoint = root / "local_memory" / "checkpoints" / "2026-10-27-main-controller-ipos-review-pass"
        manifest = json.loads((checkpoint / "checkpoint_manifest.json").read_text(encoding="utf-8"))
        with zipfile.ZipFile(checkpoint / manifest["archive"]) as archive:
            cls.approved_word = archive.read("pilot/digital_ipos_main-controller.docx")
            cls.records = json.loads(archive.read("pilot/materialization_audit.json"))["normalized_records"]
        inventory = {row["record_id"]: row for row in cls.records
                     if row["record_id"].startswith("inventory:")}
        requirements = [row for row in cls.records if row["record_id"].startswith("requirement:")]
        local, shared = [], []
        for row in cls.records:
            if not row["record_id"].startswith("source-context:"):
                continue
            metadata = json.loads(row["provenance"][1])
            destination = shared if "consumer_document" in metadata else local
            destination.append((row["record_id"].removeprefix("source-context:"),
                                row["text"], row["provenance"][1]))
        prefix = "requirement:Main Controller:"
        cls.functional = IPOSFunctionalInput(
            block="Main Controller",
            domain="digital",
            function=inventory["inventory:function"]["text"],
            inputs=inventory["inventory:inputs"]["text"],
            outputs=inventory["inventory:outputs"]["text"],
            local_requirement_ids=tuple(row["record_id"].removeprefix(prefix) for row in requirements),
            local_requirement_evidence=tuple(row["text"] for row in requirements),
            candidate_requirement_records=tuple(
                ("Main Controller", row["record_id"].removeprefix(prefix),
                 row["text"], row["provenance"][1]) for row in requirements),
            materialized=True,
            provenance=tuple(inventory["inventory:function"]["provenance"][1:]),
            descriptive_source_records=tuple(local),
            shared_context_records=tuple(shared),
        )

    @staticmethod
    def section(events, number):
        result = []
        active = False
        for event in events:
            if event["kind"] == "heading":
                title = event["text"]
                if title.startswith(number + " "):
                    active = True
                elif active and not title.startswith(number + "."):
                    break
            if active:
                result.append(event)
        return result

    def test_exact_approved_word_sections_are_reproduced_from_frozen_inputs(self):
        sections, _audit = compose_ipos_overview(self.functional)
        paragraphs = []
        for number, name, title in (
            ("1.2", "scope", "Supported functions and scope"),
            ("1.4", "internal_functions", "Supported block functions"),
        ):
            paragraphs.extend(["### " + number + " " + title, *sections[name]])
        with tempfile.TemporaryDirectory() as directory:
            directory = Path(directory)
            reference = directory / "approved.docx"
            reference.write_bytes(self.approved_word)
            markdown = directory / "generated.md"
            markdown.write_text("\n\n".join(paragraphs), encoding="utf-8")
            word = directory / "generated.docx"
            subprocess.run(["pandoc", str(markdown), "--to=docx", "--output", str(word)],
                           check=True, capture_output=True, text=True)
            expected = drs_document_events(reference)
            actual = drs_document_events(word)
            for number in ("1.2", "1.4"):
                with self.subTest(section=number):
                    approved = self.section(expected, number)
                    self.assertTrue(approved)
                    self.assertEqual(self.section(actual, number), approved)

    def test_frozen_input_texts_and_provenance_are_not_replaced_by_approved_prose(self):
        records = build_ipos_normalized_records(self.functional)
        self.assertEqual(
            {row.record_id: (row.text, row.provenance) for row in records},
            {row["record_id"]: (row["text"], tuple(row["provenance"])) for row in self.records},
        )


if __name__ == "__main__":
    unittest.main()
