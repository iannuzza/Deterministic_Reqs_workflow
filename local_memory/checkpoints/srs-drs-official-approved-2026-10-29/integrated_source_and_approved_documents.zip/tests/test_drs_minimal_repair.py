import copy
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from governed_descriptive_scope import project_shared_descriptive_uses
from spec_document_contract import (
    assess_descriptive_synthesis, load_descriptive_synthesis_contract,
    validate_descriptive_synthesis_contract,
)
from test_governed_descriptive_scope import admitted, record
from test_spec_document_contract import _write_docx
from workflow_routing import (
    compose_document_responsibilities,
    document_domain_catalogues,
    shared_descriptive_evidence_model,
)


class DRSMinimalRepairTests(unittest.TestCase):
    def use(self, statement, *, role="context", identity="processor-description"):
        source = record(identity, statement, evidence_scope="shared",
                        section_context_json=json.dumps([["5", "Digital overview"]]))
        source["approved_uses_json"] = json.dumps([{
            "use_id": "reviewed", "document": "DRS", "block": "", "domain": "digital",
            "role": role, "start": 0, "end": len(statement), "rationale": "Reviewed complete excerpt.",
        }])
        return project_shared_descriptive_uses(
            admitted({"governed_source_context": {"version": 1, "records": [source]}}),
            document="DRS")

    def evidence(self, uses, *, owner="Quartz Core", requirements=()):
        return {
            "document": "DRS", "snapshot_id": "synthetic-approved",
            "architecture_fingerprint": "synthetic-architecture",
            "inventory": [{
                "owner": owner, "statement": "Connection Matrix Destination Source",
                "inputs": "sample data", "outputs": "processed results",
                "entity_kind": "concrete_block", "domains": ["digital"], "applicable": True,
                "scope": "allocated_owner", "source": "approved architecture",
            }],
            "requirements": list(requirements), "shared_records": list(uses),
            "function_decomposition": [], "interactions": [], "local_records": [],
        }

    def processor(self, owner="Quartz Core", modal="can"):
        return (f"The advanced {owner} (24bit proprietary core) is a low-power programmable core "
                f"which {modal} execute spectral processing and classification algorithms at the edge.")

    def test_complete_processor_meaning_is_recovered_not_only_the_fragment_removed(self):
        uses = self.use(self.processor())
        model = shared_descriptive_evidence_model(uses, document="DRS")
        activities = [value.meaning for value in model.propositions if value.meaning.predicate == "execute"]
        self.assertEqual(len(activities), 1)
        meaning = activities[0]
        self.assertEqual(meaning.subject, "The advanced Quartz Core")
        self.assertEqual(meaning.modality, "can")
        self.assertIn("spectral processing and classification algorithms at the edge",
                      " ".join(meaning.objects))
        self.assertFalse(model.unresolved_contexts)

    def test_recovered_purpose_uses_approved_description_without_rewriting_inventory(self):
        uses = self.use(self.processor())
        evidence = self.evidence(uses)
        original = copy.deepcopy(evidence)
        paragraphs, audit = compose_document_responsibilities(evidence, document="DRS")
        self.assertIn("#### Quartz Core", paragraphs)
        self.assertIn("Quartz Core can execute spectral processing and classification algorithms at the edge.",
                      paragraphs)
        selected = next(row for row in audit if row.get("owner") == "Quartz Core")
        self.assertEqual(selected["association_rule"], "approved_description_function_fallback")
        self.assertTrue(any(span["record_id"] == uses[0]["record_id"] for span in selected["spans"]))
        self.assertEqual(selected["source"], uses[0]["record_id"])
        self.assertEqual(selected["inventory_source"], "approved architecture")
        self.assertEqual(evidence, original)

    def test_context_mapping_needs_the_explicit_DRS_contract_amendment(self):
        uses = self.use(self.processor())
        policy = load_descriptive_synthesis_contract("DRS")
        policy.pop("context_placement", None)
        with patch("spec_document_contract.load_descriptive_synthesis_contract", return_value=policy):
            paragraphs, _audit = compose_document_responsibilities(self.evidence(uses), document="DRS")
        self.assertNotIn("#### Quartz Core", paragraphs)
        functions = self.use(self.processor(), role="functions")
        with patch("spec_document_contract.load_descriptive_synthesis_contract", return_value=policy):
            paragraphs, _audit = compose_document_responsibilities(self.evidence(functions), document="DRS")
        self.assertIn("#### Quartz Core", paragraphs)

    def test_same_owner_requirement_fallback_preserves_conditions(self):
        owner = "Measurement Engine"
        requirement = {
            "source_req_id": "MEASURE-01", "source": "approved snapshot", "applicable": True,
            "requirement_statement": f"When capture is enabled, {owner} shall process sampled measurements.",
            "allocation": {"approved_block": owner, "owning_target": "DRS"},
        }
        paragraphs, audit = compose_document_responsibilities(
            self.evidence((), owner=owner, requirements=(requirement,)), document="DRS")
        self.assertIn("When capture is enabled, measurement Engine processes sampled measurements.", paragraphs)
        self.assertTrue(any(row.get("association_rule") == "approved_requirement_function_fallback"
                            for row in audit))
        foreign = copy.deepcopy(requirement)
        foreign["allocation"]["approved_block"] = "Other Engine"
        paragraphs, _ = compose_document_responsibilities(
            self.evidence((), owner=owner, requirements=(foreign,)), document="DRS")
        self.assertNotIn("#### Measurement Engine", paragraphs)

    def test_overlapping_sources_do_not_duplicate_function_or_lose_contributors(self):
        first = self.use(self.processor(), identity="first-excerpt")
        second = self.use(self.processor(), identity="second-excerpt")
        paragraphs, audit = compose_document_responsibilities(
            self.evidence((*first, *second)), document="DRS")
        sentence = "Quartz Core can execute spectral processing and classification algorithms at the edge."
        self.assertEqual(paragraphs.count(sentence), 1)
        selected = next(row for row in audit if row.get("owner") == "Quartz Core")
        self.assertEqual({span["record_id"] for span in selected["spans"]},
                         {first[0]["record_id"], second[0]["record_id"]})

    def test_complete_source_recovers_function_while_fragment_remains_only_source_context(self):
        fragment = "main benefits of the Quartz Core are programming tools and an external software ecosystem."
        complete = self.use(self.processor() + " The " + fragment, identity="complete-source")
        truncated = self.use(fragment, identity="historical-fragment")
        paragraphs, audit = compose_document_responsibilities(
            self.evidence((*complete, *truncated)), document="DRS")
        sentence = "Quartz Core can execute spectral processing and classification algorithms at the edge."
        self.assertEqual(paragraphs.count(sentence), 1)
        self.assertNotIn("benefits", " ".join(paragraphs))
        selected = next(row for row in audit if row.get("owner") == "Quartz Core")
        self.assertEqual({span["record_id"] for span in selected["spans"]},
                         {complete[0]["record_id"]})
        fragment_only, _ = compose_document_responsibilities(self.evidence(truncated), document="DRS")
        self.assertNotIn("#### Quartz Core", fragment_only)

    def test_unknown_or_cross_document_placement_policy_is_rejected(self):
        policy = load_descriptive_synthesis_contract("DRS")
        policy.pop("contract_sha256")
        self.assertEqual(validate_descriptive_synthesis_contract(
            {"document_type": "DRS", "descriptive_synthesis": policy}), policy)
        for document, value in (("DRS", "unrestricted"),
                                ("IPOS", "supported_local_function_v1"),
                                ("SRS", "supported_local_function_v1")):
            with self.subTest(document=document), self.assertRaises(ValueError):
                validate_descriptive_synthesis_contract({
                    "document_type": document,
                    "descriptive_synthesis": {**policy, "context_placement": value}})

    def test_incomplete_or_foreign_processor_is_not_completed_or_reassigned(self):
        for text in (
            self.processor("Other Engine"),
            self.processor().replace("which can execute", "which could execute"),
            self.processor().replace("spectral processing and classification algorithms at the edge.", "the"),
        ):
            with self.subTest(text=text):
                paragraphs, _ = compose_document_responsibilities(
                    self.evidence(self.use(text)), document="DRS")
                self.assertNotIn("#### Quartz Core", paragraphs)

    def test_conflicting_or_negative_description_never_establishes_a_positive_purpose(self):
        positive = self.use(self.processor(), identity="positive")
        negative = self.use(self.processor().replace("can execute", "can not execute"), identity="negative")
        for uses in (negative, (*positive, *negative)):
            paragraphs, _ = compose_document_responsibilities(self.evidence(uses), document="DRS")
            self.assertNotIn("#### Quartz Core", paragraphs)

    def test_independent_readback_rejects_lost_modality_or_wrong_execution_owner(self):
        uses = self.use(self.processor())
        evidence = self.evidence(uses)
        purpose, _ = compose_document_responsibilities(evidence, document="DRS")
        context = list(document_domain_catalogues(evidence, document="DRS")[0].values())
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "drs.md"
            for before, after in (("", ""), ("can execute", "executes"), ("Quartz Core can", "Other Core can")):
                paragraphs = ["# 3. Top Level Overview", *context, "# 3.1 Digital Main Functions", *purpose]
                changed = [value.replace(before, after) if before else value for value in paragraphs]
                path.write_text("\n\n".join(changed), encoding="utf-8")
                _write_docx(path.with_suffix(".docx"), changed)
                with patch("workflow_routing.compose_document_responsibilities",
                           side_effect=AssertionError("independent readback cannot call the producer")):
                    report = assess_descriptive_synthesis(path, "DRS", evidence)
                functional = [row for row in report["gaps"] if row["obligation"] in {
                    "semantic_fidelity", "essential_qualifications"}
                    and row.get("source") == uses[0]["record_id"]]
                self.assertEqual(bool(functional), bool(before), report["gaps"])

    def test_requirement_fallback_has_independent_source_mapping_and_quantity_check(self):
        requirement = {
            "source_req_id": "PROCESS-1", "source": "approved snapshot", "applicable": True,
            "requirement_statement": "When enabled, SpectralEngine shall process sampled data after 4 cycles.",
            "allocation": {"approved_block": "SpectralEngine", "owning_target": "DRS"},
        }
        evidence = self.evidence((), owner="SpectralEngine", requirements=(requirement,))
        purpose, _ = compose_document_responsibilities(evidence, document="DRS")
        context = list(document_domain_catalogues(evidence, document="DRS")[0].values())
        paragraphs = ["# 3. Top Level Overview", *context, "# 3.1 Digital Main Functions", *purpose]
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "drs.md"
            for changed in (False, True):
                output = [text.replace("4 cycles", "9 cycles") if changed else text for text in paragraphs]
                path.write_text("\n\n".join(output), encoding="utf-8")
                _write_docx(path.with_suffix(".docx"), output)
                report = assess_descriptive_synthesis(path, "DRS", evidence)
                mappings = [row for row in report["claim_to_source"]
                            if row["source"] == "requirement:SpectralEngine:PROCESS-1"]
                if not changed:
                    self.assertEqual(len(mappings), 2)
                    self.assertTrue(all(row["section"] == "3.1" for row in mappings))
                else:
                    self.assertTrue(any(row["obligation"] in {"semantic_fidelity", "essential_qualifications"}
                                        and row.get("source") == "requirement:SpectralEngine:PROCESS-1"
                                        for row in report["gaps"]))


if __name__ == "__main__":
    unittest.main()
