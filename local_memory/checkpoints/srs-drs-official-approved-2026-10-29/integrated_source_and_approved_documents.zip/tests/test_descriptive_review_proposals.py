import ast
import copy
import hashlib
import json
from datetime import datetime
from pathlib import Path
import tempfile
import unittest
from unittest.mock import MagicMock, patch
from zipfile import ZipFile

from openpyxl import Workbook, load_workbook
from openpyxl.workbook.protection import WorkbookProtection

from test_governed_descriptive_scope import fixture, admitted, record
from descriptive_review_proposals import (
    PROPOSAL_FIELDS, _seal, accepted_destination_rows, destination_proposals, requested_destination_rows,
)
from mapping_review_sync import (
    DESCRIPTIVE_SHEET, DESTINATIONS_SHEET, architecture_review_profile, prepare_shared_destinations,
    reviewed_descriptive_context, write_descriptive_review_sheet,
)
from governed_descriptive_scope import (
    CLASSIFICATION_FIELD, SHARED_CONTEXT_AUTHORIZATION, project_shared_descriptive_uses,
    validate_projected_shared_use, serialize_descriptive_destinations,
)
from approved_snapshot_resolver import validate_governed_source_context
from workflow_routing import (
    build_ipos_functional_input, compose_ipos_overview, build_ipos_normalized_records,
    build_ipos_semantic_units, shared_document_descriptive_contributions,
    validate_ipos_descriptive_output, write_ipos_descriptive_audit,
    write_shared_descriptive_audit, validate_shared_descriptive_artifacts,
)


class DescriptiveReviewProposalTests(unittest.TestCase):
    def configuration_profile(self):
        statement = (
            "Set CAPTURE bit in Mode_Control register to 1 and FILTER to 0. "
            "This disconnects the sequencer from the processing unit. "
            "The input interface stores averaged samples in FIFO according to the user's configuration. "
            "Raw samples remain available except when FIFO FULL occurs."
        )
        source = record("qualified-mode", statement, evidence_scope="shared", approved_uses_json="[]",
                        section="4.2", section_context_json='[["4", "Operating modes"], ["4.2", "Capture Mode"]]')
        profile = {"block_defs": {"Vector Engine": {}, "Timing Hub": {}, "Other Unit": {}},
                   "governed_source_context": {"version": 1, "records": [source]}}
        request = dict(document="SRS, DRS, ARS", block="Vector Engine, Timing Hub", role="context",
                       excerpt=statement, start=0, end=len(statement), rationale="Reviewed mode and complete conditions.")
        return profile, source, request

    def test_qualified_mode_preserves_evidence_without_literal_synthesis_fallback(self):
        from test_spec_document_contract import _write_docx
        from spec_document_contract import write_materialization_audit, validate_materialization_chain

        profile, source, request = self.configuration_profile()
        rows = requested_destination_rows(request, source, [source], profile, list(profile["block_defs"]))
        self.assertEqual(len(rows), 5)
        self.assertTrue(all(row["support_status"] == "ready" for row in rows))
        for row in rows:
            row["review_decision"] = "approved"
        accepted = accepted_destination_rows(source, [source], rows, profile, list(profile["block_defs"]), [])
        source.update(serialize_descriptive_destinations(source, "shared", accepted))
        self.assertEqual(validate_governed_source_context(profile), [])
        sources = admitted(profile)
        for document in ("SRS", "DRS", "ARS"):
            projected = project_shared_descriptive_uses(sources, document=document)
            audit = []
            text = "\n".join(value for values in shared_document_descriptive_contributions(
                projected, document=document, audit_rows=audit).values() for value in values)
            if document == "ARS":
                self.assertIn("4.2 Capture Mode", text)
                self.assertTrue(text.endswith(source["statement"]))
            else:
                self.assertEqual(text, "")
                self.assertEqual(audit[0]["decision"], "projection_gap")
                self.assertIn("human review", audit[0]["reason"])
                self.assertEqual(audit[0]["statement"], source["statement"])
            self.assertEqual(projected[0]["statement"], source["statement"])
        for block, domain in (("Vector Engine", "digital"), ("Timing Hub", "analog")):
            projected = project_shared_descriptive_uses(sources, document="IPOS", block=block, domain=domain)
            inventory = {"Function": "perform measurement", "Inputs": "samples", "Outputs": "results"}
            functional = build_ipos_functional_input(block, inventory, domain=domain, shared_context_records=projected)
            sections, audit = compose_ipos_overview(functional)
            baseline, _ = compose_ipos_overview(build_ipos_functional_input(block, inventory, domain=domain))
            self.assertEqual(sections["functionality"], baseline["functionality"])
            self.assertEqual(sections["internal_functions"], baseline["internal_functions"])
            context = next(row for row in audit if row.get("unit_id", "").startswith("qualified-context:"))
            self.assertEqual(context["decision"], "projection_gap")
            self.assertEqual(context["rendered_summary"], "")
            self.assertIn("human review", context["reason"])
            self.assertNotIn(source["statement"], "\n".join(text for values in sections.values() for text in values))
            self.assertNotIn("Source mode/configuration context", str(sections))
            self.assertEqual(json.loads(context["normalized_record_json"])["statement"], source["statement"])
            normalized = build_ipos_normalized_records(functional)
            self.assertTrue(any(value.record_id == context["source_record_id"] and value.text == source["statement"]
                                for value in normalized))
            units = build_ipos_semantic_units(functional, sections, audit)
            self.assertFalse(any(source["statement"] in unit.text for unit in units))
            paragraphs = ["# 1. Block overview"]
            for key, title in (("functionality", "1.1 Functionality"),
                               ("scope", "1.2 Supported functions and scope")):
                paragraphs.extend(["# " + title, *sections[key]])
            with tempfile.TemporaryDirectory() as directory:
                path = Path(directory) / "ipos.md"
                audit_path = path.with_name("descriptive_summary_audit.csv")
                original = "\n\n".join(paragraphs) + "\n"
                path.write_text(original, encoding="utf-8")
                _write_docx(path.with_suffix(".docx"), paragraphs)
                write_ipos_descriptive_audit(audit_path, audit)
                self.assertEqual(validate_ipos_descriptive_output(path, audit_path, block, (), (), (), functional), [])
                _write_docx(path.with_suffix(".docx"), [text.replace("user's", "user\u2019s") for text in paragraphs])
                self.assertEqual(validate_ipos_descriptive_output(path, audit_path, block, (), (), (), functional), [])
                _write_docx(path.with_suffix(".docx"), paragraphs)
                materialization = path.with_name("materialization_audit.json")
                write_materialization_audit(materialization, "IPOS", normalized, units, path, path.with_suffix(".docx"))
                self.assertEqual(validate_materialization_chain(
                    materialization, "IPOS", normalized, path, path.with_suffix(".docx")), [])
                path.write_text(original + "\n" + source["statement"], encoding="utf-8")
                self.assertTrue(validate_ipos_descriptive_output(
                    path, audit_path, block, (), (), (), functional))
                path.write_text(original, encoding="utf-8")
                _write_docx(path.with_suffix(".docx"), [*paragraphs, source["statement"]])
                self.assertTrue(validate_ipos_descriptive_output(
                    path, audit_path, block, (), (), (), functional))
                _write_docx(path.with_suffix(".docx"), paragraphs)
                altered_audit = copy.deepcopy(audit)
                next(row for row in altered_audit if row.get("unit_id") == context["unit_id"])["rendered_summary"] = "Changed"
                write_ipos_descriptive_audit(audit_path, altered_audit)
                self.assertIn("ipos_qualified_context_audit_changed",
                              validate_ipos_descriptive_output(path, audit_path, block, (), (), (), functional))
        self.assertEqual(project_shared_descriptive_uses(sources, document="IPOS", block="Other Unit"), ())

    def test_qualified_document_context_is_independently_checked_with_heading_settings_and_exception(self):
        from docx import Document

        profile, source, request = self.configuration_profile()
        rows = requested_destination_rows(request, source, [source], profile, list(profile["block_defs"]))
        for row in rows:
            row["review_decision"] = "approved"
        source.update(serialize_descriptive_destinations(source, "shared", rows))
        for document in ("ARS",):
            projected = project_shared_descriptive_uses(admitted(profile), document=document)
            section, statements = next(iter(shared_document_descriptive_contributions(projected, document=document).items()))
            literal = statements[0]
            with self.subTest(document=document), tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                path = root / "document.md"
                original = "## " + section + " Context\n\n" + literal + "\n"
                path.write_text(original, encoding="utf-8")

                def write_document(text):
                    doc = Document()
                    doc.add_heading(section + " Context", level=2)
                    doc.add_paragraph(text)
                    doc.save(path.with_suffix(".docx"))

                write_document(literal)
                contract = MagicMock()
                contract.shared_descriptive_context.return_value = projected
                with patch("validate_downstream_coherence.resolve_downstream_contract", return_value=contract):
                    write_shared_descriptive_audit(path, projected, document=document, snapshot_id="snapshot-new")
                    self.assertEqual(validate_shared_descriptive_artifacts(
                        root, path, document=document, snapshot_id="snapshot-new"), [])
                    write_document(literal.replace("user's", "user\u2019s"))
                    self.assertEqual(validate_shared_descriptive_artifacts(
                        root, path, document=document, snapshot_id="snapshot-new"), [])
                    write_document(literal)
                    for before, after in (("4.2 Capture Mode", "4.2 Another Mode"), (" and FILTER to 0", ""),
                                          ("FILTER", "filter"),
                                          (" except when FIFO FULL occurs", "")):
                        path.write_text(original.replace(before, after), encoding="utf-8")
                        self.assertIn("shared_descriptive_excerpt_missing_or_changed:document.md:" + section,
                            validate_shared_descriptive_artifacts(root, path, document=document, snapshot_id="snapshot-new"))
                        path.write_text(original, encoding="utf-8")
                        write_document(literal.replace(before, after))
                        self.assertIn("shared_descriptive_excerpt_missing_or_changed:document.docx:" + section,
                            validate_shared_descriptive_artifacts(root, path, document=document, snapshot_id="snapshot-new"))
                        write_document(literal)

    def test_mode_context_does_not_authorize_clipping_normative_content_or_functional_promotion(self):
        profile, source, request = self.configuration_profile()
        catalogue = list(profile["block_defs"])
        variants = [
            (dict(source, section_context_json="[]"), request),
            (dict(source, section_context_json='[["mode", 42]]'), request),
            (dict(source, section_context_json='[["4", "Overview"]]'), request),
            (source, dict(request, role="functions")),
        ]
        for removed in (source["statement"].split(". ", 1)[0] + ". ",
                        " except when FIFO FULL occurs"):
            excerpt = source["statement"].replace(removed, "")
            if removed.startswith(" except"):
                # Keep an exact shorter prefix; it must not lose a trailing guard.
                excerpt = source["statement"][:source["statement"].index(removed)]
            start = source["statement"].index(excerpt)
            variants.append((source, dict(request, excerpt=excerpt, start=start, end=start + len(excerpt))))
        for suffix in (" The user shall select a channel.", " The module must stop.", "\n# Requirement", " | mode |"):
            changed = dict(source, statement=source["statement"] + suffix)
            variants.append((changed, dict(request, excerpt=changed["statement"], end=len(changed["statement"]))))
        for changed, selection in variants:
            with self.subTest(source=changed, selection=selection):
                rows = requested_destination_rows(selection, changed, [changed], profile, catalogue)
                self.assertTrue(all(row["support_status"] == "unsupported_descriptive_excerpt" for row in rows))

    def test_qualified_mode_snapshot_rechecks_missing_or_changed_qualification(self):
        profile, source, request = self.configuration_profile()
        rows = requested_destination_rows(request, source, [source], profile, list(profile["block_defs"]))
        for row in rows:
            row["review_decision"] = "approved"
        source.update(serialize_descriptive_destinations(source, "shared", rows))
        for change in ("missing", "changed", "functional", "clipped"):
            with self.subTest(change=change):
                altered = copy.deepcopy(profile)
                parent = altered["governed_source_context"]["records"][0]
                uses = json.loads(parent["approved_uses_json"])
                if change == "missing":
                    uses[0].pop("context_qualification")
                elif change == "changed":
                    uses[0]["context_qualification"]["headings"][-1][1] = "Another Mode"
                elif change == "functional":
                    uses[0]["role"] = "functions"
                else:
                    uses[0]["start"] = source["statement"].index("The input interface")
                parent["approved_uses_json"] = json.dumps(uses)
                self.assertIn("governed_source_context_invalid_configuration_context:qualified-mode",
                              validate_governed_source_context(altered))

    def test_policy_three_mode_approvals_survive_computed_status_refresh(self):
        profile, _source, request = self.configuration_profile()
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path = root / "review.xlsx"
            book = Workbook()
            book.save(path)
            book.close()
            write_descriptive_review_sheet(path, profile)
            prepare_shared_destinations(path, profile, profile, backup_path=root / "initial.xlsx")
            book = load_workbook(path)
            sheet = book[DESTINATIONS_SHEET]
            sheet["C2"], sheet["D2"] = request["document"], request["block"]
            book.save(path)
            book.close()
            prepare_shared_destinations(path, profile, profile, backup_path=root / "expanded.xlsx")
            records = reviewed_descriptive_context(path, profile, profile, for_proposals=True)["records"]
            book = load_workbook(path)
            catalogue = [row[0].value for row in book["Approved Block Choices"].iter_rows(min_row=2) if row[0].value]
            sheet = book[DESTINATIONS_SHEET]
            headers = {cell.value: cell.column for cell in sheet[1]}
            for cells in sheet.iter_rows(min_row=2):
                row = dict(zip(PROPOSAL_FIELDS, ("" if cell.value is None else str(cell.value) for cell in cells)))
                row.update(review_decision="approved" if row["document"] != "ARS" else "rejected",
                           support_status="unsupported_descriptive_excerpt")
                row["start"], row["end"] = int(row["start"]), int(row["end"])
                row["proposal_fingerprint"] = _seal(
                    row, records[0], records, profile, catalogue,
                    row["proposal_fingerprint"].partition(":")[0], policy=3)
                for field, column in headers.items():
                    sheet.cell(cells[0].row, column).value = row[field]
            book.save(path)
            book.close()
            prepared = prepare_shared_destinations(path, profile, profile, backup_path=root / "migrated.xlsx")
            self.assertEqual(prepared["pending"], 0)
            self.assertEqual(prepared["blocked"], 0)
            context = reviewed_descriptive_context(path, profile, profile)
            uses = json.loads(context["records"][0]["approved_uses_json"])
            self.assertEqual({(use["document"], use["block"]) for use in uses},
                             {("SRS", ""), ("DRS", ""), ("IPOS", "Vector Engine"), ("IPOS", "Timing Hub")})
            self.assertTrue(all("context_qualification" in use for use in uses))
            original = path.read_bytes()
            prepare_shared_destinations(path, profile, profile, backup_path=root / "again.xlsx")
            self.assertEqual(path.read_bytes(), original)

    def make_review(self, root):
        profile = fixture()
        parent = profile["governed_source_context"]["records"][-1]
        parent.update(evidence_scope="block_local", approved_uses_json="[]", review_decision="pending",
                      domain="digital", section_context_json='[["1", "System overview"]]')
        path = root / "review.xlsx"
        book = Workbook()
        book.save(path)
        book.close()
        write_descriptive_review_sheet(path, profile)
        book = load_workbook(path)
        sheet = book[DESCRIPTIVE_SHEET]
        headers = {cell.value: cell.column for cell in sheet[1]}
        sheet.cell(4, headers[CLASSIFICATION_FIELD]).value = "shared"
        sheet.cell(4, headers["review_decision"]).value = "approved"
        book.save(path)
        book.close()
        return path, profile

    def choose(self, path, decision="approved", *, document=None):
        book = load_workbook(path)
        sheet = book[DESTINATIONS_SHEET]
        headers = {cell.value: cell.column for cell in sheet[1]}
        for row in range(2, sheet.max_row + 1):
            if sheet.cell(row, 1).value and (document is None or sheet.cell(row, headers["document"]).value == document):
                sheet.cell(row, headers["review_decision"]).value = decision
        book.save(path)
        book.close()

    def test_generated_rows_are_pending_linked_and_require_human_acceptance(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path, profile = self.make_review(root)
            result = prepare_shared_destinations(path, profile, profile, backup_path=root / "backup.xlsx")
            self.assertEqual(result["pending"], 4)
            with self.assertRaisesRegex(ValueError, "await human"):
                reviewed_descriptive_context(path, profile, profile)
            book = load_workbook(path)
            sheet = book[DESTINATIONS_SHEET]
            self.assertEqual(tuple(cell.value for cell in sheet[1]), PROPOSAL_FIELDS)
            self.assertEqual({sheet.cell(row, 1).value for row in range(2, 5)}, {"shared-system"})
            self.assertTrue(sheet["G2"].protection.locked)
            self.assertFalse(sheet["L2"].protection.locked)
            book.close()
            self.choose(path)
            context = reviewed_descriptive_context(path, profile, profile)
            uses = json.loads(context["records"][-1]["approved_uses_json"])
            self.assertEqual({use["document"] for use in uses}, {"SRS", "DRS", "IPOS"})
            functional = next(use for use in uses if use["document"] == "IPOS")
            self.assertEqual(functional["role"], "functions")
            self.assertEqual(functional["supporting_record_ids"], ["local-compute"])
            again = prepare_shared_destinations(path, profile, profile, backup_path=root / "again.xlsx")
            self.assertEqual(again["pending"], 0)
            self.assertEqual(reviewed_descriptive_context(path, profile, profile), context)

    def test_rejection_is_not_serialized_and_changed_binding_resets_acceptance(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path, profile = self.make_review(root)
            prepare_shared_destinations(path, profile, profile, backup_path=root / "first.xlsx")
            self.choose(path)
            self.choose(path, "rejected", document="DRS")
            before = reviewed_descriptive_context(path, profile, profile)
            self.assertNotIn("DRS", [use["document"] for use in json.loads(before["records"][-1]["approved_uses_json"])])
            again = prepare_shared_destinations(path, profile, profile, backup_path=root / "again.xlsx")
            self.assertEqual(again["pending"], 0)
            book = load_workbook(path)
            book[DESCRIPTIVE_SHEET]["D4"] = "Changed applicability rationale."
            book.save(path)
            book.close()
            with self.assertRaisesRegex(ValueError, "refresh and review"):
                reviewed_descriptive_context(path, profile, profile)
            changed = prepare_shared_destinations(path, profile, profile, backup_path=root / "changed.xlsx")
            self.assertEqual(changed["pending"], 4)

    def test_preparation_requires_closed_excel_even_when_no_refresh_is_needed(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path, profile = self.make_review(root)
            prepare_shared_destinations(path, profile, profile, backup_path=root / "first.xlsx")
            before = path.read_bytes()
            path.with_name("~$" + path.name).write_text("Excel lock", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "Save and close Excel"):
                prepare_shared_destinations(path, profile, profile, backup_path=root / "blocked.xlsx")
            self.assertEqual(path.read_bytes(), before)
            self.assertFalse((root / "blocked.xlsx").exists())

    def test_catalogue_mismatch_and_missing_local_support_cannot_be_approved(self):
        profile = fixture()
        record = profile["governed_source_context"]["records"][-1]
        record.update(evidence_scope="shared", domain="digital", statement="The Preview Unit exchanges samples.",
                      approved_uses_json="[]")
        rows = destination_proposals(record, profile["governed_source_context"]["records"],
                                     profile, ["System", "Digital", "Analog", "Preview Unit"])
        ipos = next(row for row in rows if row["document"] == "IPOS")
        self.assertEqual(ipos["support_status"], "needs_architecture_profile")
        self.assertEqual(ipos["review_decision"], "pending")
        ipos["review_decision"] = "approved"
        with self.assertRaisesRegex(ValueError, "lacks supporting"):
            accepted_destination_rows(record, profile["governed_source_context"]["records"], [ipos],
                                      profile, ["System", "Digital", "Analog", "Preview Unit"], [])
        profile["block_defs"]["Preview Unit"] = {}
        rows = destination_proposals(record, profile["governed_source_context"]["records"],
                                     profile, ["Preview Unit"])
        self.assertEqual(next(row for row in rows if row["document"] == "IPOS")["support_status"], "ready")

    def test_changed_generated_destination_cannot_be_accepted(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path, profile = self.make_review(root)
            prepare_shared_destinations(path, profile, profile, backup_path=root / "backup.xlsx")
            self.choose(path)
            book = load_workbook(path)
            book[DESTINATIONS_SHEET]["C2"] = "ARS"
            book.save(path)
            book.close()
            with self.assertRaisesRegex(ValueError, "refresh and review"):
                reviewed_descriptive_context(path, profile, profile)
    def test_terms_alone_do_not_map_an_unnamed_owner(self):
        profile = fixture()
        record = profile["governed_source_context"]["records"][-1]
        record.update(evidence_scope="shared", domain="system",
                      statement="The system stores samples and controls acquisition.")
        rows = destination_proposals(record, profile["governed_source_context"]["records"],
                                     profile, ["Compute Unit", "Storage Unit"])
        self.assertEqual({row["document"] for row in rows}, {"SRS"})
        self.assertTrue(all(row["review_decision"] == "pending" for row in rows))
        self.assertFalse(any(row["block"] for row in rows))

    def test_documented_source_hierarchy_can_propose_context_without_term_ownership(self):
        profile = fixture()
        records = profile["governed_source_context"]["records"]
        records[0]["section"] = "1.2"
        parent = records[-1]
        parent.update(evidence_scope="shared", domain="system", section="1",
                      statement="The system stores samples and controls acquisition.")
        rows = destination_proposals(parent, records, profile, ["Compute Unit", "Storage Unit"])
        ipos = [row for row in rows if row["document"] == "IPOS"]
        self.assertEqual(len(ipos), 1)
        self.assertEqual(ipos[0]["block"], "Compute Unit")
        self.assertEqual(ipos[0]["role"], "context")
        records[0]["source_revision_id"] = "other-revision"
        rows = destination_proposals(parent, records, profile, ["Compute Unit", "Storage Unit"])
        self.assertFalse(any(row["document"] == "IPOS" for row in rows))

    def test_raw_metadata_hidden_catalogue_shared_and_other_package_parts_preserved(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path, profile = self.make_review(root)
            prepare_shared_destinations(path, profile, profile, backup_path=root / "backup.xlsx")
            book = load_workbook(path)
            sheet = book[DESCRIPTIVE_SHEET]
            headers = {cell.value: cell.column_letter for cell in sheet[1]}
            self.assertTrue(sheet.column_dimensions[headers["source_spans_json"]].hidden)
            self.assertTrue(sheet.column_dimensions[headers["content_sha256"]].hidden)
            self.assertFalse(sheet.column_dimensions[headers["record_id"]].hidden)
            self.assertFalse(sheet.column_dimensions[headers["statement"]].hidden)
            validation = next(value for value in sheet.data_validations.dataValidation if "B2" in value)
            self.assertEqual(validation.formula1, 'INDIRECT("\'Approved Block Choices\'!$A$2:$A$6")')
            book.close()
            with ZipFile(root / "backup.xlsx") as old, ZipFile(path) as new:
                changed = [name for name in old.namelist() if old.read(name) != new.read(name)]
                self.assertTrue(all(name.startswith("xl/worksheets/") or name == "xl/workbook.xml" for name in changed))

    def test_comma_or_space_lists_expand_independent_levels_and_blocks_then_require_review(self):
        for documents, blocks in (("SRS, DRS", "Compute Unit, Storage Unit"),
                                  ("SRS DRS", "Compute Unit Storage Unit")):
            with self.subTest(documents=documents), tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                path, profile = self.make_review(root)
                prepare_shared_destinations(path, profile, profile, backup_path=root / "first.xlsx")
                book = load_workbook(path)
                sheet = book[DESTINATIONS_SHEET]
                sheet["C2"], sheet["D2"], sheet["L2"] = documents, blocks, "approved"
                book.save(path)
                book.close()
                with self.assertRaisesRegex(ValueError, "refresh and review"):
                    reviewed_descriptive_context(path, profile, profile)
                result = prepare_shared_destinations(path, profile, profile, backup_path=root / "expanded.xlsx")
                self.assertGreaterEqual(result["pending"], 4)
                book = load_workbook(path)
                sheet = book[DESTINATIONS_SHEET]
                rows = [dict(zip(PROPOSAL_FIELDS, row)) for row in sheet.iter_rows(min_row=2, values_only=True) if row[0]]
                book.close()
                requested = [row for row in rows if row["use_id"].startswith("requested-")]
                self.assertEqual({(row["document"], row["block"] or "") for row in requested},
                                 {("SRS", ""), ("DRS", ""), ("IPOS", "Compute Unit"), ("IPOS", "Storage Unit")})
                self.assertTrue(all(row["review_decision"] == "pending" for row in requested))
                with self.assertRaisesRegex(ValueError, "await human"):
                    reviewed_descriptive_context(path, profile, profile)
                self.choose(path)
                context = reviewed_descriptive_context(path, profile, profile)
                projected = admitted(dict(profile, governed_source_context=context))
                for document in ("SRS", "DRS"):
                    self.assertTrue(project_shared_descriptive_uses(projected, document=document))
                for block in ("Compute Unit", "Storage Unit"):
                    self.assertTrue(project_shared_descriptive_uses(projected, document="IPOS", block=block))
                self.assertEqual(project_shared_descriptive_uses(projected, document="ARS"), ())
                again = prepare_shared_destinations(path, profile, profile, backup_path=root / "again.xlsx")
                self.assertEqual(again["pending"], 0)
                self.assertEqual(reviewed_descriptive_context(path, profile, profile), context)
                updated_profile = dict(profile, governed_source_context=context)
                result = prepare_shared_destinations(path, profile, updated_profile, backup_path=root / "profile.xlsx")
                self.assertEqual(result["pending"], 0)
                self.assertEqual(reviewed_descriptive_context(path, profile, updated_profile), context)

    def test_manual_block_lists_still_require_local_and_literal_functional_support(self):
        profile = fixture()
        records = profile["governed_source_context"]["records"]
        record = records[-1]
        row = dict(record_id=record["record_id"], document="SRS DRS", block="Compute Unit Storage Unit",
                   excerpt=record["statement"], start=0, end=len(record["statement"]), role="context",
                   rationale="Human-reviewed independent destinations.")
        catalogue = ["Compute Unit", "Storage Unit"]
        records[1]["review_decision"] = "pending"
        rows = requested_destination_rows(row, record, records, profile, catalogue)
        self.assertEqual(next(value for value in rows if value["block"] == "Storage Unit")["support_status"],
                         "ready")
        functional = records[0]["statement"]
        row.update(document="IPOS", role="functions", excerpt=functional,
                   start=record["statement"].index(functional), end=len(record["statement"]))
        records[1]["review_decision"] = "approved"
        rows = requested_destination_rows(row, record, records, profile, catalogue)
        self.assertEqual(next(value for value in rows if value["block"] == "Compute Unit")["support_status"], "ready")
        self.assertEqual(next(value for value in rows if value["block"] == "Storage Unit")["support_status"],
                         "needs_functional_evidence")
        blocked = next(value for value in rows if value["block"] == "Storage Unit")
        blocked["review_decision"] = "approved"
        with self.assertRaisesRegex(ValueError, "lacks supporting"):
            accepted_destination_rows(record, records, [blocked], profile, catalogue, [])

    def test_explicit_context_without_local_evidence_reaches_only_named_snapshot_destinations(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path = root / "review.xlsx"
            profile = {
                "block_defs": {"Vector Engine": {}, "Sample Frontend": {}, "Other Unit": {}},
                "governed_source_context": {"version": 1, "records": [
                    record("shared-overview", "The system supports measurement.",
                           evidence_scope="shared", approved_uses_json="[]"),
                ]},
            }
            book = Workbook()
            book.save(path)
            book.close()
            write_descriptive_review_sheet(path, profile)
            prepare_shared_destinations(path, profile, profile, backup_path=root / "initial.xlsx")
            book = load_workbook(path)
            sheet = book[DESTINATIONS_SHEET]
            sheet["C2"], sheet["D2"] = "SRS, DRS, ARS", "Vector Engine, Sample Frontend"
            book.save(path)
            book.close()
            prepared = prepare_shared_destinations(path, profile, profile, backup_path=root / "expanded.xlsx")
            self.assertEqual(prepared["destinations"], 6)
            self.assertEqual(prepared["blocked"], 0)
            with self.assertRaisesRegex(ValueError, "await human"):
                reviewed_descriptive_context(path, profile, profile)
            self.choose(path)
            context = reviewed_descriptive_context(path, profile, profile)
            self.assertEqual(validate_governed_source_context(dict(profile, governed_source_context=context)), [])
            uses = json.loads(context["records"][0]["approved_uses_json"])
            ipos = [use for use in uses if use["document"] == "IPOS"]
            self.assertEqual(len(ipos), 2)
            self.assertTrue(all(use["context_authorization"] == SHARED_CONTEXT_AUTHORIZATION for use in ipos))
            self.assertTrue(all(not use.get("supporting_record_ids") for use in ipos))
            sources = admitted(dict(profile, governed_source_context=context))
            for block, domain in (("Vector Engine", "digital"), ("Sample Frontend", "analog")):
                projected = project_shared_descriptive_uses(sources, document="IPOS", block=block, domain=domain)
                self.assertEqual(len(projected), 1)
                self.assertEqual(projected[0]["domain"], domain)
                validate_projected_shared_use(projected[0], document="IPOS", block=block, domain=domain)
                baseline, _ = compose_ipos_overview(build_ipos_functional_input(block, {}, domain=domain))
                sections, audit = compose_ipos_overview(build_ipos_functional_input(
                    block, {}, domain=domain, shared_context_records=projected))
                self.assertNotIn("The system supports measurement.", sections["scope"])
                self.assertTrue(any("does not establish block-local functional ownership" in row.get("reason", "")
                                    for row in audit))
                self.assertEqual(sections["functionality"], baseline["functionality"])
                self.assertEqual(sections["internal_functions"], baseline["internal_functions"])
            self.assertEqual(project_shared_descriptive_uses(sources, document="IPOS", block="Other Unit"), ())
            self.assertEqual(prepare_shared_destinations(
                path, profile, profile, backup_path=root / "again.xlsx")["pending"], 0)
            broken = copy.deepcopy(context)
            broken_uses = json.loads(broken["records"][0]["approved_uses_json"])
            selected = next(use for use in broken_uses if use["document"] == "IPOS")
            selected["role"] = "functions"
            selected["domain"] = "digital"
            broken["records"][0]["approved_uses_json"] = json.dumps(broken_uses)
            findings = validate_governed_source_context(dict(profile, governed_source_context=broken))
            self.assertIn("governed_source_context_missing_local_cross_reference:shared-overview", findings)
            selected["role"] = "context"
            selected.pop("context_authorization")
            broken["records"][0]["approved_uses_json"] = json.dumps(broken_uses)
            self.assertIn("governed_source_context_missing_local_cross_reference:shared-overview",
                          validate_governed_source_context(dict(profile, governed_source_context=broken)))

    def test_policy_migration_preserves_only_unchanged_sealed_context_dispositions(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path, profile = self.make_review(root)
            profile["governed_source_context"]["records"][1]["review_decision"] = "pending"
            previous_profile = copy.deepcopy(profile)
            del previous_profile["block_defs"]["Storage Unit"]
            book = load_workbook(path)
            book[DESCRIPTIVE_SHEET]["A3"] = "pending"
            book.save(path)
            book.close()
            prepare_shared_destinations(path, profile, profile, backup_path=root / "initial.xlsx")
            book = load_workbook(path)
            book[DESTINATIONS_SHEET]["C2"], book[DESTINATIONS_SHEET]["D2"] = "IPOS", "Storage Unit"
            book.save(path)
            book.close()
            prepare_shared_destinations(path, profile, profile, backup_path=root / "requested.xlsx")
            records = reviewed_descriptive_context(path, profile, profile, for_proposals=True)["records"]
            book = load_workbook(path)
            catalogue = [row[0].value for row in book["Approved Block Choices"].iter_rows(min_row=2) if row[0].value]
            sheet = book[DESTINATIONS_SHEET]
            headers = {cell.value: cell.column for cell in sheet[1]}
            for cells in sheet.iter_rows(min_row=2):
                row = dict(zip(PROPOSAL_FIELDS, ("" if cell.value is None else str(cell.value) for cell in cells)))
                if row["role"] != "context":
                    sheet.cell(cells[0].row, headers["review_decision"]).value = "rejected"
                    continue
                row["review_decision"] = "approved" if row["block"] == "Storage Unit" else "rejected"
                if row["block"] == "Storage Unit":
                    row["domain"] = ""
                    row["support_status"] = "needs_architecture_profile"
                row["start"], row["end"] = int(row["start"]), int(row["end"])
                kind = row["proposal_fingerprint"].partition(":")[0]
                row["proposal_fingerprint"] = _seal(
                    row, records[-1], records, previous_profile, catalogue, kind, policy=2)
                for field, column in headers.items():
                    sheet.cell(cells[0].row, column).value = row[field]
            book.save(path)
            book.close()
            prepare_shared_destinations(path, profile, previous_profile, backup_path=root / "migrated.xlsx")
            context = reviewed_descriptive_context(path, profile, profile)
            uses = json.loads(context["records"][-1]["approved_uses_json"])
            self.assertEqual({(use["document"], use["block"]) for use in uses}, {("IPOS", "Storage Unit")})

    def test_approved_context_does_not_override_descriptive_excerpt_integrity_checks(self):
        source = record("register-steps", "Set the control bit to start acquisition.",
                        evidence_scope="shared", approved_uses_json="[]")
        profile = {"block_defs": {"Vector Engine": {}}}
        row = dict(document="IPOS", block="Vector Engine", role="context", excerpt=source["statement"],
                   start=0, end=len(source["statement"]), rationale="Explicit human review.")
        rows = requested_destination_rows(row, source, [source], profile, ["Vector Engine"])
        rows[0]["review_decision"] = "approved"
        self.assertEqual(rows[0]["support_status"], "unsupported_descriptive_excerpt")
        with self.assertRaisesRegex(ValueError, "not a missing block-local evidence"):
            accepted_destination_rows(source, [source], rows, profile, ["Vector Engine"], [])

    def test_analog_level_and_arbitrary_catalogue_blocks_are_not_restricted_to_examples(self):
        blocks = ("Filter Engine", "Timing Hub")
        for levels, block_list in (("SRS, ARS", ", ".join(blocks)), ("SRS ARS", " ".join(blocks)),
                                   ("SRS, DRS, ARS", ", ".join(blocks))):
            with self.subTest(levels=levels), tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                path = root / "review.xlsx"
                profile = {
                    "block_defs": {block: {} for block in blocks},
                    "governed_source_context": {
                        "version": 1,
                        "records": [
                            record("filter-local", "The Filter Engine processes samples.", blocks[0], "digital"),
                            record("timing-local", "The Timing Hub coordinates sampling.", blocks[1], "digital"),
                            record("shared-context", "The system coordinates acquisition.",
                                   evidence_scope="shared", approved_uses_json="[]"),
                        ],
                    },
                }
                book = Workbook()
                book.save(path)
                book.close()
                write_descriptive_review_sheet(path, profile)
                prepare_shared_destinations(path, profile, profile, backup_path=root / "initial.xlsx")
                book = load_workbook(path)
                sheet = book[DESTINATIONS_SHEET]
                sheet["C2"], sheet["D2"] = levels, block_list
                book.save(path)
                book.close()
                result = prepare_shared_destinations(path, profile, profile, backup_path=root / "expanded.xlsx")
                expected_levels = set(levels.replace(",", " ").split())
                self.assertEqual(result["pending"], len(expected_levels) + len(blocks))
                self.assertEqual(result["blocked"], 0)
                self.choose(path)
                context = reviewed_descriptive_context(path, profile, profile)
                uses = json.loads(context["records"][-1]["approved_uses_json"])
                self.assertEqual({(use["document"], use.get("block", "")) for use in uses},
                                 {(document, "") for document in expected_levels}
                                 | {("IPOS", block) for block in blocks})
                projected = admitted(dict(profile, governed_source_context=context))
                self.assertEqual(project_shared_descriptive_uses(projected, document="ARS")[0]["domain"], "analog")
                for block in blocks:
                    self.assertTrue(project_shared_descriptive_uses(projected, document="IPOS", block=block))
                if "DRS" not in expected_levels:
                    self.assertEqual(project_shared_descriptive_uses(projected, document="DRS"), ())

    def test_editing_existing_approved_legacy_targets_is_not_silently_discarded(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            profile = fixture()
            path = root / "review.xlsx"
            book = Workbook()
            book.save(path)
            book.close()
            write_descriptive_review_sheet(path, profile)
            book = load_workbook(path)
            sheet = book[DESTINATIONS_SHEET]
            self.assertEqual(sheet["C3"].value, "DRS")
            sheet["C3"], sheet["D3"] = "SRS, DRS", "Compute Unit, Storage Unit"
            book.save(path)
            book.close()
            result = prepare_shared_destinations(path, profile, profile, backup_path=root / "expanded.xlsx")
            self.assertGreaterEqual(result["pending"], 4)
            self.choose(path)
            context = reviewed_descriptive_context(path, profile, profile)
            uses = json.loads(context["records"][-1]["approved_uses_json"])
            self.assertIn(("IPOS", "Storage Unit"), {(use["document"], use.get("block", "")) for use in uses})

    def test_requested_rejection_survives_refresh_and_new_level_requires_new_review(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path, profile = self.make_review(root)
            prepare_shared_destinations(path, profile, profile, backup_path=root / "first.xlsx")
            book = load_workbook(path)
            sheet = book[DESTINATIONS_SHEET]
            sheet["C2"], sheet["D2"] = "SRS DRS", "Compute Unit Storage Unit"
            book.save(path)
            book.close()
            prepare_shared_destinations(path, profile, profile, backup_path=root / "expanded.xlsx")
            self.choose(path)
            book = load_workbook(path)
            sheet = book[DESTINATIONS_SHEET]
            sheet["C2"] = "SRS ARS"
            book.save(path)
            book.close()
            changed = prepare_shared_destinations(path, profile, profile, backup_path=root / "changed.xlsx")
            self.assertEqual(changed["pending"], 1)
            self.choose(path, "rejected", document="ARS")
            context = reviewed_descriptive_context(path, profile, profile)
            self.assertNotIn("ARS", {use["document"] for use in json.loads(context["records"][-1]["approved_uses_json"])})
            again = prepare_shared_destinations(path, profile, profile, backup_path=root / "again.xlsx")
            self.assertEqual(again["pending"], 0)
            self.assertEqual(reviewed_descriptive_context(path, profile, profile), context)

    def test_unknown_and_ambiguous_choices_are_rejected_not_partially_mapped(self):
        profile = fixture()
        records = profile["governed_source_context"]["records"]
        record = records[-1]
        row = dict(document="SRS DRS", block="Compute Unit Storage Unit", excerpt=record["statement"],
                   start=0, end=len(record["statement"]), role="context", rationale="Explicit.")
        for changes, message in (({"document": "SRS UNKNOWN"}, "Unknown document"),
                                 ({"block": "Compute Unit Unknown Unit"}, "Unknown or ambiguous"),
                                 ({"block": "Compute Unit,,"}, "Empty block"),
                                 ({"block": "A B C"}, "Unknown or ambiguous")):
            with self.subTest(changes=changes), self.assertRaisesRegex(ValueError, message):
                requested_destination_rows(dict(row, **changes), record, records, profile,
                                           ["Compute Unit", "Storage Unit", "A", "B C", "A B", "C"])

    def test_all_workbook_protection_removed_but_source_edits_still_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path, profile = self.make_review(root)
            book = load_workbook(path)
            book.security = WorkbookProtection(lockStructure=True)
            for sheet in book:
                sheet.protection.sheet = True
            book.save(path)
            book.close()
            prepare_shared_destinations(path, profile, profile, backup_path=root / "protected.xlsx")
            book = load_workbook(path)
            self.assertFalse(book.security and book.security.lockStructure)
            self.assertTrue(all(not sheet.protection.sheet for sheet in book))
            sheet = book[DESCRIPTIVE_SHEET]
            headers = {cell.value: cell.column for cell in sheet[1]}
            sheet.cell(2, headers["statement"]).value = "Altered source text."
            book.save(path)
            book.close()
            with self.assertRaisesRegex(ValueError, "text/provenance was changed"):
                reviewed_descriptive_context(path, profile, profile)

    def test_missing_source_domains_report_cells_and_rationales_are_optional(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path, profile = self.make_review(root)
            prepare_shared_destinations(path, profile, profile, backup_path=root / "first.xlsx")
            self.choose(path)
            book = load_workbook(path)
            sheet = book[DESCRIPTIVE_SHEET]
            sheet["C2"], sheet["D2"], sheet["C4"], sheet["D4"] = "", "", "", ""
            book.save(path)
            book.close()
            before = path.read_bytes()
            for discovery in (False, True):
                with self.subTest(discovery=discovery), self.assertRaises(ValueError) as caught:
                    reviewed_descriptive_context(path, profile, profile, for_proposals=discovery)
                message = str(caught.exception)
                for address in ("C2", "C4"):
                    self.assertIn(DESCRIPTIVE_SHEET + "!" + address, message)
                for address in ("D2", "D4"):
                    self.assertNotIn(DESCRIPTIVE_SHEET + "!" + address, message)
                self.assertIn("digital, analog, mixed_signal or system", message)
                self.assertIn("not SRS/DRS/ARS/IPOS", message)
                self.assertIn("governed_source_context_invalid_domain", message)
            with self.assertRaisesRegex(ValueError, "Descriptive Content Review!C4"):
                prepare_shared_destinations(path, profile, profile, backup_path=root / "invalid.xlsx")
            self.assertEqual(path.read_bytes(), before)
            self.assertFalse((root / "invalid.xlsx").exists())
            book = load_workbook(path)
            sheet = book[DESCRIPTIVE_SHEET]
            sheet["C2"], sheet["C4"] = "digital", "system"
            book.save(path)
            book.close()
            result = prepare_shared_destinations(path, profile, profile, backup_path=root / "corrected.xlsx")
            self.assertGreater(result["pending"], 0)
            self.choose(path)
            context = reviewed_descriptive_context(path, profile, profile)
            self.assertEqual(context["records"][0]["review_rationale"], "")
            self.assertEqual(context["records"][-1]["review_rationale"], "")
            book = load_workbook(path)
            self.assertTrue(book[DESCRIPTIVE_SHEET].column_dimensions["D"].hidden)
            self.assertFalse(book[DESCRIPTIVE_SHEET].column_dimensions["A"].hidden)
            book.close()

    def test_draft_only_block_is_staged_without_mutation_or_invented_local_support(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path, draft = self.make_review(root)
            profile = copy.deepcopy(draft)
            del profile["block_defs"]["Compute Unit"]
            original = copy.deepcopy(profile)
            draft_original = copy.deepcopy(draft)
            staged = architecture_review_profile(draft, profile, workbook_path=path)
            self.assertEqual(profile, original)
            self.assertEqual(draft, draft_original)
            self.assertEqual(staged["block_defs"]["Compute Unit"], draft["block_defs"]["Compute Unit"])
            draft["block_defs"]["Storage Unit"] = {"function": "Unreviewed replacement."}
            draft["block_defs"]["Generic Unlisted Term"] = {"function": "Not an approved review choice."}
            refreshed = architecture_review_profile(draft, profile, workbook_path=path)
            self.assertNotIn("Generic Unlisted Term", refreshed["block_defs"])
            self.assertEqual(refreshed["block_defs"]["Storage Unit"],
                             profile["block_defs"]["Storage Unit"])
            result = prepare_shared_destinations(path, draft, profile, backup_path=root / "staged.xlsx")
            self.assertEqual(result["catalogue_profile_gaps"], [])
            self.assertEqual(result["blocked"], 0)
            self.assertEqual(profile, original)
            self.choose(path)
            self.assertIsNotNone(reviewed_descriptive_context(
                path, draft, architecture_review_profile(draft, profile, workbook_path=path)))
            records = draft["governed_source_context"]["records"]
            records[0]["review_decision"] = "pending"
            # The workbook classifies this parent as shared; its original draft is still local.
            parent = dict(records[-1], evidence_scope="shared")
            rows = destination_proposals(parent, records, staged, ["Compute Unit"])
            self.assertEqual(next(row for row in rows if row["document"] == "IPOS")["support_status"],
                             "ready")

    def test_explicit_gate_approval_persists_staged_block_and_cancellation_does_not(self):
        for reviewer in (None, "Human reviewer"):
            with self.subTest(reviewer=reviewer), tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                path, draft = self.make_review(root)
                old_profile = copy.deepcopy(draft)
                del old_profile["block_defs"]["Compute Unit"]
                prepare_shared_destinations(path, draft, old_profile, backup_path=root / "staged.xlsx")
                self.choose(path)
                environment = self.gate_environment(root, path, old_profile)
                environment["profile_draft"].write_text(json.dumps(draft), encoding="utf-8")
                environment["simpledialog"].askstring.return_value = reviewer
                environment["self"]._validate_mapping_preview_csv.return_value = []
                before = environment["approved_profile"].read_bytes()
                environment["approve_reviewed_mapping_csv"]()
                environment["self"]._show_error.assert_not_called()
                environment["simpledialog"].askstring.assert_called_once()
                self.assertIn("Compute Unit", environment["simpledialog"].askstring.call_args.args[1])
                if reviewer is None:
                    self.assertEqual(environment["approved_profile"].read_bytes(), before)
                    environment["self"]._sync_mapping_workbook_to_csv.assert_not_called()
                else:
                    approved = json.loads(environment["approved_profile"].read_text(encoding="utf-8"))
                    self.assertIn("Compute Unit", approved["block_defs"])
                    self.assertEqual(approved["approval"]["approved_by"], reviewer)
                    self.assertEqual(approved["approval"]["status"], "approved")
                    self.assertEqual(approved["governed_source_context"],
                                     reviewed_descriptive_context(path, draft, approved))
                    from validate_stage2_profile import _draft_review_sha256, validate_approval_evidence
                    draft["review_package"] = {"draft_profile_sha256": ""}
                    draft["review_package"]["draft_profile_sha256"] = _draft_review_sha256(draft)
                    environment["profile_draft"].write_text(json.dumps(draft), encoding="utf-8")
                    approved["approval"]["reviewed_draft_profile_sha256"] = draft["review_package"]["draft_profile_sha256"]
                    environment["approved_profile"].write_text(json.dumps(approved), encoding="utf-8")
                    self.assertEqual(validate_approval_evidence(environment["approved_profile"],
                        environment["profile_draft"], environment["mapping_preview"]), [])

    def gate_environment(self, root, path, profile):
        source = Path(__file__).resolve().parents[1] / "scripts" / "workflow_gui.py"
        tree = ast.parse(source.read_text(encoding="utf-8"))
        self.assertFalse(any(isinstance(node, ast.Constant) and node.value in {
            "Prepare Shared Destinations", "Add Shared Evidence Fields"}
                             for node in ast.walk(tree)))
        self.assertFalse(any(isinstance(node, ast.FunctionDef) and node.name == "add_shared_evidence_fields"
                             for node in ast.walk(tree)))
        names = {"prepare_shared_review", "approve_reviewed_mapping_csv"}
        functions = [node for node in ast.walk(tree) if isinstance(node, ast.FunctionDef) and node.name in names]
        profile_path, draft_path = root / "profile.json", root / "draft.json"
        profile_path.write_text(json.dumps(profile), encoding="utf-8")
        draft_path.write_text(json.dumps(profile), encoding="utf-8")
        mapping = path.with_suffix(".csv")
        mapping.write_text("requirement_id\nR1\n", encoding="utf-8")
        gui = MagicMock()
        gui.is_running = False
        environment = dict(
            self=gui, REPO_ROOT=root, profile_draft=draft_path, approved_profile=profile_path,
            mapping_workbook=path, mapping_preview=mapping, dialog=None,
            messagebox=MagicMock(), simpledialog=MagicMock(), datetime=datetime, json=json,
            reviewed_descriptive_context=reviewed_descriptive_context,
            architecture_review_profile=architecture_review_profile, hashlib=hashlib,
        )
        exec(compile(ast.Module(body=functions, type_ignores=[]), str(source), "exec"), environment)
        return environment

    def test_gui_enable_gate_prepares_then_stops_before_asking_for_approval(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path, profile = self.make_review(root)
            environment = self.gate_environment(root, path, profile)
            before = environment["approved_profile"].read_bytes()
            environment["approve_reviewed_mapping_csv"]()
            environment["self"]._open_mapping_workbook.assert_called_once_with(path, None)
            environment["self"]._sync_mapping_workbook_to_csv.assert_not_called()
            environment["simpledialog"].askstring.assert_not_called()
            self.assertEqual(environment["approved_profile"].read_bytes(), before)
            with self.assertRaisesRegex(ValueError, "await human"):
                reviewed_descriptive_context(path, profile, profile)

    def test_gui_blocked_destinations_marked_approved_stop_before_reviewer_and_csv_sync(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path, profile = self.make_review(root)
            prepare_shared_destinations(path, profile, profile, backup_path=root / "first.xlsx")
            profile["block_defs"]["Preview Unit"] = {}
            book = load_workbook(path)
            book["Approved Block Choices"].append(["Preview Unit"])
            book[DESTINATIONS_SHEET]["D2"] = "Preview Unit"
            book[DESTINATIONS_SHEET]["F2"] = "functions"
            book.save(path)
            book.close()
            prepared = prepare_shared_destinations(path, profile, profile, backup_path=root / "expanded.xlsx")
            self.assertGreater(prepared["blocked"], 0)
            self.choose(path)
            environment = self.gate_environment(root, path, profile)
            before = environment["approved_profile"].read_bytes()
            environment["approve_reviewed_mapping_csv"]()
            environment["self"]._sync_mapping_workbook_to_csv.assert_not_called()
            environment["simpledialog"].askstring.assert_not_called()
            environment["self"]._show_error.assert_called_once()
            message = environment["self"]._show_error.call_args.args[1]
            self.assertIn("Preview Unit", message)
            self.assertIn("needs_local_evidence", message)
            self.assertIn("reject this destination", message)
            self.assertEqual(environment["approved_profile"].read_bytes(), before)

if __name__ == "__main__":
    unittest.main()
