import json
import re
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

from test_spec_document_contract import _write_docx
from csv_artifacts import csv_artifact_reader
from workflow_routing import (
    build_ipos_functional_input, compose_ipos_overview, validate_ipos_descriptive_output,
    write_ipos_descriptive_audit, ipos_publication_quality_findings,
)


class FunctionalOpeningTests(unittest.TestCase):
    def example(self, domain="analog", owner="Charge Reader"):
        return build_ipos_functional_input(owner,
            {"Function": "Acquire measurements, process data, and write results."}, [
                {"source_req_id": "collect", "statement":
                 f"When acquisition_valid is high, {owner} shall accumulate measured inputs until target_count is reached."},
                {"source_req_id": "average", "statement":
                 f"When collected_count is equal to 12, {owner} shall average the acquired measurements."},
                {"source_req_id": "limit", "statement":
                 f"If reject_mode is set to 1, {owner} shall not subtract the reference measurement."},
            ], domain=domain)

    def materialize(self, directory, functional):
        sections, rows = compose_ipos_overview(functional)
        paragraphs = []
        for key, title in (("functionality", "1.1 Functionality"),
                           ("scope", "1.2 Supported functions and scope"),
                           ("internal_functions", "1.4 Supported block functions")):
            paragraphs.extend(["### " + title, *sections[key]])
        path = Path(directory) / "pilot.md"
        path.write_text("\n\n".join(paragraphs), encoding="utf-8")
        _write_docx(path.with_suffix(".docx"), paragraphs)
        audit = path.with_suffix(".csv")
        write_ipos_descriptive_audit(audit, rows)
        return path, audit, paragraphs, sections, rows

    def findings(self, path, audit, functional):
        return validate_ipos_descriptive_output(path, audit, functional.block,
            functional.local_requirement_evidence, functional.local_requirement_ids, (), functional)

    def test_complementary_meanings_form_a_functional_description_in_both_domains(self):
        for domain, owner in (("analog", "Charge Reader"), ("digital", "Sample Combiner")):
            with self.subTest(domain=domain):
                functional = self.example(domain, owner)
                sections, rows = compose_ipos_overview(functional)
                descriptions = [row for row in rows if row["decision"] == "function_explanation"]
                self.assertEqual(len(descriptions), 1)
                row = descriptions[0]
                intro = row["rendered_summary"]
                self.assertIn("forms results from acquired data", intro)
                self.assertIn("sample accumulation", intro)
                self.assertIn("sample averaging", intro)
                self.assertNotRegex(intro, r"\bWhen\b|\bIf\b|acquisition_valid|collected_count|reject_mode")
                self.assertNotRegex(intro, r"\bfunction (?:combines|provides)|\bcovers\b")
                proof = json.loads(row["functional_synthesis_json"])
                self.assertEqual(proof["status"], "SUPPORTED")
                self.assertGreaterEqual(len(proof["supporting_claim_ids"]), 2)
                detail = "\n".join(sections["internal_functions"])
                for phrase in ("acquisition_valid is high", "collected_count is equal to 12",
                               "target_count", "does not subtract"):
                    self.assertIn(phrase, detail)
                self.assertNotIn("conditional difference processing", intro)

    def test_actual_prose_and_production_audit_reject_false_purpose_or_lost_conditions(self):
        functional = self.example()
        with tempfile.TemporaryDirectory() as directory:
            path, audit, paragraphs, _sections, rows = self.materialize(directory, functional)
            self.assertEqual(self.findings(path, audit, functional), [])
            with csv_artifact_reader(audit) as reader:
                persisted = [row for row in reader if row["decision"] == "function_explanation"]
            self.assertTrue(persisted[0]["functional_claim_json"])
            self.assertTrue(persisted[0]["functional_synthesis_json"])
            intro = next(row["rendered_summary"] for row in rows if row["decision"] == "function_explanation")
            for artifact, before, after in (
                ("markdown", intro, "The function provides supported local behavior."),
                ("docx", "forms results from acquired data", "encrypts data for transmission"),
                ("markdown", "collected_count is equal to 12", "collected_count is equal to 13"),
                ("docx", "does not subtract", "subtracts"),
            ):
                with self.subTest(artifact=artifact, after=after):
                    changed = [text.replace(before, after) for text in paragraphs]
                    self.assertNotEqual(changed, paragraphs)
                    path.write_text("\n\n".join(changed if artifact == "markdown" else paragraphs), encoding="utf-8")
                    _write_docx(path.with_suffix(".docx"), changed if artifact == "docx" else paragraphs)
                    self.assertTrue(self.findings(path, audit, functional))

    def test_isolated_signal_relationship_reports_unsupported_synthesis_without_filler(self):
        functional = build_ipos_functional_input("Pulse Status", {"Function": "Report status."},
            [{"source_req_id": "flag", "statement": "When timer_ready is high, pulse_flag shall go high."}],
            domain="digital")
        sections, rows = compose_ipos_overview(functional)
        explanation = next(row for row in rows if row["decision"] == "function_explanation")
        proof = json.loads(explanation["functional_synthesis_json"])
        self.assertEqual(proof["status"], "UNSUPPORTED")
        self.assertIn("isolated control relationships", proof["unsupported"][0])
        self.assertEqual(explanation["rendered_summary"], "")
        self.assertIn("pulse_flag goes high", "\n".join(sections["internal_functions"]))
        self.assertTrue(any(row["decision"] == "projection_gap" for row in rows))

    def test_multiple_channel_explanations_do_not_repeat_generic_sentences(self):
        statements = [
            f"When {channel} Channel Operation is selected and mode is set to {mode}, acquire_enable shall go high and {count} acquisitions are required."
            for channel in ("PRESSURE", "CURRENT") for mode, count in ((0, 3), (1, 6))
        ]
        functional = build_ipos_functional_input("Measurement Core", {"Function": "Control measurements."},
            [{"source_req_id": "REQ-" + str(index), "statement": text}
             for index, text in enumerate(statements)], domain="analog")
        sections, rows = compose_ipos_overview(functional)
        intros = [row["rendered_summary"] for row in rows if row["decision"] == "function_explanation"
                  and json.loads(row["functional_synthesis_json"])["status"] == "SUPPORTED"]
        self.assertEqual(len(intros), 2)
        sentences = [sentence for intro in intros for sentence in re.split(r"(?<=[.!?])\s+", intro)]
        self.assertEqual(len(sentences), len(set(sentences)))
        self.assertFalse(any("duplicated_explanation" in finding for finding in
            ipos_publication_quality_findings({"1.4": " ".join(
                entry for entry in sections["internal_functions"] if not entry.startswith("#### "))})))


if __name__ == "__main__":
    unittest.main()
