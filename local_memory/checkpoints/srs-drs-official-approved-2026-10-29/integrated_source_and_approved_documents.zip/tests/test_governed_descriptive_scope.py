import copy
import csv
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import MagicMock, patch
from zipfile import ZipFile

from openpyxl import Workbook, load_workbook

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

from approved_snapshot_resolver import (
    resolve_governed_descriptive_context, validate_governed_source_context,
)
from governed_descriptive_scope import (
    CLASSIFICATION_FIELD, DESCRIPTIVE_REVIEW_FIELDS, DESTINATION_FIELDS, descriptive_destination_rows,
    project_shared_descriptive_uses, serialize_descriptive_destinations, validate_projected_shared_use,
)
from mapping_review_sync import (
    DESCRIPTIVE_SHEET, DESTINATIONS_SHEET, reviewed_descriptive_context, upgrade_descriptive_review_fields,
    write_descriptive_review_sheet,
)
from validate_downstream_coherence import DownstreamContract
from validate_stage2_profile import _draft_review_sha256, validate_approval_evidence
from workflow_routing import (
    build_ipos_functional_input, compose_ipos_overview, compose_srs_system_overview,
    shared_document_descriptive_contributions, validate_shared_descriptive_artifacts,
    verified_shared_descriptive_paragraphs,
    write_shared_descriptive_audit, validate_srs_system_overview, SRS_SYSTEM_OVERVIEW_HEADINGS,
)


def record(identity, statement, owner="", domain="system", **extra):
    return {
        "record_id": identity, "statement": statement,
        "content_sha256": hashlib.sha256(statement.encode()).hexdigest(),
        "source_file": "primary.pdf", "source_revision_id": "revision-1",
        "source_spans_json": json.dumps([{
            "page": 2, "line": 3, "text_file": "page2.txt", "artifact_sha256": "a" * 64,
        }]),
        "evidence_kind": "descriptive", "mapped_block": owner, "domain": domain,
        "review_decision": "approved", "review_rationale": "Reviewed source and scope.",
        **extra,
    }


def fixture():
    local = record("local-compute", "The Compute Unit controls acquisition.", "Compute Unit", "digital")
    other = record("local-storage", "The Storage Unit stores samples.", "Storage Unit", "digital")
    statement = "The system supports measurement. The Compute Unit controls acquisition."
    uses = [
        {"use_id": "system", "document": "SRS", "block": "", "domain": "system",
         "role": "purpose", "start": 0, "end": 32, "rationale": "System purpose."},
        {"use_id": "digital", "document": "DRS", "block": "", "domain": "digital",
         "role": "context", "start": 0, "end": 32, "rationale": "Digital subsystem context."},
        {"use_id": "compute-context", "document": "IPOS", "block": "Compute Unit", "domain": "digital",
         "role": "context", "start": 0, "end": 32, "supporting_record_ids": ["local-compute"],
         "rationale": "System context for the locally documented acquisition responsibility."},
    ]
    shared = record("shared-system", statement, evidence_scope="multi_level", approved_uses_json=json.dumps(uses))
    return {"block_defs": {"Compute Unit": {}, "Storage Unit": {}},
            "governed_source_context": {"version": 1, "records": [local, other, shared]}}


def admitted(profile, snapshot="snapshot-new"):
    return [dict(value, snapshot_id=snapshot, admission_state="admitted")
            for value in profile["governed_source_context"]["records"] if value["review_decision"] == "approved"]


def mutate_use(profile, **changes):
    value = profile["governed_source_context"]["records"][-1]
    uses = json.loads(value["approved_uses_json"])
    uses[-1].update(changes)
    value["approved_uses_json"] = json.dumps(uses)


def write_legacy_shared_audit(path, projected, *, document, snapshot_id):
    from workflow_routing import _shared_descriptive_audit

    payload = _shared_descriptive_audit(projected, document=document, snapshot_id=snapshot_id, legacy_literal=True)
    path.with_name("governed_shared_context_audit.json").write_text(json.dumps(payload), encoding="utf-8")


class GovernedDescriptiveScopeTests(unittest.TestCase):
    def test_shared_allows_both_reuse_dimensions_but_only_explicit_destinations(self):
        profile = fixture()
        shared = profile["governed_source_context"]["records"][-1]
        shared["evidence_scope"] = "shared"
        uses = json.loads(shared["approved_uses_json"])
        uses.append(dict(uses[-1], use_id="storage", block="Storage Unit", supporting_record_ids=["local-storage"]))
        shared["approved_uses_json"] = json.dumps(uses)
        self.assertEqual(validate_governed_source_context(profile), [])
        rows = admitted(profile)
        self.assertEqual(len(project_shared_descriptive_uses(rows, document="SRS")), 1)
        for block in ("Compute Unit", "Storage Unit"):
            self.assertEqual(len(project_shared_descriptive_uses(rows, document="IPOS", block=block, domain="digital")), 1)
        self.assertEqual(project_shared_descriptive_uses(rows, document="ARS"), ())
        self.assertEqual(project_shared_descriptive_uses(rows, document="IPOS", block="Unlisted Unit"), ())
        shared["approved_uses_json"] = "[]"
        self.assertIn("governed_source_context_shared_record_missing_uses:shared-system",
                      validate_governed_source_context(profile))

    def test_mapped_block_dropdown_lists_all_concrete_profile_blocks_and_allows_blank(self):
        profile = fixture()
        profile["block_defs"].update({"Unassigned": {}, "Zeta Unit": {}})
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "review.xlsx"
            book = Workbook()
            book.save(path)
            book.close()
            write_descriptive_review_sheet(path, profile)
            self.assertEqual(reviewed_descriptive_context(path, profile, profile), profile["governed_source_context"])
            book = load_workbook(path)
            sheet = book[DESCRIPTIVE_SHEET]
            choices = [value for value in sheet.data_validations.dataValidation if "B2" in value]
            self.assertEqual(len(choices), 1)
            self.assertEqual(choices[0].formula1, 'INDIRECT("\'Approved Block Choices\'!$A$2:$A$7")')
            self.assertEqual(str(choices[0].sqref), "B2:B4")
            self.assertTrue(choices[0].allowBlank)
            self.assertTrue(choices[0].showErrorMessage)
            self.assertFalse(choices[0].showDropDown)
            self.assertEqual(choices[0].errorStyle, "stop")
            inventory = [book["Approved Block Choices"].cell(row, 1).value for row in range(2, 8)]
            self.assertEqual(inventory, ["System", "Digital", "Analog", "Compute Unit", "Storage Unit", "Zeta Unit"])
            self.assertIsNone(sheet["B4"].value)
            book.close()

    def test_existing_structured_workbook_gets_owner_dropdown_without_changing_decisions(self):
        profile = fixture()
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path = root / "review.xlsx"
            book = Workbook()
            book.save(path)
            book.close()
            write_descriptive_review_sheet(path, profile)
            book = load_workbook(path)
            sheet = book[DESCRIPTIVE_SHEET]
            sheet.data_validations.dataValidation = [value for value in sheet.data_validations.dataValidation if "B2" not in value]
            book.save(path)
            book.close()
            before = reviewed_descriptive_context(path, profile, profile)
            backup = root / "backup.xlsx"
            self.assertTrue(upgrade_descriptive_review_fields(path, profile, profile, backup_path=backup))
            self.assertEqual(reviewed_descriptive_context(path, profile, profile), before)
            with ZipFile(backup) as old, ZipFile(path) as new:
                self.assertEqual(old.namelist(), new.namelist())
                self.assertEqual(set(name for name in old.namelist() if old.read(name) != new.read(name)),
                                 {"xl/worksheets/sheet2.xml", "xl/worksheets/sheet4.xml"})
            self.assertFalse(upgrade_descriptive_review_fields(path, profile, profile, backup_path=root / "unused.xlsx"))

    def test_single_record_dropdown_stays_unique_after_excel_range_normalization(self):
        profile = fixture()
        profile["governed_source_context"]["records"] = profile["governed_source_context"]["records"][:1]
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path = root / "review.xlsx"
            book = Workbook()
            book.save(path)
            book.close()
            write_descriptive_review_sheet(path, profile)
            book = load_workbook(path)
            book.save(path)
            book.close()
            upgrade_descriptive_review_fields(path, profile, profile, backup_path=root / "backup.xlsx")
            book = load_workbook(path)
            choices = [value for value in book[DESCRIPTIVE_SHEET].data_validations.dataValidation if "B2" in value]
            self.assertEqual(len(choices), 1)
            self.assertTrue(choices[0].allowBlank)
            book.close()

    def test_two_choice_dropdown_and_structured_rows_preserve_legacy_review_exactly(self):
        from openpyxl.styles import Protection
        profile = fixture()
        draft = copy.deepcopy(profile)
        draft["governed_source_context"]["records"][-1].update(
            evidence_scope="block_local", approved_uses_json="[]", review_decision="pending")
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path = root / "legacy.xlsx"
            book = Workbook()
            book.active.title = "Unrelated"
            book.active.append(["Keep", "=1+2"])
            sheet = book.create_sheet(DESCRIPTIVE_SHEET)
            choices = book.create_sheet("Approved Block Choices")
            choices.append(["approved_block choices"])
            for name in ("System", "Digital", "Analog", "Compute Unit", "Storage Unit"):
                choices.append([name])
            fields = list(DESCRIPTIVE_REVIEW_FIELDS) + sorted(
                set().union(*(value.keys() for value in profile["governed_source_context"]["records"]))
                - set(DESCRIPTIVE_REVIEW_FIELDS))
            sheet.append(fields)
            for record in profile["governed_source_context"]["records"]:
                sheet.append([record.get(field, "") for field in fields])
            for row in sheet.iter_rows(min_row=2):
                for cell, field in zip(row, fields):
                    cell.protection = Protection(locked=field not in DESCRIPTIVE_REVIEW_FIELDS)
            book.save(path)
            book.close()
            before = reviewed_descriptive_context(path, draft, profile)
            self.assertTrue(upgrade_descriptive_review_fields(path, draft, profile, backup_path=root / "backup.xlsx"))
            self.assertEqual(reviewed_descriptive_context(path, draft, profile), before)
            book = load_workbook(path)
            sheet = book[DESCRIPTIVE_SHEET]
            fields = {cell.value: cell.column for cell in sheet[1]}
            classification = sheet.cell(4, fields[CLASSIFICATION_FIELD])
            self.assertEqual(classification.value, "shared")
            self.assertFalse(classification.protection.locked)
            validations = [value for value in sheet.data_validations.dataValidation if classification.coordinate in value]
            self.assertEqual(len(validations), 1)
            self.assertEqual(validations[0].formula1, '"block_local,shared"')
            self.assertEqual(validations[0].errorStyle, "stop")
            self.assertTrue(validations[0].showErrorMessage)
            self.assertFalse(validations[0].allowBlank)
            self.assertEqual(sheet.cell(4, fields["evidence_scope"]).value, "multi_level")
            self.assertEqual(book[DESTINATIONS_SHEET]["C2"].value, "SRS")
            self.assertEqual(book[DESTINATIONS_SHEET]["G2"].value, "The system supports measurement.")
            book.close()
            with ZipFile(root / "backup.xlsx") as old, ZipFile(path) as new:
                self.assertEqual(old.read("xl/styles.xml"), new.read("xl/styles.xml"))
                self.assertEqual(old.read("xl/worksheets/sheet1.xml"), new.read("xl/worksheets/sheet1.xml"))

    def test_workbook_destination_edits_require_reapproval_and_do_not_grant_ownership(self):
        profile = fixture()
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path = root / "review.xlsx"
            book = Workbook()
            book.save(path)
            book.close()
            write_descriptive_review_sheet(path, profile)
            mapping = root / "review.csv"
            mapping.write_text("requirement_id\nR1\n", encoding="utf-8")
            draft_path, profile_path = root / "draft.json", root / "profile.json"
            draft_path.write_text(json.dumps(profile), encoding="utf-8")
            approved = copy.deepcopy(profile)
            approved["approval"] = {
                "status": "approved", "approved_by": "Human reviewer",
                "reviewed_draft_profile_sha256": _draft_review_sha256(profile),
                "reviewed_mapping_preview_csv_sha256": hashlib.sha256(mapping.read_bytes()).hexdigest(),
            }
            profile_path.write_text(json.dumps(approved), encoding="utf-8")
            self.assertEqual(validate_approval_evidence(profile_path, draft_path, mapping), [])
            book = load_workbook(path)
            sheet = book[DESTINATIONS_SHEET]
            sheet.delete_cols(12, 4)
            # New destination: exact excerpt with no manually authored offsets/JSON.
            values = descriptive_destination_rows(profile["governed_source_context"]["records"][-1])[-1]
            values.update(use_id="storage", block="Storage Unit", start="", end="",
                          supporting_record_ids="local-storage")
            for column, field in enumerate(DESTINATION_FIELDS, 1):
                sheet.cell(5, column).value = values[field]
            book.save(path)
            book.close()
            reviewed = reviewed_descriptive_context(path, profile, profile)
            shared = reviewed["records"][-1]
            self.assertEqual(shared["evidence_scope"], "shared")
            self.assertEqual(len(json.loads(shared["approved_uses_json"])), 4)
            self.assertEqual(shared["review_decision"], "approved")
            self.assertNotEqual(reviewed, profile["governed_source_context"])
            self.assertIn("Descriptive workbook decisions differ from the reviewed architecture profile",
                          validate_approval_evidence(profile_path, draft_path, mapping))
            # The edited profile is not approved merely because its source row was.
            self.assertNotEqual(_draft_review_sha256(dict(profile, governed_source_context=reviewed)),
                                _draft_review_sha256(profile))
            book = load_workbook(path)
            book[DESTINATIONS_SHEET]["K5"] = "local-compute"
            book.save(path)
            book.close()
            with self.assertRaisesRegex(ValueError, "invalid_local_cross_reference"):
                reviewed_descriptive_context(path, profile, profile)

    def test_long_multifunction_passage_does_not_classify_or_authorize_itself(self):
        profile = fixture()
        profile["governed_source_context"]["records"][-1].update(
            evidence_scope="block_local", approved_uses_json="[]", review_decision="pending")
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "review.xlsx"
            book = Workbook()
            book.save(path)
            book.close()
            write_descriptive_review_sheet(path, profile)
            self.assertEqual(reviewed_descriptive_context(path, profile, profile), profile["governed_source_context"])
            book = load_workbook(path)
            sheet = book[DESCRIPTIVE_SHEET]
            fields = {cell.value: cell.column for cell in sheet[1]}
            self.assertEqual(sheet.cell(4, fields[CLASSIFICATION_FIELD]).value, "block_local")
            self.assertEqual(sheet.cell(4, fields["review_decision"]).value, "pending")
            self.assertFalse(any(book[DESTINATIONS_SHEET].cell(2, column).value for column in range(1, 12)))
            sheet.cell(4, fields[CLASSIFICATION_FIELD]).value = "global"
            book.save(path)
            book.close()
            with self.assertRaisesRegex(ValueError, "block_local or shared"):
                reviewed_descriptive_context(path, profile, profile)

    def test_legacy_multiblock_can_add_a_level_only_as_an_explicit_changed_use(self):
        profile = fixture()
        shared = profile["governed_source_context"]["records"][-1]
        original = json.loads(shared["approved_uses_json"])
        uses = [original[-1], dict(original[-1], use_id="storage", block="Storage Unit",
                                 supporting_record_ids=["local-storage"])]
        shared.update(evidence_scope="multi_block", approved_uses_json=json.dumps(uses))
        rows = descriptive_destination_rows(shared)
        self.assertEqual(serialize_descriptive_destinations(shared, "shared", rows), {
            "evidence_scope": "multi_block", "approved_uses_json": shared["approved_uses_json"],
        })
        system_row = dict(rows[0], use_id="system", document="SRS", block="", domain="system",
                          role="purpose", supporting_record_ids="")
        shared.update(serialize_descriptive_destinations(shared, "shared", [*rows, system_row]))
        self.assertEqual(shared["evidence_scope"], "shared")
        self.assertEqual(validate_governed_source_context(profile), [])
        self.assertEqual(len(json.loads(shared["approved_uses_json"])), 3)

    def test_destination_rows_reject_formulas_unknown_parents_duplicates_and_changed_text(self):
        profile = fixture()
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "review.xlsx"
            book = Workbook()
            book.save(path)
            book.close()
            write_descriptive_review_sheet(path, profile)
            book = load_workbook(path)
            book[DESTINATIONS_SHEET].delete_cols(12, 4)
            book.save(path)
            book.close()
            baseline = path.read_bytes()
            for address, value, message in (
                ("A2", "unknown", "Unknown descriptive destination"),
                ("G2", "=1+2", "Formulas"),
                ("B3", "system", "duplicate destination"),
                ("G2", "An unapproved replacement.", "differs from immutable source"),
                ("H2", "0.5", "integer character offsets"),
            ):
                with self.subTest(address=address, value=value):
                    path.write_bytes(baseline)
                    book = load_workbook(path)
                    book[DESTINATIONS_SHEET][address] = value
                    book.save(path)
                    book.close()
                    with self.assertRaisesRegex(ValueError, message):
                        reviewed_descriptive_context(path, profile, profile)

    def test_repeated_excerpt_requires_explicit_offsets_and_crlf_is_preserved(self):
        sentence = "The system supports measurement."
        shared = record("shared", sentence + "\r\n" + sentence, evidence_scope="shared", approved_uses_json="[]")
        row = dict(record_id="shared", use_id="system", document="SRS", block="", domain="system",
                   role="purpose", excerpt=sentence, start="", end="", rationale="Reviewed.", supporting_record_ids="")
        with self.assertRaisesRegex(ValueError, "exactly once"):
            serialize_descriptive_destinations(shared, "shared", [row])
        row.update(start=0, end=len(sentence))
        compiled = serialize_descriptive_destinations(shared, "shared", [row])
        self.assertEqual(json.loads(compiled["approved_uses_json"])[0]["start"], 0)
        profile = fixture()
        shared = profile["governed_source_context"]["records"][-1]
        shared["statement"] = shared["statement"].replace(". The", ".\r\nThe")
        shared["content_sha256"] = hashlib.sha256(shared["statement"].encode()).hexdigest()
        uses = json.loads(shared["approved_uses_json"])
        uses[0]["end"] = len(shared["statement"])
        shared["approved_uses_json"] = json.dumps(uses)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "review.xlsx"
            book = Workbook()
            book.save(path)
            book.close()
            write_descriptive_review_sheet(path, profile)
            self.assertEqual(reviewed_descriptive_context(path, profile, profile), profile["governed_source_context"])
            book = load_workbook(path)
            self.assertEqual(book[DESTINATIONS_SHEET]["G2"].value, shared["statement"])
            book.close()

    def test_blank_owner_is_not_global_for_legacy_records(self):
        profile = fixture()
        shared = profile["governed_source_context"]["records"][-1]
        shared.pop("evidence_scope")
        shared.pop("approved_uses_json")
        self.assertIn("governed_source_context_unknown_owner:shared-system",
                      validate_governed_source_context(profile))

    def test_multilevel_approval_projects_only_explicit_documents_and_blocks(self):
        profile = fixture()
        self.assertEqual(validate_governed_source_context(profile), [])
        records = admitted(profile)
        for document, block, domain in (("SRS", "", "system"), ("DRS", "", "digital"),
                                        ("IPOS", "Compute Unit", "digital")):
            rows = project_shared_descriptive_uses(records, document=document, block=block, domain=domain)
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0]["statement"], "The system supports measurement.")
            self.assertNotIn("mapped_block", rows[0])
            validate_projected_shared_use(rows[0], document=document, block=block, domain=domain)
        self.assertEqual(project_shared_descriptive_uses(
            records, document="IPOS", block="Storage Unit", domain="digital"), ())

    def test_shared_evidence_requires_same_owner_approved_local_cross_reference(self):
        mutations = [
            {"supporting_record_ids": []},
            {"supporting_record_ids": ["missing"]},
            {"supporting_record_ids": ["local-storage"]},
            {"supporting_record_ids": ["shared-system"]},
            {"domain": "analog"},
            {"block": "Unknown"},
        ]
        for changes in mutations:
            with self.subTest(changes=changes):
                profile = fixture()
                mutate_use(profile, **changes)
                self.assertTrue(validate_governed_source_context(profile))
        profile = fixture()
        profile["governed_source_context"]["records"][0]["review_decision"] = "pending"
        self.assertTrue(validate_governed_source_context(profile))

    def test_functions_require_literal_local_support_not_shared_keywords(self):
        profile = fixture()
        mutate_use(profile, role="functions")
        self.assertIn("governed_source_context_functional_use_not_in_local_evidence:shared-system",
                      validate_governed_source_context(profile))
        mutate_use(profile, start=33, end=len(profile["governed_source_context"]["records"][-1]["statement"]))
        self.assertEqual(validate_governed_source_context(profile), [])
        rows = project_shared_descriptive_uses(admitted(profile), document="IPOS",
                                              block="Compute Unit", domain="digital")
        self.assertEqual(rows[0]["statement"], "The Compute Unit controls acquisition.")

    def test_partial_sentence_or_guard_removal_is_rejected(self):
        for changes in ({"start": 4}, {"end": 22}, {"end": "32"}, {"start": True}, {"role": "invented"}):
            with self.subTest(changes=changes):
                profile = fixture()
                mutate_use(profile, **changes)
                self.assertTrue(validate_governed_source_context(profile))

    def test_multi_block_requires_explicit_distinct_block_uses(self):
        profile = fixture()
        shared = profile["governed_source_context"]["records"][-1]
        uses = json.loads(shared["approved_uses_json"])[-1:]
        shared.update(evidence_scope="multi_block", approved_uses_json=json.dumps(uses))
        self.assertTrue(validate_governed_source_context(profile))
        uses.append(dict(uses[0], use_id="storage-context", block="Storage Unit",
                         supporting_record_ids=["local-storage"]))
        shared["approved_uses_json"] = json.dumps(uses)
        self.assertEqual(validate_governed_source_context(profile), [])
        for block in ("Compute Unit", "Storage Unit"):
            self.assertEqual(len(project_shared_descriptive_uses(
                admitted(profile), document="IPOS", block=block, domain="digital")), 1)

    def test_snapshot_scope_never_reads_working_or_newer_profile(self):
        old = fixture()
        old["governed_source_context"]["records"] = old["governed_source_context"]["records"][:2]
        new = fixture()
        with patch("approved_snapshot_resolver.resolve_approved_snapshot",
                   side_effect=lambda _root, snapshot_id: {"project_id": "P", "snapshot_id": snapshot_id}), \
                patch("approved_snapshot_resolver.resolve_snapshot_profile",
                      side_effect=lambda _root, snapshot: old if snapshot["snapshot_id"] == "old" else new):
            old_rows = resolve_governed_descriptive_context(Path("."), snapshot_id="old", project_id="P")
            new_rows = resolve_governed_descriptive_context(Path("."), snapshot_id="new", project_id="P")
        self.assertEqual(project_shared_descriptive_uses(old_rows, document="SRS"), ())
        self.assertEqual(len(project_shared_descriptive_uses(new_rows, document="SRS")), 1)
        self.assertEqual(new_rows[-1]["snapshot_id"], "new")
        new["governed_source_context"]["records"][-1]["review_decision"] = "pending"
        self.assertFalse(project_shared_descriptive_uses(admitted(new), document="SRS"))

    def test_projection_tampering_and_cross_snapshot_support_fail(self):
        profile = fixture()
        rows = project_shared_descriptive_uses(admitted(profile), document="IPOS", block="Compute Unit", domain="digital")
        changed = copy.deepcopy(rows[0])
        changed["statement"] = "The Compute Unit performs all system functions."
        with self.assertRaises(ValueError):
            validate_projected_shared_use(changed, document="IPOS", block="Compute Unit", domain="digital")
        changed = copy.deepcopy(rows[0])
        binding = json.loads(changed["provenance_json"])
        binding["supporting_records"][0]["snapshot_id"] = "other-snapshot"
        changed["provenance_json"] = json.dumps(binding)
        with self.assertRaisesRegex(ValueError, "snapshot mismatch"):
            validate_projected_shared_use(changed, document="IPOS", block="Compute Unit", domain="digital")

    def test_shared_ipos_context_does_not_become_local_function_or_purpose(self):
        profile = fixture()
        records = admitted(profile)
        local = [value for value in records if value.get("mapped_block") == "Compute Unit"]
        shared = project_shared_descriptive_uses(records, document="IPOS", block="Compute Unit", domain="digital")
        kwargs = dict(domain="digital", descriptive_source_records=local)
        baseline = build_ipos_functional_input("Compute Unit", {"Function": "Control acquisition."}, **kwargs)
        functional = build_ipos_functional_input(
            "Compute Unit", {"Function": "Control acquisition."}, shared_context_records=shared, **kwargs)
        before, _ = compose_ipos_overview(baseline)
        sections, audit = compose_ipos_overview(functional)
        self.assertEqual(sections["functionality"], before["functionality"])
        self.assertEqual(sections["internal_functions"], before["internal_functions"])
        self.assertNotIn("The system supports measurement.", sections["scope"])
        self.assertTrue(any("functional ownership" in row.get("reason", "") for row in audit))
        self.assertTrue(any("shared-system::compute-context" in row.get("source_record_id", "") for row in audit))
        without_local = build_ipos_functional_input(
            "Compute Unit", {"Function": "Control acquisition."}, domain="digital", shared_context_records=shared)
        with self.assertRaisesRegex(ValueError, "matching admitted local evidence"):
            compose_ipos_overview(without_local)

    def test_srs_and_drs_do_not_report_an_atomic_literal_as_synthesis(self):
        records = admitted(fixture())
        srs = project_shared_descriptive_uses(records, document="SRS")
        sections = compose_srs_system_overview(srs)
        self.assertNotIn("The system supports measurement.", sections["3.1 General System Description"])
        drs = project_shared_descriptive_uses(records, document="DRS")
        audit = []
        self.assertEqual(shared_document_descriptive_contributions(drs, document="DRS", audit_rows=audit), {})
        self.assertTrue(any(row["decision"] == "projection_gap" for row in audit))

    def test_shared_supported_facts_are_synthesized_and_unsupported_clauses_are_visible(self):
        from workflow_routing import descriptive_writing_quality

        statement = ("When acquisition is enabled, the system can acquire ECG samples. "
                     "When acquisition is enabled, the system can acquire PPG samples. "
                     "An unexplained construction without a supported relationship.")
        for document, domain, section in (("SRS", "system", "3.4"), ("DRS", "digital", "3"),
                                          ("ARS", "analog", "3")):
            with self.subTest(document=document):
                source = record("shared-acquisition", statement, evidence_scope="shared",
                                approved_uses_json=json.dumps([{
                                    "use_id": "context", "document": document, "block": "", "domain": domain,
                                    "role": "context", "start": 0, "end": len(statement),
                                    "rationale": "Reviewed shared acquisition context.",
                                }]))
                original = copy.deepcopy(source)
                projected = project_shared_descriptive_uses(
                    admitted({"governed_source_context": {"version": 1, "records": [source]}}), document=document)
                audit = []
                sections = shared_document_descriptive_contributions(projected, document=document, audit_rows=audit)
                self.assertEqual(sections, {section: [
                    "When acquisition is enabled, the system can acquire ECG samples and PPG samples."]})
                self.assertTrue(any(row["decision"] == "projection_gap"
                                    and "unsupported" in row["reason"] for row in audit))
                if document != "ARS":
                    self.assertEqual(descriptive_writing_quality(document, audit)["status"], "UNRESOLVED")
                self.assertEqual(source, original)
                self.assertNotIn(statement, str(sections))

    def test_shared_incomplete_sentence_does_not_become_successful_prose(self):
        profile = fixture()
        shared = profile["governed_source_context"]["records"][-1]
        statement = "The system supports measurement and"
        shared["statement"] = statement
        shared["content_sha256"] = hashlib.sha256(statement.encode()).hexdigest()
        uses = json.loads(shared["approved_uses_json"])
        for use in uses:
            use["end"] = len(statement)
        shared["approved_uses_json"] = json.dumps(uses)
        projected = project_shared_descriptive_uses(admitted(profile), document="DRS")
        audit = []
        self.assertEqual(shared_document_descriptive_contributions(
            projected, document="DRS", audit_rows=audit), {})
        self.assertTrue(any(row["decision"] == "projection_gap" for row in audit))

    def test_shared_power_keywords_cannot_expand_srs_approved_section(self):
        profile = fixture()
        shared = profile["governed_source_context"]["records"][-1]
        statement = ("The system supports power domains with independent power control. "
                     "The system supports supply coordination.")
        shared["statement"] = statement
        shared["content_sha256"] = hashlib.sha256(statement.encode()).hexdigest()
        uses = json.loads(shared["approved_uses_json"])
        for use in uses:
            use["end"] = len(statement)
        shared["approved_uses_json"] = json.dumps(uses)
        projected = project_shared_descriptive_uses(admitted(profile), document="SRS")
        baseline = compose_srs_system_overview(())
        actual = compose_srs_system_overview(projected, power_records=projected)
        for section in baseline:
            self.assertEqual(actual[section], baseline[section], section)

    def test_approved_shared_context_does_not_exempt_unrelated_repeated_scope(self):
        from validate_downstream_coherence import _check_ipos_cross_document_description_reuse

        profile = fixture()
        shared = profile["governed_source_context"]["records"][-1]
        shared["evidence_scope"] = "multi_block"
        uses = []
        for name, local in (("Compute Unit", "local-compute"), ("Storage Unit", "local-storage")):
            uses.append({"use_id": local, "document": "IPOS", "block": name, "domain": "digital",
                         "role": "context", "start": 0, "end": 32, "rationale": "Reviewed block context.",
                         "supporting_record_ids": [local]})
        shared["approved_uses_json"] = json.dumps(uses)
        records = admitted(profile)
        contract = MagicMock(snapshot_id="snapshot-new")
        contract.shared_descriptive_context.side_effect = lambda root, **kwargs: project_shared_descriptive_uses(records, **kwargs)
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            paths = {name: root / name for name in ("Compute Unit", "Storage Unit")}
            for name, path in paths.items():
                path.mkdir()
                projected = project_shared_descriptive_uses(records, document="IPOS", block=name)
                functional = build_ipos_functional_input(
                    name, {"Function": "Acquire samples."}, domain="digital",
                    descriptive_source_records=[value for value in records if value.get("mapped_block") == name],
                    shared_context_records=projected,
                )
                _, audit = compose_ipos_overview(functional)
                with (path / "descriptive_summary_audit.csv").open("w", newline="", encoding="utf-8") as handle:
                    writer = csv.DictWriter(handle, fieldnames=[
                        "decision", "source_record_id", "supporting_requirement_evidence_ids",
                    ], extrasaction="ignore")
                    writer.writeheader()
                    writer.writerows(audit)
            with patch("validate_downstream_coherence.created_ipos_block_directories",
                       side_effect=lambda root, stage: paths if stage == "Digital IPOS" else {}):
                for extra in ("", "\n\nRepeated unrelated subsystem behavior."):
                    for path in paths.values():
                        (path / "block.md").write_text(
                            "### 1.2 Supported functions and scope\n\n"
                            "- The system supports measurement." + extra + "\n\n### 1.3 Internal structure\n",
                            encoding="utf-8")
                    self.assertTrue(_check_ipos_cross_document_description_reuse(root))
                    findings = _check_ipos_cross_document_description_reuse(root, contract)
                    self.assertTrue(findings, "Unsupported shared context must not exempt literal reuse")

    def test_ars_and_analog_ipos_use_the_same_rules_without_digital_inheritance(self):
        profile = fixture()
        local = record("local-analog", "The Measurement Unit acquires samples.", "Measurement Unit", "analog")
        profile["block_defs"]["Measurement Unit"] = {}
        profile["governed_source_context"]["records"].insert(0, local)
        shared = profile["governed_source_context"]["records"][-1]
        uses = json.loads(shared["approved_uses_json"])
        uses.extend([
            {"use_id": "analog", "document": "ARS", "block": "", "domain": "analog",
             "role": "context", "start": 0, "end": 32, "rationale": "Analog system context."},
            {"use_id": "analog-block", "document": "IPOS", "block": "Measurement Unit", "domain": "analog",
             "role": "context", "start": 0, "end": 32, "supporting_record_ids": ["local-analog"],
             "rationale": "Context for documented measurement responsibility."},
        ])
        shared["approved_uses_json"] = json.dumps(uses)
        self.assertEqual(validate_governed_source_context(profile), [])
        records = admitted(profile)
        ars = project_shared_descriptive_uses(records, document="ARS")
        self.assertEqual(shared_document_descriptive_contributions(ars, document="ARS"),
                         {"3": ["The system supports measurement."]})
        analog = project_shared_descriptive_uses(records, document="IPOS", block="Measurement Unit", domain="analog")
        self.assertEqual(len(analog), 1)
        self.assertEqual(project_shared_descriptive_uses(
            records, document="IPOS", block="Measurement Unit", domain="digital"), ())
        functional = build_ipos_functional_input(
            "Measurement Unit", {"Function": "Acquire samples."}, domain="analog",
            descriptive_source_records=[value for value in records if value.get("mapped_block") == "Measurement Unit"],
            shared_context_records=analog)
        sections, _audit = compose_ipos_overview(functional)
        self.assertNotIn("The system supports measurement.", sections["scope"])
        self.assertTrue(any("functional ownership" in row.get("reason", "") for row in _audit))

    def test_downstream_contract_keeps_local_and_shared_authority_separate(self):
        contract = object.__new__(DownstreamContract)
        contract.snapshot_id = "snapshot-new"
        contract.expected = {
            "R1": {"approved_block": "Compute Unit", "owning_domain": "digital", "owning_target": "Digital IPOS"},
            "R2": {"approved_block": "Storage Unit", "owning_domain": "digital", "owning_target": "Digital IPOS"},
        }
        with patch("validate_downstream_coherence.resolve_governed_descriptive_context",
                   return_value=admitted(fixture())):
            local = contract.descriptive_context(Path("."), block="Compute Unit", domain="digital")
            self.assertEqual([value["record_id"] for value in local], ["local-compute"])
            shared = contract.shared_descriptive_context(
                Path("."), document="IPOS", block="Compute Unit", domain="digital")
            self.assertEqual(len(shared), 1)
            contract.expected = {}
            with self.assertRaisesRegex(RuntimeError, "outside approved IPOS scope"):
                contract.shared_descriptive_context(Path("."), document="IPOS", block="Compute Unit", domain="digital")

    def test_downstream_descriptive_domain_uses_approved_target_not_source_category(self):
        contract = object.__new__(DownstreamContract)
        contract.snapshot_id = "snapshot-new"
        records = admitted(fixture())
        for source_category in ("Digital", "dIgItAl", "Block", "System", "Analog", ""):
            with self.subTest(source_category=source_category):
                contract.expected = {
                    "R1": {"approved_block": "Compute Unit", "owning_domain": source_category,
                           "owning_target": "Digital IPOS"},
                }
                before = copy.deepcopy(records)
                with patch("validate_downstream_coherence.resolve_governed_descriptive_context",
                           return_value=records):
                    self.assertEqual([row["record_id"] for row in contract.descriptive_context(
                        Path("."), block="Compute Unit", domain="digital")], ["local-compute"])
                    self.assertEqual(len(contract.shared_descriptive_context(
                        Path("."), document="IPOS", block="Compute Unit", domain="digital")), 1)
                    self.assertEqual(contract.descriptive_context(
                        Path("."), block="Storage Unit", domain="digital"), ())
                self.assertEqual(records, before)

        contract.expected["R1"]["owning_target"] = "Analog IPOS"
        with patch("validate_downstream_coherence.resolve_governed_descriptive_context", return_value=records):
            with self.assertRaisesRegex(RuntimeError, "conflicts with approved ownership"):
                contract.descriptive_context(Path("."), block="Compute Unit", domain="digital")
            with self.assertRaisesRegex(RuntimeError, "outside approved IPOS scope"):
                contract.shared_descriptive_context(
                    Path("."), document="IPOS", block="Compute Unit", domain="digital")
        records[0]["domain"] = "analog"
        with patch("validate_downstream_coherence.resolve_governed_descriptive_context", return_value=records):
            self.assertEqual([row["record_id"] for row in contract.descriptive_context(
                Path("."), block="Compute Unit", domain="analog")], ["local-compute"])
            contract.expected = {}
            self.assertEqual(contract.descriptive_context(Path(".")), ())

    def test_approval_gate_binds_shared_review_fields_without_modifying_candidate_text(self):
        profile = fixture()
        draft = copy.deepcopy(profile)
        draft["governed_source_context"]["records"][-1].update(
            review_decision="pending", evidence_scope="block_local", approved_uses_json="[]")
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            mapping = root / "mapping.csv"
            mapping.write_text("requirement_id\nR1\n", encoding="utf-8")
            draft_path, profile_path = root / "draft.json", root / "profile.json"
            draft_path.write_text(json.dumps(draft), encoding="utf-8")
            profile["approval"] = {
                "status": "approved", "approved_by": "Human reviewer",
                "reviewed_draft_profile_sha256": _draft_review_sha256(draft),
                "reviewed_mapping_preview_csv_sha256": hashlib.sha256(mapping.read_bytes()).hexdigest(),
            }
            book = Workbook()
            book.save(mapping.with_suffix(".xlsx"))
            book.close()
            write_descriptive_review_sheet(mapping.with_suffix(".xlsx"), profile)
            profile_path.write_text(json.dumps(profile), encoding="utf-8")
            self.assertEqual(validate_approval_evidence(profile_path, draft_path, mapping), [])
            altered = copy.deepcopy(profile)
            mutate_use(altered, rationale="An unreviewed change.")
            profile_path.write_text(json.dumps(altered), encoding="utf-8")
            self.assertTrue(validate_approval_evidence(profile_path, draft_path, mapping))

    def test_document_audit_and_final_artifacts_are_independently_checked(self):
        from docx import Document
        from workflow_routing import document_descriptive_writing_quality, LEGACY_SHARED_DESCRIPTIVE_WRITING_RULE
        projected = project_shared_descriptive_uses(admitted(fixture()), document="DRS")
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            markdown = root / "document.md"
            markdown.write_text("## 3. Top Level Overview\n\nThe system supports measurement.\n", encoding="utf-8")
            doc = Document()
            doc.add_heading("3. Top Level Overview", level=2)
            doc.add_paragraph("The system supports measurement.")
            doc.save(markdown.with_suffix(".docx"))
            contract = MagicMock()
            contract.shared_descriptive_context.return_value = projected
            with patch("validate_downstream_coherence.resolve_downstream_contract", return_value=contract):
                write_legacy_shared_audit(markdown, projected, document="DRS", snapshot_id="snapshot-new")
                self.assertEqual(validate_shared_descriptive_artifacts(
                    root, markdown, document="DRS", snapshot_id="snapshot-new"), [])
                self.assertEqual(verified_shared_descriptive_paragraphs(
                    root, markdown, document="DRS", snapshot_id="snapshot-new"),
                    ({"3": {"The system supports measurement."}}, []))
                audit_path = markdown.with_name("governed_shared_context_audit.json")
                current_audit = audit_path.read_text(encoding="utf-8")
                legacy = json.loads(current_audit)
                legacy.pop("projections", None)
                legacy["rule"] = LEGACY_SHARED_DESCRIPTIVE_WRITING_RULE
                audit_path.write_text(json.dumps(legacy), encoding="utf-8")
                self.assertEqual(validate_shared_descriptive_artifacts(
                    root, markdown, document="DRS", snapshot_id="snapshot-new"), [])
                quality = document_descriptive_writing_quality(markdown, "DRS", [
                    {"section": section, "decision": "selected"} for section in ("3", "3.1")])
                self.assertEqual(quality["status"], "UNRESOLVED")
                self.assertTrue(any("legacy literal" in gap["reason"] for gap in quality["gaps"]))
                self.assertFalse(quality["generation_blocking"])
                audit_path.write_text(current_audit, encoding="utf-8")
                markdown.write_text("## 3. Top Level Overview\n\nThe system supports processing.\n", encoding="utf-8")
                findings = validate_shared_descriptive_artifacts(root, markdown, document="DRS", snapshot_id="snapshot-new")
                self.assertTrue(any("excerpt_missing_or_changed" in value for value in findings))
                audit = markdown.with_name("governed_shared_context_audit.json")
                changed = json.loads(audit.read_text(encoding="utf-8"))
                changed["records"][0]["statement"] = "The system supports processing."
                audit.write_text(json.dumps(changed), encoding="utf-8")
                self.assertIn("shared_descriptive_audit_changed", validate_shared_descriptive_artifacts(
                    root, markdown, document="DRS", snapshot_id="snapshot-new"))

    def test_shared_artifact_tables_do_not_crash_or_substitute_for_descriptive_prose(self):
        from docx import Document

        statement = "The system supports measurement. The system supports data exchange."
        for document, domain, section in (("SRS", "system", "3.4"), ("DRS", "digital", "3"),
                                           ("ARS", "analog", "3")):
            with self.subTest(document=document), tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                source = record("shared-context", statement, evidence_scope="shared",
                                approved_uses_json=json.dumps([{
                                    "use_id": "context", "document": document, "block": "", "domain": domain,
                                    "role": "context", "start": 0, "end": len(statement),
                                    "rationale": "Reviewed document context.",
                                }]))
                profile = {"governed_source_context": {"version": 1, "records": [source]}}
                projected = project_shared_descriptive_uses(admitted(profile), document=document)
                rendered = next(iter(shared_document_descriptive_contributions(projected, document=document).values()))[0]
                markdown = root / "document.md"

                def write_artifacts(prose):
                    markdown.write_text(
                        f"## {section} Context\n\n{prose}\n\n"
                        f"| Attribute | Description |\n|---|---|\n| Context | {statement} |\n",
                        encoding="utf-8",
                    )
                    doc = Document()
                    doc.add_heading(section + " Context", level=2)
                    doc.add_paragraph(prose)
                    table = doc.add_table(rows=2, cols=2)
                    table.cell(0, 0).text = "Attribute"
                    table.cell(0, 1).text = "Description"
                    table.cell(1, 0).text = "Context"
                    table.cell(1, 1).text = statement
                    doc.save(markdown.with_suffix(".docx"))

                contract = MagicMock()
                contract.shared_descriptive_context.return_value = projected
                with patch("validate_downstream_coherence.resolve_downstream_contract", return_value=contract):
                    write_shared_descriptive_audit(markdown, projected, document=document, snapshot_id="snapshot-new")
                    write_artifacts(rendered)
                    self.assertEqual(validate_shared_descriptive_artifacts(
                        root, markdown, document=document, snapshot_id="snapshot-new"), [])
                    write_artifacts("Different descriptive text.")
                    self.assertEqual(set(validate_shared_descriptive_artifacts(
                        root, markdown, document=document, snapshot_id="snapshot-new")), {
                            "shared_descriptive_excerpt_missing_or_changed:document.md:" + section,
                            "shared_descriptive_excerpt_missing_or_changed:document.docx:" + section,
                        })

    def test_srs_overview_separates_snapshot_verified_literal_context_from_authored_prose(self):
        from docx import Document

        statement = ("Set STORE_SEL bit in Mode_Config register to 1. "
                     "The user's samples remain available except when FIFO FULL occurs.")
        source = record(
            "shared-mode", statement, evidence_scope="shared",
            section_context_json=json.dumps([["8", "Functional Modes"], ["8.1", "Storage Mode"]]),
            approved_uses_json=json.dumps([{
                "use_id": "system-context", "document": "SRS", "block": "", "domain": "system",
                "role": "context", "start": 0, "end": len(statement),
                "rationale": "Reviewed complete source mode and its setup and limitations.",
            }]),
        )
        source.update(serialize_descriptive_destinations(source, "shared", [{
            **json.loads(source["approved_uses_json"])[0], "excerpt": statement,
            "review_decision": "approved", "support_status": "ready",
        }]))
        projected = project_shared_descriptive_uses(
            admitted({"governed_source_context": {"version": 1, "records": [source]}}), document="SRS")
        excerpt = shared_document_descriptive_contributions(projected, document="SRS", _legacy_literal=True)["3.4"][0]
        contract = MagicMock()
        contract.shared_descriptive_context.return_value = projected
        generic_findings = {
            "srs_system_overview_contains_implementation_detail",
            "srs_system_overview_contains_normative_or_raw_source_fragment",
        }
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            markdown = root / "system.md"

            def write_artifacts(*, shared=excerpt, extra="", section="3.4", docx_shared=None):
                lines = ["## 3. System Overview", ""]
                document = Document()
                document.add_heading("3. System Overview", level=2)
                for heading in SRS_SYSTEM_OVERVIEW_HEADINGS:
                    body = f"System description for {heading}."
                    lines.extend(["### " + heading, "", body, ""])
                    document.add_heading(heading, level=3)
                    document.add_paragraph(body)
                    if heading.startswith(section + " "):
                        lines.extend([shared, ""])
                        document.add_paragraph(shared if docx_shared is None else docx_shared)
                    if heading.startswith("3.1 ") and extra:
                        lines.extend([extra, ""])
                        document.add_paragraph(extra)
                lines.append("## 4. Detail")
                document.add_heading("4. Detail", level=2)
                markdown.write_text("\n".join(lines), encoding="utf-8")
                document.save(markdown.with_suffix(".docx"))
                write_legacy_shared_audit(markdown, projected, document="SRS", snapshot_id="snapshot-new")

            with patch("validate_downstream_coherence.resolve_downstream_contract", return_value=contract), \
                    patch("workflow_routing._validate_srs_fact_audit", return_value=[]), \
                    patch("workflow_routing.validate_srs_support_content", return_value=[]):
                write_artifacts()
                self.assertEqual(set(validate_srs_system_overview(markdown)), generic_findings)
                self.assertEqual(validate_srs_system_overview(
                    markdown, repo_root=root, snapshot_id="snapshot-new"), [])
                write_artifacts(shared=excerpt.replace("user's", "user\u2019s"))
                self.assertEqual(validate_srs_system_overview(
                    markdown, repo_root=root, snapshot_id="snapshot-new"), [])
                for extra in ("The device shall set EXTRA_FLAG register to 0x10.", excerpt):
                    with self.subTest(extra=extra):
                        write_artifacts(extra=extra)
                        findings = validate_srs_system_overview(
                            markdown, repo_root=root, snapshot_id="snapshot-new")
                        self.assertTrue(generic_findings <= set(findings))
                for changes in (
                    {"shared": excerpt.replace("STORE_SEL", "store_sel")},
                    {"shared": excerpt.rsplit(" except", 1)[0]},
                    {"docx_shared": "Changed context."},
                    {"section": "3.5"},
                    {"shared": excerpt + "\n\n" + excerpt},
                ):
                    with self.subTest(changes=changes):
                        write_artifacts(**changes)
                        findings = validate_srs_system_overview(
                            markdown, repo_root=root, snapshot_id="snapshot-new")
                        self.assertTrue(any("shared_" in value for value in findings))
                        self.assertTrue(generic_findings <= set(findings))
                write_artifacts()
                audit = markdown.with_name("governed_shared_context_audit.json")
                changed = json.loads(audit.read_text(encoding="utf-8"))
                changed["records"][0]["statement"] = "Forged local audit context."
                audit.write_text(json.dumps(changed), encoding="utf-8")
                findings = validate_srs_system_overview(
                    markdown, repo_root=root, snapshot_id="snapshot-new")
                self.assertIn("shared_descriptive_audit_changed", findings)
                self.assertTrue(generic_findings <= set(findings))
                write_artifacts()
                findings = validate_srs_system_overview(
                    markdown, repo_root=root, snapshot_id="snapshot-other")
                self.assertIn("shared_descriptive_audit_changed", findings)
                self.assertTrue(generic_findings <= set(findings))

    def test_drs_raw_fragment_scan_requires_unique_snapshot_verified_whole_paragraphs(self):
        from docx import Document
        from spec_document_contract import DRS_TEMPLATE, load_drs_contract, validate_drs_events

        statement = ("Set STORE_SEL bit in Mode_Config register to 1. "
                     "The controller supports two operating states: \u2022 acquire samples; \u2022 retain results.")
        source = record("shared-states", statement, evidence_scope="shared",
                        section_context_json=json.dumps([["8", "Functional Modes"], ["8.1", "Storage Mode"]]),
                        approved_uses_json=json.dumps([{
                            "use_id": "digital-context", "document": "DRS", "block": "", "domain": "digital",
                            "role": "context", "start": 0, "end": len(statement),
                            "rationale": "Reviewed complete digital context.",
                        }]))
        source.update(serialize_descriptive_destinations(source, "shared", [{
            **json.loads(source["approved_uses_json"])[0], "excerpt": statement,
            "review_decision": "approved", "support_status": "ready",
        }]))
        projected = project_shared_descriptive_uses(
            admitted({"governed_source_context": {"version": 1, "records": [source]}}), document="DRS")
        statement = shared_document_descriptive_contributions(projected, document="DRS", _legacy_literal=True)["3"][0]
        contract = MagicMock()
        contract.shared_descriptive_context.return_value = projected
        document_contract = load_drs_contract(Path(__file__).resolve().parents[1] / DRS_TEMPLATE)
        events = [
            {"kind": "heading", "level": 2, "text": "3. Top Level Overview"},
            {"kind": "paragraph", "text": statement},
        ]

        def raw_findings(verified=None, content=events):
            return [finding for finding in validate_drs_events(
                content, document_contract, [], verified_shared_paragraphs=verified)
                    if "raw snippet" in finding]

        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            markdown = root / "digital.md"

            def write_artifacts(*, text=statement, section="3", docx_text=None, duplicate=False):
                paragraphs = [text, text] if duplicate else [text]
                markdown.write_text(
                    "## " + section + " Context\n\n" + "\n\n".join(paragraphs) + "\n",
                    encoding="utf-8")
                document = Document()
                document.add_heading(section + " Context", level=2)
                for paragraph in paragraphs:
                    document.add_paragraph(paragraph if docx_text is None else docx_text)
                document.save(markdown.with_suffix(".docx"))
                write_legacy_shared_audit(markdown, projected, document="DRS", snapshot_id="snapshot-new")

            with patch("validate_downstream_coherence.resolve_downstream_contract", return_value=contract):
                self.assertTrue(raw_findings())
                write_artifacts()
                verified, findings = verified_shared_descriptive_paragraphs(
                    root, markdown, document="DRS", snapshot_id="snapshot-new")
                self.assertEqual(findings, [])
                self.assertEqual(raw_findings(verified), [])
                self.assertTrue(raw_findings(verified, [events[0], {
                    "kind": "paragraph", "text": statement + " Added unsupported detail.",
                }]))
                self.assertTrue(raw_findings(verified, [
                    {"kind": "heading", "level": 3, "text": "3.1 Other section"}, events[1],
                ]))
                for changes in (
                    {"text": statement.replace("results", "Results")},
                    {"text": statement.split(";")[0]},
                    {"text": "Additional detail. " + statement},
                    {"docx_text": "Changed context."},
                    {"section": "3.1"},
                    {"duplicate": True},
                ):
                    with self.subTest(changes=changes):
                        write_artifacts(**changes)
                        verified, findings = verified_shared_descriptive_paragraphs(
                            root, markdown, document="DRS", snapshot_id="snapshot-new")
                        self.assertTrue(findings)
                        self.assertEqual(verified, {})
                        self.assertTrue(raw_findings(verified))
                write_artifacts()
                audit = markdown.with_name("governed_shared_context_audit.json")
                payload = json.loads(audit.read_text(encoding="utf-8"))
                payload["records"][0]["statement"] = "Forged context."
                audit.write_text(json.dumps(payload), encoding="utf-8")
                self.assertIn("shared_descriptive_audit_changed", verified_shared_descriptive_paragraphs(
                    root, markdown, document="DRS", snapshot_id="snapshot-new")[1])
                write_artifacts()
                verified, findings = verified_shared_descriptive_paragraphs(
                    root, markdown, document="DRS", snapshot_id="snapshot-other")
                self.assertEqual(verified, {})
                self.assertIn("shared_descriptive_audit_changed", findings)

    def test_srs_drs_and_ars_writers_do_not_copy_unsupported_ordinary_shared_context(self):
        import run_ars_gen_spec_agent as ars
        import run_drs_gen_spec_agent as drs
        import run_srs_gen_spec_agent as srs
        from spec_document_contract import DRS_TEMPLATE, load_drs_contract
        from workflow_routing import apply_shared_spec_markdown_formatting

        profile = fixture()
        shared = profile["governed_source_context"]["records"][-1]
        uses = json.loads(shared["approved_uses_json"])
        uses.append({"use_id": "analog", "document": "ARS", "block": "", "domain": "analog",
                     "role": "context", "start": 0, "end": 32, "rationale": "Analog context."})
        statement = ("- The system supports power domains with independent power control: "
                     "\u2022 always-on acquisition; \u25cf retained samples.")
        shared["statement"] = statement
        shared["content_sha256"] = hashlib.sha256(statement.encode()).hexdigest()
        for use in uses:
            use["end"] = len(statement)
        shared["approved_uses_json"] = json.dumps(uses)
        records = admitted(profile)
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            ars_path = root / "analog.md"
            ars._write_ars_markdown(
                ars_path, "primary.pdf", "Example", "Reviewer", "snapshot-new", "0.1",
                [], {}, {}, [], [], [], {}, [], [], "go", [], {}, {},
                shared_descriptive_records=list(project_shared_descriptive_uses(records, document="ARS")),
            )
            self.assertNotIn(statement, ars_path.read_text(encoding="utf-8"))
            drs_path = root / "digital.md"
            drs._write_drs_markdown(
                drs_path, "primary.pdf", "Example", "Reviewer", "snapshot-new", "0.1",
                [], {}, [], {}, [], {}, [], {}, [],
                list(project_shared_descriptive_uses(records, document="DRS")),
                [], "go", [], {}, set(), {}, [], [],
                load_drs_contract(Path(__file__).resolve().parents[1] / DRS_TEMPLATE),
            )
            text = drs_path.read_text(encoding="utf-8")
            self.assertNotIn(statement, text)
            srs_path = root / "system.md"
            with patch.object(srs, "_structured_srs_low_power_records", return_value=[]):
                srs._write_srs_markdown(
                    output_path=srs_path,
                    template_path=Path(__file__).resolve().parents[1] / "templates" / "SRS_gen_AI_template_prompt.md",
                    source_spec="primary.pdf", project_name="Example", document_author="Reviewer",
                    requirements=[], srs_id_map={}, req_to_block={}, block_inventory_rows=[],
                    interface_rows=[], source_port_rows=[], interaction_rows=[],
                    connection_matrix_srs_ids={}, function_rows=[],
                    descriptive_records=list(project_shared_descriptive_uses(records, document="SRS")),
                    block_requirements={}, unmapped_requirements=[], user_specific_requirements=[],
                    non_block_context_rows=[], crosscheck_decision="PASS", missing_inputs=[],
                    mode_rows=[], approved_srs_source_ids=set(), snapshot_id="snapshot-new",
                    contract_fingerprint="test-contract", document_version="0.1",
                )
            self.assertNotIn(statement, srs_path.read_text(encoding="utf-8"))
            self.assertEqual(apply_shared_spec_markdown_formatting(
                ["\u2022 Generated item", statement], literal_lines=[statement]), ["- Generated item", statement])

    def test_document_excerpt_in_wrong_section_cannot_satisfy_approved_use(self):
        from docx import Document
        statement = "The system supports measurement. The system supports data exchange."
        source = record("synthetic-shared", statement, evidence_scope="shared", approved_uses_json=json.dumps([{
            "use_id": "digital", "document": "DRS", "block": "", "domain": "digital",
            "role": "context", "start": 0, "end": len(statement), "rationale": "Reviewed context."}]))
        projected = project_shared_descriptive_uses(
            admitted({"governed_source_context": {"records": [source]}}), document="DRS")
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            markdown = root / "digital.md"
            markdown.write_text(
                "## 3. Top Level Overview\n\nOther context.\n\n### 3.1 Digital Main Functions\n\n"
                "The system supports measurement and data exchange.\n", encoding="utf-8")
            doc = Document()
            doc.add_heading("3. Top Level Overview", level=2)
            doc.add_paragraph("Other context.")
            doc.add_heading("3.1 Digital Main Functions", level=3)
            doc.add_paragraph("The system supports measurement and data exchange.")
            doc.save(markdown.with_suffix(".docx"))
            write_shared_descriptive_audit(markdown, projected, document="DRS", snapshot_id="snapshot-new")
            contract = MagicMock()
            contract.shared_descriptive_context.return_value = projected
            with patch("validate_downstream_coherence.resolve_downstream_contract", return_value=contract):
                findings = validate_shared_descriptive_artifacts(root, markdown, document="DRS", snapshot_id="snapshot-new")
            self.assertEqual(sum("excerpt_missing_or_changed" in value for value in findings), 2)

    def test_review_fields_are_editable_but_source_remains_immutable(self):
        profile = fixture()
        draft = copy.deepcopy(profile)
        draft["governed_source_context"]["records"][-1].update(
            evidence_scope="block_local", approved_uses_json="[]", review_decision="pending")
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "review.xlsx"
            book = Workbook()
            book.save(path)
            book.close()
            write_descriptive_review_sheet(path, draft)
            book = load_workbook(path)
            book[DESTINATIONS_SHEET].delete_cols(12, 4)
            sheet = book[DESCRIPTIVE_SHEET]
            fields = {cell.value: cell.column for cell in sheet[1]}
            row = 4
            self.assertFalse(sheet.cell(row, fields[CLASSIFICATION_FIELD]).protection.locked)
            sheet.cell(row, fields[CLASSIFICATION_FIELD]).value = "shared"
            for field in ("evidence_scope", "approved_uses_json"):
                self.assertTrue(sheet.column_dimensions[sheet.cell(1, fields[field]).column_letter].hidden)
                self.assertTrue(sheet.cell(row, fields[field]).protection.locked)
            destination_sheet = book[DESTINATIONS_SHEET]
            for number, values in enumerate(descriptive_destination_rows(profile["governed_source_context"]["records"][-1]), 2):
                for column, field in enumerate(DESTINATION_FIELDS, 1):
                    destination_sheet.cell(number, column).value = values[field]
            sheet.cell(row, fields["review_decision"]).value = "approved"
            book.save(path)
            book.close()
            reviewed = reviewed_descriptive_context(path, draft, profile)
            expected = copy.deepcopy(profile["governed_source_context"])
            expected["records"][-1]["evidence_scope"] = "shared"
            self.assertEqual(json.loads(reviewed["records"][-1]["approved_uses_json"]),
                             json.loads(expected["records"][-1]["approved_uses_json"]))
            expected["records"][-1]["approved_uses_json"] = reviewed["records"][-1]["approved_uses_json"]
            self.assertEqual(reviewed, expected)
            book = load_workbook(path)
            book[DESCRIPTIVE_SHEET].cell(row, fields["statement"]).value += " Altered."
            book.save(path)
            book.close()
            with self.assertRaisesRegex(ValueError, "text/provenance"):
                reviewed_descriptive_context(path, draft, profile)

    def test_legacy_sheet_upgrade_preserves_all_other_package_parts_and_decisions(self):
        profile = fixture()
        profile["governed_source_context"]["records"] = profile["governed_source_context"]["records"][:2]
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path = root / "review.xlsx"
            backup = root / "backup.xlsx"
            book = Workbook()
            original = book.active
            original.title = "Requirement Mapping"
            original.append(["Keep", "=1+2"])
            book.save(path)
            book.close()
            write_descriptive_review_sheet(path, profile)
            # Recreate a genuine legacy sheet without the optional columns.
            book = load_workbook(path)
            sheet = book[DESCRIPTIVE_SHEET]
            removed = [cell.column for cell in sheet[1] if cell.value in (
                CLASSIFICATION_FIELD, "evidence_scope", "approved_uses_json",
            )]
            for column in sorted(removed, reverse=True):
                sheet.delete_cols(column)
            del book[DESTINATIONS_SHEET]
            sheet.data_validations.dataValidation = [
                value for value in sheet.data_validations.dataValidation if "block_local" not in value.formula1
            ]
            book.save(path)
            book.close()
            before = path.read_bytes()
            context = reviewed_descriptive_context(path, profile, profile)
            self.assertTrue(upgrade_descriptive_review_fields(path, profile, profile, backup_path=backup))
            self.assertEqual(backup.read_bytes(), before)
            self.assertEqual(reviewed_descriptive_context(path, profile, profile), context)
            with ZipFile(backup) as old, ZipFile(path) as new:
                self.assertEqual(len(new.namelist()), len(old.namelist()) + 1)
                changed = [name for name in old.namelist() if old.read(name) != new.read(name)]
                self.assertEqual(set(changed), {"xl/worksheets/sheet2.xml", "xl/workbook.xml",
                                               "xl/_rels/workbook.xml.rels", "[Content_Types].xml"})
            self.assertFalse(upgrade_descriptive_review_fields(path, profile, profile, backup_path=root / "unused.xlsx"))
            path.with_name("~$" + path.name).write_bytes(b"Excel lock")
            with self.assertRaisesRegex(ValueError, "Save and close"):
                upgrade_descriptive_review_fields(path, profile, profile, backup_path=root / "locked.xlsx")


if __name__ == "__main__":
    unittest.main()
