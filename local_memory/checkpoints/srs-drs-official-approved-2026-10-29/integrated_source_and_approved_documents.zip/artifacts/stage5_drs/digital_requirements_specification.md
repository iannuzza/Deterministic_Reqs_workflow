# **Digital Requirements Specification** {#digital-requirements-specification}

## **STBIO** {#stbio}

Author: Alessandro Lucio IANNUZZI

<p>&nbsp;</p>

Date: 2026-10-29

<p>&nbsp;</p>

Snapshot ID: snap-8b3673edc9cf590589b8ab39

<p>&nbsp;</p>

Source specification: C:/Users/iannuzza/AppData/Local/Temp/workflow_power_arbitration_20261029/specs/DDS_STBIO1.pdf

<p>&nbsp;</p>

## **0. Document Navigation** {#0-document-navigation}

### **0.1 Table of contents** {#01-table-of-contents}

- [STBIO](#stbio)
- [0. Document Navigation](#0-document-navigation)
- [1. Introduction](#1-introduction)
  - [1.1 Purpose](#11-purpose)
  - [1.2 Scope](#12-scope)
  - [1.3 Intended audience](#13-intended-audience)
  - [1.4 References](#14-references)
- [2. Definitions and terminology](#2-definitions-and-terminology)
  - [2.1 Conventions](#21-conventions)
- [3. Top Level Overview](#3-top-level-overview)
  - [3.1 Digital Main Functions](#31-digital-main-functions)
- [4. Digital requirements](#4-digital-requirements)
  - [4.1 Digital block list](#41-digital-block-list)
  - [4.2 Arbitration, control, and shared resources](#42-arbitration-control-and-shared-resources)
  - [4.3 Register and configuration requirements](#43-register-and-configuration-requirements)
  - [4.4 Interface and communication requirements](#44-interface-and-communication-requirements)
  - [4.5 Data-path and buffering requirements](#45-data-path-and-buffering-requirements)
  - [4.6 Digital performance requirements](#46-digital-performance-requirements)
  - [4.7 Clock and synchronization across domains](#47-clock-and-synchronization-across-domains)
    - [4.7.1 Clock connections](#471-clock-connections)
    - [4.7.2 Reset connections](#472-reset-connections)
- [5. Validation and qualification requirements](#5-validation-and-qualification-requirements)
- [6. Requirement identification and traceability](#6-requirement-identification-and-traceability)
  - [6.1 Numbering convention](#61-numbering-convention)
  - [6.2 Traceability contract](#62-traceability-contract)
  - [6.3 Requirement catalog](#63-requirement-catalog)
  - [6.4 Source Function Context](#64-source-function-context)
    - [6.4.1 ADC TEST FAST](#641-adc-test-fast)
    - [6.4.2 ADC TEST LOW NOISE](#642-adc-test-low-noise)
    - [6.4.3 BIST MODE](#643-bist-mode)
    - [6.4.4 CHECK DATA](#644-check-data)
    - [6.4.5 CONFIGURE ADC SAMPLING PERIOD](#645-configure-adc-sampling-period)
    - [6.4.6 Debug mode](#646-debug-mode)
    - [6.4.7 ISPU integration](#647-ispu-integration)
    - [6.4.8 PPG FRAMES CONFIG](#648-ppg-frames-config)
    - [6.4.9 SELECT CHANNEL](#649-select-channel)
    - [6.4.10 SELECT DIVISION INDEX FOR CONFIGURED CHANNELS](#6410-select-division-index-for-configured-channels)
    - [6.4.11 SELECT OPERATIVE MODE](#6411-select-operative-mode)
    - [6.4.12 Scan mode](#6412-scan-mode)
    - [6.4.13 TIME SLOT LENGTH](#6413-time-slot-length)
    - [6.4.14 XBAR Connection Matrix](#6414-xbar-connection-matrix)
- [7. Interfaces and mixed-signal interactions](#7-interfaces-and-mixed-signal-interactions)
- [8. Assumptions](#8-assumptions)
- [9. Top-level integration requirements](#9-top-level-integration-requirements)
  - [9.1 Sensor-Hub](#91-sensor-hub)
  - [9.2 ADSP](#92-adsp)
  - [9.3 Main Controller](#93-main-controller)
  - [9.4 Smart FIFO](#94-smart-fifo)
  - [9.5 Regmap](#95-regmap)
  - [9.6 IRQ logic](#96-irq-logic)
  - [9.7 PMU](#97-pmu)
  - [9.8 BIST Controller](#98-bist-controller)
  - [9.9 I2C_SPI_AHB](#99-i2cspiahb)
  - [9.10 OTP](#910-otp)
  - [9.11 PAD MUX](#911-pad-mux)
  - [9.12 ISPU](#912-ispu)
- [10. Missing Inputs](#10-missing-inputs)

### **0.2 Internal index for paragraphs and pages** {#02-internal-index-for-paragraphs-and-pages}
#### **Table 3. Section navigation index** {#table-3-section-navigation-index}

| Section | Paragraph anchor | Internal link | Page (rendered PDF) |
|---|---|---|---|
| STBIO | 0 | [Jump](#stbio) | Auto |
| 0. Document Navigation | 0 | [Jump](#0-document-navigation) | Auto |
| 1. Introduction | 1 | [Jump](#1-introduction) | Auto |
| 1.1 Purpose | 1.1 | [Jump](#11-purpose) | Auto |
| 1.2 Scope | 1.2 | [Jump](#12-scope) | Auto |
| 1.3 Intended audience | 1.3 | [Jump](#13-intended-audience) | Auto |
| 1.4 References | 1.4 | [Jump](#14-references) | Auto |
| 2. Definitions and terminology | 2 | [Jump](#2-definitions-and-terminology) | Auto |
| 2.1 Conventions | 2.1 | [Jump](#21-conventions) | Auto |
| 3. Top Level Overview | 3 | [Jump](#3-top-level-overview) | Auto |
| 3.1 Digital Main Functions | 3.1 | [Jump](#31-digital-main-functions) | Auto |
| 4. Digital requirements | 4 | [Jump](#4-digital-requirements) | Auto |
| 4.1 Digital block list | 4.1 | [Jump](#41-digital-block-list) | Auto |
| 4.2 Arbitration, control, and shared resources | 4.2 | [Jump](#42-arbitration-control-and-shared-resources) | Auto |
| 4.3 Register and configuration requirements | 4.3 | [Jump](#43-register-and-configuration-requirements) | Auto |
| 4.4 Interface and communication requirements | 4.4 | [Jump](#44-interface-and-communication-requirements) | Auto |
| 4.5 Data-path and buffering requirements | 4.5 | [Jump](#45-data-path-and-buffering-requirements) | Auto |
| 4.6 Digital performance requirements | 4.6 | [Jump](#46-digital-performance-requirements) | Auto |
| 4.7 Clock and synchronization across domains | 4.7 | [Jump](#47-clock-and-synchronization-across-domains) | Auto |
| 4.7.1 Clock connections | 4.7.1 | [Jump](#471-clock-connections) | Auto |
| 4.7.2 Reset connections | 4.7.2 | [Jump](#472-reset-connections) | Auto |
| 5. Validation and qualification requirements | 5 | [Jump](#5-validation-and-qualification-requirements) | Auto |
| 6. Requirement identification and traceability | 6 | [Jump](#6-requirement-identification-and-traceability) | Auto |
| 6.1 Numbering convention | 6.1 | [Jump](#61-numbering-convention) | Auto |
| 6.2 Traceability contract | 6.2 | [Jump](#62-traceability-contract) | Auto |
| 6.3 Requirement catalog | 6.3 | [Jump](#63-requirement-catalog) | Auto |
| 6.4 Source Function Context | 6.4 | [Jump](#64-source-function-context) | Auto |
| 6.4.1 ADC TEST FAST | 6.4.1 | [Jump](#641-adc-test-fast) | Auto |
| 6.4.2 ADC TEST LOW NOISE | 6.4.2 | [Jump](#642-adc-test-low-noise) | Auto |
| 6.4.3 BIST MODE | 6.4.3 | [Jump](#643-bist-mode) | Auto |
| 6.4.4 CHECK DATA | 6.4.4 | [Jump](#644-check-data) | Auto |
| 6.4.5 CONFIGURE ADC SAMPLING PERIOD | 6.4.5 | [Jump](#645-configure-adc-sampling-period) | Auto |
| 6.4.6 Debug mode | 6.4.6 | [Jump](#646-debug-mode) | Auto |
| 6.4.7 ISPU integration | 6.4.7 | [Jump](#647-ispu-integration) | Auto |
| 6.4.8 PPG FRAMES CONFIG | 6.4.8 | [Jump](#648-ppg-frames-config) | Auto |
| 6.4.9 SELECT CHANNEL | 6.4.9 | [Jump](#649-select-channel) | Auto |
| 6.4.10 SELECT DIVISION INDEX FOR CONFIGURED CHANNELS | 6.4.10 | [Jump](#6410-select-division-index-for-configured-channels) | Auto |
| 6.4.11 SELECT OPERATIVE MODE | 6.4.11 | [Jump](#6411-select-operative-mode) | Auto |
| 6.4.12 Scan mode | 6.4.12 | [Jump](#6412-scan-mode) | Auto |
| 6.4.13 TIME SLOT LENGTH | 6.4.13 | [Jump](#6413-time-slot-length) | Auto |
| 6.4.14 XBAR Connection Matrix | 6.4.14 | [Jump](#6414-xbar-connection-matrix) | Auto |
| 7. Interfaces and mixed-signal interactions | 7 | [Jump](#7-interfaces-and-mixed-signal-interactions) | Auto |
| 8. Assumptions | 8 | [Jump](#8-assumptions) | Auto |
| 9. Top-level integration requirements | 9 | [Jump](#9-top-level-integration-requirements) | Auto |
| 9.1 Sensor-Hub | 9.1 | [Jump](#91-sensor-hub) | Auto |
| 9.2 ADSP | 9.2 | [Jump](#92-adsp) | Auto |
| 9.3 Main Controller | 9.3 | [Jump](#93-main-controller) | Auto |
| 9.4 Smart FIFO | 9.4 | [Jump](#94-smart-fifo) | Auto |
| 9.5 Regmap | 9.5 | [Jump](#95-regmap) | Auto |
| 9.6 IRQ logic | 9.6 | [Jump](#96-irq-logic) | Auto |
| 9.7 PMU | 9.7 | [Jump](#97-pmu) | Auto |
| 9.8 BIST Controller | 9.8 | [Jump](#98-bist-controller) | Auto |
| 9.9 I2C_SPI_AHB | 9.9 | [Jump](#99-i2cspiahb) | Auto |
| 9.10 OTP | 9.10 | [Jump](#910-otp) | Auto |
| 9.11 PAD MUX | 9.11 | [Jump](#911-pad-mux) | Auto |
| 9.12 ISPU | 9.12 | [Jump](#912-ispu) | Auto |
| 10. Missing Inputs | 10 | [Jump](#10-missing-inputs) | Auto |

<p>&nbsp;</p>

### **0.3 Document control** {#03-document-control}
#### **Table 1. Version history** {#table-1-version-history}

| Version | Date | Description | Author |
|---|---|---|---|
| 1.1 | 2026-10-01 | Snapshot snap-b2e8101b00dc6909feaed885 DRS baseline generated from Stage 1 and Stage 2 artifacts | Alessandro Lucio IANNUZZI |
| 1.2 | 2026-10-09 | Snapshot snap-73c872b1307b6adb5eaf843e DRS baseline generated from Stage 1 and Stage 2 artifacts | Alessandro Lucio IANNUZZI |
| 1.3 | 2026-10-20 | Snapshot snap-4bb32f59db82884706d69751 DRS baseline generated from Stage 1 and Stage 2 artifacts | Alessandro Lucio IANNUZZI |
| 1.4 | 2026-10-27 | Snapshot snap-8b3673edc9cf590589b8ab39 DRS baseline generated from Stage 1 and Stage 2 artifacts | Alessandro Lucio IANNUZZI |

<p>&nbsp;</p>

#### **Table 2. Reference documents** {#table-2-reference-documents}

| Doc name | Version | Author |
|---|---|---|
| artifacts/stage4_ars/analog_requirements_specification.md | 0.1 | ARS Gen Spec Agent |
| artifacts/stage1_requirements/requirements_summary.csv | 0.1 | Requirements Extraction Agent |
| artifacts/stage2_mirco_arc/micro_architecture_report.md | 0.1 | Micro-Architectural Analysis Agent |
| artifacts/stage2_mirco_arc/requirement_to_block_traceability.csv | 0.1 | Micro-Architectural Analysis Agent |
| templates/DRS_gen_AI_template_prompt.md | 0.1 | Project template maintainers |

<p>&nbsp;</p>

#### **Table 6. Category convention** {#table-6-category-convention}

| Category | Naming rule / prefix | Scope | Notes / example |
|---|---|---|---|
| Digital authored requirement | DRS-REQ-xxx | Project-specific DRS atomic entries | Covers one upstream requirement per row |
| Source digital/system/cross-domain requirement | source_req_id | Stage 1 source requirement catalog | Linked to authored SRS upstream ID |
| DRS upstream reference in Covers | SRS-REQ-xxx | Authored SRS requirement catalog | Required for every DRS authored requirement |

<p>&nbsp;</p>

### **0.4 Table of tables** {#04-table-of-tables}

| Table | Title | Link |
|---|---|---|
| Table 1 | Version history | [Go to Table 1](#table-1-version-history) |
| Table 2 | Reference documents | [Go to Table 2](#table-2-reference-documents) |
| Table 3 | Section navigation index | [Go to Table 3](#table-3-section-navigation-index) |
| Table 6 | Category convention | [Go to Table 6](#table-6-category-convention) |
| Table 8 | Clock connections | [Go to Table 8](#table-8-clock-connections) |
| Table 9 | Reset connections | [Go to Table 9](#table-9-reset-connections) |

<p>&nbsp;</p>

## **1. Introduction** {#1-introduction}

### **1.1 Purpose** {#11-purpose}
This specification describes the digital integration of Sensor-Hub, ADSP, Main Controller, Smart FIFO, Regmap, IRQ logic, PMU, BIST Controller, I2C_SPI_AHB, OTP, PAD MUX, ISPU.

<p>&nbsp;</p>

### **1.2 Scope** {#12-scope}
This specification covers digital integration behavior and the relationships between the digital subsystem and its interfaces. Block-local implementation remains outside this integration scope.

<p>&nbsp;</p>

### **1.3 Intended audience** {#13-intended-audience}
System architects, digital design, firmware, validation, and verification stakeholders.

<p>&nbsp;</p>

### **1.4 References** {#14-references}
Reference files are listed in Table 2. Reference documents.

<p>&nbsp;</p>

## **2. Definitions and terminology** {#2-definitions-and-terminology}
Source and destination labels in the architecture tables retain their integration-evidence meanings; the block list distinguishes concrete digital blocks from other interaction endpoints.

<p>&nbsp;</p>

### **2.1 Conventions** {#21-conventions}

#### **Comment** {#comment}

This category denotes that the content of the object text is a general comment. For example, this may be an explanation why the requirement demands certain items when there would also be other possibilities. A comment should not be necessary to understand the related requirements

<p>&nbsp;</p>

#### **Definition** {#definition}

This category is used for the definition of terms, wordings, technical expressions etc. It is a documentation of design decisions and general instructions that belong to the document itself, e.g. owner of the document, structure of the document. It is needed to understand a related requirement. It is not linked to any test case.

<p>&nbsp;</p>

#### **Assumption** {#assumption}

This category is used for requirements this document provide upstream to another document, indicating what this IP/block/system needs to work properly.

<p>&nbsp;</p>

#### **Requirement** {#requirement}

This category denotes a requirement that has to be implemented and verified. Accordingly, it is necessary to establish traces from the different requirement levels to the test cases for this category.

<p>&nbsp;</p>

## **3. Top Level Overview** {#3-top-level-overview}
STBIO1 is an Analog Front End Device with embedded processing capabilities. Within STBIO1, the digital engine can reduce external host processing workload through multiple IPs, reduce bus congestion and provide meta-data for final application in both time and frequency domains.

<p>&nbsp;</p>

The digital domain combines signal acquisition, digital sample control, FIFO and interrupt signaling, SPI host register access path, I2C host register access path, power, clock, and startup behavior and self-test and calibration as complementary subsystem responsibilities.

<p>&nbsp;</p>

The digital domain includes the following implementation blocks: ADSP, I2C_SPI_AHB, ISPU (32-bit processor), Main Controller, OTP, PAD MUX, PMU, Regmap, Sensor-Hub and Smart FIFO (data collector).

<p>&nbsp;</p>

### **3.1 Digital Main Functions** {#31-digital-main-functions}

#### **ADSP** {#adsp}
ADSP executes ADSP firmware for OTP boot/write/test and signal elaboration.

<p>&nbsp;</p>

#### **I2C_SPI_AHB** {#i2cspiahb}
I2C_SPI_AHB accepts I2C/SPI accesses and translates them as needed into AHB transactions for device configuration and readback, including ISPU access.

<p>&nbsp;</p>

#### **ISPU** {#ispu}
ISPU can execute signal processing and AI algorithms in the edge.

<p>&nbsp;</p>

#### **Main Controller** {#main-controller}
Main Controller generates and receives Analog Domain control signals, performs DSP elaboration on ADC outputs and writes elaborated results to the defined addresses.

<p>&nbsp;</p>

#### **OTP** {#otp}
OTP provides the source-specified one-time-programmable memory interface used by ADSP boot, programming, and test routines.

<p>&nbsp;</p>

#### **PAD MUX** {#pad-mux}
PAD MUX routes source-specified functional, scan, BIST, debug, and ISPU-debug signals to and from device pads.

<p>&nbsp;</p>

#### **PMU** {#pmu}
PMU sequences POR-driven LDO1V8 enable, 64/32 kHz and 16 MHz clocks, clock-ready signaling, and digital-reset release for boot and power modes.

<p>&nbsp;</p>

#### **Regmap** {#regmap}
Regmap implements the mapped AFE, system, and OTP registers, exposing configuration/status while enforcing reset and OTP write-protection rules.

<p>&nbsp;</p>

#### **Sensor-Hub** {#sensor-hub}
Sensor-Hub operates the Sensor Hub I2C master for external targets, including trigger/control, pad enable, data collection, and FIFO multi-mode coordination.

<p>&nbsp;</p>

#### **Smart FIFO** {#smart-fifo}
Smart FIFO provides FIFO storage and AHB/memory access in mutually exclusive Unique or Multiple modes, including sub-FIFO depth/addressing and tagged Sensor Hub data formatting.

<p>&nbsp;</p>

#### **Power and clock islands** {#power-and-clock-islands}
The clock network distributes 16 MHz clocks with and without clock gating; 32 kHz clocks without clock gating.

<p>&nbsp;</p>

PMU provides power/clock status to Main Controller.

<p>&nbsp;</p>

#### **Buses and interconnects** {#buses-and-interconnects}
SPI interface provides SPI register transactions to Regmap. I2C interface provides I2C register transactions to Regmap. Regmap provides register read response to SPI interface and I2C interface. I2C_SPI_AHB provides SPI host transactions to SPI interface and I2C host transactions to I2C interface.

| Source | Destination | Architectural exchange |
|---|---|---|
| SPI interface | Regmap | SPI register transactions |
| I2C interface | Regmap | I2C register transactions |
| Regmap | SPI interface | register read response |
| Regmap | I2C interface | register read response |
| I2C_SPI_AHB | SPI interface | SPI host transactions |
| I2C_SPI_AHB | I2C interface | I2C host transactions |

<p>&nbsp;</p>

#### **Arbitration, control, and shared resources** {#arbitration-control-and-shared-resources}
Regmap is a shared register resource with documented integration paths connecting SPI interface, I2C interface, Main Controller, ADSP, I2C_SPI_AHB, ISPU and ISPU debug.

Smart FIFO is a shared memory and storage resource with documented integration paths connecting Main Controller, ADSP, I2C_SPI_AHB, SENSOR HUB, ISPU and ISPU debug.

ADC provides digital samples to Main Controller. Main Controller provides sample stream and FIFO mode control to Smart FIFO. Smart FIFO provides watermark/overrun/empty flags to IRQ logic. Regmap provides configuration writes to Main Controller. BIST Controller provides self-test/calibration status to Regmap. SPI interface provides SPI register transactions to Regmap. I2C interface provides I2C register transactions to Regmap. I2C_SPI_AHB provides SPI host transactions to SPI interface and I2C host transactions to I2C interface. Main Controller and ISPU debug connect to Regmap through XBAR. ADSP and ISPU connect to Regmap and FIFO through XBAR. SENSOR HUB connects to FIFO through XBAR.

<p>&nbsp;</p>



| Source | Destination | Architectural exchange |
|---|---|---|
| ADC | Main Controller | digital samples |
| Main Controller | Smart FIFO | sample stream and FIFO mode control |
| Smart FIFO | IRQ logic | watermark/overrun/empty flags |
| Regmap | Main Controller | configuration writes |
| BIST Controller | Regmap | self-test/calibration status |
| Main Controller | Regmap | XBAR connection |
| SPI interface | Regmap | SPI register transactions |
| I2C interface | Regmap | I2C register transactions |
| I2C_SPI_AHB | SPI interface | SPI host transactions |
| I2C_SPI_AHB | I2C interface | I2C host transactions |
| ADSP | Regmap | XBAR connection |
| ADSP | FIFO | XBAR connection |
| SENSOR HUB | FIFO | XBAR connection |
| ISPU | Regmap | XBAR connection |
| ISPU | FIFO | XBAR connection |
| ISPU debug | Regmap | XBAR connection |

<p>&nbsp;</p>

#### **Digital processing blocks** {#digital-processing-blocks}
ADSP executes ADSP firmware for signal elaboration.

Main Controller performs DSP elaboration on ADC outputs.

ADSP connects to SENSOR HUB through XBAR. ISPU connects to SENSOR HUB and ADSP through XBAR. ISPU debug connects to SENSOR HUB, ISPU and ADSP through XBAR.

| Source | Destination | Architectural exchange |
|---|---|---|
| ADSP | SENSOR HUB | XBAR connection |
| ISPU | SENSOR HUB | XBAR connection |
| ISPU | ADSP | XBAR connection |
| ISPU debug | SENSOR HUB | XBAR connection |
| ISPU debug | ISPU | XBAR connection |
| ISPU debug | ADSP | XBAR connection |

<p>&nbsp;</p>

#### **Power-domain architecture** {#power-domain-architecture}
The always-on domains PD_TOP1V2, PD_TOP3V3, PD_TOPIO support digital operation under HW control. PD_TOP1V2 ensures continuity of critical functions (Data Storage Mode, Sensor-Hub acquisition, FIFO read and write data, Elaboration Mode with ADSP only). PD_TOP3V3 supplies power to the OTP memory block. PD_TOPIO powers communication PAD.

<p>&nbsp;</p>

The switchable domain PD_STREDL supports digital operation under SW control. PD_STREDL powers the STREDL core and associated cache.

| Domain | Type | Control | Function |
|---|---|---|---|
| PD_TOP1V2 | Always-On | HW | Ensures continuity of critical functions (Data Storage Mode, Sensor-Hub acquisition, FIFO read and write data, Elaboration Mode with ADSP only) |
| PD_STREDL | Switchable | SW | Powers the STREDL core and associated cache |
| PD_TOP3V3 | Always-On | HW | power supply to the OTP memory block |
| PD_TOPIO | Always-On | HW | Powers communication PAD |

<p>&nbsp;</p>

#### **Sequencing and domain control** {#sequencing-and-domain-control}
PMU provides power/clock status to Main Controller.

<p>&nbsp;</p>

#### **Low-power responsibility** {#low-power-responsibility}
PMU uses VDD for core supply. PMU uses VDD_IO for digital IO supply.

| Interface | Owner | Function |
|---|---|---|
| VDD | PMU | Core supply |
| VDD_IO | PMU | Digital IO supply |

<p>&nbsp;</p>

## **4. Digital requirements** {#4-digital-requirements}

Digital integration paths and their authored requirements are distinguished below from block-local behavior.

<p>&nbsp;</p>

Residual digital-relevant requirements are captured in the requirement catalog with SRS upstream Covers links.

<p>&nbsp;</p>

### **4.1 Digital block list** {#41-digital-block-list}
The digital blocks carry the following functions and architectural exchanges:

| Block | Role | Architectural relationship |
|---|---|---|
| Sensor-Hub | Operate the Sensor Hub I2C master for external targets, including trigger/control, pad enable, data collection, and FIFO multi-mode coordination. |  |
| ADSP | Execute ADSP firmware for OTP boot/write/test and signal elaboration, using mapped program/data/register memory and soft-reset handling. | from Main Controller (XBAR connection); to Regmap (XBAR connection); to SENSOR HUB (XBAR connection); to FIFO (XBAR connection); from I2C_SPI_AHB (XBAR connection); from ISPU (XBAR connection); from ISPU debug (XBAR connection) |
| Main Controller | Generate and receive Analog Domain control signals, perform DSP elaboration on ADC outputs, and write elaborated results to the defined addresses. | from ADC (digital samples); to Smart FIFO (sample stream and FIFO mode control); from Regmap (configuration writes); from PMU (power/clock status); to Regmap (XBAR connection); to FIFO (XBAR connection); to ADSP (XBAR connection) |
| Smart FIFO | Provide FIFO storage and AHB/memory access in mutually exclusive Unique or Multiple modes, including sub-FIFO depth/addressing and tagged Sensor Hub data formatting. | from Main Controller (sample stream and FIFO mode control); to IRQ logic (watermark/overrun/empty flags) |
| Regmap | Implement the mapped AFE, system, and OTP registers, exposing configuration/status while enforcing reset and OTP write-protection rules. | to Main Controller (configuration writes); from SPI interface (SPI register transactions); from I2C interface (I2C register transactions); to SPI interface (register read response); to I2C interface (register read response); from BIST Controller (self-test/calibration status); from Main Controller (XBAR connection); from ADSP (XBAR connection); from I2C_SPI_AHB (XBAR connection); from ISPU (XBAR connection); from ISPU debug (XBAR connection) |
| IRQ logic | Aggregate and route FIFO, Sensor Hub, ISPU sample-ready, software, and timer interrupt status to configured GPIO/interrupt outputs. | from Smart FIFO (watermark/overrun/empty flags) |
| PMU | Sequence POR-driven LDO1V8 enable, 64/32 kHz and 16 MHz clocks, clock-ready signaling, and digital-reset release for boot and power modes. | to Main Controller (power/clock status) |
| BIST Controller | Control BIST operating modes and coordinate ADC/OTP test operations and their register-visible results. | to Regmap (self-test/calibration status) |
| I2C_SPI_AHB | Accept I2C/SPI accesses and translate them as needed into AHB transactions for device configuration and readback, including ISPU access. | to SPI interface (SPI host transactions); to I2C interface (I2C host transactions); to Regmap (XBAR connection); to SENSOR HUB (XBAR connection); to ISPU (XBAR connection); to FIFO (XBAR connection); to ADSP (XBAR connection) |
| OTP | Provide the source-specified one-time-programmable memory interface used by ADSP boot, programming, and test routines. |  |
| PAD MUX | Route source-specified functional, scan, BIST, debug, and ISPU-debug signals to and from device pads. |  |
| ISPU | An interrupt triggers ISPU wake-up. | from I2C_SPI_AHB (XBAR connection); to Regmap (XBAR connection); to SENSOR HUB (XBAR connection); to FIFO (XBAR connection); to ADSP (XBAR connection); from ISPU debug (XBAR connection) |

<p>&nbsp;</p>

### **4.2 Arbitration, control, and shared resources** {#42-arbitration-control-and-shared-resources}
Main Controller provides sample stream and FIFO mode control to Smart FIFO. Regmap provides configuration writes to Main Controller and register read response to SPI interface and I2C interface. SPI interface provides SPI register transactions to Regmap. I2C interface provides I2C register transactions to Regmap. PMU provides power/clock status to Main Controller. BIST Controller provides self-test/calibration status to Regmap. Main Controller connects to Regmap, FIFO and ADSP through XBAR. ADSP connects to Regmap, SENSOR HUB and FIFO through XBAR. I2C_SPI_AHB and ISPU debug connect to Regmap, SENSOR HUB, ISPU, FIFO and ADSP through XBAR. SENSOR HUB connects to FIFO through XBAR. ISPU connects to Regmap, SENSOR HUB, FIFO and ADSP through XBAR.

<p>&nbsp;</p>

Shared-resource ownership: Smart FIFO provides FIFO storage and AHB/memory access in mutually exclusive Unique or Multiple modes, including sub-FIFO depth/addressing and tagged Sensor Hub data formatting.

<p>&nbsp;</p>

Register and memory access coordination: Regmap implements the mapped AFE, system, and OTP registers, exposing configuration/status while enforcing reset and OTP write-protection rules. BIST Controller coordinates ADC/OTP test operations and their register-visible results. I2C_SPI_AHB translates them as needed into AHB transactions for device configuration and readback, including ISPU access. SPI interface provides SPI register transactions to Regmap. I2C interface provides I2C register transactions to Regmap. Regmap provides register read response to SPI interface and I2C interface.

<p>&nbsp;</p>

Reset and boot coordination: ADSP executes ADSP firmware for OTP boot/write/test and signal elaboration. PMU sequences POR-driven LDO1V8 enable, 64/32 kHz and 16 MHz clocks, clock-ready signaling, and digital-reset release for boot and power modes. OTP provides the source-specified one-time-programmable memory interface used by ADSP boot, programming, and test routines.

<p>&nbsp;</p>

Power and clock interaction: PMU provides power/clock status to Main Controller.

<p>&nbsp;</p>

common bus and shared resources arbitration policy to be clarified

| Source | Destination | Architectural exchange |
|---|---|---|
| Main Controller | Smart FIFO | sample stream and FIFO mode control |
| Regmap | Main Controller | configuration writes |
| SPI interface | Regmap | SPI register transactions |
| I2C interface | Regmap | I2C register transactions |
| Regmap | SPI interface | register read response |
| Regmap | I2C interface | register read response |
| PMU | Main Controller | power/clock status |
| BIST Controller | Regmap | self-test/calibration status |
| Main Controller | Regmap | XBAR connection |
| Main Controller | FIFO | XBAR connection |
| Main Controller | ADSP | XBAR connection |
| ADSP | Regmap | XBAR connection |
| ADSP | SENSOR HUB | XBAR connection |
| ADSP | FIFO | XBAR connection |
| I2C_SPI_AHB | Regmap | XBAR connection |
| I2C_SPI_AHB | SENSOR HUB | XBAR connection |
| I2C_SPI_AHB | ISPU | XBAR connection |
| I2C_SPI_AHB | FIFO | XBAR connection |
| I2C_SPI_AHB | ADSP | XBAR connection |
| SENSOR HUB | FIFO | XBAR connection |
| ISPU | Regmap | XBAR connection |
| ISPU | SENSOR HUB | XBAR connection |
| ISPU | FIFO | XBAR connection |
| ISPU | ADSP | XBAR connection |
| ISPU debug | Regmap | XBAR connection |
| ISPU debug | SENSOR HUB | XBAR connection |
| ISPU debug | ISPU | XBAR connection |
| ISPU debug | FIFO | XBAR connection |
| ISPU debug | ADSP | XBAR connection |

<p>&nbsp;</p>



<p>&nbsp;</p>



<p>&nbsp;</p>



<p>&nbsp;</p>

### **4.3 Register and configuration requirements** {#43-register-and-configuration-requirements}
Regmap provides configuration writes to Main Controller and register read response to SPI interface and I2C interface. SPI interface provides SPI register transactions to Regmap. I2C interface provides I2C register transactions to Regmap.

| Source | Destination | Architectural exchange |
|---|---|---|
| Regmap | Main Controller | configuration writes |
| SPI interface | Regmap | SPI register transactions |
| I2C interface | Regmap | I2C register transactions |
| Regmap | SPI interface | register read response |
| Regmap | I2C interface | register read response |

<p>&nbsp;</p>

### **4.4 Interface and communication requirements** {#44-interface-and-communication-requirements}
SPI interface provides SPI register transactions to Regmap. I2C interface provides I2C register transactions to Regmap. I2C_SPI_AHB provides SPI host transactions to SPI interface and I2C host transactions to I2C interface.

| Source | Destination | Architectural exchange |
|---|---|---|
| SPI interface | Regmap | SPI register transactions |
| I2C interface | Regmap | I2C register transactions |
| I2C_SPI_AHB | SPI interface | SPI host transactions |
| I2C_SPI_AHB | I2C interface | I2C host transactions |

<p>&nbsp;</p>

### **4.5 Data-path and buffering requirements** {#45-data-path-and-buffering-requirements}
ADC provides digital samples to Main Controller. Main Controller provides sample stream and FIFO mode control to Smart FIFO. Smart FIFO provides watermark/overrun/empty flags to IRQ logic.

| Source | Destination | Architectural exchange |
|---|---|---|
| ADC | Main Controller | digital samples |
| Main Controller | Smart FIFO | sample stream and FIFO mode control |
| Smart FIFO | IRQ logic | watermark/overrun/empty flags |

<p>&nbsp;</p>

### **4.6 Digital performance requirements** {#46-digital-performance-requirements}
The clock network distributes 16 MHz clocks with and without clock gating; 32 kHz clocks without clock gating.

<p>&nbsp;</p>

Reset connection DDS_STBIO1_2054: PMU.resetn_32k_main_ctrl -> Main Controller.i_rstn_sync_32;

<p>&nbsp;</p>

Clock distribution:

| Source requirement | Source clock | Destination clock | Frequency | Clock gating |
|---|---|---|---|---|
| DDS_STBIO1_1024 | stbio1_top.dig_wrapper_LV.u_pmu.clk_16m_dft | stbio1_top.dig_wrapper_LV.u_xbar_afe.hclk | 16 MHz |  |
| DDS_STBIO1_1023 | stbio1_top.dig_wrapper_LV.u_pmu.w_sh_clk | stbio1_top.dig_wrapper_LV.u_masterblaze_ahb.sys_clk | 16 MHz |  |
| DDS_STBIO1_2026 | stbio1_top.dig_wrapper_LV.u_pmu.clk_xbar | stbio1_top.dig_wrapper_LV.u_regmap_otp.hclk | 16 MHz |  |
| DDS_STBIO1_1025 | u_stbio1_top.u_pmu.u_device_startup.tst_clk_32k | stbio1_top.dig_wrapper_LV.tst_clk_32k | 32 kHz | Not gated |
| DDS_STBIO1_1022 | stbio1_top.dig_wrapper_LV.u_pmu.clk_16m_dft | stbio1_top.dig_wrapper_LV.u_ADSP.stmc_clk | 16 MHz |  |
| DDS_STBIO1_2025 | stbio1_top.dig_wrapper_LV.u_pmu.clk_stredl | stbio1_top.dig_wrapper_LV.u_ispu.clk | 16 MHz | Not gated |
| DDS_STBIO1_1026 | stbio1_top.dig_wrapper_LV.u_pmu.tst_clk_16m | stbio1_top.dig_wrapper_LV.u_main_controller_top.i_clk_16MHz | 16 MHz |  |
| DDS_STBIO1_1027 | stbio1_top.dig_wrapper_LV.u_pmu.tst_clk_32k | stbio1_top.dig_wrapper_LV.u_main_controller_top.i_clk_32kHz | 32 kHz | Not gated |

<p>&nbsp;</p>

Reset outputs:

| Power/clock owner | Reset output | Approved description | Source page |
|---|---|---|---|
| PMU | resetn_stredl | wire reset mngmt inside stredl_afe_top | 41 |
| PMU | resetn_xbar | wire xbar reset | 41 |
| PMU | resetn_intf | wire reset interface | 41 |
| PMU | resetn_main_ctrl | wire reset main controller | 41 |
| PMU | resetn_32k_main_ctrl | wire reset 32kHz domain main controller | 41 |
| PMU | resetn_stmc | wire reset adsp | 41 |
| PMU | resetn_fifo | wire reset FIFO | 41 |
| PMU | resetn_masterblaze | wire reset sensor hub | 41 |
| PMU | resetn_regmap | wire reset regmap | 41 |

<p>&nbsp;</p>



<p>&nbsp;</p>



<p>&nbsp;</p>

### **4.7 Clock and synchronization across domains** {#47-clock-and-synchronization-across-domains}
The clock network distributes 16 MHz clocks with and without clock gating; 32 kHz clocks without clock gating; 64 kHz clocks without clock gating.

<p>&nbsp;</p>

Reset/synchronization-labelled connection DDS_STBIO1_2054: PMU.resetn_32k_main_ctrl -> Main Controller.i_rstn_sync_32;

<p>&nbsp;</p>

Interrupt-triggered wake-up is specified for ISPU.

<p>&nbsp;</p>

Clock distribution:

| Source requirement | Source clock | Destination clock | Frequency | Clock gating |
|---|---|---|---|---|
| DDS_STBIO1_1024 | stbio1_top.dig_wrapper_LV.u_pmu.clk_16m_dft | stbio1_top.dig_wrapper_LV.u_xbar_afe.hclk | 16 MHz |  |
| DDS_STBIO1_1023 | stbio1_top.dig_wrapper_LV.u_pmu.w_sh_clk | stbio1_top.dig_wrapper_LV.u_masterblaze_ahb.sys_clk | 16 MHz |  |
| DDS_STBIO1_2026 | stbio1_top.dig_wrapper_LV.u_pmu.clk_xbar | stbio1_top.dig_wrapper_LV.u_regmap_otp.hclk | 16 MHz |  |
| DDS_STBIO1_1025 | u_stbio1_top.u_pmu.u_device_startup.tst_clk_32k | stbio1_top.dig_wrapper_LV.tst_clk_32k | 32 kHz | Not gated |
| DDS_STBIO1_1022 | stbio1_top.dig_wrapper_LV.u_pmu.clk_16m_dft | stbio1_top.dig_wrapper_LV.u_ADSP.stmc_clk | 16 MHz |  |
| DDS_STBIO1_2024 |  |  | 16 MHz |  |
| DDS_STBIO1_2025 | stbio1_top.dig_wrapper_LV.u_pmu.clk_stredl | stbio1_top.dig_wrapper_LV.u_ispu.clk | 16 MHz | Not gated |
| DDS_STBIO1_1021 | stbio1_top.clk_64k | stbio1_top.dig_wrapper_LV.u_pmu.clk_64k | 64 kHz | Not gated |
| DDS_STBIO1_1026 | stbio1_top.dig_wrapper_LV.u_pmu.tst_clk_16m | stbio1_top.dig_wrapper_LV.u_main_controller_top.i_clk_16MHz | 16 MHz |  |
| DDS_STBIO1_1027 | stbio1_top.dig_wrapper_LV.u_pmu.tst_clk_32k | stbio1_top.dig_wrapper_LV.u_main_controller_top.i_clk_32kHz | 32 kHz | Not gated |
| DDS_STBIO1_1020 | stbio1_top.clk_16m | stbio1_top.dig_wrapper_LV.u_pmu.clk_16m | 16 MHz | Not gated |

<p>&nbsp;</p>

| Timing focus | Source requirement | Upstream reference |
|---|---|---|
| Interrupt status or wake-up | DDS_STBIO1_0505 | DDS_STBIO1_0505 |
| Interrupt status or wake-up | DDS_STBIO1_0501 | DDS_STBIO1_0501 |
| Interrupt status or wake-up | DDS_STBIO1_0504 | DDS_STBIO1_0504 |
| Interrupt status or wake-up | DDS_STBIO1_0502 | DDS_STBIO1_0502 |
| Interrupt status or wake-up | DDS_STBIO1_05010 | DDS_STBIO1_05010 |
| Interrupt status or wake-up | DDS_STBIO1_0503 | DDS_STBIO1_0503 |

<p>&nbsp;</p>



<p>&nbsp;</p>

#### **4.7.1 Clock connections** {#471-clock-connections}

##### **Table 8. Clock connections** {#table-8-clock-connections}

| Source requirement | Source | Destination | Clock frequency | Clock gate condition |
|---|---|---|---|---|
| DDS_STBIO1_1024 | stbio1_top.dig_wrapper_LV.u_pmu.clk_16m_dft | stbio1_top.dig_wrapper_LV.u_xbar_afe.hclk | 16 MHz | stbio1_top.dig_wrapper_LV.u_pm u.clk_xbar_en \| stbio1_top.dig_wrapper_LV.u_pm u.all_test_mode \| ~stbio1_top.dig_wrapper_LV.u_p ad_mux.scan_enable |
| DDS_STBIO1_1023 | stbio1_top.dig_wrapper_LV.u_pmu.w_sh_clk | stbio1_top.dig_wrapper_LV.u_masterblaze_ahb.sys_clk | 16 MHz | stbio1_top.dig_wrapper_LV.u_pm u.i_en_sh_clk \| stbio1_top.dig_wrapper_LV.u_pm u.all_test_mode \| ~stbio1_top.dig_wrapper_LV.u_p ad_mux.scan_enable |
| DDS_STBIO1_2026 | stbio1_top.dig_wrapper_LV.u_pmu.clk_xbar | stbio1_top.dig_wrapper_LV.u_regmap_otp.hclk | 16 MHz | stbio1_top.dig_wrapper_LV.u_pm u.clk_en_m3 \| stbio1_top.dig_wrapper_LV.u_pm u.all_test_mode \| stbio1_top.dig_wrapper_LV.u_pm u.clk_en_m3_reg \| stbio1_top.dig_wrapper_LV.u_pm u.clk_en_s3 \| ~stbio1_top.dig_wrapper_LV.u_p ad_mux.scan_enable |
| DDS_STBIO1_1025 | u_stbio1_top.u_pmu.u_device_startup.tst_clk_32k | stbio1_top.dig_wrapper_LV.tst_clk_32k | 32 kHz | Not gated |
| DDS_STBIO1_1022 | stbio1_top.dig_wrapper_LV.u_pmu.clk_16m_dft | stbio1_top.dig_wrapper_LV.u_ADSP.stmc_clk | 16 MHz | stbio1_top.dig_wrapper_LV.u_pm u.adsp_run \| stbio1_top.dig_wrapper_LV.u_pm u.all_test_mode \| ~stbio1_top.dig_wrapper_LV.u_p ad_mux.scan_enable |
| DDS_STBIO1_2024 | stbio1_top.dig_wrapper_LV.u_pmuclk_xbar | stbio1_top.dig_wrapper_LV.u.fifo.HCLK | 16 MHz | stbio1_top.dig_wrapper_LV.u_pm u.clk_en_m2 \| stbio1_top.dig_wrapper_LV.u_pm u.all_test_mode \| stbio1_top.dig_wrapper_LV.u_pm u.clk_en_m2_reg \| ~stbio1_top.dig_wrapper_LV.u_p ad_mux.scan_enable |
| DDS_STBIO1_2025 | stbio1_top.dig_wrapper_LV.u_pmu.clk_stredl | stbio1_top.dig_wrapper_LV.u_ispu.clk | 16 MHz | Not gated |
| DDS_STBIO1_1021 | stbio1_top.clk_64k | stbio1_top.dig_wrapper_LV.u_pmu.clk_64k | 64 kHz | Not gated |
| DDS_STBIO1_1026 | stbio1_top.dig_wrapper_LV.u_pmu.tst_clk_16m | stbio1_top.dig_wrapper_LV.u_main_controller_top.i_clk_16MHz | 16 MHz | stbio1_top.dig_wrapper_LV.u_pm u.i_en_clk_16MHz_sleep \| stbio1_top.dig_wrapper_LV.u_pm u.scan_mode \| ~stbio1_top.dig_wrapper_LV.u_p ad_mux.scan_enable |
| DDS_STBIO1_1027 | stbio1_top.dig_wrapper_LV.u_pmu.tst_clk_32k | stbio1_top.dig_wrapper_LV.u_main_controller_top.i_clk_32kHz | 32 kHz | Not gated |
| DDS_STBIO1_1020 | stbio1_top.clk_16m | stbio1_top.dig_wrapper_LV.u_pmu.clk_16m | 16 MHz | Not gated |

<p>&nbsp;</p>

#### **4.7.2 Reset connections** {#472-reset-connections}

##### **Table 9. Reset connections** {#table-9-reset-connections}

| Source requirement | Source | Destination |
|---|---|---|
| DDS_STBIO1_2054 | u_stbio1_top.dig_wrapper_LV.u_p | mu.resetn_32k_main_ctrlu_stbio1_top.dig_wrapper_LV.u_main_controller_top.i_rstn_sync_32 |
| DDS_STBIO1_2052 |  | u_device_startup.u_por_main_resetn.RST_N_FF[0]u_stbio1_top.dig_wrapper_LV.u_xbar_afe.hresetn |
| DDS_STBIO1_1053 | u_stbio1_top.dig_wrapper_LV.u_p | mu.resetn_fifou_stbio1_top.dig_wrapper_LV.u_multi_channel_fifo_top.HRESETn |
| DDS_STBIO1_1052 | u_stbio1_top.dig_wrapper_LV.u_p | mu.resetn_regmapu_stbio1_top.dig_wrapper_LV.u_regmap_otp.hresetn |
| DDS_STBIO1_1050 | u_stbio1_top.dig_wrapper_LV.u_p | mu.resetn_stmcu_stbio1_top.dig_wrapper_LV.u_ADSP.HRESETn |
| DDS_STBIO1_1051 | u_stbio1_top.dig_wrapper_LV.u_p | mu.resetn_masterblazeu_stbio1_top.dig_wrapper_LV.u_masterblaze_ahb.HRESETn |
| DDS_STBIO1_1054 | u_stbio1_top.dig_wrapper_LV.u_p | mu.resetn_main_ctrlu_stbio1_top.dig_wrapper_LV.u_main_controller_top.i_rstn |
| DDS_STBIO1_2053 | u_stbio1_top.dig_wrapper_LV.u_p | mu.resetn_regmapu_stbio1_top.dig_wrapper_LV.u_ispu.main_rst_n |

<p>&nbsp;</p>

## **5. Validation and qualification requirements** {#5-validation-and-qualification-requirements}

- Verification shall combine inspection, analysis, and test with measurable acceptance criteria.

## **6. Requirement identification and traceability** {#6-requirement-identification-and-traceability}
### **6.1 Numbering convention** {#61-numbering-convention}
DRS authored requirements use DRS-REQ-### numbering. Source requirements retain their original IDs and are referenced through Covers linkage.

<p>&nbsp;</p>

### **6.2 Traceability contract** {#62-traceability-contract}
DRS requirement catalog entries include statement only; full traceability details are maintained in artifacts/stage5_drs/drs_traceability_matrix.csv.

<p>&nbsp;</p>

### **6.3 Requirement catalog** {#63-requirement-catalog}

#### **Digital requirements** {#digital-requirements}

- No residual unmapped requirements for this domain (mapped items are captured in project-specific sub-block requirement paragraphs).

#### **Cross-domain requirements** {#cross-domain-requirements}

- No residual unmapped requirements for this domain (mapped items are captured in project-specific sub-block requirement paragraphs).

#### **Use case, user specific** {#use-case-user-specific}

- None

### **6.4 Source Function Context** {#64-source-function-context}

#### **6.4.1 ADC TEST FAST** {#641-adc-test-fast}

<p>&nbsp;</p>

**[DRS-REQ-016] Requirement:**

To turn on the ADC TEST LOW NOISE mode shall be:

- Select page 3 of the regmap (ADDRESS=0x40, DATA=0x03)
- Enable LDO 1V8 by writing to regmap VIREF_LDO1V8_CLK16M register (ADDRESS=0xF, DATA=0x02)
- Enable clock by writing to regmap VIREF_LDO1V8_CLK16M register (ADDRESS=0x0F, DATA=0x12)
- Enable ADC in debug mode (ADDRESS=0x09, DATA=0x06)
- Select page 2 of the regmap (ADDRESS=0x40, DATA=0x02)
- Enable ADC TEST LOW NOISE and input of ADC from GPIO (ADDRESS=0x0A, DATA=0x0C)
- Select page 3 of the regmap (ADDRESS=0x40, DATA=0x02)
- Enable debug mode by writing to regmap (ADDRESS=0x3E, DATA=0x08)

Covers: DDS_STBIO1_1507

[End]

Source paragraph: Section 18.4 ADC TEST FAST (under Section 18 Digital DFT), paragraph 010 (page 161)

<p>&nbsp;</p>

#### **6.4.2 ADC TEST LOW NOISE** {#642-adc-test-low-noise}

<p>&nbsp;</p>

**[DRS-REQ-011] Requirement:**

To turn on the ADC TEST LOW NOISE mode shall be:

- Select page 3 of the regmap (ADDRESS=0x40, DATA=0x03)
- Enable LDO 1V8 by writing to regmap VIREF_LDO1V8_CLK16M register (ADDRESS=0xF, DATA=0x02)
- Enable clock by writing to regmap VIREF_LDO1V8_CLK16M register (ADDRESS=0x0F, DATA=0x12)
- Enable ADC in debug mode (ADDRESS=0x09, DATA=0x06)
- Select page 2 of the regmap (ADDRESS=0x40, DATA=0x02)
- Enable ADC TEST LOW NOISE and input of ADC from GPIO (ADDRESS=0x0A, DATA=0x14)
- Select page 3 of the regmap (ADDRESS=0x40, DATA=0x02)
- Enable debug mode by writing to regmap (ADDRESS=0x3E, DATA=0x08)

Covers: DDS_STBIO1_0701

[End]

Source paragraph: Section 18.3 ADC TEST LOW NOISE (under Section 18 Digital DFT), paragraph 006 (page 160)

<p>&nbsp;</p>

**[DRS-REQ-053] Requirement:**

To turn on the ADC TEST LOW NOISE mode shall be:

- Select page 3 of the regmap (ADDRESS=0x40, DATA=0x03)
- Enable LDO 1V8 by writing to regmap VIREF_LDO1V8_CLK16M register (ADDRESS=0xF, DATA=0x02)
- Enable clock by writing to regmap VIREF_LDO1V8_CLK16M register (ADDRESS=0x0F, DATA=0x12)
- Enable ADC in debug mode (ADDRESS=0x09, DATA=0x06)
- Select page 2 of the regmap (ADDRESS=0x40, DATA=0x02)
- Enable ADC TEST LOW NOISE and input of ADC from GPIO (ADDRESS=0x0A, DATA=0x14)
- Select page 3 of the regmap (ADDRESS=0x40, DATA=0x02)
- Enable debug mode by writing to regmap (ADDRESS=0x3E, DATA=0x08)

Covers: DDS_STBIO1_0702

[End]

Source paragraph: Section 18.3 ADC TEST LOW NOISE (under Section 18 Digital DFT), paragraph 023 (page 160)

<p>&nbsp;</p>

#### **6.4.3 BIST MODE** {#643-bist-mode}

<p>&nbsp;</p>

**[DRS-REQ-036] Requirement:**

After the initial boot phase, to turn on the Debug mode shall be:

- Select page 3 of the regmap (ADDRESS=0x40, DATA=0x03)
- Enable LDO 1V8 by writing to regmap VIREF_LDO1V8_CLK16M register (ADDRESS=0x0F, DATA=0x02)
- Enable clock by writing to regmap VIREF_LDO1V8_CLK16M register (ADDRESS=0x0F, DATA=0x12)
- Enable the power island
- Enable bist mode by writing to regmap (ADDRESS=0x3E, DATA=0x04)

Covers: DDS_STBIO1_2507

[End]

Source paragraph: Section 18.5 BIST MODE (under Section 18 Digital DFT), paragraph 030 (page 161)

<p>&nbsp;</p>

#### **6.4.4 CHECK DATA** {#644-check-data}

<p>&nbsp;</p>

**[DRS-REQ-019] Requirement:**

- To check data in unique FIFO (default config) the user shall check the first MSB. PPG DATA has 20 bits of data and 4 of TAG. The 4 bits, from 0 to 11, are used to identify the frame (as described in the table in DATA TAG table).

Covers: DDS_STBIO1_0149

[End]

Source paragraph: Section 7 CHECK DATA: (under Section 15.3.3 PPG Only), paragraph 011 (page 153)

<p>&nbsp;</p>

#### **6.4.5 CONFIGURE ADC SAMPLING PERIOD** {#645-configure-adc-sampling-period}

<p>&nbsp;</p>

**[DRS-REQ-038] Requirement:**

- The user shall configure the number of clocks for sampling PPG data from ADC in ADC_CONFIG_PPG register.

Covers: DDS_STBIO1_0146

[End]

Source paragraph: Section 4 CONFIGURE ADC SAMPLING PERIOD: (under Section 15.3.3 PPG Only), paragraph 022 (page 152)

<p>&nbsp;</p>

#### **6.4.6 Debug mode** {#646-debug-mode}

<p>&nbsp;</p>

**[DRS-REQ-012] Requirement:**

After the initial boot phase, to turn on the Debug mode shall be:

- Select page 3 of the regmap (ADDRESS=0x40, DATA=0x03)
- Enable LDO 1V8 by writing to regmap VIREF_LDO1V8_CLK16M register (ADDRESS=0x0F, DATA=0x02)
- Enable clock by writing to regmap VIREF_LDO1V8_CLK16M register (ADDRESS=0x0F, DATA=0x12)
- Enable debug mode by writing to regmap (ADDRESS=0x3E, DATA=0x08)

Covers: DDS_STBIO1_0700

[End]

Source paragraph: Section 18.2 Debug mode (under Section 18 Digital DFT), paragraph 024 (page 159)

<p>&nbsp;</p>

#### **6.4.7 ISPU integration** {#647-ispu-integration}

<p>&nbsp;</p>

**[DRS-REQ-026] Requirement:**

The irq_FIFO_U_M_IRQ_STsATUS interrupt shall be connected to FIFO status to bit 29.

Covers: DDS_STBIO1_0501

[End]

Source paragraph: Section 13.3.1 Requirements (under Section 13.3 ISPU integration), paragraph 007 (page 130)

<p>&nbsp;</p>

**[DRS-REQ-045] Requirement:**

The irq_SENSHUB_STS interrupt shall be connected to SENSOR HUB status to bit 28.

Covers: DDS_STBIO1_0502

[End]

Source paragraph: Section 13.3.1 Requirements (under Section 13.3 ISPU integration), paragraph 008 (page 130)

<p>&nbsp;</p>

**[DRS-REQ-052] Requirement:**

The irq_ISPU_MC_INTR_STS interrupt shall be connected to ECG, BIA or PPG samples ready for elaboration to bit 27.

Covers: DDS_STBIO1_0503

[End]

Source paragraph: Section 13.3.1 Requirements (under Section 13.3 ISPU integration), paragraph 009 (page 130)

<p>&nbsp;</p>

**[DRS-REQ-031] Requirement:**

The sw_interrupt interrupt shall be connected to sw interrupt used by ADSP or external user to bit 26:11 16.

Covers: DDS_STBIO1_0504

[End]

Source paragraph: Section 13.3.1 Requirements (under Section 13.3 ISPU integration), paragraph 011 (page 130)

<p>&nbsp;</p>

**[DRS-REQ-005] Requirement:**

The irq_timer interrupt shall be connected to Internal timer to bit 1.

Covers: DDS_STBIO1_0505

[End]

Source paragraph: Section 13.3.1 Requirements (under Section 13.3 ISPU integration), paragraph 013 (page 130)

<p>&nbsp;</p>

**[DRS-REQ-032] Requirement:**

To put the ISPU into sleep mode, it is necessary to perform a read at address 0x80054.

Covers: DDS_STBIO1_0509

[End]

Source paragraph: Section 13.3.1 Requirements (under Section 13.3 ISPU integration), paragraph 023 (page 131)

<p>&nbsp;</p>

**[DRS-REQ-046] Requirement:**

To wake up the ISPU, it is necessary to trigger an interrupt.

Covers: DDS_STBIO1_05010

[End]

Source paragraph: Section 13.3.1 Requirements (under Section 13.3 ISPU integration), paragraph 027 (page 131)

<p>&nbsp;</p>

**[DRS-REQ-048] Requirement:**

When the ISPU is in sleep mode, it is possible to perform reads and writes from the data and code memory by triggering an AHB transition.

Covers: DDS_STBIO1_05011

[End]

Source paragraph: Section 13.3.1 Requirements (under Section 13.3 ISPU integration), paragraph 031 (page 131)

<p>&nbsp;</p>

#### **6.4.8 PPG FRAMES CONFIG** {#648-ppg-frames-config}

<p>&nbsp;</p>

**[DRS-REQ-015] Requirement:**

The user shall configure each frame following these steps:

5.1 ALC PARAMETERS:

- T1 in PPG_ALC_CONFIG_PARAM_1 register.
- T2, GAIN_START_SET, GAIN_MAX_SET in PPG_ALC_CONFIG_PARAM_2 register.

5.2 DIGITAL RAMP PARAMETERS:

- N_MAX, T_DELTA in DIGITAL_RAMP_CONFIG_PARAM_1 register.
- DELTA, T_DELTA1 in DIGITAL_RAMP_CONFIG_PARAM_2 register.
- DELTA1 in DIGITAL_RAMP_CONFIG_PARAM_3 register.

5.3 GENERAL PPG PARAMETERS:

- N_PPG_FRAME, WAVE_VELOCITY_MODE, SEL_PPG_ELAB in GENERAL_PPG_PARAMETERS_1 register.
- T_TX_STARTUP in GENERAL_PPG_PARAMETERS_2 register.
- T_RX_SET, PPG_START_UP_TIME_l in GENERAL_PPG_PARAMETERS_3 register.
- PPG_START_UP_TIME_h in GENERAL_PPG_PARAMETERS_4 register.

5.4 PARAMETERS FOR EACH FRAME CONFIGURED BY USER:

- RX_CH_FRAME_{n}, FRAME_{n}_SAMPLES, FRAME_{n}_REPETITION in FRAME_n_PARAMETERS_1 register.
- BTIA_GAIN_FRAME_{n}, TX_LEDSET_FRAME_l_{n} in FRAME_n_PARAMETERS_2 register.
- TX_LEDSET_FRAME_h_{n}, TX_LEDOFF_FRAME_l_{n} in FRAME_n_PARAMETERS_3 register.
- TX_LEDOFF_FRAME_h_{n} in FRAME_n_PARAMETERS_4 register.
- IDAC_DC_PPG_FRAME_{n} in FRAME_n_PARAMETERS_5 register.
- EN_TX_i in FRAME_n_PARAMETERS_6 register.
- CURR_SEL_TX_FRAME{n} in FRAME_n_PARAMETERS_7 register.
- TX1_OUTAB_SEL_FRAME_{n}, TX2_OUTAB_SEL_FRAME_{n}, TX3_OUTAB_SEL_FRAME_{n}, TX4_OUTAB_SEL_FRAME_{n} in FRAME_n_PARAMETERS_10 register.

Covers: DDS_STBIO1_0147

[End]

Source paragraph: Section 5 PPG FRAMES CONFIG: (under Section 15.3.3 PPG Only), paragraph 026 (page 152)

<p>&nbsp;</p>

#### **6.4.9 SELECT CHANNEL** {#649-select-channel}

<p>&nbsp;</p>

**[DRS-REQ-051] Requirement:**

- The user shall select active channel, in this case only PPG_SEL and DS_SEL (data Storage) in DEVICE_CONFIG_CHANNEL register shall be set to 0x30.

Covers: DDS_STBIO1_0144

[End]

Source paragraph: Section 2 SELECT CHANNEL: (under Section 15.3.3 PPG Only), paragraph 014 (page 152)

<p>&nbsp;</p>

#### **6.4.10 SELECT DIVISION INDEX FOR CONFIGURED CHANNELS** {#6410-select-division-index-for-configured-channels}

<p>&nbsp;</p>

**[DRS-REQ-028] Requirement:**

- The user shall configure a division index PPG, writing M_PPG_l and M_PPG_h in SET_PPG_FREQ_l register and SET_PPG_FREQ_h register.

Covers: DDS_STBIO1_0145

[End]

Source paragraph: Section 3 SELECT DIVISION INDEX FOR CONFIGURED CHANNELS: (under Section 15.3.3 PPG Only), paragraph 018 (page 152)

<p>&nbsp;</p>

#### **6.4.11 SELECT OPERATIVE MODE** {#6411-select-operative-mode}

<p>&nbsp;</p>

**[DRS-REQ-043] Requirement:**

- The user shall write DEVICE_CONFIG_OPERATION register [0] at 1.

Covers: DDS_STBIO1_0148

[End]

Source paragraph: Section 6 SELECT OPERATIVE MODE: (under Section 15.3.3 PPG Only), paragraph 008 (page 153)

<p>&nbsp;</p>

#### **6.4.12 Scan mode** {#6412-scan-mode}

<p>&nbsp;</p>

**[DRS-REQ-034] Requirement:**

After the initial boot phase, only with SPI interface, to turn on the Scan mode shall be:

- Select page 3 of the regmap (ADDRESS=0x40, DATA=0x03)
- Enable LDO 1V8 by writing to regmap VIREF_LDO1V8_CLK16M register (ADDRESS=0x0F, DATA=0x02)
- Enable clock by writing to regmap VIREF_LDO1V8_CLK16M register (ADDRESS=0x0F, DATA=0x12)
- Enable debug mode by writing to regmap (ADDRESS=0x3E, DATA=0x01) Figure 26 scan mode activation timing

Covers: DDS_STBIO1_0699

[End]

Source paragraph: Section 18.1 Scan mode (under Section 18 Digital DFT), paragraph 011 (page 159)

<p>&nbsp;</p>

#### **6.4.13 TIME SLOT LENGTH** {#6413-time-slot-length}

<p>&nbsp;</p>

**[DRS-REQ-009] Requirement:**

- The User shall configure time slot duration in DEVICE_CONFIG_OPERATION register [4:2].

Covers: DDS_STBIO1_0143

[End]

Source paragraph: Section 1 TIME SLOT LENGTH: (under Section 15.3.3 PPG Only), paragraph 010 (page 152)

<p>&nbsp;</p>

#### **6.4.14 XBAR Connection Matrix** {#6414-xbar-connection-matrix}

## **7. Interfaces and mixed-signal interactions** {#7-interfaces-and-mixed-signal-interactions}
ADC provides digital samples to Main Controller. SPI interface provides SPI register transactions to Regmap. I2C interface provides I2C register transactions to Regmap. Regmap provides register read response to SPI interface and I2C interface. I2C_SPI_AHB provides SPI host transactions to SPI interface and I2C host transactions to I2C interface. Main Controller and SENSOR HUB connect to FIFO through XBAR. ADSP, I2C_SPI_AHB and ISPU connect to SENSOR HUB and FIFO through XBAR. ISPU debug connects to Regmap, SENSOR HUB, ISPU, FIFO and ADSP through XBAR.

| Source | Destination | Architectural exchange |
|---|---|---|
| ADC | Main Controller | digital samples |
| SPI interface | Regmap | SPI register transactions |
| I2C interface | Regmap | I2C register transactions |
| Regmap | SPI interface | register read response |
| Regmap | I2C interface | register read response |
| I2C_SPI_AHB | SPI interface | SPI host transactions |
| I2C_SPI_AHB | I2C interface | I2C host transactions |
| Main Controller | FIFO | XBAR connection |
| ADSP | SENSOR HUB | XBAR connection |
| ADSP | FIFO | XBAR connection |
| I2C_SPI_AHB | SENSOR HUB | XBAR connection |
| I2C_SPI_AHB | FIFO | XBAR connection |
| SENSOR HUB | FIFO | XBAR connection |
| ISPU | SENSOR HUB | XBAR connection |
| ISPU | FIFO | XBAR connection |
| ISPU debug | Regmap | XBAR connection |
| ISPU debug | SENSOR HUB | XBAR connection |
| ISPU debug | ISPU | XBAR connection |
| ISPU debug | FIFO | XBAR connection |
| ISPU debug | ADSP | XBAR connection |

<p>&nbsp;</p>

## **8. Assumptions** {#8-assumptions}

- ASSUME-001: Firmware and verification environments provide deterministic digital stimulus and observability.


## **9. Top-level integration requirements** {#9-top-level-integration-requirements}

Shared-resource, interface, clock/reset, interrupt, and interaction constraints are rendered here at integration scope. Detailed block-local behavior remains in Digital IPOS specifications.

<p>&nbsp;</p>

**[DRS-REQ-001] Requirement:**

The ADSP block shall be connected to the FIFO block.

Covers: DDS_STBIO1_0206

[End]

<p>&nbsp;</p>

**[DRS-REQ-004] Requirement:**

The I2C_SPI_AHB block shall be connected to the SENSOR HUB block.

Covers: DDS_STBIO1_0208

[End]

<p>&nbsp;</p>

**[DRS-REQ-008] Requirement:**

The ISPU block shall be connected to the ADSP block.

Covers: DDS_STBIO1_0222

[End]

<p>&nbsp;</p>

**[DRS-REQ-010] Requirement:**

The I2C_SPI_AHB block shall be connected to the Regmap block.

Covers: DDS_STBIO1_0207

[End]

<p>&nbsp;</p>

**[DRS-REQ-013] Requirement:**

The Main Controller block shall be connected to the Regmap block.

Covers: DDS_STBIO1_0201

[End]

<p>&nbsp;</p>

**[DRS-REQ-014] Requirement:**

The ISPU debug block shall be connected to the SENSOR HUB block.

Covers: DDS_STBIO1_0217

[End]

<p>&nbsp;</p>

**[DRS-REQ-018] Requirement:**

The I2C_SPI_AHB block shall be connected to the ISPU block.

Covers: DDS_STBIO1_0209

[End]

<p>&nbsp;</p>

**[DRS-REQ-021] Requirement:**

The ISPU block shall be connected to the FIFO block.

Covers: DDS_STBIO1_0215

[End]

<p>&nbsp;</p>

**[DRS-REQ-022] Requirement:**

The I2C_SPI_AHB block shall be connected to the FIFO block.

Covers: DDS_STBIO1_0210

[End]

<p>&nbsp;</p>

**[DRS-REQ-024] Requirement:**

The ISPU debug block shall be connected to the FIFO block.

Covers: DDS_STBIO1_0220

[End]

<p>&nbsp;</p>

**[DRS-REQ-025] Requirement:**

The I2C_SPI_AHB block shall be connected to the ADSP block.

Covers: DDS_STBIO1_0221

[End]

<p>&nbsp;</p>

**[DRS-REQ-027] Requirement:**

The ISPU block shall be connected to the Regmap block.

Covers: DDS_STBIO1_0212

[End]

<p>&nbsp;</p>

**[DRS-REQ-030] Requirement:**

The ISPU debug block shall be connected to the Regmap block.

Covers: DDS_STBIO1_0216

[End]

<p>&nbsp;</p>

**[DRS-REQ-033] Requirement:**

The Main Controller block shall be connected to the ADSP block.

Covers: DDS_STBIO1_0219

[End]

<p>&nbsp;</p>

**[DRS-REQ-037] Requirement:**

The ADSP block shall be connected to the SENSOR HUB block.

Covers: DDS_STBIO1_0204

[End]

<p>&nbsp;</p>

**[DRS-REQ-039] Requirement:**

The Main Controller block shall be connected to the FIFO block.

Covers: DDS_STBIO1_0202

[End]

<p>&nbsp;</p>

**[DRS-REQ-041] Requirement:**

The SENSOR HUB block shall be connected to the FIFO block.

Covers: DDS_STBIO1_0211

[End]

<p>&nbsp;</p>

**[DRS-REQ-042] Requirement:**

The ADSP block shall be connected to the Regmap block.

Covers: DDS_STBIO1_0203

[End]

<p>&nbsp;</p>

**[DRS-REQ-050] Requirement:**

The ISPU debug block shall be connected to the ISPU block.

Covers: DDS_STBIO1_0218

[End]

<p>&nbsp;</p>

**[DRS-REQ-054] Requirement:**

The ISPU block shall be connected to the SENSOR HUB block.

Covers: DDS_STBIO1_0213

[End]

<p>&nbsp;</p>

**[DRS-REQ-055] Requirement:**

The ISPU debug block shall be connected to the ADSP block.

Covers: DDS_STBIO1_0223

[End]


### **9.1 Sensor-Hub** {#91-sensor-hub}
The Sensor-Hub block is designed to operate the Sensor Hub I2C master for external targets, including trigger/control, pad enable, data collection, and FIFO multi-mode coordination.

<p>&nbsp;</p>

Source interface table 1: Table 26: Sensor Hub I/O List

- source table from OCR extract page 105

| Port name | Direction | Type / Function | TOP CONNECTION / Details |
|---|---|---|---|
| scan_mode | input |  | |
| scan_enable | input |  | |
| scan_rstn | input |  | |
| HCLKM | input |  | |
| HCLKS | input |  | |
| sys_clk | input |  | |
| HRESETn | input |  | |
| DEBUG_MODE_i | input |  | |
| scl_master_in | input |  | |
| sda_master_in | input |  | |
| scl_master_out | output |  | |
| sda_master_out | output |  | |
| dvalid_masterblaze_ext | input |  | |
| dvalid_masterblaze_ext_enable | input |  | |
| sleep_master | output |  | |
| master_end_op_pulse | output |  | |
| SH_SMARTFIFO_OCCUPATION | Input |  | |
| fifo_mode | input |  | |
| fifo_offset | input | [11:0] | |
| HSELS | input |  | |
| HADDRS | input | [ADDRWIDTH- | |

<p>&nbsp;</p>

| Port name | Direction | Type / Function | TOP CONNECTION / Details |
|---|---|---|---|
| HTRANSS | input | [1:0] | |
| HSIZES | input | [2:0] | |
| HWRITES | input |  | |
| HREADYS | input |  | |
| HWDATAS | input | [31:0] | |
| HREADYOUTS | output |  | |
| HRESPS | output |  | |
| HRDATAS | output | [31:0] | |
| ahb_master_on | output |  | |
| HRDATAM | input | [31:0] | |
| HREADYM | input |  | |
| HRESPM | input | [1:0] | |
| HGRANTM | input |  | |
| HSELM | output |  | |
| HADDRM | output | [31:0] | |
| HTRANSM | output | [1:0] | |
| HWRITEM | output |  | |
| HSIZEM | output | [2:0] | |
| HBURSTM | output | [2:0] | |
| HPROTM | output | [3:0] | |
| HWDATAM | output | [31:0] | |
| HBUSREQM | output |  | |
| HLOCKM | output |  | |

<p>&nbsp;</p>

**[DRS-REQ-007] Requirement:**

The Sensor-Hub block shall implement: Input sda_master_in of sensor hub shall be connected to input buffer from sensor hub's SDA PAD. [Vpriority High] [TO: IPOS_Senshub_MB_i2c].

Covers: DDS_STBIO1_9012

[End]

<p>&nbsp;</p>

**[DRS-REQ-023] Requirement:**

The Sensor-Hub block shall implement: Input sys_clk of sensor hub shall be connected to 8MHz clock to generate I2C communications compliant with FM+ I2C standard. [TO: IPOS_Senshub_MB_i2c].

Covers: DDS_STBIO1_9004

[End]

<p>&nbsp;</p>

**[DRS-REQ-040] Requirement:**

The Sensor-Hub block shall implement: Output sda_master_out of sensor hub shall be connected to enable of output buffer of sensor hub's SDA PAD. [Vpriority High] [TO: IPOS_Senshub_MB_i2c].

Covers: DDS_STBIO1_9014

[End]

<p>&nbsp;</p>

**[DRS-REQ-044] Requirement:**

The Sensor-Hub block shall implement: Input scl_master_in of sensor hub shall be connected to input buffer from sensor hub's SCL PAD. [Vpriority High] [TO: IPOS_Senshub_MB_i2c].

Covers: DDS_STBIO1_9011

[End]

<p>&nbsp;</p>

**[DRS-REQ-047] Requirement:**

The Sensor-Hub block shall implement: Output scl_master_out of sensor hub shall be connected to enable of output buffer of sensor hub's SCL PAD in case it is a bi-directional PAD). [Vpriority High] [TO: IPOS_Senshub_MB_i2c].

Covers: DDS_STBIO1_9013

[End]


### **9.2 ADSP** {#92-adsp}
The ADSP block is designed to execute ADSP firmware for OTP boot/write/test and signal elaboration, using mapped program/data/register memory and soft-reset handling.

<p>&nbsp;</p>

Source interface table 1: Table 19: ADSP I/O List

- source table from OCR extract page 87

| Parameter | Value / Type | Details |
|---|---|---|
| ADDRWIDTH | 12 | |

<p>&nbsp;</p>

| Port name | Direction | Type / Function | TOP CONNECTION / Details |
|---|---|---|---|
| stmc_clk | input | wire u_pmu.tst_clk_16m | |
| HCLK | input | wire u_pmu.clk_stmc | |
| HRESETn | input | wire u_pmu.resetn_stmc | |
| HSELS | input | wire u_xbar_afe. | |
| HADDRS | input | wire [ADDRWIDTH-1:0] u_xbar_afe.haddr_M1 | |
| HTRANSS | input | wire [ 1:0] u_xbar_afe.htrans_M1 | |
| HSIZES | input | wire [ 2:0] u_xbar_afe. | |
| HWRITES | input | wire u_xbar_afe. | |
| HREADYS | input | wire u_xbar_afe. | |
| HWDATAS | input | wire [ 31:0] u_xbar_afe. | |
| HREADYOUTS | output | wire u_xbar_afe. | |
| HRESPS | output | wire u_xbar_afe. | |
| HRDATAS | output | wire [ 31:0] u_xbar_afe. | |
| HRDATAM | input | wire [ 31:0] | |
| HREADYM | input | wire | |
| HRESPM | input | wire [ 1:0] | |
| HGRANTM | input | wire | |
| HSELM | output | wire | |
| HADDRM | output | wire [ 31:0] | |
| HTRANSM | output | wire [ 1:0] | |
| HWRITEM | output | wire | |
| HSIZEM | output | wire [ 2:0] | |
| HBURSTM | output | wire [ 2:0] | |
| HPROTM | output | wire [ 3:0] | |
| HWDATAM | output | wire [ 31:0] | |
| HBUSREQM | output | wire | |
| HLOCKM | output | wire | |
| stmc_data_CSN | output | wire | |
| stmc_data_WEN | output | wire | |
| stmc_data_A | output | wire [ 8:0] | |
| stmc_data_D | output | wire [ 63:0] | |
| stmc_data_M | output | wire [ 63:0] | |
| stmc_data_Q | input | wire [ 63:0] | |
| stmc_rom_CLK | output | wire | |
| stmc_rom_CSN | output | wire | |
| stmc_rom_A | output | wire [ 10:0] | |
| stmc_rom_Q | input | wire [ 22:0] | |
| quokka_run | output | wire | |
| quokka_boot_end | output | wire main_controller_top.i_quokka_b | |
| ahb_master_clk_en | output | wire U_pmu.clk_en_s1 | |
| scan_mode | input | wire | |
| scan_en | input | wire | |
| scan_clk | input | wire | |
| scan_rst_n | input | wire | |

<p>&nbsp;</p>

**[DRS-REQ-020] Requirement:**

The ADSP block shall implement: After each Boot routine performed by the ADSP, a value of 0x04 shall be written once to address 0x0CA00C to ensure correct operation of the AHB transactions. [Vpriority High].

Covers: DDS_STBIO1_0032

[End]


### **9.3 Main Controller** {#93-main-controller}
The Main Controller block is designed to generate and receive Analog Domain control signals, perform DSP elaboration on ADC outputs, and write elaborated results to the defined addresses.

<p>&nbsp;</p>

Source interface table 1: 13.1.3.2. Main Controller TOP I/O List

- source table from OCR extract page 74

| Parameter | Value / Type | Details |
|---|---|---|
| ppg_frame_bit_top | 4 | |
| n_max_frame | 12 | |
| ppg_rx_channel_bit_top | 3 | |
| T_tx_led_set_bit_top | 9 | |
| T_tx_led_off_max_bit_top | 11 | |
| m_odr_max_bit_top | 12 | |
| mode_operation_n_bit_top | 2 | |
| idac_dc_ppg_frame_bit_top | 6 | |
| time_slot_sel_bit_top | 3 | |
| T_tx_startup_bit_top | 8 | |
| T_rx_set_bit_top | 9 | |
| Nmax_bit_top | 4 | |
| base_address_bit_top | 12 | |
| delta_bit_top | 4 | |
| gain_max_bit_top | 4 | |
| T1_max_bit_top | 9 | |
| T2_max_bit_top | 5 | |
| N_clk_max_bit_top | 6 | |
| n_average_ppg_max_bit_top | 3 | |
| rx_ch_gain_max_bit_top | 4 | |
| BTIA_ALC_register_bit_top | 9 | |
| n_channel_bit_top | 4 | |
| n_channel_adc_bit | 4 | |
| quokka_routine_bit_top | 16 | |
| vcm_bit_top | 14 | |
| gnc_cmm_top | 15 | |
| id_frame_max_bit_top | 4 | |
| data_in_size_bit_top | 16 | |
| ppg_start_up_bit_top | 9 | |
| data_out_size_bit_top | 20 | |
| n_average_ecg_bia_gsr_max_bit_top | 8 | |
| rx_ch_frame_n_bit_top | 3 | |
| curr_sel_bit_top | 8 | |
| bit_outab_sel_top | 1 | |
| n_average_ppg_max_value | 128 | |
| n_average_ecg_bia_gsr_max_value | 16 | |
| max_frame_repetition_top | 2 | |
| n_tx_channel | 4 | |
| ahb_base_address | [31:0] 32'h000C4000 | |
| time_buffer_const_bit_top | 10 | |
| T1_max_bit_from_decoder_top | 4 | |
| T2_max_bit_from_decoder_top | 2 | |
| ppg_frame_bit_ALC_BTIA_top | 12 | |
| ecg_channel_bit | 2 | |

<p>&nbsp;</p>

| Port name | Direction | Type / Function | TOP CONNECTION / Details |
|---|---|---|---|
| i_clk_32kHz | input | clk 32kHz from pmu | |
| i_clk_16MHz | input | clk 16MHz from pmu | |
| i_clk_gsr_16M | input | clk for gsr signal | |
| i_clk_ahb_master | input | clock for ahb master | |
| i_rstn | input | reset in 16MHz domain | |
| i_rstn_sync_32 | input | reset in 32kz domain | |
| i_wave_velocity_mode | input | enable of the wave velocity mode | |
| i_ispu_end_elab | input |  | |
| i_n_ppg_frame | input | [ppg_frame_bit_top-1:0] number of frame selected | |
| i_const_value_ioff | input | [data_in_size_bit_top-1:0] constant value from regmap used for ppg ioff | |
| i_rx_ch_frame | input | [n_max_frame-1:0] ppg rx channel frame from regamp | |
| i_T_tx_led_set | input | [n_max_frame-1:0] tx led set time from regmap | |
| i_T_tx_led_off | input | [n_max_frame-1:0] tx led off time from regmap | |
| i_curr_sel_tx_frame_x | input | [n_max_frame-1:0] current injection | |
| i_tx1_outlab_sel_frame_x | input | [n_max_frame-1:0] led output selected from regmap for each frame | |
| i_tx2_outlab_sel_frame_x | input | [n_max_frame-1:0] led output selected from regmap for each frame | |
| i_tx3_outlab_sel_frame_x | input | [n_max_frame-1:0] led output selected from regmap for each frame | |
| i_tx4_outlab_sel_frame_x | input | [n_max_frame-1:0] led output selected from regmap for each frame | |
| i_idac_dc_ppg_frame | input | [n_max_frame-1:0] idac value for each frame selected from regmap | |
| i_average_ppg | input | [n_max_frame-1:0] average ppg for each frame selected from | |
| i_gain_alc_start | input | [gain_max_bit_top-1:0] btia gain for alc from regmap | |
| i_gain_start | input | [n_max_frame-1:0] btia gain start for compensation from regmap | |
| i_Tx_idac_Vref_debug | input | [Nmax_bit_top-1:0] Idac value for debug from regmap | |

<p>&nbsp;</p>

| Port name | Direction | Type / Function | TOP CONNECTION / Details |
|---|---|---|---|
| i_ppg_start_up_time | input | [ppg_start_up_decod_bit_top-1:0] start up time for ppg from regmap | |
| i_en_txi | input | [n_max_frame-1:0] tx enabling for each frame from regmap | |
| i_frame_repetition | input | [n_max_frame-1:0] i frame repetition for each frame from regmap | |
| i_T_preset | input | [1:0] Preset time for digital ramp from regmap | |
| i_m_ecg | input | [m_odr_max_bit_top-1:0] m parameter for ecg from regmap | |
| i_m_bia | input | [m_odr_max_bit_top-1:0] m parameter for bia from regmap | |
| i_m_gsr | input | [m_odr_max_bit_top-1:0] m parameter for gsr from regmap | |
| i_m_ppg | input | [m_odr_max_bit_top-1:0] m parameter for ppg from regmap | |
| i_debug_adc_error_cap8_0_bypass | input | error cap bypass for adc from regmap | |
| i_base_address_ecg0 | input | [base_address_bit_top-1:0] base address for ecg0 in multiple fifo | |
| i_base_address_bia | input | [base_address_bit_top-1:0] base address for bia/ecg1-2 in multiple fifo | |
| i_base_address_gsr | input | [base_address_bit_top-1:0] base address for gsr in multiple fifo | |
| i_base_address_ppg | input | [base_address_bit_top-1:0] base address for ppg in multiple fifo | |
| i_frame_ppg_debug | input | [ppg_frame_bit_top-1:0] frame selection for ppg data debug | |
| i_en_buf_gpio1 | input | enable buffer on gpio1 | |
| i_en_buf_gpio2 | input | enable buffer on gpio2 | |
| i_en_biobuf | input | enable biobuffer | |
| i_do_calibration | input | enabling for adc calibration | |
| i_mode_operation | input | [mode_operation_n_bit_top-1:0] mode operation selection | |
| i_T_rx_set | input | [T1_max_bit_from_decoder_top- | |
| i_en_clkf | input | en 16 MHz clock | |
| i_quokka_boot_end | input | from quokka | |
| i_quokka_run | input | from quokka | |

<p>&nbsp;</p>

| Port name | Direction | Type / Function | TOP CONNECTION / Details |
|---|---|---|---|
| i_clk_16MHz_ready | input | (from analog circuit) | |
| i_imp_curinj_en | input | enabling current injection for bia | |
| i_en_ldo_1v8 | input | enabling ldo 1v8 | |
| i_debug_comp_rx_ck | input | enabling debug for comp rx ck | |
| i_debug_gsr_on | input | gsr on debug mode | |
| i_debug_gsr_curr_on | input | gsr curr on debug mode | |
| i_alc_disabled | input | [n_max_frame-1:0] disabling alc bit for each frame | |
| i_en_cm_buf | input | enabling common buffer | |
| i_en_rld | input | enabling rld | |
| i_en_avg1 | input | enabling avg1 | |
| i_en_avg2 | input | enabling avg1 | |
| i_hc_en | input | enabling health channel | |
| i_debug | input | enabling debug mode | |
| i_imp_en | input | enabling bia channel | |
| i_debug_en_tia | input | enabling debug tia | |
| i_debug_en_buffer | input | enabling debug for buffer | |
| i_debug_en_idac | input | enabling debug for IDAC | |
| i_en_clk_chop10k | input | enabling chopper clock | |
| i_debug_tx_preset | input | enabling tx preset | |
| i_en_ldo_1v8_ext | input | enabling external ldo 1v8 | |
| i_clk_imp_10k_en | input | enabling clock chopper for bia | |
| i_b_cap_idac | input | [1:0] enabling cap for idac | |
| i_adc_mux_bio_channel_debug | input | [2:0] enabling debug adc mux bio channel | |
| i_adc_mux_sel_debug | input | enabling adc mux | |

<p>&nbsp;</p>

| Port name | Direction | Type / Function | TOP CONNECTION / Details |
|---|---|---|---|
| i_ispu_core_sw_rstn | input | ispu core enabling | |
| i_T_TIAON | input | [T1_max_bit_from_decoder_top- | |
| i_scan_mode | input | scan mode enabling | |
| i_reset_debug_adc_data | input | reset adc data debug | |
| i_start_adc_debug | input | pilot adc start om debug | |
| i_en_ADC_debug | input | enabling adc debug | |
| i_debug_adc_readout_bypass | input | enabling adc readout bypass | |
| i_su_hlt_dly | input | enabling start up delay for ecg | |
| i_multiple_fifo_sel | input | enabling multiple fifo | |
| i_debug_calibration | input | enabling debug calibraiton | |
| i_en_gsr_dc_cds | input | [1:0] enabling gsr cds mode | |
| i_ADC_EOC | input | end of conversion from adc | |
| i_ecg0_sel | input | select ecg0 channel | |
| i_bia_sel | input | select bia channel | |
| i_gsr_sel | input | select gsr channel | |
| i_ppg_sel | input | select ppg channel | |
| i_ppg_ioff_calibration | input | enabling ppg ioff calibration | |
| i_ecg1_ecg2_sel | input | enabling ecg1 and ecg2 channel | |
| i_rst_async_ecg | input | reset async for ecg | |
| i_rst_async_bia | input | reset async for bia | |
| i_ppg_quokka_elab_sel | input | enabling adsp elab for ppg | |
| i_data_ADC_out | input | [data_in_size_bit_top-1:0] (from analog circuit) | |
| i_time_slot_selection | input | [time_slot_sel_bit_top-1:0] odr selection from regmap | |

<p>&nbsp;</p>

| Port name | Direction | Type / Function | TOP CONNECTION / Details |
|---|---|---|---|
| i_Nmax_to_reg | input | [Nmax_bit_top-1:0] Max value for digital ramp | |
| i_nstart_case | input | [Nmax_bit_top-1:0] n_start value for frist sterp | |
| i_debug_rx_ch | input | [rx_ch_frame_n_bit_top-1:0] enabling debug for rx channel | |
| i_T_delta1_to_reg | input | [delta_bit_top-1:0] delta 1 time for digital ramp | |
| i_gain_max_set | input | [gain_max_bit_top-1:0] gain max for alc | |
| i_BTIA_ALC_debug | input | [BTIA_ALC_register_bit_top-1:0] BTIA ALC Debug enable | |
| i_comp_rx_out | input | input from analog comparator | |
| i_adc_error_cap8_debug | input | [6:0] adc cap error debug | |
| i_adc_error_cap7_debug | input | [6:0] adc cap error debug | |
| i_adc_error_cap6_debug | input | [6:0] adc cap error debug | |
| i_adc_error_cap5_debug | input | [6:0] adc cap error debug | |

<p>&nbsp;</p>

Source interface table 2: Table 17: Main Controller I/O List

- source table from OCR extract page 85

| Port name | Direction | Type / Function | TOP CONNECTION / Details |
|---|---|---|---|
| o_adc_error_cap5 | output | [6:0] 0 adc calibration result | |
| o_adc_error_cap4 | output | [6:0] 0 adc calibration result | |
| o_adc_error_cap3 | output | [6:0] 0 adc calibration result | |
| o_adc_error_cap2 | output | [6:0] 0 adc calibration result | |
| o_adc_error_cap1 | output | [6:0] 0 adc calibration result | |
| o_adc_error_cap0 | output | [6:0] 0 adc calibration result | |
| o_pd_cm_buf | output | 1 power down common buffer | |
| o_pd_rld | output | 1 power down rld | |
| o_pd_avg1 | output | 1 power down avg1 | |
| o_pd_avg2 | output | 1 power down avg2 | |
| o_mc_ahb_clk_en | output | 0 enable for master ahb clock | |
| o_main_controller_device_status_register | output | [2:0] 0 device status register | |
| o_main_controller_elab_status_register | output | [3:0] 0 device status register | |
| o_en_ldo_1v8 | output | 0 enable ldo | |
| o_en_bufxbio | output | 0 enable biobuffer to analog domain | |
| o_rx_ch_frame | output | [ppg_rx_channel_bit_top-1:0] 0 selected rx ch frame to analog domain | |
| o_ldo_ext | output | 0 enable external ldo | |
| o_ppg_status_register | output | [n_state_bit-1:0] 0 ppg state status register | |
| o_b_cap_idac | output | [1:0] 0 b cap idac to analog domain | |
| o_ispu_irq_ctrl | output | [3:0] 0 ispu irq | |
| o_irq_start_measurement | output | 0 irq start measurement to GPIO | |
| o_end_calibration | output | 1 end calibration to analog domain | |
| o_alc_data | output | [data_out_size_bit_top+2:0] 0 alc data to regmap | |
| o_ppg_data_raw | output | [data_out_size_bit_top+2:0] 0 ppg raw data to regmap | |

<p>&nbsp;</p>

| Port name | Direction | Type / Function | TOP CONNECTION / Details |
|---|---|---|---|
| o_pd_buf_gpio1 | output | 1 power down for buffer gpio1 | |
| o_pd_buf_gpio2 | output | 1 power down for buffer gpio2 | |
| o_adc_data_debug_alc_1 | output | [frame_ppg_debug_alc_top-1:0] 0 alc 1 registers data debug | |
| o_adc_data_debug_alc_2 | output | [frame_ppg_debug_alc_top-1:0] 0 alc 2 registers data debug | |
| o_adc_data_debug_ppg_raw | output | [frame_ppg_debug_ppg_raw_top- | |
| o_en_lead_off | output | 0 mask lead off | |
| o_mc_busy | output | 0 main controller is working | |
| o_en_ck_m_p_q | output | 0 clock m and q bia | |
| o_en_ck_chop_imp | output | 0 clock chopper bia | |
| o_saturation_flag | output | [n_max_frame-1:0] 0 ppg saturation flag | |
| o_en_ck_hc2_10k | output | 0 clock chipper ecg | |
| o_en_clk_16MHz_sleep | output | 1 sleep signal for pmu | |
| o_gsr_clk_en_16M | output | 0 enable clock for gsr channel | |

<p>&nbsp;</p>

| Port name | Direction | Type / details | Source page |
|---|---|---|---|
| i_clk_32kHz | input | clk 32kHz from pmu | 76 |
| i_clk_16MHz | input | clk 16MHz from pmu | 76 |
| i_clk_gsr_16M | input | clk for gsr signal | 76 |
| i_clk_ahb_master | input | clock for ahb master | 76 |
| i_rstn | input | reset in 16MHz domain | 76 |
| i_rstn_sync_32 | input | reset in 32kz domain | 76 |
| i_wave_velocity_mode | input | enable of the wave velocity mode | 76 |
| i_ispu_end_elab | input |  | 76 |
| i_n_ppg_frame | input | [ppg_frame_bit_top-1:0] number of frame selected | 76 |
| i_const_value_ioff | input | [data_in_size_bit_top-1:0] constant value from regmap used for ppg ioff calibraton | 76 |
| i_rx_ch_frame | input | [n_max_frame-1:0] ppg rx channel frame from regamp | 76 |
| i_T_tx_led_set | input | [n_max_frame-1:0] tx led set time from regmap | 76 |
| i_T_tx_led_off | input | [n_max_frame-1:0] tx led off time from regmap | 76 |
| i_curr_sel_tx_frame_x | input | [n_max_frame-1:0] current injection | 76 |
| i_tx1_outlab_sel_frame_x | input | [n_max_frame-1:0] led output selected from regmap for each frame | 76 |
| i_tx2_outlab_sel_frame_x | input | [n_max_frame-1:0] led output selected from regmap for each frame | 76 |
| i_tx3_outlab_sel_frame_x | input | [n_max_frame-1:0] led output selected from regmap for each frame | 76 |
| i_tx4_outlab_sel_frame_x | input | [n_max_frame-1:0] led output selected from regmap for each frame | 76 |
| i_idac_dc_ppg_frame | input | [n_max_frame-1:0] idac value for each frame selected from regmap | 76 |
| i_average_ppg | input | [n_max_frame-1:0] average ppg for each frame selected from regmap | 76 |
| i_gain_alc_start | input | [gain_max_bit_top-1:0] btia gain for alc from regmap | 76 |
| i_gain_start | input | [n_max_frame-1:0] btia gain start for compensation from regmap | 76 |
| i_Tx_idac_Vref_debug | input | [Nmax_bit_top-1:0] Idac value for debug from regmap 76 | 76 |
| i_ppg_start_up_time | input | [ppg_start_up_decod_bit_top-1:0] start up time for ppg from regmap | 77 |
| i_en_txi | input | [n_max_frame-1:0] tx enabling for each frame from regmap | 77 |
| i_frame_repetition | input | [n_max_frame-1:0] i frame repetition for each frame from regmap | 77 |
| i_T_preset | input | [1:0] Preset time for digital ramp from regmap | 77 |
| i_m_ecg | input | [m_odr_max_bit_top-1:0] m parameter for ecg from regmap | 77 |
| i_m_bia | input | [m_odr_max_bit_top-1:0] m parameter for bia from regmap | 77 |
| i_m_gsr | input | [m_odr_max_bit_top-1:0] m parameter for gsr from regmap | 77 |
| i_m_ppg | input | [m_odr_max_bit_top-1:0] m parameter for ppg from regmap | 77 |
| i_debug_adc_error_cap8_0_bypass | input | error cap bypass for adc from regmap | 77 |
| i_base_address_ecg0 | input | [base_address_bit_top-1:0] base address for ecg0 in multiple fifo | 77 |
| i_base_address_bia | input | [base_address_bit_top-1:0] base address for bia/ecg1-2 in multiple fifo | 77 |
| i_base_address_gsr | input | [base_address_bit_top-1:0] base address for gsr in multiple fifo | 77 |
| i_base_address_ppg | input | [base_address_bit_top-1:0] base address for ppg in multiple fifo | 77 |
| i_frame_ppg_debug | input | [ppg_frame_bit_top-1:0] frame selection for ppg data debug | 77 |
| i_en_buf_gpio1 | input | enable buffer on gpio1 | 77 |
| i_en_buf_gpio2 | input | enable buffer on gpio2 | 77 |
| i_en_biobuf | input | enable biobuffer | 77 |
| i_do_calibration | input | enabling for adc calibration | 77 |
| i_mode_operation | input | [mode_operation_n_bit_top-1:0] mode operation selection | 77 |
| i_T_rx_set | input | [T1_max_bit_from_decoder_top- 1:0] rx channel time set | 77 |
| i_en_clkf | input | en 16 MHz clock | 77 |
| i_quokka_boot_end | input | from quokka | 77 |
| i_quokka_run | input | from quokka 77 | 77 |
| i_clk_16MHz_ready | input | (from analog circuit) | 78 |
| i_imp_curinj_en | input | enabling current injection for bia | 78 |
| i_en_ldo_1v8 | input | enabling ldo 1v8 | 78 |
| i_debug_comp_rx_ck | input | enabling debug for comp rx ck | 78 |
| i_debug_gsr_on | input | gsr on debug mode | 78 |
| i_debug_gsr_curr_on | input | gsr curr on debug mode | 78 |
| i_alc_disabled | input | [n_max_frame-1:0] disabling alc bit for each frame | 78 |
| i_en_cm_buf | input | enabling common buffer | 78 |
| i_en_rld | input | enabling rld | 78 |
| i_en_avg1 | input | enabling avg1 | 78 |
| i_en_avg2 | input | enabling avg1 | 78 |
| i_hc_en | input | enabling health channel | 78 |
| i_debug | input | enabling debug mode | 78 |
| i_imp_en | input | enabling bia channel | 78 |
| i_debug_en_tia | input | enabling debug tia | 78 |
| i_debug_en_buffer | input | enabling debug for buffer | 78 |
| i_debug_en_idac | input | enabling debug for IDAC | 78 |
| i_en_clk_chop10k | input | enabling chopper clock | 78 |
| i_debug_tx_preset | input | enabling tx preset | 78 |
| i_en_ldo_1v8_ext | input | enabling external ldo 1v8 | 78 |
| i_clk_imp_10k_en | input | enabling clock chopper for bia | 78 |
| i_b_cap_idac | input | [1:0] enabling cap for idac | 78 |
| i_adc_mux_bio_channel_debug | input | [2:0] enabling debug adc mux bio channel | 78 |
| i_adc_mux_sel_debug | input | enabling adc mux 78 | 78 |
| i_ispu_core_sw_rstn | input | ispu core enabling | 79 |
| i_T_TIAON | input | [T1_max_bit_from_decoder_top- 1:0] TIA Time | 79 |
| i_scan_mode | input | scan mode enabling | 79 |
| i_reset_debug_adc_data | input | reset adc data debug | 79 |
| i_start_adc_debug | input | pilot adc start om debug | 79 |
| i_en_ADC_debug | input | enabling adc debug | 79 |
| i_debug_adc_readout_bypass | input | enabling adc readout bypass | 79 |
| i_su_hlt_dly | input | enabling start up delay for ecg | 79 |
| i_multiple_fifo_sel | input | enabling multiple fifo | 79 |
| i_debug_calibration | input | enabling debug calibraiton | 79 |
| i_en_gsr_dc_cds | input | [1:0] enabling gsr cds mode | 79 |
| i_ADC_EOC | input | end of conversion from adc | 79 |
| i_ecg0_sel | input | select ecg0 channel | 79 |
| i_bia_sel | input | select bia channel | 79 |
| i_gsr_sel | input | select gsr channel | 79 |
| i_ppg_sel | input | select ppg channel | 79 |
| i_ppg_ioff_calibration | input | enabling ppg ioff calibration | 79 |
| i_ecg1_ecg2_sel | input | enabling ecg1 and ecg2 channel | 79 |
| i_rst_async_ecg | input | reset async for ecg | 79 |
| i_rst_async_bia | input | reset async for bia | 79 |
| i_ppg_quokka_elab_sel | input | enabling adsp elab for ppg | 79 |
| i_data_ADC_out | input | [data_in_size_bit_top-1:0] (from analog circuit) | 79 |
| i_time_slot_selection | input | [time_slot_sel_bit_top-1:0] odr selection from regmap 79 | 79 |
| i_Nmax_to_reg | input | [Nmax_bit_top-1:0] Max value for digital ramp | 80 |
| i_nstart_case | input | [Nmax_bit_top-1:0] n_start value for frist sterp | 80 |
| i_debug_rx_ch | input | [rx_ch_frame_n_bit_top-1:0] enabling debug for rx channel | 80 |
| i_T_delta1_to_reg | input | [delta_bit_top-1:0] delta 1 time for digital ramp | 80 |
| i_gain_max_set | input | [gain_max_bit_top-1:0] gain max for alc | 80 |
| i_BTIA_ALC_debug | input | [BTIA_ALC_register_bit_top-1:0] BTIA ALC Debug enable | 80 |
| i_comp_rx_out | input | input from analog comparator | 80 |
| i_adc_error_cap8_debug | input | [6:0] adc cap error debug | 80 |
| i_adc_error_cap7_debug | input | [6:0] adc cap error debug | 80 |
| i_adc_error_cap6_debug | input | [6:0] adc cap error debug | 80 |
| i_adc_error_cap5_debug | input | [6:0] adc cap error debug | 80 |
| i_adc_error_cap4_debug | input | [6:0] adc cap error debug | 80 |
| i_adc_error_cap3_debug | input | [6:0] adc cap error debug | 80 |
| i_adc_error_cap2_debug | input | [6:0] adc cap error debug | 80 |
| i_adc_error_cap1_debug | input | [6:0] adc cap error debug | 80 |
| i_adc_error_cap0_debug | input | [6:0] adc cap error debug | 80 |
| i_BIDAC_debug_register | input | [IDAC_offset-1:0] | 80 |
| i_sleep_master | input |  | 80 |
| i_lpm | input | [1:0] low power mode for ldo | 80 |
| i_mpm | input | [1:0] medium power mode for ldo | 80 |
| i_hpm | input | [1:0] high power mode for ldo | 80 |
| i_dis_rc_viref | input | dis rc viref | 80 |
| i_T1 | input | [T1_max_bit_from_decoder_top- 1:0] 4 to 10 us=160nclk 80 | 80 |
| i_T2 | input | [T2_max_bit_from_decoder_top- 1:0] 0.5 to 2 us=~32 | 81 |
| i_N_clk_ppg | input | [N_clk_max_bit_top-1:0] Sample time for ppg | 81 |
| i_N_clk_ecg | input | [N_clk_max_bit_top-1:0] Sample time for ecg | 81 |
| i_N_clk_cal | input | [N_clk_max_bit_top-1:0] Sample time for adc calibration | 81 |
| scan_enable | input | scan enable for scan mode | 81 |
| i_timer_buffer_config | input | [1:0] timer buffer configuration | 81 |
| i_ppg_alc_frame_save | input | [ppg_frame_bit_top-1:0] alc data frame to save | 81 |
| i_reset_ppg_ioff_calib | input |  | 81 |
| HRDATA | input | [31:0] AHB Protocol signals | 81 |
| HREADY | input | AHB Protocol signals | 81 |
| HRESP | input | [1:0] AHB Protocol signals | 81 |
| HGRANT | input | AHB Protocol signals | 81 |
| SCANENABLE | input | Scan Test Mode Enbl | 81 |
| SCANINHCLK | input | Scan Chain Input | 81 |
| SCANOUTHCLK | output | Scan Chain Output | 81 |
| HSEL | output | 0 AHB Protocol signals | 81 |
| HADDR | output | [31:0] 0 AHB Protocol signals | 81 |
| HTRANS | output | [1:0] 0 AHB Protocol signals | 81 |
| HWRITE | output | 0 AHB Protocol signals | 81 |
| HSIZE | output | [2:0] 0 AHB Protocol signals | 81 |
| HBURST | output | [2:0] 0 AHB Protocol signals | 81 |
| HPROT | output | [3:0] 0 AHB Protocol signals | 81 |
| HWDATA | output | [31:0] 0 AHB Protocol signals 81 | 81 |
| HBUSREQ | output | 0 AHB Protocol signals | 82 |
| HLOCK | output | 0 AHB Protocol signals | 82 |
| o_bio_clock_div | output | 0 output for clock chopper | 82 |
| o_BIDAC | output | [IDAC_offset-1:0] 0 IDAC for top | 82 |
| o_rst_imp | output | 1 bia start up rst signal | 82 |
| o_rsti_imp | output | 1 bia start up rsti signal | 82 |
| o_sug_imp | output | 1 bia start up sug channel | 82 |
| o_pd_imp | output | 1 bia start up pd channel | 82 |
| o_start_operative_16MHz | output | 0 start operative 16MHz | 82 |
| o_su_hc2 | output | 1 ecg start up hc2 signal | 82 |
| o_rst_hc2 | output | 1 ecg start up rst signal | 82 |
| o_rsti_hc2 | output | 1 ecg start up rsti signal | 82 |
| o_pd_hc2 | output | 1 ecg start up pd signal | 82 |
| o_reset_reg_rst | output | 1 end of reset async phase | 82 |
| o_reset_reg_rst_imp_async | output | 1 end of reset async phase | 82 |
| o_imp_curinj_pd | output | 0 bia current injection output | 82 |
| o_Txi_IDAC_Vref | output | [Nmax_bit_top-1:0] 0 TX IDAC VREF TO analog domain | 82 |
| o_comp_rx_ck | output | 0 output for comparator debug | 82 |
| o_BTIA_gain | output | [gain_max_bit_top-1:0] 0 BTIA gain output to analog domain | 82 |
| o_data_out_debug_adc | output | [15:0] 0 o data output for adc debug | 82 |
| o_en_mask_ldo_pdclkf_reg | output | 1 mask for en_ldo and pdf | 82 |
| o_pd_clkf | output | 1 pd_clkf | 82 |
| o_trim_ldo_d | output | [1:0] 3 trim ldo value | 82 |
| o_BDC_PPG | output | [idac_dc_ppg_frame_bit_top-1:0] 0 idac dc ppg frame output 82 | 82 |
| o_adc_mux_bio_channel | output | [2:0] 0 adc mux bio channel | 83 |
| o_adc_mux_sel | output | 0 adc mux sel output | 83 |
| o_error_time_slot | output | 0 error time slot irq | 83 |
| o_curr_sel_tx_frame_x | output | [curr_sel_bit_top-1:0] 0 current selection for tx channel output | 83 |
| o_tx1_outlab_sel_frame_x | output | [bit_outab_sel_top-1:0] 0 tx outlab sel frame x | 83 |
| o_tx2_outlab_sel_frame_x | output | [bit_outab_sel_top-1:0] 0 tx outlab sel frame x | 83 |
| o_tx3_outlab_sel_frame_x | output | [bit_outab_sel_top-1:0] 0 tx outlab sel frame x | 83 |
| o_tx4_outlab_sel_frame_x | output | [bit_outab_sel_top-1:0] 0 tx outlab sel frame x | 83 |
| o_tx_preset | output | 0 tx prese to analog domain | 83 |
| o_en_tx | output | [n_tx_channel-1:0] 0 tx enable to analog domain | 83 |
| o_PD_TIA | output | 1 enabling tia to analog domain | 83 |
| o_PD_PGA | output | 1 enabling buffer to analog domain | 83 |
| o_PD_IDAC | output | 1 enabling idac to analog domain | 83 |
| o_gsr_curr_on | output | 0 gsr curr on pilot to analog domain | 83 |
| o_gsr_on | output | 0 grs on on pilot to analog domain | 83 |
| o_ADC_en | output | 0 ADC enabling | 83 |
| o_half_charge_ldo | output | 0 | 83 |
| o_ADC_start | output | 0 ADC Start sampling | 83 |
| o_N_step2_to_reg | output | [rx_ch_gain_limit-1:0] 0 N_Step2 calibration value | 83 |
| o_adc_test_cap | output | [9:0] 0 adc test cap | 83 |
| o_adc_error_cap9 | output | [7:0] 0 adc calibration result | 83 |
| o_adc_error_cap8 | output | [6:0] 0 adc calibration result | 83 |
| o_adc_error_cap7 | output | [6:0] 0 adc calibration result | 83 |
| o_adc_error_cap6 | output | [6:0] 0 adc calibration result 83 | 83 |

<p>&nbsp;</p>

**[DRS-REQ-006] Requirement:**

The Main Controller block shall implement: .

- To check data in unique FIFO (default config) the user shall check the first MSB which will have to be equal to the one described in the DATA TAG Table. [TO: IPOS_MAIN_CTRL]

Covers: DDS_STBIO1_0142

[End]

<p>&nbsp;</p>

**[DRS-REQ-017] Requirement:**

The Main Controller block shall implement: .

- The user shall start measurement writing register DEVICE_CONFIG_OPERATION [0] at 1. [TO: IPOS_MAIN_CTRL]

Covers: DDS_STBIO1_0141

[End]

<p>&nbsp;</p>

**[DRS-REQ-029] Requirement:**

The Main Controller block shall implement: To perform a SOFT Reset procedure, the user shall perform the following steps: 1. If Mode Operation has been set to 1, shall be reset to 0 2. Set the Soft Reset Main Controller Bit (SW_RESETN_REG[0]) to 0 for at least 1 ms 3. Set the Soft Reset Main Controller Bit (SW_RESETN_REG[0]) to 1 4. Wait for the DEVICE_STATUS_REGISTER to reach the IDLE Value.

Covers: DDS_STBIO1_1114

[End]


### **9.4 Smart FIFO** {#94-smart-fifo}
The Smart FIFO block is designed to provide FIFO storage and AHB/memory access in mutually exclusive Unique or Multiple modes, including sub-FIFO depth/addressing and tagged Sensor Hub data formatting.

<p>&nbsp;</p>

Source interface table 1: Table 28: FIFO Controller I/O List

- source table from OCR extract page 112

| Parameter | Value / Type | Details |
|---|---|---|
| AW | 13 | |

<p>&nbsp;</p>

| Port name | Direction | Type / Function | TOP CONNECTION / Details |
|---|---|---|---|
| TEST_MODE | input | ScanMode u_pad_mux. | |
| HCLK | input | AHB Master Handler | |
| HRESETn | input | u_pmu.resetn_fifo | |
| HSEL | input | AHB Slave Port u_afa_xbar.hsel_M2 | |
| HADDR | input | [AW-1:0] AHB Slave Port u_afa_xbar.haddr_M2 | |
| HMASTER | input | [3:0] AHB Slave Port u_afa_xbar.hmaster_M2 | |
| HTRANS | input | [1:0] AHB Slave Port u_afa_xbar.htrans_M2 | |
| HSIZE | input | [2:0] AHB Slave Port u_afa_xbar.hsize_M2 | |
| HWRITE | input | AHB Slave Port u_afa_xbar. | |
| HWDATA | input | [31:0] AHB Slave Port u_afa_xbar. | |
| HREADY | input | AHB Slave Port u_afa_xbar. | |
| HREADYOUT | output | AHB Slave Port u_afa_xbar. | |
| HRDATA | output | [31:0] AHB Slave Port u_afa_xbar. | |
| HRESP | output | AHB Slave Port u_afa_xbar. | |
| O_FIFO_RAM_A | output | [ADDR_WIDTH- | |
| O_FIFO_RAM_D | output | [23:0] u_ca_fifo_bist_c.csns_1 | |
| O_FIFO_RAM_CSN | output | u_ca_fifo_bist_c.dgs_1 | |
| O_FIFO_RAM_M | output | [23:0] u_ca_fifo_bist_c.wens_1 | |
| O_FIFO_RAM_WEN | output | u_ca_fifo_bist_c.mgs_1 | |
| I_FIFO_RAM_Q | input | [23:0] u_ca_fifo_bist_c.dgrs_1 | |

<p>&nbsp;</p>

### **9.5 Regmap** {#95-regmap}
The Regmap block is designed to implement the mapped AFE, system, and OTP registers, exposing configuration/status while enforcing reset and OTP write-protection rules.

<p>&nbsp;</p>

**[DRS-REQ-002] Requirement:**

The Regmap block shall implement: To turn off the ISPU shall be:.

- Disable the power island by writing to regmap POWER CONFIGURATION REGISTER via AHB interface (ADDRESS=0xCA000, DATA=0x00)

Covers: DDS_STBIO1_0508

[End]

<p>&nbsp;</p>

**[DRS-REQ-003] Requirement:**

The Regmap block shall implement: After the initial boot phase, to turn on the ISPU shall be:.

- Select page 3 of the regmap (ADDRESS=0x04, DATA=0x03)
- Enable LDO 1V8 by writing to regmap VIREF_LDO1V8_CLK16M register (ADDRESS=0x0F, DATA=0x02)
- Enable clock by writing to regmap VIREF_LDO1V8_CLK16M register (ADDRESS=0x0F, DATA=0x12)
- Enable user mode by writing to regmap (ADDRESS=0x5E, DATA=0x01)
- Enable the power island by writing to regmap POWER CONFIGURATION REGISTER via AHB interface (ADDRESS=0xCA000, DATA=0x01)

Covers: DDS_STBIO1_0507

[End]


### **9.6 IRQ logic** {#96-irq-logic}
The IRQ logic block is designed to aggregate and route FIFO, Sensor Hub, ISPU sample-ready, software, and timer interrupt status to configured GPIO/interrupt outputs.

<p>&nbsp;</p>

### **9.7 PMU** {#97-pmu}
The PMU block is designed to sequence POR-driven LDO1V8 enable, 64/32 kHz and 16 MHz clocks, clock-ready signaling, and digital-reset release for boot and power modes.

<p>&nbsp;</p>

Source interface table 1: 13.1.1.2. PMU TOP I/O List

- source table from OCR extract page 37

| Port name | Direction | Type / Function | TOP CONNECTION / Details |
|---|---|---|---|
| clk_16m | input | wire Clock 16 MHz from analog ring oscillators | |
| clk_64k | input | wire Clock 64kHz from analog ring oscillators | |
| POR1V2_1V2 | input | wire POR Signal | |
| START_CLK_16M | input | wire Clock ready for 16MHz | |
| PDClockF | input | wire Power Down for 16MHz Ring Oscillator | |
| i_bio_divider | input | wire Enable 32kHz geneartion from 16MHz when | |
| EN_LDO | input | wire enable LDO from main controller | |
| PD_CLK_REG | input | wire power down 16MHz from Regmap | |
| EN_LDO1V8_REG | input | wire Enable LDO from regmap | |
| bist_mode | input | wire enable bist mode | |
| debug_mode | input | wire enable debug | |
| scan_mode | input | wire enable scan mode | |
| scan_enable | input | wire start scan mode | |
| scan_clk | input | wire scan clk | |
| scan_rstn | input | wire scan rst | |
| clk_bistctlr | input | wire bist controller and collar clock | |
| rst_bistctlr_n | input | wire bist controller and collar resetn | |
| clk_ext_en | input | wire enable external clock from pad | |
| clk_ext_slow | input | wire external clock 32kHz | |
| i_en_sh_clk | input | wire enable sensor hub clock | |
| i_senshub_clk_sel | input | wire | |
| i_test_clk_fast | input | wire enable test and trimming for 16MHz clock | |
| i_half_charge_ldo | input | wire enable the low power mode for ldo when | |
| mask_en_ldo_pdclkf | input | wire mask the control of pdf and ldo control | |
| clk_en_s0 | input | wire clock gating logic inside stredl_afe_top | |
| clk_en_s1 | input | wire if present should be HSEL STMC AHB | |
| clk_en_s2_i2c | input | wire if present should be HSEL STMC AHB | |
| clk_en_s2_on | input | wire clk gating ON from AHB I2C/SPI Interface | |
| clk_en_s2_off | input | wire clk gating OFF from AHB I2C/SPI Interface | |
| clk_en_s3 | input | wire clk gating from AHB Master Main Controller | |
| clk_en_s4 | input | wire clock gating logic inside stredl_afe_top | |
| clk_en_s5 | input | wire clock gating logic inside masterblaze_ahb | |
| clk_en_m0 | input | wire clock gating logic inside stredl_afe_top | |
| clk_en_m1 | input | wire HSEL M1 from xbar to STMC AHB Slave | |
| clk_en_m2 | input | wire HSEL M2 from xbar to FIFO | |
| clk_en_m22 | input | wire HSEL M2 from xbar to MASTERBLAZE | |
| clk_en_m3 | input | wire HSEL M3 from xbar to Regmap | |
| iso_i | input | wire from register | |
| vdden_i | input | wire enable ISPU Power Island | |
| i_start_operative_16MHz | input | wire enable the lead of check | |
| main_ctrl_sw_resetn | input | wire soft reset for main controller | |
| stmc_sw_resetn | input | wire adsp soft reset | |
| fifo_sw_resetn | input | wire fifo soft reset | |
| masterblaze_sw_resetn | input | wire sensor hub soft reset | |
| regmap_sw_resetn | input | wire regmap soft reset | |
| adsp_run | input | wire adsp is running | |
| adsp_xbar_sw_en | input | wire adsp clk ahb | |
| i_en_clk_gsr_16M | input | wire enable the clock for gsr digital circuit | |
| i_en_ck_m_p_q | input | wire enable quadrature and phase clock | |
| i_en_clk_mod_debug | input | wire enable the clock modulation debug | |
| i_en_chop_ref | input | wire enable chopper clock | |
| i_en_ck_chop_imp | input | wire enable chopper clock for bia | |
| i_en_ck_hc2_10k | input | wire enable health channel clock | |
| i_freq_bia_m_p_q | input | wire | |
| i_en_clk_16MHz_sleep | input | wire enable clock in SLEEP mode when a bio- | |
| EN_ADC_TEST_LOW_NOISE | input | wire enable adc test low noise | |
| EN_ADC_TEST_FAST | input | wire enable adc test fast | |
| if_sh_ck_in | input | wire sensor hub clock interface | |
| o_EN_LDO1V8 | output | wire enable ldo to analog domain | |
| o_PD_CLKF | output | wire power down 16MHz clock to analog domain | |
| o_CLK_16M_READY | output | wire clock ready to the digital domain | |
| o_DIS_RC_VIREF | output | wire dis rc viref to the analog domain | |
| pd_osc_clk32k | output | wire power down for clk 64kHz | |
| tst_clk_32k | output | wire clock slow 32k to main_controller | |
| tst_clk_16m | output | wire clock fast 16M | |
| tst_clk_bistctlr | output | wire test clock for bist ctrl | |
| tst_rst_bistctlr_n | output | wire test reset for bist ctrl | |
| clk_stredl | output | wire clock gating logic inside stredl_afe_top | |
| clk_xbar | output | wire xbar clock | |
| clk_intf | output | wire interface clock | |
| clk_main_ctrl | output | wire clock for main controller | |
| clk_stmc | output | wire adsp clock | |
| clk_stmc_ahb | output | wire adsp clk elaboration | |
| clk_fifo | output | wire fifo clock | |
| clk_masterblaze_m | output | wire sensor hub master clock | |
| clk_masterblaze_s | output | wire sensor hub slave clock | |
| clk_regmap | output | wire regmap clock | |
| o_clk_ext_en | output | wire enable external clock | |
| resetn_stredl | output | wire reset mngmt inside stredl_afe_top | |
| resetn_xbar | output | wire xbar reset | |
| resetn_intf | output | wire reset interface | |
| resetn_main_ctrl | output | wire reset main controller | |
| resetn_32k_main_ctrl | output | wire reset 32kHz domain main controller | |
| resetn_stmc | output | wire reset adsp | |
| resetn_fifo | output | wire reset FIFO | |
| resetn_masterblaze | output | wire reset sensor hub | |
| resetn_regmap | output | wire reset regmap | |
| o_trimming_clk_fast | output | wire trimming output clock fast | |
| iso_o | output | wire left open . to be connected in synthesis | |
| vdden_o | output | wire to be connected to psw_ctrl.VDDIEN | |
| o_ck_bg | output | wire bg clock to analog domain | |
| o_sh_clk | output | wire sensor hub clock | |
| o_ck_chop_imp | output | wire chopper bia clock to analog domain | |
| o_ck_m | output | wire modulation clock to analog domain | |
| o_ck_hc2_10k | output | wire healt channel 10kHz clock to analog domain | |
| o_ck_p | output | wire phase clock to analog domain | |
| o_ck_q | output | wire quadrature clock to analog domain | |
| o_clk_16M_mc | output | wire 16MHz clock for Main Controller | |
| o_clk_dft_adc | output | wire 16MHz clock for ADC DFT | |
| o_clk_gsr_16M | output | wire gsr clock to digital domain | |
| o_ADC_clk_serial_dft | output | wire adc serial clock in dft | |
| o_sh_clk_gate | output | wire status clk reg clk sh 16Mhz | |

<p>&nbsp;</p>

Source interface table 2: Table 10: PMU I/O List

- source table from OCR extract page 42

| Port name | Direction | Type / details | Source page |
|---|---|---|---|
| clk_16m | input | wire Clock 16 MHz from analog ring oscillators | 37 |
| clk_64k | input | wire Clock 64kHz from analog ring oscillators | 37 |
| POR1V2_1V2 | input | wire POR Signal | 37 |
| START_CLK_16M | input | wire Clock ready for 16MHz | 37 |
| PDClockF | input | wire Power Down for 16MHz Ring Oscillator from main controller | 37 |
| i_bio_divider | input | wire Enable 32kHz geneartion from 16MHz when a Bio-Channel is activated | 37 |
| EN_LDO | input | wire enable LDO from main controller | 37 |
| PD_CLK_REG | input | wire power down 16MHz from Regmap 37 | 37 |
| EN_LDO1V8_REG | input | wire Enable LDO from regmap | 38 |
| bist_mode | input | wire enable bist mode | 38 |
| debug_mode | input | wire enable debug | 38 |
| scan_mode | input | wire enable scan mode | 38 |
| scan_enable | input | wire start scan mode | 38 |
| scan_clk | input | wire scan clk | 38 |
| scan_rstn | input | wire scan rst | 38 |
| clk_bistctlr | input | wire bist controller and collar clock | 38 |
| rst_bistctlr_n | input | wire bist controller and collar resetn | 38 |
| clk_ext_en | input | wire enable external clock from pad | 38 |
| clk_ext_slow | input | wire external clock 32kHz | 38 |
| i_en_sh_clk | input | wire enable sensor hub clock | 38 |
| i_senshub_clk_sel | input | wire [2:0] selector for sensor hub clock | 38 |
| i_test_clk_fast | input | wire enable test and trimming for 16MHz clock | 38 |
| i_half_charge_ldo | input | wire enable the low power mode for ldo when only ppg is selected | 38 |
| mask_en_ldo_pdclkf | input | wire mask the control of pdf and ldo control during boot | 38 |
| clk_en_s0 | input | wire clock gating logic inside stredl_afe_top | 38 |
| clk_en_s1 | input | wire if present should be HSEL STMC AHB Master | 38 |
| clk_en_s2_i2c | input | wire if present should be HSEL STMC AHB Master | 38 |
| clk_en_s2_on | input | wire clk gating ON from AHB I2C/SPI Interface | 38 |
| clk_en_s2_off | input | wire clk gating OFF from AHB I2C/SPI Interface | 38 |
| clk_en_s3 | input | wire clk gating from AHB Master Main Controller 38 | 38 |
| clk_en_s4 | input | wire clock gating logic inside stredl_afe_top | 39 |
| clk_en_s5 | input | wire clock gating logic inside masterblaze_ahb | 39 |
| clk_en_m0 | input | wire clock gating logic inside stredl_afe_top | 39 |
| clk_en_m1 | input | wire HSEL M1 from xbar to STMC AHB Slave | 39 |
| clk_en_m2 | input | wire HSEL M2 from xbar to FIFO | 39 |
| clk_en_m22 | input | wire HSEL M2 from xbar to MASTERBLAZE | 39 |
| clk_en_m3 | input | wire HSEL M3 from xbar to Regmap | 39 |
| iso_i | input | wire from register | 39 |
| vdden_i | input | wire enable ISPU Power Island | 39 |
| i_start_operative_16MHz | input | wire enable the lead of check | 39 |
| main_ctrl_sw_resetn | input | wire soft reset for main controller | 39 |
| stmc_sw_resetn | input | wire adsp soft reset | 39 |
| fifo_sw_resetn | input | wire fifo soft reset | 39 |
| masterblaze_sw_resetn | input | wire sensor hub soft reset | 39 |
| regmap_sw_resetn | input | wire regmap soft reset | 39 |
| adsp_run | input | wire adsp is running | 39 |
| adsp_xbar_sw_en | input | wire adsp clk ahb | 39 |
| i_en_clk_gsr_16M | input | wire enable the clock for gsr digital circuit | 39 |
| i_en_ck_m_p_q | input | wire enable quadrature and phase clock | 39 |
| i_en_clk_mod_debug | input | wire enable the clock modulation debug | 39 |
| i_en_chop_ref | input | wire enable chopper clock | 39 |
| i_en_ck_chop_imp | input | wire enable chopper clock for bia | 39 |
| i_en_ck_hc2_10k | input | wire enable health channel clock | 39 |
| i_freq_bia_m_p_q | input | wire [2:0] frequency selector for phase and quadrature 39 | 39 |
| i_en_clk_16MHz_sleep | input | wire enable clock in SLEEP mode when a bio- channel is selected | 40 |
| EN_ADC_TEST_LOW_NOISE | input | wire enable adc test low noise | 40 |
| EN_ADC_TEST_FAST | input | wire enable adc test fast | 40 |
| if_sh_ck_in | input | wire sensor hub clock interface | 40 |
| o_EN_LDO1V8 | output | wire enable ldo to analog domain | 40 |
| o_PD_CLKF | output | wire power down 16MHz clock to analog domain | 40 |
| o_CLK_16M_READY | output | wire clock ready to the digital domain | 40 |
| o_DIS_RC_VIREF | output | wire dis rc viref to the analog domain | 40 |
| pd_osc_clk32k | output | wire power down for clk 64kHz | 40 |
| tst_clk_32k | output | wire clock slow 32k to main_controller | 40 |
| tst_clk_16m | output | wire clock fast 16M | 40 |
| tst_clk_bistctlr | output | wire test clock for bist ctrl | 40 |
| tst_rst_bistctlr_n | output | wire test reset for bist ctrl | 40 |
| clk_stredl | output | wire clock gating logic inside stredl_afe_top | 40 |
| clk_xbar | output | wire xbar clock | 40 |
| clk_intf | output | wire interface clock | 40 |
| clk_main_ctrl | output | wire clock for main controller | 40 |
| clk_stmc | output | wire adsp clock | 40 |
| clk_stmc_ahb | output | wire adsp clk elaboration | 40 |
| clk_fifo | output | wire fifo clock | 40 |
| clk_masterblaze_m | output | wire sensor hub master clock | 40 |
| clk_masterblaze_s | output | wire sensor hub slave clock | 40 |
| clk_regmap | output | wire regmap clock | 40 |
| o_clk_ext_en | output | wire enable external clock 40 | 40 |
| resetn_stredl | output | wire reset mngmt inside stredl_afe_top | 41 |
| resetn_xbar | output | wire xbar reset | 41 |
| resetn_intf | output | wire reset interface | 41 |
| resetn_main_ctrl | output | wire reset main controller | 41 |
| resetn_32k_main_ctrl | output | wire reset 32kHz domain main controller | 41 |
| resetn_stmc | output | wire reset adsp | 41 |
| resetn_fifo | output | wire reset FIFO | 41 |
| resetn_masterblaze | output | wire reset sensor hub | 41 |
| resetn_regmap | output | wire reset regmap | 41 |
| o_trimming_clk_fast | output | wire trimming output clock fast | 41 |
| iso_o | output | wire left open . to be connected in synthesis | 41 |
| vdden_o | output | wire to be connected to psw_ctrl.VDDIEN | 41 |
| o_ck_bg | output | wire bg clock to analog domain | 41 |
| o_sh_clk | output | wire sensor hub clock | 41 |
| o_ck_chop_imp | output | wire chopper bia clock to analog domain | 41 |
| o_ck_m | output | wire modulation clock to analog domain | 41 |
| o_ck_hc2_10k | output | wire healt channel 10kHz clock to analog domain | 41 |
| o_ck_p | output | wire phase clock to analog domain | 41 |
| o_ck_q | output | wire quadrature clock to analog domain | 41 |
| o_clk_16M_mc | output | wire 16MHz clock for Main Controller | 41 |
| o_clk_dft_adc | output | wire 16MHz clock for ADC DFT | 41 |
| o_clk_gsr_16M | output | wire gsr clock to digital domain | 41 |
| o_ADC_clk_serial_dft | output | wire adc serial clock in dft | 41 |
| o_sh_clk_gate | output | wire status clk reg clk sh 16Mhz 41 | 41 |

<p>&nbsp;</p>

### **9.8 BIST Controller** {#98-bist-controller}
The BIST Controller block is designed to control BIST operating modes and coordinate ADC/OTP test operations and their register-visible results.

<p>&nbsp;</p>

### **9.9 I2C_SPI_AHB** {#99-i2cspiahb}
The I2C_SPI_AHB block is designed to accept I2C/SPI accesses and translate them as needed into AHB transactions for device configuration and readback, including ISPU access.

<p>&nbsp;</p>

Source interface table 1: Table 24: I2C/SPI AHB I/O List

- source table from OCR extract page 101

| Port name | Direction | Type / details | Source page |
|---|---|---|---|
| rst_n | input | POR | 99 |
| i_if_cs | input | CS for SPI interface | 99 |
| o_if_cs_tud | output | Control for CS PAD. 1 in scan mode 0 otherwise | 99 |
| o_if_cs_en_n | output | Set to 0 for CS pad id bidir pad is used. Could be inverted depending on the PAD | 99 |
| o_if_cs_out_n | output | Set to 0 for CS pad id bidir pad is used. Could be inverted depending on the PAD | 99 |
| i_if_ck | input | Interface clock 99 | 99 |
| i_if_sda_sdi_in | input | SDA/SDI from pad | 100 |
| o_if_sda_sdi_en_n | output | SDA/SDI pad enable | 100 |
| o_if_sda_sdi_out | output | SDA/SDI to pad | 100 |
| o_ctrl_reg_7 | output | [7:0] 8 configuration bit set by local register (addr. 0x5e) | 100 |
| i_ext_reg_dt | input | [7:0] Data from external register block (if present) | 100 |
| o_ext_reg_wr_add | output | [7:0] Write address to external register block (if present) | 100 |
| o_ext_reg_rd_add | output | [7:0] Read address to external register block (if present) | 100 |
| o_ext_reg_dt | output | [7:0] Data to external register block (if present) | 100 |
| o_ext_reg_ck_wr | output | Write enable for external register block (if present) | 100 |
| o_ext_reg_we | output | Write direct enable for external register block (if present) rst_16m_n Sw reset for AHB domain | 100 |
| sys_16m_clk | input | AHB clock | 100 |
| o_hselm | output | AHB_M | 100 |
| o_haddrm | output | [31:0] AHB_M | 100 |
| o_htransm | output | [1:0] AHB_M | 100 |
| o_hmasterm | output | [3:0] AHB_M | 100 |
| o_hwritem | output | AHB_M | 100 |
| o_hsizem | output | [2:0] AHB_M | 100 |
| o_hmastlockm | output | AHB_M | 100 |
| o_hwdatam | output | [31:0] AHB_M | 100 |
| o_hburstm | output | [2:0] AHB_M | 100 |
| o_hprotm | output | [3:0] AHB_M | 100 |
| i_hrdatam | input | [31:0] AHB_M | 100 |
| i_hreadym | input | AHB_M | 100 |
| i_hrespm | input | AHB_M | 100 |
| o_gt_ck_on | output | Pulse on interface clock to inform system that AHB clock must be switched on 100 | 100 |
| o_gt_ck_off | output | Pulse on AHB clock to inform system that AHB clock can be switched off | 101 |
| o_ahb_error | output | Error on AHB side. Active if bit 1 or of register at address 0x4f are active. | 101 |
| o_rd_byte_nr_err | output | Active when | 101 |
| o_req_error | output | Active when number of byte is missing for read or timeout between double yte write and read is expired | 101 |
| scan_mode | input | Scan mode | 101 |
| scan_enable | input | Scan enable | 101 |
| scan_clk | input | Scan clk | 101 |
| scan_rst | input | Scan reset | 101 |

<p>&nbsp;</p>

### **9.10 OTP** {#910-otp}
The OTP block is designed to provide the source-specified one-time-programmable memory interface used by ADSP boot, programming, and test routines.

<p>&nbsp;</p>

Source interface table: OTP I/O List

| Port name | Direction | Type / details | Source page |
|---|---|---|---|
| PDN | unspecified | Power down command. | 88 |
| Memory | unspecified | is in low power mode when PDN is low. | 88 |
| A<6:0> | unspecified | A<6:0> is the word address for read or | 88 |
| programming | unspecified | operation | 88 |
| BANKEN<1:0> | unspecified | Bank selection bits. | 88 |
| Used | unspecified | to program and read each bank separately. | 88 |
| Or | unspecified | to activate redundancy when reading (2 | 88 |
| banks | unspecified | read simultaneously, | 88 |
| correction | unspecified | enabled) | 88 |
| BITSEL<2:0> | unspecified | To define the bit to be programmed in the 8 bit word. | 88 |
| Decimal | unspecified | value of (BITSEL<2:0>) | 88 |
| SELECTWLBL | unspecified | To select antifuse block to be programmed | 88 |
| PRG | unspecified | To select programming mode (active high) | 88 |
| FUSE | unspecified | Fuse command to program bit cell. | 88 |
| TREAD<3:0> | unspecified | For read condition trimming (sense current and | 88 |
| read | unspecified | voltage). | 88 |
| VREF | unspecified | Analog 1.25V+/-5% bandgap reference voltage | 88 |
| IREF | unspecified | Pin requiring external current sink of 10uA+/- 30% | 88 |

<p>&nbsp;</p>

**[DRS-REQ-035] Requirement:**

The OTP block shall implement: To check the end of the BOOT phase, the user shall read the main_controller_status_register (DEVICE_STATUS_REG register [2:0]) and follow these steps:.

- Read the DEVICE_STATUS_REG [2:0]
- Check if the Value is 1 (BOOT phase still in process)
- If the value is 2, then the BOOT phase is ended and the device is in IDLE. [TO: IPOS_MAIN_CTRL]

Covers: DDS_STBIO1_0116

[End]

<p>&nbsp;</p>

**[DRS-REQ-049] Requirement:**

The OTP block shall implement: If bit OTP_PRG10[31] in OTP Registers, called write_protection_en, is set to 1, and STBIO1 is not in debug_mode, register map shall refuse any incoming write request if the transaction address is within the OTP Registers space (from 0xCD000 to 0xCD02F).

Covers: DDS_STBIO1_0036

[End]


### **9.11 PAD MUX** {#911-pad-mux}
The PAD MUX block is designed to route source-specified functional, scan, BIST, debug, and ISPU-debug signals to and from device pads.

<p>&nbsp;</p>

Source interface table 1: 13.1.2.1. PAD MUX TOP I/O List

- source table from OCR extract page 49

| Port name | Direction | Type / Function | TOP CONNECTION / Details |
|---|---|---|---|
| i_write_protection_en | input |  | |
| o_write_protection_en | output |  | |
| i_tap_bist_mode | input |  | |
| i_EN_0P05HP_ECG0 | input |  | |
| i_EN_0P05HP_ECG12 | input |  | |
| IMPQ_PSDRES_UP_02 | input | [2:0] OTP value for Analog block | |
| IMPQ_PSDRES_DOWN_02 | input | [2:0] OTP value for Analog block | |
| IMPP_PSDRES_UP_02 | input | [2:0] OTP value for Analog block | |
| IMPP_PSDRES_DOWN_02 | input | [2:0] OTP value for Analog block | |
| ECG_PSDRES_DOWN_02 | input | [2:0] OTP value for Analog block | |
| ECG_PSDRES_UP_02 | input | [2:0] OTP value for Analog block | |
| IMPQ_PSDRES_UP_05 | input | [2:0] OTP value for Analog block | |
| IMPQ_PSDRES_DOWN_05 | input | [2:0] OTP value for Analog block | |
| IMPP_PSDRES_UP_05 | input | [2:0] OTP value for Analog block | |
| IMPP_PSDRES_DOWN_05 | input | [2:0] OTP value for Analog block | |
| ECG_PSDRES_DOWN_05 | input | [2:0] OTP value for Analog block | |
| ECG_PSDRES_UP_05 | input | [2:0] OTP value for Analog block | |
| IMPQ_PSDRES_UP | output | [2:0] OTP value for Analog block | |
| IMPQ_PSDRES_DOWN | output | [2:0] OTP value for Analog block | |
| IMPP_PSDRES_UP | output | [2:0] OTP value for Analog block | |
| IMPP_PSDRES_DOWN | output | [2:0] OTP value for Analog block | |
| ECG_PSDRES_DOWN | output | [2:0] OTP value for Analog block | |
| ECG_PSDRES_UP | output | [2:0] OTP value for Analog block | |
| i_TS_IRQ_ST | input |  | |
| i_DCCK_IRQ_ST | input |  | |
| o_en_tx_1V2 | input |  | |
| o_tx_preset_1V2 | input |  | |
| o_tx1_outlab_sel_frame_x_1V2 | input |  | |
| sel_irq_gpio1 | input | [3:0] sel irq gpi1 {000:NC, 001:i_fifo_irq, | |
| sel_irq_gpio2 | input | [3:0] sel irq gpi2 {000:NC, 001:i_fifo_irq, | |
| sel_irq_gpio3 | input | [3:0] sel irq gpi3 {000:NC, 001:i_fifo_irq, | |
| sel_irq_gpio4 | input | [3:0] sel irq gpi4 {000:NC, 001:i_fifo_irq, | |
| DCCK_P_en | input |  | |
| DCCK_N_en | input |  | |
| MODE_OPERATION | input |  | |
| o_pd_p | output |  | |
| o_pd_n | output |  | |
| O_DCCK_P_i | input |  | |
| O_DCCK_N_i | input |  | |
| if_gpio1_in_reg | output |  | |
| if_gpio1_en_reg | input |  | |
| if_gpio1_out_reg | input |  | |
| if_gpio2_in_reg | output |  | |
| if_gpio2_en_reg | input |  | |
| if_gpio2_out_reg | input |  | |
| if_gpio3_in_reg | output |  | |
| if_gpio3_en_reg | input |  | |
| if_gpio3_out_reg | input |  | |
| if_gpio4_in_reg | output |  | |
| if_gpio4_en_reg | input |  | |
| if_gpio4_out_reg | input |  | |
| o_ext_reg_dt_afe | input | [7:0] i2c/spi read data u_regmap_otp | |
| o_ext_reg_dt | output | [7:0] i2c/spi read data output | |
| i_ext_reg_add | input | [7:0] i2c/spi address | |
| i_ext_reg_dt | input | [7:0] i2c/spi write data | |
| i_ext_reg_ck_wr | input |  | |
| i_ext_reg_we | input |  | |
| if_sclk_in | input |  | |
| if_sclk_i3c_in | input |  | |
| if_sclk_out | output |  | |
| if_sclk_en | output |  | |
| if_sclk_tud | output |  | |
| if_sda_sdi_in | input |  | |
| if_sda_sdi_i3c_in | input |  | |
| if_sda_sdi_out | output |  | |
| if_sda_sdi_en | output |  | |
| if_sda_sdi_tud | output |  | |
| if_cs_in | input |  | |

<p>&nbsp;</p>

Source interface table 2: Table 1313: PAD MUX I/O List

- source table from OCR extract page 57

| Port name | Direction | Type / details | Source page |
|---|---|---|---|
| i_write_protection_en | input | write_protection_en OTP regmap enable from regmap | 49 |
| o_write_protection_en | output | write_protection_en OTP regmap enable to regmap | 49 |
| i_tap_bist_mode | input | bist_mode signal used retun in functional mode | 49 |
| i_EN_0P05HP_ECG0 | input | bit enable select PDRES 05 ECG0 channel | 49 |
| i_EN_0P05HP_ECG12 | input | bit enable select PDRES 05 ECG12 channel | 49 |
| IMPQ_PSDRES_UP_02 | input | [2:0] OTP value for Analog block | 49 |
| IMPQ_PSDRES_DOWN_02 | input | [2:0] OTP value for Analog block | 49 |
| IMPP_PSDRES_UP_02 | input | [2:0] OTP value for Analog block | 49 |
| IMPP_PSDRES_DOWN_02 | input | [2:0] OTP value for Analog block | 49 |
| ECG_PSDRES_DOWN_02 | input | [2:0] OTP value for Analog block | 49 |
| ECG_PSDRES_UP_02 | input | [2:0] OTP value for Analog block | 49 |
| IMPQ_PSDRES_UP_05 | input | [2:0] OTP value for Analog block | 49 |
| IMPQ_PSDRES_DOWN_05 | input | [2:0] OTP value for Analog block | 49 |
| IMPP_PSDRES_UP_05 | input | [2:0] OTP value for Analog block | 49 |
| IMPP_PSDRES_DOWN_05 | input | [2:0] OTP value for Analog block | 49 |
| ECG_PSDRES_DOWN_05 | input | [2:0] OTP value for Analog block | 49 |
| ECG_PSDRES_UP_05 | input | [2:0] OTP value for Analog block 49 | 49 |
| IMPQ_PSDRES_UP | output | [2:0] OTP value for Analog block | 50 |
| IMPQ_PSDRES_DOWN | output | [2:0] OTP value for Analog block | 50 |
| IMPP_PSDRES_UP | output | [2:0] OTP value for Analog block | 50 |
| IMPP_PSDRES_DOWN | output | [2:0] OTP value for Analog block | 50 |
| ECG_PSDRES_DOWN | output | [2:0] OTP value for Analog block | 50 |
| ECG_PSDRES_UP | output | [2:0] OTP value for Analog block | 50 |
| i_TS_IRQ_ST | input | time slot irq | 50 |
| i_DCCK_IRQ_ST | input | DCCK irq change status | 50 |
| o_en_tx_1V2 | input | input to LED pilot | 50 |
| o_tx_preset_1V2 | input | input to LED pilot | 50 |
| o_tx1_outlab_sel_frame_x_1V2 | input | input to LED pilot | 50 |
| sel_irq_gpio1 | input | [3:0] sel irq gpi1 {000:NC, 001:i_fifo_irq, 010:i_LED_Pilot, 011:i_DCCK_irq, 100:i_error_time_slot, 101:i_time_slot_irq} | 50 |
| sel_irq_gpio2 | input | [3:0] sel irq gpi2 {000:NC, 001:i_fifo_irq, 010:i_LED_Pilot, 011:i_DCCK_irq, 100:i_error_time_slot, 101:i_time_slot_irq} | 50 |
| sel_irq_gpio3 | input | [3:0] sel irq gpi3 {000:NC, 001:i_fifo_irq, 010:i_LED_Pilot, 011:i_DCCK_irq, 100:i_error_time_slot, 101:i_time_slot_irq} | 50 |
| sel_irq_gpio4 | input | [3:0] sel irq gpi4 {000:NC, 001:i_fifo_irq, 010:i_LED_Pilot, 011:i_DCCK_irq, 100:i_error_time_slot, 101:i_time_slot_irq} | 50 |
| DCCK_P_en | input | Manages lead off mode DCCK_P, Source: Regmap | 50 |
| DCCK_N_en | input | Manages lead off mode DCCK_P, Source: Regmap | 50 |
| MODE_OPERATION | input | Start Divice operations status 50 | 50 |
| o_pd_p | output | enable lead off mode DCCK_P, Destination:Analog block | 51 |
| o_pd_n | output | enable lead off mode DCCK_N, Destination:Analog block | 51 |
| O_DCCK_P_i | input | status lead off mode DCCK_P {0:low impedance,1:floating electrode}, Source: Analog block | 51 |
| O_DCCK_N_i | input | status lead off mode DCCK_N {0:low impedance,1:floating electrode}, Source: Analog block | 51 |
| if_gpio1_in_reg | output | ZI value from regmap | 51 |
| if_gpio1_en_reg | input | EN value from regmap | 51 |
| if_gpio1_out_reg | input | OUT value from regmap | 51 |
| if_gpio2_in_reg | output | ZI value from regmap// ZI | 51 |
| if_gpio2_en_reg | input | EN value from regmap | 51 |
| if_gpio2_out_reg | input | OUT value from regmap | 51 |
| if_gpio3_in_reg | output | ZI value from regmap | 51 |
| if_gpio3_en_reg | input | EN value from regmap | 51 |
| if_gpio3_out_reg | input | OUT value from regmap | 51 |
| if_gpio4_in_reg | output | ZI value from regmap | 51 |
| if_gpio4_en_reg | input | EN value from regmap | 51 |
| if_gpio4_out_reg | input | OUT value from regmap | 51 |
| o_ext_reg_dt_afe | input | [7:0] i2c/spi read data u_regmap_otp | 51 |
| o_ext_reg_dt | output | [7:0] i2c/spi read data output | 51 |
| i_ext_reg_add | input | [7:0] i2c/spi address | 51 |
| i_ext_reg_dt | input | [7:0] i2c/spi write data | 51 |
| i_ext_reg_ck_wr | input | i2c/spi clk 51 | 51 |
| i_ext_reg_we | input | i2c/spi regmap direct write enable | 52 |
| if_sclk_in | input | ZI_I2C | 52 |
| if_sclk_i3c_in | input | ZI_I3C | 52 |
| if_sclk_out | output | A | 52 |
| if_sclk_en | output | EN | 52 |
| if_sclk_tud | output | TUD | 52 |
| if_sda_sdi_in | input | ZI_I2C | 52 |
| if_sda_sdi_i3c_in | input | ZI_I3C | 52 |
| if_sda_sdi_out | output | A | 52 |
| if_sda_sdi_en | output | EN | 52 |
| if_sda_sdi_tud | output | TUD | 52 |
| if_cs_in | input | ZI CS | 52 |
| if_cs_out | output | A | 52 |
| if_cs_en | output | EN | 52 |
| if_cs_tud | output | TUD | 52 |
| if_gpio0_in | input | ZI GPIO0 | 52 |
| if_gpio0_out | output | A | 52 |
| if_gpio0_en | output | EN | 52 |
| if_gpio0_tud | output | TUD | 52 |
| if_gpio1_in | input | ZI GPIO1 | 52 |
| if_gpio1_out | output | A | 52 |
| if_gpio1_en | output | EN | 52 |
| if_gpio1_tud | output | TUD | 52 |
| if_gpio2_in | input | ZI GPIO2 52 | 52 |
| if_gpio2_out | output | A | 53 |
| if_gpio2_en | output | EN | 53 |
| if_gpio2_tud | output | TUD | 53 |
| if_gpio3_in | input | ZI GPIO3 | 53 |
| if_gpio3_out | output | A | 53 |
| if_gpio3_en | output | EN | 53 |
| if_gpio3_tud | output | TUD | 53 |
| if_gpio4_in | input | ZI GPIO4 | 53 |
| if_gpio4_out | output | A | 53 |
| if_gpio4_en | output | EN | 53 |
| if_gpio4_tud | output | TUD | 53 |
| if_sh_ck_in | input | ZI sensor hub ck | 53 |
| if_sh_ck_out | output | A | 53 |
| if_sh_ck_en | output | EN | 53 |
| if_sh_ck_tud | output | TUD | 53 |
| if_sh_sda_in | input | ZI sensor hub SDA | 53 |
| if_sh_sda_out | output | A | 53 |
| if_sh_sda_en | output | EN | 53 |
| if_sh_sda_tud | output | TUD | 53 |
| POR1V2_1V2 | input | POR | 53 |
| ispu_tck | output | jtag clk port ispu in ispu debug mode | 53 |
| ispu_tdi | output | jtag data in port ispu in ispu debug mode | 53 |
| ispu_tdo | input | jtag data out port ispu in ispu debug mode | 53 |
| ispu_tdo_en | input | jtag en port ispu in ispu debug mode 53 | 53 |
| ispu_tms | output | jtag state in port ispu in ispu debug mode | 54 |
| ispu_trst_n | output | jtag reset in port ispu in ispu debug mode | 54 |
| i_if_ck | output | i2c/spi clk | 54 |
| i_if_cs | output | i2c/spi cs | 54 |
| i_if_sda_sdi_in | output | i2c/spi data | 54 |
| o_if_cs_en_n | input | i2c/spi cs en from i2c/spi ip | 54 |
| o_if_cs_out_n | input | i2c/spi cs out from i2c/spi ip | 54 |
| o_if_cs_tud | input | i2c/spi cs tud from i2c/spi ip | 54 |
| o_if_sda_sdi_en_n | input | i2c/spi data en from i2c/spi ip | 54 |
| o_if_sda_sdi_out | input | i2c/spi data out from i2c/spi ip | 54 |
| scl_master_in | output | from sensorhub | 54 |
| scl_master_out | input | from sensorhub | 54 |
| sda_master_in | output | to sensorhub | 54 |
| sda_master_out | input | from sensorhub | 54 |
| afe_bist_ctrl_tdi | output | bist jtag port | 54 |
| afe_bist_ctrl_trstn | output | bist jtag port | 54 |
| afe_bist_ctrl_tms | output | bist jtag port | 54 |
| afe_bist_ctrl_tdo | input | bist jtag port | 54 |
| afe_bist_ctrl_tdo_en_n | input | bist jtag port | 54 |
| afe_bist_ctrl_tck | output | bist jtag port | 54 |
| ck_16m | input | clk16MHz trimming in debug mode | 54 |
| ck_2m | input | clk2MHz trimming in debug mode | 54 |
| ck_64k | input | clk64MHz trimming in debug mode | 54 |
| scan_rstn | output | scan reset 54 | 54 |
| scan_enable | output | scan enable | 55 |
| scan_clk | output | scan clock | 55 |
| ext_cap_en | input | extenal cap in debug mode | 55 |
| irq_fifo | input | fifo irq from main controller - regmap | 55 |
| error_time_slot | input | error timeslot from error time slot | 55 |
| gpio_in | output | gpio0 in in functional mode from regmap | 55 |
| gpio_out | input | gpio0 out in functional mode from regmap | 55 |
| gpio_en | input | gpio0 en in functional mode from regmap | 55 |
| irq_SENSHUB_STS | input | sensorhub status | 55 |
| irq_ISPU_MC_INTR_STS | input | irq main controller data-valid | 55 |
| scan_mode | output | stbio1 scan mode | 55 |
| bist_mode | output | stbio1 bist mode | 55 |
| debug_mode | output | stbio1 debug mode | 55 |
| memsafe | output | memsafe for bist | 55 |
| test_clk_fast | input | enable test clk 16MHz trimming | 55 |
| test_clk_slow | input | enable test clk 64kHz trimming | 55 |
| if_sclk_tud_reg | input | if sclk_tud from reg | 55 |
| if_sda_sdi_tud_reg | input | if sda_sdi_tud from re | 55 |
| if_sh_sda_tud_reg | input | if sh_sda_tud from reg | 55 |
| if_gpio0_tud_reg | input | if gpio0_tud from reg | 55 |
| if_gpio1_tud_reg | input | if gpio1_tud from reg | 55 |
| if_gpio2_tud_reg | input | if gpio2_tud from reg | 55 |
| if_gpio3_tud_reg | input | if gpio3_tud from reg 55 | 55 |
| if_gpio4_tud_reg | input | if gpio4_tud from reg | 56 |
| if_sh_ck_tud_reg | input | if sh_ck_tud from reg | 56 |
| clk_dft_adc | input | 16MHz adc dft clk | 56 |
| i_ADC_clk_serial_dft | input | serial clk for adc dft 16Mhz:Fast mode, if_sh_ck_in:Low noise mode | 56 |
| EN_ADC_TEST_FAST | input | enable adc test fast | 56 |
| EN_ADC_TEST_LOW_NOISE | input | enable adc test low noise | 56 |
| i_ADC_EOC | input | adc eoc input | 56 |
| i_ADC_start | input | adc star from main controller | 56 |
| i_data_ADC_out | input | [15:0] adc data input | 56 |
| o_ADC_start | output | adc star output | 56 |
| i_N_clk | input | [6- 1:0] n clk start time high | 56 |
| i_saturation_irq | input | interrupt saturation from main controller | 56 |
| i_end_boot | input | end boot signal from adsp | 56 |
| quokka_run | input | status quokka elaboration 1:run 0:not elaboration | 56 |
| sensor_hub_status | input | status sensor_hob from regmap | 56 |
| SH_CKL_EN | input | sensorhub clk enable from regmap (master_end_op_clr or sleep_master_clr or ahb_master_on_clr) | 56 |
| i_t_force_1v2 | input | input force signal to IDDQ test | 56 |
| o_t_force_1v2 | output | force signal to IDDQ test | 56 |
| i_bfail_fifo | input | bist fail fifo ram | 56 |
| i_bfail_qk | input | bist fail adsp ram | 56 |
| i_bfail_ispu1 | input | bist fail ispu ram instruction mem | 56 |
| i_bfail_ispu2 | input | bist fail ispu ram data mem 1 56 | 56 |
| i_bfail_ispu3 | input | bist fail ispu ram data mem 2 | 57 |
| i_bfail_ispu4 | input | bist fail ispu ram data mem 3 | 57 |
| i_bend | input | bist end signal | 57 |
| i_bbad | input | signal fail bist test | 57 |
| o_bypass | output | bypass memory signal | 57 |

<p>&nbsp;</p>

### **9.12 ISPU** {#912-ispu}
An interrupt triggers ISPU wake-up.

<p>&nbsp;</p>

Source interface table 1: Table 32: ISPU I/O List

- source table from OCR extract page 129

| Port name | Direction | Type / details | Source page |
|---|---|---|---|
| clk | input | clk 16MHz from pmu u_pmu_clk_stredl_sig | 116 |
| main_rst_n | input | reset in 16MHz domain u_pmu_resetn_stredl_sig | 116 |
| POR_n | input | reset in 16MHz domain u_pmu_resetn_stredl_sig | 116 |
| ispu_xbar_sw_resetn | input | Software reset ISPU xbar u_regmap_otp_ispu_xbar_sw_reset n_sig | 116 |
| ispu_core_sw_resetn | input | Software reset ISPU core u_regmap_otp_ispu_core_sw_reset n_sig | 116 |
| scan_mode | input | Scan mode u_pad_mux_scan_mode_sig | 116 |
| scan_enable | input | Scan enable u_pad_mux_scan_enable_sig | 116 |
| test_rst_n | input | Scan reset u_pad_mux_scan_rstn_sig | 116 |
| bist_mode | input | Bist mode enable u_pad_mux_bist_mode_sig | 116 |
| interrupt | input | Interrupt lines u_ca_fifo_bist_c_oen_1, u_fifo_irq_FIFO_U_M_IRQ_STATU S_sig, u_regmap_otp_irq_SENSHUB_STS _sig, u_regmap_otp_irq_ISPU_MC_INTR _STS_sig, u_regmap_otp_sw_interrupt_sig, u_ca_fifo_bist_c_oen_1, u_ca_fifo_bist_c_oen_1, u_ca_fifo_bist_c_oen_1, u_ca_fifo_bist_c_oen_1, 116 u_ca_fifo_bist_c_oen_1, u_ca_fifo_bist_c_oen_1, u_ca_fifo_bist_c_oen_1, u_ca_fifo_bist_c_oen_1, u_ca_fifo_bist_c_oen_1 | 116 |
| clk_en | output | Enable clock at ISPU core u_ispu_clk_en_sig | 117 |
| S_HSEL | input | AHB HSEL Slave Port u_xbar_afe_hsel_M0_sig | 117 |
| S_HREADY | input | AHB HREADY Slave Port u_xbar_afe_hreadymux_M0_sig | 117 |
| S_HREADYOUT | output | AHB HREADYOU T Slave Port u_ispu_S_HREADYOUT_sig | 117 |
| S_HTRANS | input | AHB HTRANS Slave Port u_xbar_afe_htrans_M0_sig | 117 |
| S_HADDR | input | AHB HADRR Slave Port u_xbar_afe_haddr_M0_sig | 117 |
| S_HSIZE | input | AHB HSIZE Slave Port u_xbar_afe_hsize_M0_sig[1:0] | 117 |
| S_HWRITE | input | AHB HWRITE Slave Port u_xbar_afe_hwrite_M0_sig | 117 |
| S_HWDATA | input | AHB HWDATA Slave Port u_xbar_afe_hwdata_M0_sig | 117 |
| S_HRDATA | output | AHB HRDATA Slave Port u_ispu_S_HRDATA_sig | 117 |
| S_HRESP | output | AHB HRESP Slave Port u_ispu_S_HRESP_sig 117 | 117 |
| M_HSEL | output | AHB HSEL Master Port u_ispu_M_HSEL_sig | 118 |
| M_HREADY | input | AHB HREADY Master Port u_xbar_afe_hready_S0_sig | 118 |
| M_HTRANS | output | AHB HTRANS Master Port u_ispu_M_HTRANS_sig | 118 |
| M_HADDR | output | AHB HADDR Master Port u_ispu_M_HADDR_sig | 118 |
| M_HSIZE | output | AHB HSIZE Master Port u_ispu_M_HSIZE_sig | 118 |
| M_HWRITE | output | AHB HWRITE Master Port u_ispu_M_HWRITE_sig | 118 |
| M_HWDATA | output | AHB HWDATA Master Port u_ispu_M_HWDATA_sig | 118 |
| M_HRDATA | input | AHB HRDATA Master Port u_xbar_afe_hrdata_S0_sig | 118 |
| M_HRESP | input | AHB HRESP Master Port u_xbar_afe_hresp_S0_sig | 118 |
| DBG_HREADY | input | AHB HREADY Debug Master Port u_xbar_afe_hready_S4_sig | 118 |
| DBG_HTRANS | output | AHB HTRANS Debug Master Port u_ispu_DBG_HTRANS_sig | 118 |
| DBG_HADDR | output | AHB HADDR Debug Master Port u_ispu_DBG_HADDR_sig 118 | 118 |
| DBG_HSIZE | output | AHB HSIZE Debug Master Port u_ispu_DBG_HSIZE_sig | 119 |
| DBG_HWRITE | output | AHB HWRITE Debug Master Port u_ispu_DBG_HWRITE_sig | 119 |
| DBG_HBURST | output | AHB DHBURST ebug Master Port NO CONN | 119 |
| DBG_HWDATA | output | AHB HWDATA Debug Master Port u_ispu_DBG_HWDATA_sig | 119 |
| DBG_HRDATA | input | AHB HRDATA Debug Master Port u_xbar_afe_hrdata_S4_sig | 119 |
| DBG_HRESP | input | AHB HRESP Debug Master Port u_xbar_afe_hresp_S4_sig | 119 |
| trst_n | input | JTAG Test Reset u_pad_mux_ispu_trst_n_sig | 119 |
| tck | input | JTAG Test Clock u_pad_mux_ispu_tck_sig | 119 |
| tms | input | JTAG Test Mode Select u_pad_mux_ispu_tms_sig | 119 |
| tdi | input | JTAG Test Data In u_pad_mux_ispu_tdi_sig | 119 |
| tdo | output | JTAG Test Data Out u_ispu_tdo_sig | 119 |
| tdo_en | output | JTAG Test Data Out Enable u_ispu_tdo_en_sig 119 ca_stredl_bist_c_rst_bistctl | 119 |
| r_n | input | BIST Asynchrono us Reset Pin for collar Serial Interface and Controller u_pmu_tst_rst_bistctlr_n_sig ca_stredl_bist_c_clk_bistctl | 120 |
| r | input | BIST Low Frequency Serial Shift Clock for the controller u_pmu_tst_clk_bistctlr_sig ca_stredl_bist_c_bist_mod | 120 |
| e | input | BIST Global BIST Mode Selection Bus u_ta_afe_bist_crtl_bist_mode_ctlr_s ig ca_stredl_bist_c_march_sh | 120 |
| ift | input | BIST March element serial data out enable to SP/ROM/RF /DP collars u_ta_afe_bist_crtl_march_shiftSP_s ig ca_stredl_bist_c_collar_co | 120 |
| nfig | input | BIST Mode selection pins for SP/ROM/RF /DP memory collars (modefunc, modestab, modecoll) u_ta_afe_bist_crtl_collar_configSP_ sig | 120 |
| ca_stredl_bist_c_march_in | input | BIST March element serial data in u_ta_afe_bist_crtl_march_outSP_si g ca_stredl_bist_c_march_ru | 120 |
| n | input | BIST March run to SP/ROM/RF /DP collars u_ta_afe_bist_crtl_march_runSP_si g 120 | 120 |
| ca_stredl_bist_c_memsafe | input | BIST Pin to globally deactivate the selected memories by making CSN high internally u_ta_afe_bist_crtl_memsafe_ctlr_si g ca_stredl_bist_c_sif_reg_e | 121 |
| n | input | BIST Enable for various types of data transfer (Bitmap, memory selection, programma ble algorithms) through serial interface. u_ta_afe_bist_crtl_sif_reg_en_ctlr_s ig ca_stredl_bist_c_sif_load_ | 121 |
| en | input | BIST Allows to control the data loading from collar registers to serial interface registers of the collar u_ta_afe_bist_crtl_sif_load_en_ctlr_ sig | 121 |
| ca_stredl_bist_c_shift_en | input | BIST Enable for Serial Input Data from Tester/Exter nal World u_ta_afe_bist_crtl_shift_en_ctlr_sig ca_stredl_bist_c_sif_updat | 121 |
| e_en | input | BIST Allows to control the data loading from collar u_ta_afe_bist_crtl_sif_update_en_ct lr_sig 121 registers to serial interface registers of the collar ca_stredl_bist_c_march_e | 121 |
| nd | output | BIST March end signal from each SP / ROM / RF / DP collar type u_ispu_ca_stredl_bist_c_march_en d_sig | 122 |
| ca_stredl_bist_c_bbad_1 | output | BIST Indicates bbad for a specific memory. There are as many bbad signals as the number of memories. NO CONN | 122 |
| ca_stredl_bist_c_bfail_1 | output | BIST Indicates bfail for a specific memory. There are as many bbad signals as the number of memories. u_ispu_ca_stredl_bist_c_bfail_1_sig ca_stredl_bist_c_repairabl | 122 |
| e_1 | output | BIST Indicates repairable for a specific memory.The re are as many repairable signals as NO CONN 122 the number of memories. For a shared collar there would be as many repairable outputs as the number of memories | 122 |
| ca_stredl_bist_c_bbad_2 | output | BIST Indicates bbad for a specific memory. There are as many bbad signals as the number of memories. NO CONN | 123 |
| ca_stredl_bist_c_bfail_2 | output | BIST Indicates bfail for a specific memory. There are as many bbad signals as the number of memories. u_ispu_ca_stredl_bist_c_bfail_2_sig ca_stredl_bist_c_repairabl | 123 |
| e_2 | output | BIST Indicates repairable for a specific memory.The re are as many repairable signals as NO CONN 123 the number of memories. For a shared collar there would be as many repairable outputs as the number of memories | 123 |
| ca_stredl_bist_c_bbad_3 | output | BIST Indicates bbad for a specific memory. There are as many bbad signals as the number of memories. NO CONN | 124 |
| ca_stredl_bist_c_bfail_3 | output | BIST Indicates bfail for a specific memory. There are as many bbad signals as the number of memories. u_ispu_ca_stredl_bist_c_bfail_3_sig ca_stredl_bist_c_repairabl | 124 |
| e_3 | output | BIST Indicates repairable for a specific memory.The re are as many repairable signals as NO CONN 124 the number of memories. For a shared collar there would be as many repairable outputs as the number of memories | 124 |
| ca_stredl_bist_c_bbad_4 | output | BIST Indicates bbad for a specific memory. There are as many bbad signals as the number of memories. NO CONN | 125 |
| ca_stredl_bist_c_bfail_4 | output | BIST Indicates bfail for a specific memory. There are as many bbad signals as the number of memories. u_ispu_ca_stredl_bist_c_bfail_4_sig ca_stredl_bist_c_repairabl | 125 |
| e_4 | output | BIST Indicates repairable for a specific memory.The re are as many repairable signals as NO CONN 125 the number of memories. For a shared collar there would be as many repairable outputs as the number of memories | 125 |
| ca_stredl_bist_c_serial_out | output | BIST Serial Output Data from Tester / External World u_ispu_ca_stredl_bist_c_serial_out_ sig | 126 |
| ca_stredl_bist_c_bypass | input | BIST Memory Bypass Pin for RAM type memories. One top level port per collar. u_pad_mux_scan_mode_sig | 126 |
| ca_stredl_bist_c_serial_in | input | BIST Serial Input Data from Tester / External World u_ta_afe_bist_crtl_serial_out_ctlr_si g | 126 |
| ca_stredl_bist_c_test_se | input | BIST Scan Enable Signal Used internally by the BIST to prevent memory operation during scan shifting (a dedicated u_pad_mux_scan_enable_sig 126 test_se (one test_se per collar) is provided at the top level ca_stredl_bist_c_tst_gated | 126 |
| clock | input | BIST Clock Gating Signal for the entire BIST. Used to force clock gating cell transparenc y in ATPG mode . u_pad_mux_scan_enable_sig ca_stredl_bist_c_tst_reset_ | 127 |
| mux | input | BIST Bypass for reset synchronize r. allows to force reset synchronizin g circuit transparenc y in ATPG mode. u_pad_mux_scan_mode_sig | 127 |
| ca_stredl_bist_c_oen_1 | input | BIST Memory Output Enable 1 u_ca_fifo_bist_c_oen_1 | 127 |
| ca_stredl_bist_c_oen_2 | input | BIST Memory Output Enable 2 u_ca_fifo_bist_c_oen_1 | 127 |
| ca_stredl_bist_c_oen_3 | input | BIST Memory Output Enable 3 u_ca_fifo_bist_c_oen_1 | 127 |
| ca_stredl_bist_c_oen_4 | input | BIST Memory u_ca_fifo_bist_c_oen_1 127 Output Enable 4 ca_stredl_bist_c_mem_atp | 127 |
| g_mode | input | BIST For ATPG purpose: Used to constraint few memory inputs and improve controllabilit y and observability . u_ca_fifo_bist_c_oen_1 ca_stredl_bist_c_tst_mem_ | 128 |
| selck_1 | input | BIST To select the clock and memory ports in ATPG mode 0: Functional Clock / Functional Ports 1: Test Clock/ Test Ports u_ca_fifo_bist_c_oen_1 ca_stredl_bist_c_tst_mem_ | 128 |
| selck_2 | input | BIST To select the clock and memory ports in ATPG mode 0: Functional Clock / Functional Ports 1: Test Clock/ Test Ports u_ca_fifo_bist_c_oen_1 ca_stredl_bist_c_tst_mem_ | 128 |
| selck_3 | input | BIST To select the u_ca_fifo_bist_c_oen_1 128 clock and memory ports in ATPG mode 0: Functional Clock / Functional Ports 1: Test Clock/ Test Ports ca_stredl_bist_c_tst_mem_ | 128 |
| selck_4 | input | BIST To select the clock and memory ports in ATPG mode 0: Functional Clock / Functional Ports 1: Test Clock/ Test Ports u_ca_fifo_bist_c_oen_1 ca_stredl_bist_c_par_mem | 129 |
| sel | input | BIST Parallel Memory Selection Bus { 1'b0, u_ca_fifo_bist_c_oen_1, u_ca_fifo_bist_c_oen_1, u_ca_fifo_bist_c_oen_1 } | 129 |

<p>&nbsp;</p>

## **10. Missing Inputs** {#10-missing-inputs}

- None

