# SRS descriptive synthesis and destination review

The existing local deterministic flow separates source support, destination
permission, composition, and final-artifact assessment. It does not use an LLM,
remote service, or generated specification as a source of authority.

## Obligation -> implementation -> independent check

| Obligation | Existing implementation surface | Independent check |
|---|---|---|
| Interpret source meaning without creating permission | `srs_source_evidence_model` and the shared source interpreter in [workflow_routing.py](../scripts/workflow_routing.py) | Hand-established meaning/quantity/qualification assertions in [test_srs_process_correction.py](../tests/test_srs_process_correction.py); unsupported constructions remain explicit |
| Make semantic destinations reviewable | `DOCUMENT_SECTIONS` and `SRS_DESTINATION_MEANINGS` in [governed_descriptive_scope.py](../scripts/governed_descriptive_scope.py) | Contract/role consistency and cross-document isolation tests |
| Preserve the ordinary approval lane | [descriptive_review_proposals.py](../scripts/descriptive_review_proposals.py), [mapping_review_sync.py](../scripts/mapping_review_sync.py), existing profile and snapshot resolvers | Pending/rejected use tests, role-edit invalidation, workbook roundtrip, profile hash verification and source-bound resolver projection |
| Explain rather than list contributors | `srs_section_explanation_claim`, `compose_srs_section_explanation` and the existing section planner | Actual prose recovery, not heading or contributor counts; active SRS writer and DOCX converter tests |
| Preserve supported behaviour during abstraction | `abstract_srs_evidence_model` | Independent Markdown/Word mutations of quantities, ownership, guards, exceptions, raw-data distinctions, optionality and alternatives |
| Distinguish missing permission from missing source support | Complete `source_records` collection and `assess_srs_meaning_dispositions` in [spec_document_contract.py](../scripts/spec_document_contract.py) | Snapshot-scope comparison and actual final-prose readback; incomplete scope examination is NOT CHECKED |
| Keep publication and readiness separate | Existing gate/report boundaries are unchanged | Generation does not certify writing quality, publication eligibility or implementation readiness |

The active obligations are in the existing general rules and the Markdown/
embedded YAML [SRS template](../templates/SRS_gen_AI_template_prompt.md).
The correction adds the missing review destination and clarifies the existing
operating-concept restriction role; it does not introduce another pipeline,
approval mechanism, mandatory writing gate or readiness policy.

## Review destinations

| Review role | SRS section | Meaning |
|---|---|---|
| `purpose` | 3.1 | Supported product identity and application role |
| `functions` | 3.2 | Top-level capabilities |
| `organization` | 3.3 | Supported architectural organization |
| `context` | 3.4 | Boundaries, interactions and authorized context |
| `operating_concept` | 3.5 | Supported operating behaviour and restrictions |

Semantic candidates appear as pending rows in **Shared Evidence Destinations**.
They retain exact source bodies/offsets, source identities, bindings and review
seals. Selecting approved cannot make a computed unsupported interpretation
ready. Changing a destination role requires refresh and renewed destination
review; it does not revoke source approval.

Existing context permissions are not silently converted to operating-concept
permissions. With both permissions present, equivalent meanings use their
explicit semantic destination once; existing permissions themselves remain
unchanged. Source-bound synthesis proposals expose corresponding destination
requests, but neither a request nor a preview is an approved use.

Semantic fitness is checked even when only a context permission exists.
Identity/purpose, capabilities, organization and operating behaviour do not
become boundary prose merely because section 3.4 is the currently authorized
destination. Such meanings are withheld from the authorized prose and reported
for destination review. The independent assessor uses their semantic roles,
not a context-use label that would mask incorrect placement.

The existing synthesis-proposal JSON includes current sections, proposed sections,
source-bound meanings and requests, and unchanged source/destination decisions.
Normal SRS generation also renders its proposed sections into a separate Markdown
and Word review companion. Both are explicitly non-authoritative and ineligible
for publication; Word headers repeat that status. These companions do not carry
an authorized document contract or replace the existing approval/snapshot process.
They are written outside the Stage 3 publication-input directory, under
`artifacts/reviews`, so ordinary SRS Markdown-to-LaTeX collection cannot include
the proposed prose in the generated publication.

Shared reuse can retain an approved source owner. The owner is not a wildcard
destination: only explicit reviewed uses are projected, and the original owner's
local authority remains available. A functional IPOS use needs same-owner local
support or an explicit source-bound actor/action; accessibility, wiring and
mentions do not establish execution. Named passive storage is another bounded
support construction. It does not certify the interpreter's entire passage.

Mixed non-mode source context can be admitted for semantic-only SRS analysis
under a source-hash-bound approved-use policy. It cannot be rendered literally,
and normative/programming fragments remain unresolved rather than becoming
descriptive facts. Setup-dependent mode bodies retain the stricter complete-mode
binding. A partial flattened-list proposal expands to complete source context
instead of clipping a trailing qualification.

## Bounded explanation and abstraction

Compatible relationships are ordered as supported responsibility/outcome,
contributing activities, boundaries/availability, and essential qualifications.
Conditions and modes remain attached to their activities; incompatible actors,
guards, optionality or polarity are not merged.

A complete bounded two-phase explanation can retain named phases, actors,
and/or alternatives, eventual activity, optional processing and exclusive
residual activity. The phase names and period come from source evidence, not
project-specific labels. Presentation order does not assert a transition or
sequencing relationship absent from the source. Unsupported or editorial-future
constructions remain unresolved rather than becoming unconditional behaviour.
Mode-qualified interaction restrictions belong to operating explanation, not
static boundary description. Review paragraphs are grouped by source-supported
mode, phase context or actor; these groupings do not grant reuse permission.

A bounded rule can summarize multiple compatible system acquisitions that
explicitly store samples in the same destination as acquisition with sample
storage. The individual channels, quantities, raw/averaged distinctions and
exceptions remain in the explanation. The rule cannot infer a processing
outcome from wiring, accessibility or a coordination relationship.

Register syntax is excluded from SRS prose, not from immutable source evidence.
A mode heading alone does not establish equivalence with register settings.
The supported source-bound configuration qualification is retained; unknown
setup/meaning relationships remain unresolved. Approved internal actors are
identified using structural evidence, not a list of project block names.
An unsupported system consequence is not invented for an internal restriction.
The final SRS gate uses the same implementation-syntax classifier as abstraction:
the word "register" in a supported high-level access capability is not itself
a named register, bit value, address or programming instruction.
The built-in SRS writing profile uses that same distinction when admitting
facts; other excluded terms and document profiles retain their restrictions.

Bounded access rules preserve direct/bus alternatives, bus-only restrictions
and disabled-by-default qualifications without attributing execution to the
register map. A uniquely identified source bank can be abstracted to the
source-specified register bank; multiple distinct banks remain unresolved.
An explicit enablement sequence can retain supply/oscillator startup followed
by the stated clock-stability check while leaving programming and status-bit
details unresolved. A flattened enablement heading is kept separate from its
preceding programming example, with exact source offsets preserved.
Self-contained advice to change a source-specified mode only in a named device
state remains a recommendation, not a mandatory requirement. It does not inherit
an unrelated preceding setup command; additional guards remain unresolved.

Complete FIFO configuration descriptions retain alternative configurations,
the partition upper bound, configurable depth and first-in first-out ordering.
Storage and partition identities must agree. Unknown embedded guards or
changed status polarity do not qualify for these bounded interpretations.
Ambiguous channel/result-to-partition correspondence remains explicitly
unresolved; a source-assignment qualification does not establish that mapping.
The prose does not substitute a vague assertion of a "source-specified"
assignment for an explanation. The unresolved mapping remains visible in source
dispositions and review evidence; only independently supported storage behaviour
is composed. Alternative storage configurations are operating concepts, not a
second copy of the main-functions overview.
These interpretations create neither destination permissions nor approvals.
Generated provenance audits are read with a field limit sized to the artifact,
not the CSV library's smaller default. The process-wide limit is restored after
each read; source bodies and audit cells are never truncated to fit it.
The DRS low-power renderer retains approved structured power-domain records
even though its general digital-interaction input excludes them. This restores
existing table rows; it neither extends SRS section 3.6 nor introduces new power
authority. Modern DRS overview verification checks the supported recomposed
overview, after independent source/audit validation, rather than requiring
the pre-composition paragraph layout.
IPOS publication, blocker assessment, its gate and central coherence all rebuild
the descriptive input from the same selected snapshot's architecture inventory
and snapshot-bound provenance. A mutable CSV inventory is not substituted when
checking a snapshot-bound materialization audit.
SysML consumers retain the snapshot's exact block label after resolving an
approved alias, so display capitalization cannot invalidate a block-bound
review or change normalized descriptive identities.
SysML documentation declarations end at `*/`, without a following semicolon.
Both architecture generation and the SRS converter preserve the complete
documentation and provenance under this syntax. Metadata and overview readers
also recognize historical semicolon-terminated artifacts, but that compatibility
is not language-parser validation. Structural review, actual language-server
diagnostics and implementation readiness remain separate checks.
Embedded YAML contracts use a bounded parse cache keyed by complete template
content and document type. The file is still read on each load, and callers
receive independent deep copies. Same-size edits with unchanged timestamps,
invalid contracts and deleted files therefore retain their existing behavior;
no approval, policy or validation result is cached.

## Meaning dispositions and uncertainty

The writing-quality report includes `meaning_dispositions` and source ->
meaning -> responsibility -> section links. Applicable meanings are classified
as synthesized, retained in authorized detail, justified exclusion or unresolved.
Gap classes distinguish missing authorization, unsupported interpretation,
authorized-but-unrendered meaning, incorrect placement, prose defects and
NOT CHECKED. Missing evidence is not certified from a producer's omission or an
incompletely examined source scope.
Destination review reports `projection_gap` when the bounded parser recognizes
no proposition, rather than claiming that supporting source evidence is missing.
An explicitly wrong semantic role remains `unsupported_interpretation`.

`retained_in_authorized_detail` identifies local source scope. If the destination
document was not read, `detail_readback` is NOT CHECKED and
`final_coverage_credit` is false. It does not satisfy an SRS summary obligation.
The same is true of pending previews, contributor IDs, section headings and
retained implementation syntax.

## Demonstrated semantic limits

This is not an arbitrary-language semantic parser or a guarantee that every new
project needs configuration changes only. The bounded interpreter supports
specific identity/application constructions, typed functional descriptions,
qualified source modes and supported acquisition/storage/availability/optional
processing relationships. Unique setup binding is deliberately conservative.

Unknown grammar, ambiguous antecedents, unsupported transitions, unclear
ownership and unproved configuration equivalences remain unresolved. Supporting
another construction requires a reusable source-backed interpretation rule and
new independent fixtures, not project-name exceptions or borrowed prose.
The assessor reads source meanings independently of producer selection and
paragraph plans, but shares bounded source interpretation infrastructure.
Source-supported acquisition/storage summaries are examined even when their
operating-concept destination is pending: semantic recovery must not depend on
permission already having been granted. Readback binds actions to their actor
within semicolon-separated clauses and checks the supported mode, preventing
one storage actor's action from being credited to another. Finite forms of
supported rejection behaviour are normalized without admitting new source
constructions.
Tests with handwritten expectations reduce that shared-parser risk; they do not
prove arbitrary natural-language equivalence or certify general readability.

SRS 3.6 remains outside this correction. Existing SRS/ARS/DRS/IPOS gates,
normative IDs, allocations, Covers and Source I/O are not relaxed or migrated.
