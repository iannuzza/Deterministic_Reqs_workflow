import copy
import json
import shutil
import tempfile
import unittest
from pathlib import Path

from descriptive_review_proposals import accepted_destination_rows, requested_destination_rows
from governed_descriptive_scope import project_shared_descriptive_uses, serialize_descriptive_destinations
from test_governed_descriptive_scope import record
import test_srs_process_correction as process_tests
import test_local_storage_composition as storage_tests
from workflow_routing import (
    SRS_SYSTEM_OVERVIEW_HEADINGS,
    compose_srs_system_overview,
    functional_meaning_role,
    srs_source_evidence_model,
)


def context_evidence(statement):
    source = record("independent-source", statement, evidence_scope="shared", approved_uses_json="[]")
    profile = {"block_defs": {}, "governed_source_context": {"version": 1, "records": [source]}}
    request = {"document": "SRS", "block": "", "role": "context", "start": 0,
               "end": len(statement), "excerpt": statement, "rationale": "Synthetic context-only decision"}
    uses = requested_destination_rows(request, source, [source], profile, [])
    for use in uses:
        use["review_decision"] = "approved"
    accepted = accepted_destination_rows(source, [source], uses, profile, [], [])
    source.update(serialize_descriptive_destinations(source, "shared", accepted))
    admitted = dict(source, snapshot_id="fixed-independent", admission_state="admitted")
    return {"snapshot_id": "fixed-independent", "document": "SRS",
            "source_records": [admitted],
            "shared_records": list(project_shared_descriptive_uses([admitted], document="SRS")),
            "inventory": [], "functions": [], "function_decomposition": []}


class SRSSemanticPlacementTests(unittest.TestCase):
    def compose(self, evidence):
        review, proposals = {}, []
        actual = compose_srs_system_overview(
            evidence["shared_records"], evidence=evidence,
            review_sections=review, proposal_rows=proposals)
        return actual, review, proposals

    def test_context_permission_does_not_make_identity_or_application_a_boundary(self):
        for name, identity, application in (
            ("AURORA8", "an environmental sensing instrument", "remote atmospheric surveys"),
            ("QUASAR3", "a vibration acquisition device", "industrial condition monitoring"),
        ):
            with self.subTest(name=name):
                evidence = context_evidence(
                    f"{name} is {identity}. {name} is intended for {application}.")
                before = copy.deepcopy(evidence)
                actual, review, proposals = self.compose(evidence)
                self.assertFalse(actual[SRS_SYSTEM_OVERVIEW_HEADINGS[0]])
                self.assertFalse(actual[SRS_SYSTEM_OVERVIEW_HEADINGS[3]])
                purpose = " ".join(review[SRS_SYSTEM_OVERVIEW_HEADINGS[0]])
                self.assertIn(identity, purpose)
                self.assertIn(application, purpose)
                self.assertTrue(proposals)
                self.assertTrue(all(not item["authority"] for item in proposals))
                self.assertEqual(evidence, before)

    def test_mode_qualified_interaction_is_behavior_not_a_static_boundary(self):
        statement = (
            "Set PATH bit in Transfer_Control register to 2 and FORMAT to 7 in Sample_Control. "
            "This will cut the communication between Sequencer and Analyzer.")
        source = record("mode-interaction", statement, evidence_scope="shared", approved_uses_json="[]",
            section="6.2", section_context_json=json.dumps(
                [["6", "Operating modes"], ["6.2", "Survey Mode"]]))
        model = srs_source_evidence_model(source)
        interactions = [value.meaning for value in model.propositions
                        if value.meaning.relation == "interaction"]
        self.assertEqual(len(interactions), 1)
        self.assertEqual(functional_meaning_role(interactions[0]), "behavior")
        self.assertEqual(interactions[0].mode, "Survey Mode")
        self.assertIn("Sequencer", interactions[0].subject)
        self.assertIn("Analyzer", interactions[0].subject)

    def test_complete_phases_preserve_actors_alternatives_and_qualifications(self):
        statements = (
            "- In each SAMPLE_WINDOW we can distinguish two phases: "
            "o Observe: where all configured observations are executed and "
            "Reducer and/or Classifier eventually runs its algorithms. "
            "o Quiet: where observations are finished, eventually only Reducer and/or Classifier "
            "is terminating its algorithms and writing summarized data in Archive.",
            "Each sampling cycle comprises two phases: "
            "Gather: all configured measurements are completed and Analyzer may finish its analysis. "
            "Rest: measurements are finished, only Analyzer is writing compressed results in Queue.",
        )
        for statement in statements:
            with self.subTest(statement=statement):
                evidence = context_evidence(statement)
                actual, review, _proposals = self.compose(evidence)
                self.assertFalse(actual[SRS_SYSTEM_OVERVIEW_HEADINGS[3]])
                self.assertFalse(actual[SRS_SYSTEM_OVERVIEW_HEADINGS[4]])
                operation = " ".join(review[SRS_SYSTEM_OVERVIEW_HEADINGS[4]])
                self.assertIn("two phases", operation)
                self.assertIn("only", operation)
                self.assertNotIn("SAMPLE_WINDOW", operation)
                self.assertNotIn("transitions to", operation)
                self.assertNotIn("followed by", operation)
                if "and/or" in statement:
                    self.assertIn("Reducer and/or Classifier", operation)
                    self.assertIn("eventually", operation)
                    self.assertIn("all configured observations are executed", operation)
                    self.assertIn("observations are finished", operation)
                else:
                    self.assertIn("Analyzer may finish", operation)
                with tempfile.TemporaryDirectory() as directory:
                    report = process_tests.SRSProcessCorrectionTests().assess(Path(directory), evidence, review)
                self.assertEqual(report["obligations"]["essential_qualifications"]["status"], "PASS", report)

    def test_independent_readback_rejects_identity_left_in_context_section(self):
        evidence = context_evidence("ORION9 is a distributed measurement instrument.")
        sections = {heading: [] for heading in SRS_SYSTEM_OVERVIEW_HEADINGS[:5]}
        sections[SRS_SYSTEM_OVERVIEW_HEADINGS[3]] = [
            "ORION9 is a distributed measurement instrument."]
        with tempfile.TemporaryDirectory() as directory:
            report = process_tests.SRSProcessCorrectionTests().assess(Path(directory), evidence, sections)
        findings = report["obligations"]["section_roles"]["findings"]
        self.assertTrue(any("conflicts with section" in row["reason"] for row in findings), findings)

    def test_independent_word_readback_rejects_lost_exclusivity(self):
        statement = (
            "Each observation cycle has two phases: "
            "Acquire: all observations are executed and Evaluator may finish its analysis. "
            "Wait: observations are finished, only Evaluator is writing results in Journal.")
        evidence = context_evidence(statement)
        _actual, review, _proposals = self.compose(evidence)
        with tempfile.TemporaryDirectory() as directory:
            report = process_tests.SRSProcessCorrectionTests().assess(
                Path(directory), evidence, review,
                word_change=lambda text: text.replace("only Evaluator", "Evaluator"))
        self.assertNotEqual(report["obligations"]["essential_qualifications"]["status"], "PASS")

    def test_independent_readback_binds_storage_actors_and_modes(self):
        source = storage_tests.LocalStorageCompositionTests().source(
            "Sample Queue", "Single Queue", "Partitioned Queue", 4)
        evidence = context_evidence(source["statement"])
        _actual, review, _proposals = self.compose(evidence)
        with tempfile.TemporaryDirectory() as directory:
            report = process_tests.SRSProcessCorrectionTests().assess(Path(directory), evidence, review)
        self.assertEqual(report["obligations"]["nonduplication"]["status"], "PASS", report)
        with tempfile.TemporaryDirectory() as directory:
            changed = process_tests.SRSProcessCorrectionTests().assess(
                Path(directory), evidence, review, word_change=lambda text: text.replace(
                    "the Sample Queue provides first-in first-out storage",
                    "the Coordinator provides first-in first-out storage"))
        self.assertTrue(any(row["artifact"].endswith(".docx")
            and "not independently recovered" in row["reason"]
            for row in changed["obligations"]["semantic_fidelity"]["findings"]), changed)

    def test_editorial_future_and_examples_are_not_promoted_into_complete_phase_definitions(self):
        source = record("editorial", (
            "Each cycle has two phases: "
            "Example: all observations are executed and Evaluator will finish its analysis. "
            "Rest: observations are finished, only Evaluator is writing results in Journal."),
            evidence_scope="shared", approved_uses_json="[]")
        model = srs_source_evidence_model(source)
        self.assertFalse(any(value.meaning.subject == "Each cycle" for value in model.propositions))
        self.assertTrue(model.unresolved_contexts)

    @unittest.skipUnless(shutil.which("pandoc"), "Existing DOCX converter is unavailable")
    def test_review_companion_remains_explicitly_nonauthoritative_in_markdown_and_word(self):
        from docx import Document
        from run_srs_gen_spec_agent import _write_descriptive_review_proposal

        root = Path(__file__).resolve().parents[1]
        evidence = context_evidence("VEGA5 is an atmospheric measurement device.")
        actual, review, proposals = self.compose(evidence)
        payload = {"snapshot_id": evidence["snapshot_id"], "authority": False,
                   "publication_eligible": False, "review_sections": review,
                   "current_sections": actual, "proposals": proposals}
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "proposals.json"
            path.write_text(json.dumps(payload), encoding="utf-8")
            markdown, word = _write_descriptive_review_proposal(path, Path(directory) / "reviews", None, root)
            notice = "REVIEW PROPOSAL - NOT AUTHORIZED - NOT PUBLICATION-ELIGIBLE"
            self.assertIn(notice, markdown.read_text(encoding="utf-8"))
            self.assertIn(evidence["snapshot_id"], markdown.read_text(encoding="utf-8"))
            document = Document(word)
            for section in document.sections:
                for header in (section.header, section.first_page_header, section.even_page_header):
                    self.assertIn(notice, header.paragraphs[0].text)
            self.assertTrue(any("atmospheric measurement device" in paragraph.text
                                for paragraph in document.paragraphs))
            payload["authority"] = True
            path.write_text(json.dumps(payload), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "non-authoritative"):
                _write_descriptive_review_proposal(path, Path(directory) / "reviews", None, root)


if __name__ == "__main__":
    unittest.main()
