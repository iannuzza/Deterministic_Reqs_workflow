import copy
import csv
import json
import tempfile
import unittest
from dataclasses import replace
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from csv_artifacts import csv_artifact_reader
from governed_descriptive_scope import project_shared_descriptive_uses, serialize_descriptive_destinations
from workflow_routing import (
    SRS_DESCRIPTIVE_PROFILE, compose_descriptive_paragraphs, descriptive_proposition_fact,
    shared_document_descriptive_contributions, srs_source_evidence_model, validate_descriptive_paragraphs,
)
from test_governed_descriptive_scope import record


class LocalStorageCompositionTests(unittest.TestCase):
    def test_downstream_ipos_input_uses_the_same_snapshot_inventory_as_publication(self):
        from validate_downstream_coherence import DownstreamContract
        from workflow_routing import build_ipos_functional_input, build_ipos_normalized_records

        inventory = {"Block": "Storage", "Function": "Buffer samples.", "Inputs": "samples",
                     "Outputs": "stored samples", "_synthesis_source": "snapshot architecture profile:binding:Storage"}
        contract = SimpleNamespace(
            snapshot_id="synthetic", expected={"REQ": {"owning_target": "Digital IPOS", "approved_block": "Storage"}},
            requirement_input=object(), descriptive_context=lambda *args, **kwargs: (),
            shared_descriptive_context=lambda *args, **kwargs: ())
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            with patch("generate_ipos_specs._block_inventory_record", return_value=inventory) as lookup, \
                    patch("validate_downstream_coherence._read_csv", return_value=([], [])), \
                    patch("validate_downstream_coherence.approved_snapshot_candidate_rows", return_value=[]), \
                    patch("ipos_blocker_review.apply_descriptive_omissions",
                          side_effect=lambda root, **kwargs: kwargs["functional_input"]):
                actual = DownstreamContract.ipos_descriptive_input(contract, root, block="storage", domain="digital")
            lookup.assert_called_once_with(root, "storage", snapshot_id="synthetic")
            self.assertEqual(actual.block, "Storage")
            expected = build_ipos_functional_input(
                "Storage", inventory, [], domain="digital", materialized=True,
                provenance=("approved snapshot:synthetic", inventory["_synthesis_source"]),
                candidate_requirement_rows=[], descriptive_source_records=(), shared_context_records=())
            self.assertEqual(build_ipos_normalized_records(actual), build_ipos_normalized_records(expected))

    def test_complete_large_provenance_cells_and_csv_limit_restoration(self):
        previous_limit = csv.field_size_limit()
        value = "complete source provenance; " * 7000
        self.assertGreater(len(value), 131072)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "audit.csv"
            with path.open("w", encoding="utf-8", newline="") as handle:
                writer = csv.writer(handle)
                writer.writerow(["provenance"])
                writer.writerow([value])
            with csv_artifact_reader(path) as reader:
                self.assertEqual(list(reader), [{"provenance": value}])
            self.assertEqual(csv.field_size_limit(), previous_limit)
            with self.assertRaisesRegex(ValueError, "fixture"):
                with csv_artifact_reader(path):
                    raise ValueError("fixture")
            self.assertEqual(csv.field_size_limit(), previous_limit)

    def source(self, name, single, multiple, count):
        return record("storage", (
            f"All the data are stored inside a {name} that can be configured as: "
            f"\u2022 {single}: Classic FIFO, the First Data that is written inside the Memory "
            f"is also the First that is read. \u2022 {multiple}: "
            f"The Queue is split up to {count} Sub-Queue (one for each Channels plus one for processing results). "
            "The depth of each Sub-Queue is configurable by control map. "
            "Each Sub-Queue behaves as a Classic FIFO."),
            evidence_scope="shared", approved_uses_json="[]")

    def test_storage_alternatives_quantities_and_order_are_composed(self):
        for name, single, multiple, count in (
                ("Sample Queue", "Single Queue", "Partitioned Queue", 3),
                ("Capture Queue", "Linear Storage", "Channel Storage", 11)):
            with self.subTest(name=name):
                source = self.source(name, single, multiple, count)
                original = copy.deepcopy(source)
                model = srs_source_evidence_model(source)
                self.assertEqual(len(model.propositions), 5)
                self.assertTrue(model.unresolved_contexts)
                use = {"use_id": "context", "document": "SRS", "block": "", "domain": "system",
                       "role": "context", "start": 0, "end": len(source["statement"]),
                       "excerpt": source["statement"], "rationale": "Synthetic reviewed use."}
                reviewed = dict(source, **serialize_descriptive_destinations(source, "shared", [use]))
                projected = project_shared_descriptive_uses(
                    [dict(reviewed, snapshot_id="synthetic", admission_state="admitted")], document="SRS")
                context_only = shared_document_descriptive_contributions(projected, document="SRS")
                self.assertFalse(context_only.get("3.4"))
                uses = [use, *(dict(use, use_id=role, role=role)
                               for role in ("functions", "operating_concept"))]
                reviewed = dict(source, **serialize_descriptive_destinations(source, "shared", uses))
                projected = project_shared_descriptive_uses(
                    [dict(reviewed, snapshot_id="synthetic", admission_state="admitted")], document="SRS")
                audit = []
                prose = " ".join(text for values in shared_document_descriptive_contributions(
                    projected, document="SRS", audit_rows=audit).values() for text in values)
                for expected in (single, multiple, "up to " + str(count), "configurable storage depth",
                                 "first-in first-out"):
                    self.assertIn(expected, prose)
                self.assertNotIn("control map", prose)
                self.assertNotIn("source-specified channel and result assignment", prose)
                self.assertIn(" or ", prose)
                contributions = shared_document_descriptive_contributions(projected, document="SRS")
                self.assertFalse(contributions.get("3.2"))
                self.assertIn(" or ", " ".join(contributions["3.5"]))
                self.assertFalse(shared_document_descriptive_contributions(
                    projected, document="SRS").get("3.4"))
                self.assertTrue(any(row["decision"] == "projection_gap" for row in audit))
                self.assertEqual(source, original)

    def test_unknown_guards_are_not_removed_to_match_storage_rule(self):
        source = self.source("Sample Queue", "Single Queue", "Partitioned Queue", 7)
        source["statement"] = source["statement"].replace("configurable by", "configurable only when unlocked by")
        model = srs_source_evidence_model(source)
        self.assertFalse(any(value.meaning.predicate == "provide"
                             and "first-in first-out storage" in value.meaning.objects
                             for value in model.propositions))
        self.assertTrue(model.unresolved_contexts)

    def test_storage_identity_and_embedded_conditions_are_not_discarded(self):
        original = self.source("Sample Queue", "Single Queue", "Partitioned Queue", 7)
        for old, new in (
                ("The Queue is split", "The Buffer is split"),
                ("one for each Channels", "only when enabled one for each Channels"),
                ("Partitioned Queue:", "Partitioned Queue unless locked:"),
                ("Single Queue:", "Single Queue after startup:"),
                ("one for each Channels", "one for each Channels without invalid data"),
                ("by control map", "by control map only if enabled")):
            with self.subTest(mutation=new):
                source = dict(original, statement=original["statement"].replace(old, new))
                self.assertNotEqual(source["statement"], original["statement"])
                model = srs_source_evidence_model(source)
                self.assertFalse(any(
                    value.meaning.predicate == "support" and value.meaning.coordination == "or"
                    for value in model.propositions))
                self.assertTrue(model.unresolved_contexts)

    def test_access_restriction_realizes_a_grammatical_sentence(self):
        source = record("access",
            "The DATA registers are accessible by LINK direct access and BUS interface, "
            "while the others are only by BUS.", evidence_scope="shared", approved_uses_json="[]")
        use = {"use_id": "access", "document": "SRS", "block": "", "domain": "system",
               "role": "context", "start": 0, "end": len(source["statement"]),
               "excerpt": source["statement"], "rationale": "Synthetic reviewed use."}
        reviewed = dict(source, **serialize_descriptive_destinations(source, "shared", [use]))
        projected = project_shared_descriptive_uses(
            [dict(reviewed, snapshot_id="synthetic", admission_state="admitted")], document="SRS")
        prose = " ".join(text for values in shared_document_descriptive_contributions(
            projected, document="SRS").values() for text in values)
        self.assertIn("The other registers are accessible only through the BUS interface.", prose)
        self.assertNotIn("The other registers is accessible", prose)

    def test_access_enablement_preserves_startup_order_and_clock_check(self):
        statement = (
            "To enable FABRIC Access, it needs using LINK direct access mode, for: "
            "\u2022 First turn-on the SUPPLY and the Oscillator "
            "(set EN_SUPPLY and EN_OSC of CONTROL, see address in the Table 4). "
            "\u2022 Check the Fast Clock(24MHz), is stable "
            "(when the Oscillator is stable, the READY bit in STATUS (0x10) register is set to 1).")
        source = record("enable", statement)
        model = srs_source_evidence_model(source)
        self.assertEqual(len(model.propositions), 1)
        meaning = model.propositions[0].meaning
        self.assertEqual(meaning.subject, "Enablement of the FABRIC interface")
        self.assertEqual(meaning.objects, ("LINK direct access",))
        self.assertEqual(meaning.qualifiers, (
            "to start SUPPLY and Oscillator and then check that the 24 MHz fast clock is stable",))
        fact = descriptive_proposition_fact(
            model.propositions[0], model, section=SRS_DESCRIPTIVE_PROFILE.topic_roles[0])
        paragraphs = compose_descriptive_paragraphs([fact], profile=SRS_DESCRIPTIVE_PROFILE)
        self.assertEqual(paragraphs[0].text,
            "Enablement of the FABRIC interface uses LINK direct access to start SUPPLY and Oscillator "
            "and then check that the 24 MHz fast clock is stable.")
        self.assertEqual(validate_descriptive_paragraphs(
            paragraphs, facts=[fact], profile=SRS_DESCRIPTIVE_PROFILE), [])
        reversed_fact = replace(fact, qualifiers=(
            "to check that the 24 MHz fast clock is stable and then start SUPPLY and Oscillator",))
        reversed_paragraphs = compose_descriptive_paragraphs([reversed_fact], profile=SRS_DESCRIPTIVE_PROFILE)
        self.assertTrue(any("descriptive_sequence_not_supported" in finding
            for finding in validate_descriptive_paragraphs(
                reversed_paragraphs, facts=[reversed_fact], profile=SRS_DESCRIPTIVE_PROFILE)))
        self.assertEqual(model.propositions[0].spans[0].text, statement)
        self.assertTrue(model.unresolved_contexts)
        joined = dict(source, statement="Programming example address=0x16 " + statement)
        joined_model = srs_source_evidence_model(joined)
        self.assertEqual([value.meaning for value in joined_model.propositions], [meaning])
        self.assertEqual(joined_model.propositions[0].spans[0].text, statement)
        multiword = dict(source, statement=statement.replace("Oscillator", "Fast-Ring Oscillator"))
        multiword_model = srs_source_evidence_model(multiword)
        self.assertEqual(len(multiword_model.propositions), 1)
        self.assertIn("SUPPLY and Fast-Ring Oscillator and then check",
                      multiword_model.propositions[0].meaning.qualifiers[0])
        for old, new in (
                ("is set to 1", "is set to 0"),
                ("First turn-on", "First optionally turn-on"),
                ("when the Oscillator is stable", "when the DifferentClock is stable"),
                ("is stable (when", "is stable only when unlocked (when")):
            with self.subTest(mutation=new):
                changed = dict(source, statement=statement.replace(old, new))
                self.assertFalse(any(value.meaning.subject == meaning.subject
                                     for value in srs_source_evidence_model(changed).propositions))

    def test_self_contained_mode_advice_is_not_promoted_to_a_requirement_or_setup(self):
        advice = ("Pay Attention: is strictly recommended to change the user_mode only when "
                  "the Device is in IDLE STATE (check DEVICE_STATUS_REGISTER in REGMAP).")
        source = record("advice", "Set user_mode at 1. " + advice)
        model = srs_source_evidence_model(source)
        self.assertEqual(len(model.propositions), 1)
        fact = descriptive_proposition_fact(
            model.propositions[0], model, section=SRS_DESCRIPTIVE_PROFILE.topic_roles[0])
        text = compose_descriptive_paragraphs([fact], profile=SRS_DESCRIPTIVE_PROFILE)[0].text
        self.assertEqual(text, "A change to the source-specified user mode is strongly recommended "
                               "only when the device is in the IDLE state.")
        self.assertNotIn("shall", text)
        self.assertNotIn("must", text)
        self.assertEqual(model.propositions[0].spans[0].text, advice)
        for changed in (
                advice.replace("strictly recommended", "required"),
                advice.replace("only when", "unless"),
                advice[:-1] + " except during reset."):
            with self.subTest(advice=changed):
                mutated = dict(source, statement="Set user_mode at 1. " + changed)
                self.assertFalse(any(value.meaning.subject == fact.subject
                                     for value in srs_source_evidence_model(mutated).propositions))

    def test_drs_writer_keeps_approved_structured_power_rows(self):
        import run_drs_gen_spec_agent as drs
        from spec_document_contract import DRS_TEMPLATE, load_drs_contract

        source = {"evidence_kind": "power_domain", "scope": "architecture", "domain": "power",
                  "source": "approved structured power-domain evidence",
                  "statement": "PD_SAMPLE: Included block(s): core. Domain type: Retention. "
                               "Control mode: firmware. \u2022 Function: Preserves state. "
                               "\u2022 Characteristics: Idle."}
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "digital.md"
            drs._write_drs_markdown(
                path, "primary.pdf", "Example", "Reviewer", "synthetic", "0.1",
                [], {}, [], {}, [], {}, [], {}, [], [source],
                [], "go", [], {}, set(), {}, [], [],
                load_drs_contract(Path(__file__).resolve().parents[1] / DRS_TEMPLATE))
            text = path.read_text(encoding="utf-8")
            self.assertIn("| Domain | Type | Control | Function |", text)
            self.assertIn("| PD_SAMPLE | Retention | firmware | Preserves state |", text)

    def test_verified_drs_overview_accepts_source_backed_recomposition_not_raw_paragraphs(self):
        from docx import Document
        from workflow_routing import (
            drs_overview_plan, verified_shared_descriptive_paragraphs, write_shared_descriptive_audit,
        )

        statement = (
            "UNIT is an integrated device. "
            "UNIT features an advanced digital engine, composed of multiple IPs able to reduce "
            "host workload, reducing bus congestion, providing metadata useful for final application, "
            "both in time and frequency domain. "
            "The ECG signal acquisition is designed to achieve low-noise measurements.")
        source = record("digital-overview", statement, evidence_scope="shared", domain="digital",
                        approved_uses_json="[]")
        use = {"use_id": "overview", "document": "DRS", "block": "", "domain": "digital",
               "role": "context", "start": 0, "end": len(statement),
               "excerpt": statement, "rationale": "Synthetic reviewed use."}
        reviewed = dict(source, **serialize_descriptive_destinations(source, "shared", [use]))
        projected = project_shared_descriptive_uses(
            [dict(reviewed, snapshot_id="synthetic", admission_state="admitted")], document="DRS")
        paragraphs, _ = drs_overview_plan({"shared_records": projected})
        self.assertTrue(paragraphs)
        self.assertNotIn("ECG", " ".join(paragraphs))
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path = root / "digital.md"
            path.write_text("## 3. Top Level Overview\n\n" + "\n\n".join(paragraphs), encoding="utf-8")
            document = Document()
            document.add_heading("3. Top Level Overview", 2)
            for paragraph in paragraphs:
                document.add_paragraph(paragraph)
            document.save(path.with_suffix(".docx"))
            write_shared_descriptive_audit(path, projected, document="DRS", snapshot_id="synthetic")
            contract = SimpleNamespace(shared_descriptive_context=lambda *args, **kwargs: projected)
            with patch("validate_downstream_coherence.resolve_downstream_contract", return_value=contract):
                verified, findings = verified_shared_descriptive_paragraphs(
                    root, path, document="DRS", snapshot_id="synthetic")
                self.assertEqual(findings, [])
                self.assertEqual(len(verified["3"]), len(paragraphs))
                path.write_text(path.read_text(encoding="utf-8").replace("host workload", "unrelated work"),
                                encoding="utf-8")
                self.assertTrue(verified_shared_descriptive_paragraphs(
                    root, path, document="DRS", snapshot_id="synthetic")[1])


if __name__ == "__main__":
    unittest.main()
