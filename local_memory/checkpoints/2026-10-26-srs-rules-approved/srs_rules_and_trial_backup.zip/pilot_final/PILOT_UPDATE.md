# Minimal SRS pilot update

Non-authoritative review proposal. Existing workflow rules, permissions and snapshot are unchanged.

- **3.1:** corrected 'embedded processing capabilities' and separated identity from macro-purpose.
- **3.3:** explained the conversion interface and complementary digital-domain responsibilities; did not invent an analog subsystem or new ownership.
- **3.4:** clarified serial directions from the approved interface records.
- **3.5:** corrected agreement, possessives and minor phrasing; preserved guards, alternatives and exceptions.
- **Unchanged:** all remaining prose, including section 3.2 and 'cent inputs'.

**Source ambiguities:** 'cent inputs' remains verbatim. 'Eventually' is retained because its temporal versus if-applicable sense is not resolved by the phase source. No new timing, optionality or transition is inferred. See [tracked ambiguities](review_ambiguities.json).

[Exact prose diff](pilot_update.diff). [Source-bound revision and unchanged decisions](descriptive_synthesis_proposals.json).
