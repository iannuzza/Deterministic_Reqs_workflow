# SRS descriptive synthesis review proposal

REVIEW PROPOSAL - NOT AUTHORIZED - NOT PUBLICATION-ELIGIBLE

Source snapshot: `snap-8b3673edc9cf590589b8ab39`.

This is not an authorized snapshot projection or a publication-eligible SRS. It demonstrates proposed semantic placement only. Existing source and destination decisions remain unchanged; any pending use requires the existing authoritative descriptive review and snapshot process.

### 3.1 General System Description

STBIO1 is an Analog Front End Device with embedded processing capabilities. STBIO1 collects and processes ECG, PPG, BIA and GSR as Vital Signals.

### 3.2 Main System Capabilities


#### **Signal acquisition**

The device supports sensor-path sensing and conversion of configured bio/optical channel inputs to samples.

#### **Digital sample control**

The device supports sample-rate control, data update policy and digital status handling.

#### **FIFO and interrupt signaling**

The device supports FIFO buffering modes, watermark/overrun detection and interrupt notification.

#### **Host communication over SPI**

The device supports host configuration and readback over SPI.

#### **Host communication over I2C**

The device supports host configuration and readback over I2C.

#### **Power, clock, and startup behavior**

The device supports power-domain supervision, low-power transitions and readiness control.

#### **Self-test and calibration**

The device supports self-test enable, sensitivity/offset handling and status reporting.

#### **PPG**

The optical channel (PPG) supports optical transceiver operation with stimulation of up to eight LEDs and measurement of the return signal on up to six separate cent inputs, rejects signal offsets and corruption from asynchronous modulated interference, typically from ambient light and eliminates the need for optical filters or externally controlled dc cancellation circuitry.

#### **ECG**

The ECG signal acquisition supports low noise, diagnostic level measurement in the presence of a variety of interferers. The ECG signal chain provides driven reference for common-mode rejection and lead off detection to identify a fallen electrode for ECG measurement.

#### **BIA**

The BIA signal chain supports body impedance and human breathing measurements with a configurable excitation path and measurement path. BIA channel provides the real and the imaginary parts of the body and the breathing impedance.

#### **Digital engine**

Within STBIO1, the digital engine can reduce external host processing workload through multiple IPs, reduce bus congestion and provide meta-data for final application in both time and frequency domains.

#### **System**

The system can acquire external sensor measurements through I2C master protocol with data collection and embedded processing of external measurements.

#### **GSR**

The device supports GSR measurement acquisition with raw sample storage in Data Storage Mode under the conditions described in section 3.5.

### 3.3 Main Architectural Domains and Subsystems

The conversion interface turns configured bio/optical channel inputs into samples. The digital domain contributes the complementary control and data-handling responsibilities: sampling control, data-update policy and digital status handling, buffering and interrupt notification, and host configuration and readback. Its mapped responsibilities also include power/startup supervision and self-test/calibration support.

### 3.4 External Interfaces and System Boundaries


| Boundary role | Direction | Medium |
|---|---|---|
| Sensing input | input | analog |
| Measurement data exchange | output | digital |
| Serial communication | Clock/select: input; SPI data: input/output; I2C data: bidirectional | digital |
| Interrupt reporting | output | digital |
| Power supply | input | power |

### 3.5 Operating Concept


#### **The Smart FIFO**

For storage configuration, the Smart FIFO can support Unique FIFO or Multiple Fifo.

#### **Unique FIFO**

In Unique FIFO, the Smart FIFO provides first-in first-out storage.

#### **Multiple Fifo**

In Multiple Fifo, the Smart FIFO supports up to 6 Sub-FIFO partitions; each Sub-FIFO supports configurable storage depth and provides first-in first-out storage.

#### **Phases of each time slot**

Each time slot has two phases: Operative and Sleep. During the Operative phase of each time slot, all user-configured measurements are executed; ADSP and/or ISPU eventually run their algorithms. During the Sleep phase of each time slot, measurements are finished; eventually, only ADSP and/or ISPU are terminating their algorithms and writing elaborated data in FIFO.

#### **Data Storage Mode**

In Data Storage Mode, with the configuration specified for Data Storage Mode applied, the system supports measurement acquisition with sample storage in FIFO, acquires ECG and BIA measurements from ADC, averages the samples, stores the samples in FIFO, acquires GSR measurements from ADC, stores the raw samples in FIFO, acquires PPG measurements from ADC, averages the samples according to the user's configuration and stores the samples in FIFO; raw data are always available in FIFO after storage, except when FIFO FULL occurs.

#### **Normal Mode**

In Normal Mode, ISPU can be enabled for processing raw data, data processed by ADSP, or both.

