"""Apply the requested, source-bound editorial pass to a separate review projection."""
import copy
import difflib
import hashlib
import json
import sys
from pathlib import Path

from docx import Document

ROOT = Path(r"C:\Users\iannuzza\LOCAL_PROJ\Github_copilot_proj\review_srs_20261026_1437")
REVIEW = ROOT / "artifacts" / "reviews" / "system_requirements_specification"
OUT = REVIEW / "pilot_final"
EVIDENCE = Path(__file__).parent / "srs_pilot_final_20261026"
SOURCE = ROOT / "artifacts" / "stage3_srs" / "descriptive_synthesis_proposals.json"
SNAPSHOT = "snap-8b3673edc9cf590589b8ab39"
FINGERPRINT = "0b9f2b67360f480031d7482de1776326f602608327b2b5c17d1c84c074a0656d"
sys.path.insert(0, str(ROOT / "scripts"))

from run_srs_gen_spec_agent import _write_descriptive_review_proposal
from spec_document_contract import descriptive_section_paragraphs, load_descriptive_synthesis_contract
from validate_downstream_coherence import resolve_downstream_contract


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=True) + "\n", encoding="utf-8")


if OUT.exists() or EVIDENCE.exists():
    raise FileExistsError("Refusing to overwrite an existing final pilot revision")
protected = [
    *sorted((ROOT / "scripts").glob("*.py")),
    *sorted((ROOT / "templates").glob("*")),
    *sorted((ROOT / "config").glob("*.json")),
    ROOT / "data" / "canonical" / "canonical_store.sqlite",
    ROOT / "artifacts" / "stage3_srs" / "system_requirements_specification.md",
    ROOT / "artifacts" / "stage3_srs" / "system_requirements_specification.docx",
    SOURCE,
    REVIEW / "descriptive_synthesis_review_proposal.md",
    REVIEW / "descriptive_synthesis_review_proposal.docx",
]
protected = [path for path in protected if path.is_file()]
before_hashes = {str(path): sha(path) for path in protected}
evidence = resolve_downstream_contract(ROOT, SNAPSHOT).synthesis_evidence(ROOT, document="SRS")
assert evidence["snapshot_id"] == SNAPSHOT and evidence["architecture_fingerprint"] == FINGERPRINT
original = json.loads(SOURCE.read_text(encoding="utf-8"))
assert original["snapshot_id"] == SNAPSHOT and original["authority"] is False
assert original["publication_eligible"] is False and original["authorization_changed"] is False
revision = copy.deepcopy(original)
sections = revision["review_sections"]
headings = {key.split(" ", 1)[0]: key for key in sections}
changes = []


def amend(number, before, after, rationale):
    paragraphs = sections[headings[number]]
    assert sum(value.count(before) for value in paragraphs) == 1, (number, before)
    sections[headings[number]] = [value.replace(before, after) for value in paragraphs]
    changes.append({"section": number, "before": before, "after": after, "rationale": rationale})


inventory = {row["owner"]: row for row in evidence["inventory"]}
conversion = inventory["ADC"]
assert conversion["entity_kind"] == "interface" and conversion["scope"] == "approved_function_boundary"
assert conversion["statement"].startswith("Convert configured bio/optical channel inputs to samples")
mappings = {row["top_function"]: row for row in evidence["function_decomposition"]}
assert "sample-rate control; data update policy; digital status handling" == mappings["Digital sample control"]["subfunctions"]
assert "FIFO buffering modes; watermark/overrun detection; INT1/INT2 signaling" == mappings["FIFO and interrupt signaling"]["subfunctions"]
assert inventory["I2C_SPI_AHB"]["domains"] == ["digital"]
assert "device configuration and readback" in inventory["I2C_SPI_AHB"]["statement"]
assert "power-domain supervision; low-power transitions; readiness control" == mappings["Power, clock, and startup behavior"]["subfunctions"]
assert "self-test enable; sensitivity/offset handling; status reporting" == mappings["Self-test and calibration"]["subfunctions"]
domain_sources = {
    "conversion_boundary": conversion,
    "functional_mappings": list(mappings.values()),
    "classified_digital_owners": [row for row in evidence["inventory"] if row.get("domains") == ["digital"]],
}

identity = original["review_sections"][headings["3.1"]][0]
subject = identity.split(" is ", 1)[0]
assert "embedded process capabilities and collects and processes" in identity
purpose_after = identity.replace(
    "embedded process capabilities and collects and processes",
    "embedded processing capabilities. " + subject + " collects and processes")
amend("3.1", identity, purpose_after,
      "Correct the nominal form and separate identity from macro-purpose without changing actor or scope.")

organization = original["review_sections"][headings["3.3"]][0]
organization_after = (
    "The conversion interface turns configured bio/optical channel inputs into samples. "
    "The digital domain contributes the complementary control and data-handling responsibilities: "
    "sampling control, data-update policy and digital status handling, buffering and interrupt notification, "
    "and host configuration and readback. Its mapped responsibilities also include "
    "power/startup supervision and self-test/calibration support.")
amend("3.3", organization, organization_after,
      "Explain complementary conversion-boundary and classified-domain responsibilities; do not assert an unclassified analog subsystem or new ownership.")

serial_sources = [row for row in evidence["interfaces"] if row["Interface"] in {
    "SERIAL_CLK", "SERIAL_SELECT", "SERIAL_DATA_IN", "SERIAL_DATA_OUT",
    "ALT_SERIAL_CLK", "ALT_SERIAL_DATA"}]
expected_serial = {
    "SERIAL_CLK": ("SPI interface", "input"), "SERIAL_SELECT": ("SPI interface", "input"),
    "SERIAL_DATA_IN": ("SPI interface", "input"), "SERIAL_DATA_OUT": ("SPI interface", "output"),
    "ALT_SERIAL_CLK": ("I2C interface", "input"), "ALT_SERIAL_DATA": ("I2C interface", "bidirectional"),
}
assert {row["Interface"]: (row["Owner"], row["Direction"]) for row in serial_sources} == expected_serial
amend("3.4",
      "| Serial communication | input, bidirectional, output | digital |",
      "| Serial communication | Clock/select: input; SPI data: input/output; I2C data: bidirectional | digital |",
      "Disambiguate the aggregate direction using the six explicitly owned serial-interface records.")

phase_sources = [row for row in evidence["source_records"] if row["record_id"] ==
                 "source-context-29511800076164b7e880592b"]
assert len(phase_sources) == 1
phase_source = phase_sources[0]
assert "ADSP and/or ISPU eventually runs its algorithms" in phase_source["statement"]
assert "eventually only ADSP and/or ISPU is terminating its algorithms" in phase_source["statement"]
phase_before = next(value for value in sections[headings["3.5"]] if value.startswith("Each time slot"))
phase_after = (
    "Each time slot has two phases: Operative and Sleep. "
    "During the Operative phase of each time slot, all user-configured measurements are executed; "
    "ADSP and/or ISPU eventually run their algorithms. "
    "During the Sleep phase of each time slot, measurements are finished; "
    "eventually, only ADSP and/or ISPU are terminating their algorithms and writing elaborated data in FIFO.")
amend("3.5", phase_before, phase_after,
      "Correct possessive agreement and phrasing. Retain the ambiguous source adverb, both phases, actors, and/or, exclusivity and storage activity.")
amend("3.5", "partitions; Each Sub-FIFO", "partitions; each Sub-FIFO",
      "Lowercase the continuation after the semicolon.")
amend("3.5", "; Raw data are always available", "; raw data are always available",
      "Lowercase the continuation; preserve always, after-storage dependency and FIFO-full exception.")
amend("3.5", "raw data, ADSP elaborated Data, or both", "raw data, data processed by ADSP, or both",
      "Clarify the data modifier; preserve optional enablement and raw/processed/both alternatives.")

cent_sources = []
for row in evidence["source_records"]:
    start = row["statement"].find("cent inputs")
    if start >= 0:
        cent_sources.append({"record_id": row["record_id"], "content_sha256": row["content_sha256"],
                             "start": start, "end": start + len("cent inputs"),
                             "excerpt": row["statement"][start:start + len("cent inputs")]})
assert cent_sources
ambiguities = [
    {"term": "cent inputs", "disposition": "UNCHANGED_IN_PROSE",
     "reason": "Source wording is unclear; no substitution or interpretation is asserted.",
     "sources": cent_sources},
    {"term": "eventually", "disposition": "RETAINED_WITHOUT_SEMANTIC_EXPANSION",
     "reason": "The phase source does not resolve temporal versus if-applicable usage. "
               "Do not replace it with optionality, a delay, a completion guarantee or an inferred transition.",
     "sources": [phase_source]},
]
revision["pilot_editorial_revision"] = {
    "authority": False, "publication_eligible": False, "review_status": "USER_REVIEW_PENDING",
    "workflow_rules_changed": False, "existing_decisions_changed": False,
    "scope": "Minimal source-bound review presentation only; original semantic proposals retained as provenance.",
    "changes": changes, "domain_sources": domain_sources, "serial_sources": serial_sources,
    "ambiguities": ambiguities,
}
assert revision["proposals"] == original["proposals"]
assert revision["existing_permissions"] == original["existing_permissions"]
assert revision["current_sections"] == original["current_sections"]
assert sections[headings["3.2"]] == original["review_sections"][headings["3.2"]]

OUT.mkdir(parents=True)
EVIDENCE.mkdir()
proposal_path = OUT / "descriptive_synthesis_proposals.json"
write_json(proposal_path, revision)
markdown, word = _write_descriptive_review_proposal(
    proposal_path, OUT, ROOT / "templates" / "MPT_IPOS_template.docx", ROOT)
old_markdown = REVIEW / markdown.name
old_text = old_markdown.read_text(encoding="utf-8")
expected_text = old_text
for change in changes:
    assert expected_text.count(change["before"]) == 1
    expected_text = expected_text.replace(change["before"], change["after"])
assert markdown.read_text(encoding="utf-8") == expected_text, "Unexpected remaining-prose change"
assert expected_text.count("cent inputs") == old_text.count("cent inputs")
policy = load_descriptive_synthesis_contract("SRS", ROOT)
md_sections = descriptive_section_paragraphs(markdown, policy)
word_sections = descriptive_section_paragraphs(word, policy)
normalize = lambda value: value.replace("\u2019", "'").replace("\u2018", "'")
assert {key: list(map(normalize, values)) for key, values in md_sections.items()} == {
    key: list(map(normalize, values)) for key, values in word_sections.items()}
old_word_sections = descriptive_section_paragraphs(REVIEW / word.name, policy)
assert word_sections["3.2"] == old_word_sections["3.2"]
word_document = Document(word)
serial_rows = [row for table in word_document.tables for row in table.rows
               if row.cells[0].text == "Serial communication"]
assert len(serial_rows) == 1
assert serial_rows[0].cells[1].text == "Clock/select: input; SPI data: input/output; I2C data: bidirectional"
operation = " ".join(word_sections["3.5"])
for qualification in ("and/or", "only ADSP", "eventually", "up to 6", "except when FIFO FULL occurs",
                      "after storage", "always available", "according to the user",
                      "with the configuration specified", "ISPU can be enabled", "or both"):
    assert qualification in operation, qualification
for section in word_document.sections:
    assert "NOT PUBLICATION-ELIGIBLE" in section.header.paragraphs[0].text
after_hashes = {str(path): sha(path) for path in protected}
assert before_hashes == after_hashes, "Protected workflow/source/previous review changed"
write_json(OUT / "review_ambiguities.json", ambiguities)
diff = "".join(difflib.unified_diff(old_text.splitlines(keepends=True),
                                  expected_text.splitlines(keepends=True),
                                  fromfile="previous-review-proposal.md", tofile="pilot-final-review-proposal.md"))
(OUT / "pilot_update.diff").write_text(diff, encoding="utf-8")
write_json(EVIDENCE / "verification.json", {
    "snapshot_id": SNAPSHOT, "architecture_fingerprint": FINGERPRINT,
    "status": "PASS", "authority": False, "publication_eligible": False,
    "unchanged_remaining_prose": True, "markdown_word_parity": True,
    "section_3_2_unchanged_in_word": True, "cent_inputs_unchanged": True,
    "essential_conditions_alternatives_exceptions_preserved": True,
    "protected_files_unchanged": before_hashes,
    "output_hashes": {str(path): sha(path) for path in (proposal_path, markdown, word)},
    "source_bound_changes": changes,
})
(OUT / "PILOT_UPDATE.md").write_text(
    "# Minimal SRS pilot update\n\n"
    "Non-authoritative review proposal. Existing workflow rules, permissions and snapshot are unchanged.\n\n"
    "- **3.1:** corrected 'embedded processing capabilities' and separated identity from macro-purpose.\n"
    "- **3.3:** explained the conversion interface and complementary digital-domain responsibilities; "
    "did not invent an analog subsystem or new ownership.\n"
    "- **3.4:** clarified serial directions from the approved interface records.\n"
    "- **3.5:** corrected agreement, possessives and minor phrasing; preserved guards, alternatives and exceptions.\n"
    "- **Unchanged:** all remaining prose, including section 3.2 and 'cent inputs'.\n\n"
    "**Source ambiguities:** 'cent inputs' remains verbatim. 'Eventually' is retained because its temporal "
    "versus if-applicable sense is not resolved by the phase source. No new timing, optionality or "
    "transition is inferred. See [tracked ambiguities](review_ambiguities.json).\n\n"
    "[Exact prose diff](pilot_update.diff). [Source-bound revision and unchanged decisions]"
    "(descriptive_synthesis_proposals.json).\n", encoding="utf-8")
print("Final pilot review:", OUT)
print("Validation: PASS; protected files unchanged:", len(protected))
print("Exact replacements:", len(changes))
print("Workflow rules/permissions/snapshot: unchanged")
