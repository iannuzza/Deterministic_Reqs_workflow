"""Save the approved rule baseline without deploying trial runtime or source authority."""
import hashlib
import json
import subprocess
import sys
import zipfile
from pathlib import Path

FILES = Path(__file__).parent
SESSION = FILES.parent
OFFICIAL = Path(r"C:\Users\iannuzza\LOCAL_PROJ\Github_copilot_proj\Deterministic_Reqs_workflow")
TRIAL = OFFICIAL.parent / "review_srs_20261026_1437"
NAME = "2026-10-26-srs-rules-approved"
OUT = OFFICIAL / "local_memory" / "checkpoints" / NAME
RECEIPTS = FILES / "srs_rules_approval_20261026"
TAG = "srs-rules-baseline-2026-10-26"


def sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def git(*args):
    return subprocess.check_output(["git", "--no-pager", "-C", str(OFFICIAL), *args]).decode().strip()


metadata = [OFFICIAL / ".github" / "copilot-instructions.md",
            *(OFFICIAL / "local_memory" / name for name in
              ("chat_handoff.md", "checkpoint.md", "project_activity_log.md"))]
if sys.argv[1] == "prepare":
    if OUT.exists() or RECEIPTS.exists():
        raise FileExistsError("Refusing to replace an existing checkpoint")
    OUT.mkdir()
    RECEIPTS.mkdir()
    paths = [*sorted((OFFICIAL / "scripts").rglob("*.py")),
             *sorted((OFFICIAL / "templates").rglob("*")),
             *sorted((OFFICIAL / "config").rglob("*")),
             OFFICIAL / "data" / "canonical" / "canonical_store.sqlite"]
    tracked = subprocess.check_output(
        ["git", "--no-pager", "-C", str(OFFICIAL), "ls-files", "-z", "--", "*.xlsx"]).decode().split("\0")
    paths.extend(OFFICIAL / path.replace("/", "\\") for path in tracked if path)
    paths = sorted({path for path in paths if path.is_file() and "__pycache__" not in path.parts})
    save(RECEIPTS / "protected_before.json", {str(path.relative_to(OFFICIAL)): sha(path) for path in paths})
    save(RECEIPTS / "scope.json", {
        "checkpoint": NAME, "official_root": str(OFFICIAL), "trial_root": str(TRIAL),
        "git_head": git("rev-parse", "HEAD"), "suggested_tag": TAG, "tag_created": False,
        "approval": "User approved SRS rules as valid for the main official workflow.",
        "save_scope": "Official general rules and memory/checkpoint metadata only; no runtime deployment.",
    })
    with zipfile.ZipFile(OUT / "before_metadata.zip", "w", zipfile.ZIP_DEFLATED) as archive:
        for path in metadata:
            archive.write(path, str(path.relative_to(OFFICIAL)))
    print("Prepared checkpoint:", OUT)
    print("Protected official runtime/template/config/authority files:", len(paths))
elif sys.argv[1] == "finish":
    scope = json.loads((RECEIPTS / "scope.json").read_text())
    before = json.loads((RECEIPTS / "protected_before.json").read_text())
    changed = [name for name, digest in before.items()
               if not (OFFICIAL / name).is_file() or sha(OFFICIAL / name) != digest]
    assert not changed, changed
    assert git("rev-parse", "HEAD") == scope["git_head"], "Git HEAD changed"
    check = subprocess.run(
        ["git", "--no-pager", "-C", str(OFFICIAL), "diff", "--check", "--",
         *(str(path.relative_to(OFFICIAL)) for path in metadata)], capture_output=True, text=True)
    assert check.returncode == 0, check.stdout + check.stderr
    members = []
    for folder in ("scripts", "tests"):
        members.extend((path, "trial/" + path.relative_to(TRIAL).as_posix())
                       for path in sorted((TRIAL / folder).rglob("*.py")) if "__pycache__" not in path.parts)
    for relative in (r"docs\srs-descriptive-process.md", r"templates\SRS_gen_AI_template_prompt.md"):
        members.append((TRIAL / relative, "trial/" + Path(relative).as_posix()))
    final = TRIAL / "artifacts" / "reviews" / "system_requirements_specification" / "pilot_final"
    members.extend((path, "pilot_final/" + path.name) for path in sorted(final.iterdir()) if path.is_file())
    members.extend((path, "official_metadata/" + path.relative_to(OFFICIAL).as_posix()) for path in metadata)
    members.append((OUT / "README.md", "checkpoint/README.md"))
    for relative in (
        r"srs_semantic_placement_20261026\review_manifest.json",
        r"srs_semantic_placement_20261026\product_changes.patch",
        r"srs_semantic_placement_20261026\authorized_sections.diff",
        r"srs_semantic_placement_20261026\proposed_sections.diff",
        r"srs_semantic_placement_20261026\generated_preservation.json",
        r"srs_semantic_placement_20261026\snapshot_and_permissions.json",
        r"srs_semantic_placement_20261026\regressions_verified.log",
        r"srs_semantic_placement_20261026\derived_refresh_changes.json",
        r"srs_pilot_final_20261026\verification.json",
        r"srs_pilot_final_20261026\restart_handoff.md",
        "chat_handoff.md", "local_memory.md", "finish_srs_pilot_review.py",
        "save_srs_approval_checkpoint.py",
    ):
        path = FILES / relative
        members.append((path, "session_evidence/" + Path(relative).as_posix()))
    archive_path = OUT / "srs_rules_and_trial_backup.zip"
    entries = []
    with zipfile.ZipFile(archive_path, "w", zipfile.ZIP_DEFLATED) as archive:
        for path, name in members:
            assert path.is_file(), path
            content = path.read_bytes()
            archive.writestr(name, content)
            entries.append({"member": name, "bytes": len(content),
                            "sha256": hashlib.sha256(content).hexdigest()})
    with zipfile.ZipFile(archive_path) as archive:
        assert archive.testzip() is None
        assert len(archive.namelist()) == len(set(archive.namelist())) == len(entries)
        for entry in entries:
            assert hashlib.sha256(archive.read(entry["member"])).hexdigest() == entry["sha256"]
    receipt = {
        **scope, "status": "APPROVED_SRS_RULES_SAVED_LOCAL_CHECKPOINT_VERIFIED",
        "rule_file": ".github/copilot-instructions.md", "rule_sha256": sha(metadata[0]),
        "official_runtime_imported": False, "official_documents_overwritten": False,
        "canonical_approvals_or_snapshot_changed": False, "publication_eligibility_changed": False,
        "git_commit_created": False, "tag_created": False, "git_push_performed": False,
        "protected_official_files_unchanged": len(before),
        "archive": archive_path.name, "archive_sha256": sha(archive_path),
        "before_metadata_archive_sha256": sha(OUT / "before_metadata.zip"),
        "archive_integrity": "PASS", "entries": entries,
        "scope_limit": "Source/evidence checkpoint, not a full repository or canonical database restore.",
    }
    save(OUT / "checkpoint_manifest.json", receipt)
    save(RECEIPTS / "save_receipt.json", receipt)
    print("Checkpoint verified:", OUT)
    print("Archive entries:", len(entries))
    print("Protected official files unchanged:", len(before))
    print("General-rule approval saved; runtime import/commit/tag/push NOT performed.")
else:
    raise ValueError("Use prepare or finish")
