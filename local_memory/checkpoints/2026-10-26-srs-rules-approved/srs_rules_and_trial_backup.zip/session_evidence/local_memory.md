# Local persistent memory - updated 2026-10-26

## SRS RULES APPROVED - 2026-10-26

User approval for main-workflow SRS rules is recorded in official general
instructions and checkpoint `2026-10-26-srs-rules-approved`.
Use [focused restart handoff](srs_pilot_final_20261026/restart_handoff.md) or session
[checkpoint 013](../checkpoints/013-freezing-approved-srs-rules.md).
Rule approval does not approve pending source uses or imply a snapshot freeze,
publication readiness or completed official runtime deployment. This save changes
only rules and memory/checkpoint metadata; existing official runtime/data remain
protected. Proposed tag `srs-rules-baseline-2026-10-26` is NOT created.
Next focused priorities: DRS/Main Controller or separately requested runtime import.
Prefer one bounded promising trial, targeted checks and short diffs. Use isolated
copies/worktrees for parallel implementation, not shared runtime/database artifacts.

## Final minimal pilot pass COMPLETE

The requested small review-only refinement is verified. Latest outputs are in
`review_srs_20261026_1437\artifacts\reviews\system_requirements_specification\pilot_final`.
Existing workflow rules remain valid and unchanged; the final editorial amendment
does not change scripts, approvals, permissions, snapshots or official files.
All remaining prose and "cent inputs" preserved; "eventually" ambiguity tracked
without inventing timing or optionality. 159 protected-file hashes unchanged;
actual Word/Markdown parity and one focused renderer regression pass.
Use [focused restart handoff](srs_pilot_final_20261026/restart_handoff.md) for a
new chat to avoid reloading the large history. Await user review of the final pilot.
Parallel implementation requires separate copies/worktrees, not merely windows.

## Latest SRS trial - supersedes the previous full-flow state below

New isolated workspace: `review_srs_20261026_1437`. Official and previously
reviewed workspaces must remain untouched. See the active top section of
[chat_handoff.md](chat_handoff.md) for exact paths and pending packaging work.

- Central, project-agnostic semantic placement/composition implemented.
- 203 targeted tests PASS; 44 actual Markdown/Word prose checks PASS.
- Authorized generation retains pending-permission gaps. Filled 3.1/3.5 exist
  in the explicitly nonauthoritative review companion, outside publication inputs.
- Preserved 36 source decisions/uses, fixed snapshot/fingerprint, normative
  Markdown, 90 normative Word paragraphs, SRS 3.6 and traceability.
- Full independent assessment is still UNRESOLVED (335 findings), despite
  nonduplication PASS. Do not confuse bounded test success with whole-SRS closure.
- Final package VERIFIED (`srs-final-package`, exit 0). Protected 34,260 reviewed
  and 34,144 official files unchanged. Canonical-table comparison verifies only
  normal generation timestamps changed on 357 allocations; semantics/approvals
  unchanged. Derived materialization source path is rebased locally; no workbook
  changed. Exact exceptions are documented in the review package.
- User knows the new Word proposal path; their tagged old SRS is not the new one.
- Latest user asks to close this iteration and await their slight SRS refinements
  before acceptance. Freeze here; do not begin DRS/Main Controller IPOS yet.
  They remain the subsequent priorities. No acceptance, official rollout,
  authoritative approvals or snapshot freeze authorized.

## Current state (historical pause below is superseded)

The user resumed and authorized stages 3-6 plus SysML in local review copy:
`C:\Users\iannuzza\LOCAL_PROJ\Github_copilot_proj\review_flow_20261026`.
No official import authorized/performed. See the current
[chat_handoff.md](chat_handoff.md) and verified
[review manifest](full_flow_20261026/review_manifest.json).

- Local execution finished, but whole-hierarchy meaning recovery is NOT_CLOSED.
- SRS/ARS gates remain blocked by SRS 3.1/3.5/power; SRS 3.6 is read-only.
- DRS has missing ISPU function; frozen approved function is an XBAR caption.
  Its failed generator leaves a stale contract stamp, correctly rejected.
- Eight Digital IPOS and Stage 6 gate pass.
- Eleven SysML models generated; structural review and real parser pass:
  zero errors/warnings, 2,049 hints. All exact final bytes remain validated.
- Final ordinary SysML phase exits 1 for five genuine central findings;
  publication BLOCKED, eleven models NOT_READY. 205 relation candidates remain
  unresolved/conflicting/outside scope; no complete-connectivity claim.
- 195 semantic tests and nine SysML/cache tests pass. Extended suites retain
  reproduced baseline failures; never claim a globally green test baseline.
- Final run: 129 Python scripts unchanged during execution.
- Official protection: all 34,144 recorded files unchanged, none missing.
  SRS normative Markdown/Word and section 3.6 preserved exactly.
- Fifteen local product files changed; 33 generated review deliverables indexed.
  New bounded content-keyed YAML parse cache returns independent deep copies,
  detects same-mtime/size edits, retains strict errors and missing-file failures.
- Earlier interrupted/instrumented trials are retained as failures, not PASS.
  Use `sysml_syntax_correction\phase_3` for the final ordinary run.

Actual overview readback is in
[hierarchy_actual_readback.json](full_flow_20261026/hierarchy_actual_readback.json).
Regmap five-paragraph and FIFO three-paragraph previews are nonauthoritative.
Residuals: ARS reference-only overview, Regmap publication gap, incongruous
frozen Sensor-Hub I/O, PAD MUX missing reserved-test qualifier, malformed source
endpoints and Main Controller fragments. Confirmed parse bug puts `will` inside
subject `All measurements will`, then emits `is performed`; source is explicitly
about examples. Do not globally admit editorial future clauses or invent a
universal measurement-mode claim. Discuss these remaining rules in chat.

User will review before any official import. No repetitive Excel approvals,
source/permission promotion, inactive profile activation, invented allocations
or power extension. Do not mark all 35 meanings complete or equate a green gate
with faithful whole-meaning prose.

## Historical memory - 2026-10-23 (superseded)

Paused at user's request until Monday. Current authoritative resume reference:
[chat_handoff.md](chat_handoff.md).

## Preferences and decisions

- Automated workflow should extract/consolidate descriptive meanings and present
  detailed consolidated decisions in chat, not require repetitive Excel approvals.
- Ownership and permission to reuse a meaning are separate.
- Implementation syntax inside a source must not cause loss of supported behavior.
- Where rules or composer block supported meaning, diagnose and discuss the
  restriction; no success-shaped fallback or unsupported interpretation.
- User approved five reusable corrections, with isolated verification only.
- Whole hierarchy analysis allowed; new official generations, permission
  promotion, ingestion/snapshot changes and inactive profile activation are not.
- Power/SRS 3.6 read-only.

## Verified current state

143 focused tests green; extended 212 has only seven reproduced baseline
failures. Actual fixed-snapshot isolated SRS runs exit 0. Implementation-word
false positive resolved without prose change. 3.1/3.5 remain empty; power
explanation remains missing; Stage 3 not accepted.

Source coverage analyzed: 36 approved descriptive records, 35 meaning groups.
Eight allocated Digital IPOS; no new IPOS or analog allocations invented.
Technical authority and official outputs unchanged. Only GUI geometry differs
from the original 5,313-path protection baseline.

## Remaining semantic gaps

Regmap mixed source admitted semantic-only but zero rendered paragraphs; Smart
FIFO configurations and remaining meaning groups still need full actual-prose
coverage verification. Never claim admission or matrix population as synthesis.

## Current production files touched by latest correction

- `scripts\governed_descriptive_scope.py`
- `scripts\descriptive_review_proposals.py`
- `scripts\workflow_routing.py`
- `scripts\validate_downstream_coherence.py`
- `scripts\spec_document_contract.py`
- `scripts\workflow_gui.py`
- `tests\test_hierarchy_rule_corrections.py` (six tests)
- `docs\srs-descriptive-process.md`

Prior SRS/template/process changes remain in place; preserve dirty worktree.
Latest evidence: [hierarchy_review/CORRECTION_RESULTS.md](hierarchy_review/CORRECTION_RESULTS.md).
